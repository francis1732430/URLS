import {
  html,
  LitElement,
  css,
  font14BoldMixin,
  orange,
  font24BoldMixin,
  font19BoldMixin,
  IngButton,
  ScopedElementsMixin,
} from 'ing-web';

export class TransprencyToolAcess extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
    };
  }

  static get properties() {
    return {
      routerData: { type: Object },
    };
  }

  static get styles() {
    return css`
      .content_body_area {
        margin: 0px auto;
        height: 326px;
        width: 61%;
        border-radius: 4px;
        background-color: rgb(255, 255, 255);
        box-shadow: rgb(0 0 0 / 14%) 0px 2px 2px 0px, rgb(0 0 0 / 12%) 0px 3px 1px -2px,
          rgb(0 0 0 / 20%) 0px 1px 5px 0px;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 6px;
        position: relative;
        flex-direction: column;
      }

      .access-button::before {
        margin: 0 0 0 0;
        min-height: 36px;
        width: 190px;
      }

      .access-button {
        min-width: 190px;
        height: 36px;
        ${font14BoldMixin()}
      }
      .label-text {
        color: ${orange};
        font-size: ${font24BoldMixin()};
        text-align: center;
        margin-bottom: 22px;
        font-family: 'ING Me';
      }

      @media only screen and (max-width: 750px) {
        .content_body_area {
          width: 60%;
        }
      }

      @media only screen and (max-width: 350px) {
        .content_body_area {
          width: 70%;
        }

        .label-text {
          font-size: ${font19BoldMixin()};
        }

        .access-button {
          min-width: 150px;
        }
      }
    `;
  }

  updated() {
    // eslint-disable-next-line
    console.log('routerData', this.routerData);
  }

  goToTransparencyTool(ev) {
    ev.preventDefault();
    ev.stopPropagation();
    window.scrollTo(0, 0);
    this.dispatchEvent(
      new CustomEvent('navigate-to-page', {
        bubbles: true,
        composed: true,
        detail: {
          routePath: 'transparency-tool',
        },
      }),
    );
    this.clickedAccess();
  }

  clickedAccess() {
    const ev = new CustomEvent('access-clicked');
    this.dispatchEvent(ev);
  }

  render() {
    return html` <div class="main_container transparency-tool">
      <div class="content_body_area">
        <div class="label-text"><label>Tool Trasparenza</label></div>
        <div>
          <ing-button class="access-button" @click="${this.goToTransparencyTool}">
            Accedi</ing-button
          >
        </div>
      </div>
    </div>`;
  }
}
customElements.define('transparency-tool-access', TransprencyToolAcess);
