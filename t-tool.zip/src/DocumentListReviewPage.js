import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngTab,
  IngTabs,
  IngTabPanel,
  IngIcon,
  IngLink,
  IngTextarea,
  IngInput,
  IngSwitch,
  IngButton,
  formatDate,
  IngDialog,
  IngDialogFrame,
} from 'ing-web';

import styles from './DocumentListHomePageStyles.js';
import reviewPageStyles from './DocumentListReviewPageStyles.js';
import { DocumentReviewAttachments } from './DocumentReviewAttachments.js';
import { DocumentListReviewInfo } from './DocumentReviewInfo.js';
import { IngTable } from './components/tables/IngTable.js';
import {
  contentData,
  reviewRequestHeader,
  reviewsHeader,
  reviewsContentData,
} from './data/reviewData.js';
import reviewHistoryTableStyles from './DocumentReviewHistoryTableStyles.js';
import { CollapsibleDocumentCommonDetails } from './CollapsibleDocumentCommonDetails.js';
// import { documents } from './data/documents.js';
import { ajaxInstance } from './utils/endpoints.js';
import { baseURL, baseURL2, baseURL3, baseURL5, baseURL6 } from './utils/constants.js';
import {
  transformRequestReviewToBackend,
  transformReviewRequestToFrontEnd,
} from './data/tranformations/requestReviewTransformation.js';
import {
  transformInsertReviewToBackend,
  transformReviewToFrontEnd,
} from './data/tranformations/insertReviewTransformation.js';
import { transformDocumentsToFrontEnd } from './data/tranformations/documentTranformation.js';
import { chunks, multipleFileUpload } from './utils/chunks.js';
import { messages } from './data/messages.js';
import { ConfirmationDialog } from './components/dialog/ConfirmationDialog.js';
import {
  generateId,
  getHighestItemVersionId,
  getHighestId,
} from './utils/IngFeatTransparencyToolUtils.js';

function closeDialog(event) {
  if (event && event.target) {
    event.target.dispatchEvent(
      new Event('close-overlay', {
        bubbles: true,
      }),
    );
  }
}

export class DocumentListReviewPage extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-tabs': IngTabs,
      'ing-tab': IngTab,
      'ing-tab-panel': IngTabPanel,
      'ing-icon': IngIcon,
      'ing-link': IngLink,
      'ing-textarea': IngTextarea,
      'ing-input': IngInput,
      'ing-switch': IngSwitch,
      'ing-table-generic': IngTable,
      'document-review-attachments': DocumentReviewAttachments,
      'document-list-review-info': DocumentListReviewInfo,
      'ing-button': IngButton,
      'collapsible-document-common-details': CollapsibleDocumentCommonDetails,
      'confirmation-dialog': ConfirmationDialog,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
    };
  }

  static get properties() {
    return {
      reviewData: { type: Object },
      _reviewerData: { type: Object },
      requestReviewData: { type: Object },
      reviewsList: Array,
      reviewRequests: Array,
      fileData: Array,
      emailList: Array,
      requestMessage: String,
      reviewerMessage: String,
      reviewer: String,
      reviewerFileData: Array,
      reviewStatus: Boolean,
      disableRequestReviewFields: Boolean,
      disableReviewFields: Boolean,
      confirmationMessageDetail: Object,
      versionId: String,
      requestObj: Object,
      requestValidityDate: String,
      selectedRequest: Object,
      highestVersion: Number,
    };
  }

  static get styles() {
    return [styles, reviewPageStyles];
  }

  constructor() {
    super();
    this.reviewData = {};
    this._reviewerData = {};
    this.reviewsList = [];
    this.fileData = [];
    this.emailList = [];
    this.reviewerFileData = [];
    this.reviewStatus = false;
    this.reviewRequests = [];
    this.disableRequestReviewFields = false;
    this.disableReviewFields = false;
    this.confirmationMessageDetail = {};
    this.emailMessage = {};
    this.versionId = '0';
    this.requestObj = {};
    this.requestValidityDate = '';
    this.isStoricaApiLoaded = false;
    this.reviewRequestController = new AbortController();
    this.reviewsController = new AbortController();
    this.getReviewRequests = this.getReviewRequests.bind(this);
    this.getReviewsByRequestId = this.getReviewsByRequestId.bind(this);
    this.isAbortControllerCanceled = false;
    this.showApprovedBtn = false;
    this.disConnected = false;
  }

  async firstUpdated(changed) {
    super.firstUpdated(changed);
    if (!this.reviewData?.id) {
      await new Promise(resolve => setTimeout(resolve, 2500));
      const event = new CustomEvent('go-to-home-page');
      // eslint-disable-next-line
      !this.reviewData?.id && this.dispatchEvent(event);
    }
    if (!this.reviewData?.status && this.reviewData?.id) {
      const res = await this.getVersionItemDetail(this.reviewData?.id);
      const data = transformDocumentsToFrontEnd(res?.data);
      this._cloneRecord(this.reviewData, data);
      this.requestUpdate();
      this.reviewData = { ...this.reviewData };
    }

    this.checkStatus();

    // if (this.reviewData?.status?.toUpperCase() === 'IN SVILUPPO') {
    // const res = await this.getLookupData();
    // this.emailMessage = transformLookUpDataToFrontEnd(
    //   deriveData(res?.data),
    //   'REVIEW_REQUEST_EMAIL_SUBJECT',
    // );
    // }

    // if (!localEnvironment.production) {
    // }
    // if (this.reviewData && this.reviewData.reviewRequests) {
    //   this.reviewRequests = this.reviewData.reviewRequests;
    // }
  }

  // eslint-disable-next-line
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  async updated(changed) {
    super.updated(changed);
    if (
      this.reviewData?.status?.toUpperCase() === 'IN REVISIONE' &&
      changed.has('reviewData') &&
      this.reviewData?.id &&
      !this.requestObj?.itemsVersionsID &&
      !this.disableReviewFields
    ) {
      const res = await this.getReviewItemsByDocumentId(this.reviewData.id);
      const obj = getHighestItemVersionId(res?.data?.itemChildren || []);
      if (obj?.itemsVersionsID) {
        this.requestObj = obj;
        this.requestValidityDate = obj?.validity ? obj?.validity : '';
      } else {
        this.disableReviewFields = true;
        this.requestValidityDate = '';
      }
    }
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this.disConnected = true;
    this._initStorica();
  }

  async _isCheckReviewRequestExists() {
    const reviewRequests = await this._getReviewRequestsList();
    if (reviewRequests.length) {
      const obj = getHighestId(reviewRequests || []);
      const reviews = (await (await this.getReviewsByRequestId(obj.id))?.itemChildren) || [];
      return !!reviews.length;
    }
    // eslint-disable-next-line
    return false;
  }

  checkStatus() {
    if (this.reviewData?.status?.toUpperCase() !== 'IN SVILUPPO') {
      this.disableRequestReviewFields = true;
    }

    if (this.reviewData?.status?.toUpperCase() !== 'IN REVISIONE') {
      this.disableReviewFields = true;
    }
  }

  async _getReviewRequestsList() {
    // eslint-disable-next-line
    const reviewRequests =
      (await (await this.getReviewRequests(this.reviewData?.id))?.itemChildren) || [];
    return reviewRequests.map(item => transformReviewRequestToFrontEnd(item)) || [];
  }

  async _goToStoricoPage() {
    this.reviewRequests = [];
    this.reviewsList = [];
    this.showApprovedBtn = false;
    if (!this.isStoricaApiLoaded) {
      if (this.isAbortControllerCanceled) {
        this.reviewRequestController = new AbortController();
        this.reviewsController = new AbortController();
        this.isAbortControllerCanceled = false;
      }
      this.isStoricaApiLoaded = true;
      // eslint-disable-next-line
      const reviewRequests =
        (await (await this.getReviewRequests(this.reviewData?.id))?.itemChildren) || [];
      await this.refetch(reviewRequests, this.getReviewRequests);
      const highestVersionObj = getHighestItemVersionId(reviewRequests);
      if (highestVersionObj?.itemChildren?.length) {
        this.showApprovedBtn = true;
      } else {
        this.showApprovedBtn = false;
      }
      reviewRequests?.forEach(item => {
        this.reviewRequests.push(transformReviewRequestToFrontEnd(item));
      });
      this.reviewRequests = [...this.reviewRequests];
      if (this.reviewRequests.length) {
        this._selectedTableRow({
          detail: {
            data: this.reviewRequests[0],
          },
        });
        // eslint-disable-next-line
        this.selectedRequest = this.reviewRequests[0];
      }
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getReviewRequests(id) {
    try {
      const res = await ajaxInstance.get(
        `${baseURL2}/version/${id}/select?itemTypeKeyParent=REVIEW_TYPE&itemTypeValueChild=DESCRIZIONE_REVISIONE`,
        {
          signal: this.reviewRequestController.signal,
        },
      );
      return res.data ? res.data : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    } finally {
      this.isStoricaApiLoaded = false;
    }
  }

  async _filesChanged(e) {
    // eslint-disable-next-line no-console
    console.log(e.detail, this);
    this.fileData = e.detail;
    const process = urlList => {
      this.fileData = this.fileData.map(item => {
        // eslint-disable-next-line
        item.isSaved = true;
        // eslint-disable-next-line
        item.url = urlList[0].ItemUrl;
        return item;
      });
    };

    try {
      const list = this.fileData.filter(item => !item.isSaved);
      if (list && list.length > 0) {
        const res = await this.uploadFiles(list);
        process(res?.data);
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      this._showStatusInDialog({
        status: 502,
        data: {
          status: 502,
        },
      });
    }
  }

  // eslint-disable-next-line class-methods-use-this
  uploadFiles(files) {
    return chunks(files, multipleFileUpload, 50);
  }

  _emailsChanged(e) {
    // eslint-disable-next-line no-console
    console.log(e.detail, this);
    this.emailList = e.detail;
    this.emailList = [...this.emailList];
  }

  // eslint-disable-next-line class-methods-use-this
  getLookupData() {
    return ajaxInstance.get(`${baseURL3}`);
  }

  // eslint-disable-next-line class-methods-use-this
  getReviewItemsByDocumentId(id) {
    return ajaxInstance.get(
      `${baseURL}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=DESCRIZIONE_REVISIONE`,
    );
  }

  _reviewMessageChanged(e) {
    this.requestMessage = e.target.value;
  }

  _onReviewerChange(isCheckbox) {
    return e => {
      if (!isCheckbox) {
        if (e.target.name === 'message') {
          this.reviewerMessage = e.target.value;
        } else {
          this.reviewer = e.target.value;
        }
      } else {
        this.reviewStatus = e.target.checked;
      }
    };
  }

  async _reviewerFilesChanged(e) {
    // eslint-disable-next-line no-console
    console.log(e.detail, this);
    this.reviewerFileData = e.detail;
    const process = urlList => {
      this.reviewerFileData = this.reviewerFileData.map(item => {
        // eslint-disable-next-line
        item.isSaved = true;
        // eslint-disable-next-line
        item.url = urlList[0].ItemUrl;
        return item;
      });
    };

    try {
      const list = this.reviewerFileData.filter(item => !item.isSaved);
      if (list && list.length > 0) {
        const res = await this.uploadFiles(list);
        process(res?.data);
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      this._showStatusInDialog({
        status: 502,
        data: {
          status: 502,
        },
      });
    }
  }

  async _handleChildEvent(e) {
    // eslint-disable-next-line no-console
    if (e?.detail?.target?.matches('.download-btn')) {
      // eslint-disable-next-line
      console.log('__handleChildEvent', e.detail, this);
      const ids = e?.detail?.target?.id.split('__');
      for (const id of ids) {
        // eslint-disable-next-line
        await this._handleDownloads(id, `file-${generateId()}`);
      }
    }
  }

  async _selectedTableRow(ev) {
    const { data } = ev.detail;
    this.requestReviewData = data;
    this.selectedRequest = data;
    // if (this.requestReviewData && this.requestReviewData.reviewsList.length > 0) {
    //   this.reviewsList = this.requestReviewData.reviewsList;
    // } else {
    //   this.reviewsList = [];
    // }
    this.isStoricaApiLoaded = true;
    this.reviewsList = [];
    const reviews =
      (await (await this.getReviewsByRequestId(this.requestReviewData.id))?.itemChildren) || [];
    await this.refetch(reviews, this.getReviewsByRequestId);
    reviews.forEach(item => {
      this.reviewsList.push(transformReviewToFrontEnd(item));
    });
    this.reviewsList = [...this.reviewsList];
  }

  async refetch(list = [], apiFn, iterator = 0) {
    if (iterator === list.length) {
      return;
    }
    this.isStoricaApiLoaded = true;
    const data = await apiFn(list[iterator].itemsVersionsID);
    // eslint-disable-next-line
    list[iterator] = { ...list[iterator], ...data };
    // eslint-disable-next-line
    iterator++;
    await this.refetch(list, apiFn, iterator);
  }

  // eslint-disable-next-line class-methods-use-this
  async getReviewsByRequestId(requestId) {
    try {
      const res = await ajaxInstance.get(
        `${baseURL2}/version/${requestId}/select?itemTypeKeyParent=REVIEW_TYPE&itemTypeValueChild=DESCRIZIONE_REVISIONE`,
        {
          signal: this.reviewsController.signal,
        },
      );
      return res.data ? res.data : [];
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      return [];
    } finally {
      this.isStoricaApiLoaded = false;
    }
  }

  // eslint-disable-next-line
  async makeprintPreviewBase64AjaxCall(uuid) {
    const url = `${baseURL6}/${uuid}/content/base64`;
    try {
      const res = await ajaxInstance.get(url);
      let base64Data = '';
      if (typeof res?.data === 'object') {
        const propertiesList = Object.getOwnPropertyNames(res?.data);
        if (propertiesList.length) {
          base64Data = res?.data[propertiesList[0]];
        }
      } else if (typeof res?.data === 'string') {
        base64Data = res?.data;
      }
      const contentDisposition = res?.headers['content-disposition']?.split(';')?.[1] || '';
      return {
        base64Data,
        contentType: res.headers['content-type'],
        fileName: contentDisposition?.slice(
          contentDisposition?.indexOf('filename=') + 9,
          contentDisposition?.length,
        ),
      };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return '';
    }
  }

  async _handleDownloads(id, name) {
    // eslint-disable-next-line
    let { base64Data, contentType, fileName } = await this.makeprintPreviewBase64AjaxCall(id);

    if (base64Data?.indexOf(';base64,') === -1) {
      base64Data = `data:${contentType};base64,${base64Data}`;
    }
    const downloadLink = window.document.createElement('a');
    downloadLink.href = base64Data;
    downloadLink.download = `${fileName || name}`;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }

  // eslint-disable-next-line class-methods-use-this
  async getReviewRequestsByVersion(docId) {
    try {
      const res = await ajaxInstance.get(
        `${baseURL2}/version/${docId}/select?itemTypeKeyParent=REVIEW_TYPE&itemTypeValueChild=DESCRIZIONE_REVISIONE`,
      );
      return res.data ? res.data : [];
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      return [];
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionItemDetail(id, isReturnError) {
    try {
      const res = await ajaxInstance.get(`${baseURL2}/version/${id}`);
      return res;
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      if (isReturnError) {
        throw err;
      }
      return [];
    }
  }

  async _changedVersion(ev) {
    const { data } = ev.detail;
    // const reviewDetail = documents.find(
    //   item => item.version === data && item.docId === this.reviewData.docId,
    // );
    // if (reviewDetail) {
    //   this.reviewData = reviewDetail;
    // }
    // if (reviewDetail && reviewDetail.reviewRequests) {
    //   this.reviewRequests = reviewDetail.reviewRequests;
    // } else {
    //   this.reviewRequests = [];
    // }
    const res = await this.getVersionItemDetail(data);
    const reviewData1 = transformDocumentsToFrontEnd(res?.data);
    this.requestObj = {};
    this.reviewData = {};
    setTimeout(async () => {
      this.reviewData = JSON.parse(JSON.stringify(reviewData1));
      this.versionId = this.reviewData?.id;
      if (this.reviewData?.status?.toUpperCase() !== 'IN SVILUPPO') {
        this.disableRequestReviewFields = true;
      }
      if (this.reviewData?.status?.toUpperCase() !== 'IN REVISIONE') {
        this.disableReviewFields = true;
      }
    }, 500);
    this.reviewRequests = [];
    this.reviewsList = [];
    const reviewRequests =
      (await (await this.getReviewRequestsByVersion(reviewData1.id, data)).itemChildren) || [];
    await this.refetch(reviewRequests, this.getReviewRequestsByVersion);
    reviewRequests.forEach(item => {
      this.reviewRequests.push(transformReviewRequestToFrontEnd(item));
    });
    this.reviewRequests = [...this.reviewRequests];
  }

  async _fileRemoved(ev) {
    const { id } = ev.detail;
    try {
      if (id) {
        // await this.deleteData(id);
        this.fileData = this.fileData.filter(d => d?.id?.toString() !== id?.toString());
      }
      this.fileData = [...this.fileData];
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async _reviewerFileRemoved(ev) {
    const { id } = ev.detail;
    try {
      if (id) {
        // await this.deleteData(id);
        this.reviewerFileData = this.reviewerFileData.filter(
          d => d?.id?.toString() !== id?.toString(),
        );
      }
      this.reviewerFileData = [...this.reviewerFileData];
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async deleteData(id) {
    await ajaxInstance.delete(`${baseURL}/files/${id}`);
  }

  async requestReview() {
    try {
      const params = {
        message: this.requestMessage,
        name: `REVISIONE DEL ${formatDate(new Date(), {
          hour: 'numeric',
          minute: 'numeric',
          locale: 'it-IT',
          second: 'numeric',
        })}`,
        validity: new Date().toISOString(),
        id: this.reviewData.id,
        // eslint-disable-next-line
        files: this.fileData,
        emailList: this.emailList,
        user: 'nome.cognome@ing.com',
      };
      const {
        data: { itemsVersionsID: id },
      } = await ajaxInstance.post(`${baseURL}`, transformRequestReviewToBackend(params));
      await this.makeRelationAjaxCall(this.reviewData.id, id);
      await ajaxInstance.post(
        `${baseURL5}/send-email?lookupDataSubject=${
          messages.email.requestReviewSubject
        }&&lookupDataMessage=${
          messages.email.requestReviewMessage
        }&&recipients=${this.emailList.map(d => d.labelText)}&&attachments=${
          this.fileData?.length ? this.fileData.map(d => d.id) : []
        }`,
        {},
      );
      await this.updateDocumentStatus(2);
      // const res = await this.getVersionItemDetail(this.reviewData?.id);
      // const reviewData1 = transformDocumentsToFrontEnd(res?.data);
      // // const event = new CustomEvent('go-to-home-page');
      // // this.dispatchEvent(event);
      // this._cloneRecord(this.reviewData, reviewData1);
      // this.requestUpdate();
      // this.reviewData = { ...this.reviewData };
      if (this.reviewData?.status === 'IN REVISIONE') {
        this.requestMessage = undefined;
        this.fileData = [];
        this.emailList = [];
        this.disableRequestReviewFields = true;
        this.requestObj = {};
        this.disableReviewFields = false;
      }
      // this.checkStatus();
      // const ev1 = new CustomEvent('go-to-home-page', { detail: { data: this.reviewData } });
      // this.dispatchEvent(ev1);
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
      this._showStatusInDialog({
        status: 502,
        data: {
          status: 502,
        },
      });
    }
  }

  // eslint-disable-next-line class-methods-use-this
  tranformRelationAPI(parentId, childId, order = 0) {
    return {
      itemsVersionsIDParent: parentId,
      itemsVersionsIDChild: childId,
      itemOrder: order,
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async makeRelationAjaxCall(parentId, childId, order) {
    const itemsVersionsRelationsDTO = [this.tranformRelationAPI(parentId, childId, order)];
    await ajaxInstance.put(`${baseURL}s/versions/relation`, { itemsVersionsRelationsDTO });
  }

  async insertReview() {
    try {
      const params = {
        message: this.reviewerMessage,
        reviewer: this.reviewer,
        id: this.reviewData.id,
        name: `REVISIONE DEL ${formatDate(new Date(), {
          hour: 'numeric',
          minute: 'numeric',
          locale: 'it-IT',
          second: 'numeric',
        })}`,
        validity: new Date().toISOString(),
        // eslint-disable-next-line
        files: this.reviewerFileData,
        reviewStatus: this.reviewStatus,
        user: 'nome.cognome@ing.com',
      };
      const {
        data: { itemsVersionsID: id },
      } = await ajaxInstance.post(`${baseURL}`, transformInsertReviewToBackend(params));
      await this.makeRelationAjaxCall(this.requestObj.itemsVersionsID, id);
      if (this.reviewStatus === false) {
        await this.updateDocumentStatus(0);
        if (this.reviewData?.status?.toUpperCase() === 'IN SVILUPPO') {
          this.disableRequestReviewFields = false;
          this.disableReviewFields = true;
        } else {
          this.disableReviewFields = false;
        }
        this.requestValidityDate = '';
      }
      // const event = new CustomEvent('go-to-home-page');
      // this.dispatchEvent(event);
      this.reviewerMessage = '';
      this.reviewer = '';
      this.reviewerFileData = [];
      this.reviewStatus = false;
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
      this._showStatusInDialog({
        status: 502,
        data: {
          status: 502,
        },
      });
    }
  }

  async _filesAdded(ev) {
    let { files } = ev.detail;
    if (ev && this.reviewData?.status?.toUpperCase() === 'IN SVILUPPO') {
      try {
        const res = await this.uploadFiles(files);
        files = [...res.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value)];
        files.forEach(item => {
          const index = this.fileData.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (index > -1) {
            this.fileData[index].id = item.id;
          } else {
            this.fileData.push(item);
          }
        });
        this.fileData = [...this.fileData];
      } catch (err) {
        this.fileData = this.fileData.filter(
          item => item?.id?.toString() !== files[0]?.id?.toString(),
        );
        // eslint-disable-next-line
        console.log('Error', err);
        this._showStatusInDialog({
          status: 502,
          data: {
            status: 502,
          },
        });
      }
    } else {
      this.fileData = this.fileData.filter(
        item => item?.id?.toString() !== files[0]?.id?.toString(),
      );
      // eslint-disable-next-line
      console.log('Error');
    }
  }

  // eslint-disable-next-line class-methods-use-this
  toBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  async _reviewerFilesAdded(ev) {
    if (ev) {
      let { files } = ev.detail;
      try {
        const res = await this.uploadFiles(files);
        files = [...res.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value)];
        files.forEach(item => {
          const index = this.reviewerFileData.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (index > -1) {
            this.reviewerFileData[index].id = item.id;
          } else {
            this.reviewerFileData.push(item);
          }
        });
        this.reviewerFileData = [...this.reviewerFileData];
      } catch (err) {
        this.reviewerFileData = this.reviewerFileData.filter(
          item => item?.id?.toString() !== files[0]?.id?.toString(),
        );
        // eslint-disable-next-line
        console.log('Error', err);
        this._showStatusInDialog({
          status: 502,
          data: {
            status: 502,
          },
        });
      }
    }
  }

  get disableRequestReviewBtn() {
    return (
      this.reviewData?.status?.toUpperCase() !== 'IN SVILUPPO' ||
      !this.requestMessage ||
      this.fileData.length === 0 ||
      this.emailList.length === 0
    );
  }

  get disableInsertReviewBtn() {
    return (
      this.reviewData?.status?.toUpperCase() !== 'IN REVISIONE' ||
      !this.reviewerMessage ||
      this.reviewerFileData.length === 0 ||
      !this.reviewer
    );
  }

  // eslint-disable-next-line class-methods-use-this
  async updateDocumentStatus(action, isShow) {
    try {
      await ajaxInstance.patch(
        `${baseURL}/version/status?itemsVersionsID=${this.reviewData.id}&action=${action}`,
        {},
      );
      const res = await this.getVersionItemDetail(this.reviewData?.id, true);
      const reviewData1 = transformDocumentsToFrontEnd(res?.data);
      // const event = new CustomEvent('go-to-home-page');
      // this.dispatchEvent(event);
      this._cloneRecord(this.reviewData, reviewData1);
      this.requestUpdate();
      this.reviewData = { ...this.reviewData };
      this.checkStatus();
      // if (action === 1 || action === 2) {
      //   await this._goToStoricoPage();
      // }
      const ev1 = new CustomEvent('go-to-home-page', { detail: { data: this.reviewData } });
      this.dispatchEvent(ev1);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      if (isShow) {
        this._showStatusInDialog({
          status: 502,
          data: {
            status: 502,
          },
        });
      } else {
        throw error;
      }
    }
  }

  openDialog() {
    const dialog = this.shadowRoot.querySelector('#dialog2');
    dialog.opened = true;
  }

  async _closeDialog(ev) {
    this.confirmationMessageDetail = {};
    // eslint-disable-next-line
    ev && ev.target && closeDialog(ev);
    if (ev?.detail) {
      const { confirmationMessageDetail } = ev?.detail;
      if (confirmationMessageDetail && confirmationMessageDetail.type === 'requestReview') {
        // if (!await this._isCheckReviewRequestExists()) {
        this.requestReview();
        // } else {
        //   this.disableRequestReviewFields = true;
        //   this.requestReviewExistingCheckDialog();
        // }
      } else if (confirmationMessageDetail && confirmationMessageDetail.type === 'insertReview') {
        this.insertReview();
      }
    }
  }

  requestReviewDialog() {
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.type = 'requestReview';
    this.confirmationMessageDetail.messages =
      messages?.reviews?.requestReview?.requestConfirmation || [];
    this.openDialog();
  }

  requestReviewExistingCheckDialog() {
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.type = 'requestReviewExistingCheck';
    this.confirmationMessageDetail.messages =
      messages?.reviews?.requestReview?.requestReviewExistingError || [];
    this.openDialog();
  }

  insertReviewDialog() {
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.type = 'insertReview';
    this.confirmationMessageDetail.messages =
      messages?.reviews?.insertReview?.requestConfirmation || [];
    this.openDialog();
  }

  get enableInValidaBtn() {
    return (
      (this.reviewData?.status?.toUpperCase() === 'APPROVATO' ||
        this.reviewData?.status?.toUpperCase() === 'IN REVISIONE') &&
      new Date(this.reviewData?.start_date).getTime() > new Date().getTime() &&
      this.reviewData?.version === this.highestVersion
    );
  }

  get enableApprovaBtn() {
    return (
      this.reviewData?.status?.toUpperCase() === 'IN REVISIONE' &&
      new Date(this.reviewData?.start_date).getTime() >= new Date().getTime() &&
      this.reviewData?.version === this.highestVersion &&
      this.showApprovedBtn
    );
  }

  getHighestVersion(event) {
    this.highestVersion = event?.detail;
    // eslint-disable-next-line
    console.log('fetched Highest version', this.highestVersion);
  }

  _initStorica() {
    if (this.isStoricaApiLoaded) {
      this.reviewRequestController.abort();
      this.reviewsController.abort();
      this.reviewRequests = [];
      this.reviewsList = [];
      this.isAbortControllerCanceled = true;
    }
    this.checkStatus();
  }

  _showStatusInDialog(event) {
    if (!this.disConnected) {
      const { data, status } = event;
      const type = status && (data.status === 200 || data.status === 201) ? 'success' : 'error';
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages = messages?.save[type];
      // eslint-disable-next-line
      console.log('data data data', data);
      this.openDialog();
    }
  }

  render() {
    return html` <div class="main_container">
        <div class="content_body_area">
          <ing-tabs review-child-tabs>
            <ing-tab slot="tab" @click="${() => this._initStorica()}">Richiesta Review</ing-tab>
            <ing-tab slot="tab" @click="${() => this._initStorica()}">Inserimento Review </ing-tab>
            <ing-tab slot="tab" @click="${() => this._goToStoricoPage()}">Storico Review </ing-tab>
            <ing-tab-panel slot="panel">
              <div class="tab_content review-tab-content">
                ${this.reviewData
                  ? html`
          <document-list-review-info .reviewData="${this.reviewData}"></document-list-review-info>
        </br>
        </br>
        <ing-textarea inputLabel @change="${this._reviewMessageChanged}" .modelValue="${
                      this.requestMessage
                    }" reviewtextarea label="MODIFICHE EFFETTUATE" rows="4" max-rows="4" ?disabled="${
                      this.disableRequestReviewFields
                    }"></ing-textarea>
        <div class="review-seperator"> </div>
        <label class='file-upload-title'>CARICA ALLEGATI DA ASSOCIARE</label>
        <document-review-attachments type="file" id="reviewRequest" labelText="CARICA ALLEGATI DA ASSOCIARE"
        addButtonText="Carica File"
        ._data="${this.fileData}"
        @files-added="${this._filesAdded}" @data-removed="${
                      this._fileRemoved
                    }" ?disableRequestReviewFields="${
                      this.disableRequestReviewFields
                    }"> </document-review-attachments>

        <div class="review-seperator"> </div>

        <document-review-attachments type="email" ._data="${this.emailList}" @data-received="${
                      this._emailsChanged
                    }" labelText="AGGIUNGI REVISORI"
        addButtonText="Aggiungi"
        ?disableRequestReviewFields="${this.disableRequestReviewFields}"
        > </document-review-attachments>
        <div class="save-button">
        <ing-button ?disabled="${
          this.disableRequestReviewFields || this.disableRequestReviewBtn
        }" @click="${this.requestReviewDialog}" indigo>Richiedi Review</ing-button>
      </div>
          `
                  : `No data Found`}
              </div>
            </ing-tab-panel>
            <ing-tab-panel slot="panel">
              <div class="tab_content review-tab-content">
                <document-list-review-info
                  .reviewData="${this.reviewData}"
                  lastRequestDate="${this.requestValidityDate}"
                ></document-list-review-info>
                <ing-textarea
                  .modelValue="${this.reviewerMessage}"
                  @change="${this._onReviewerChange()}"
                  name="message"
                  reviewertextarea
                  inputLabel
                  label="NOTE SULLA REVIEW EFFETTUATA
"
                  rows="4"
                  max-rows="4"
                  ?disabled="${this.disableReviewFields}"
                ></ing-textarea>
                <ing-input
                  id="reviewer"
                  name="reviewer"
                  @change="${this._onReviewerChange()}"
                  inputLabel
                  label="REVISORE"
                  .modelValue="${this.reviewer}"
                  ?disabled="${this.disableReviewFields}"
                ></ing-input>
                <div class="review-seperator"></div>
                <label class="file-upload-title">CARICA ALLEGATI RICEVUTI</label>
                <document-review-attachments
                  type="file"
                  ._data="${this.reviewerFileData}"
                  @files-added="${this._reviewerFilesAdded}"
                  @data-removed="${this._reviewerFileRemoved}"
                  labelText="CARICA ALLEGATI RICEVUTI"
                  id="insertReview"
                  addButtonText="Carica file"
                  saveButtonText=""
                  ?disableRequestReviewFields="${this.disableReviewFields}"
                >
                  <div slot="end">
                    <div class="review-switch-label">
                      <strong> SELEZIONA L'ESITO DELLA REVISIONE </strong>
                    </div>
                    <ing-switch
                      ?checked="${this.reviewStatus}"
                      @click="${this._onReviewerChange(true)}"
                      name="reviewStatus"
                      review-switch
                      label="NEGATIVO"
                      ?disabled="${this.disableReviewFields}"
                    ></ing-switch>
                    <span class="positive-text">POSITIVO</span>
                  </div>
                </document-review-attachments>
                <div class="save-button">
                  <ing-button
                    id="insert-review-btn"
                    ?disabled="${this.disableReviewFields || this.disableInsertReviewBtn}"
                    @click="${this.insertReviewDialog}"
                    indigo
                    >Inserisci Review</ing-button
                  >
                </div>
              </div>
            </ing-tab-panel>

            <ing-tab-panel slot="panel">
              <div class="tab_content review-tab-content">
                <document-list-review-info
                  .reviewData="${this.reviewData}"
                  .version="${this.versionId}"
                  @version-changed="${this._changedVersion}"
                  @highest-version=${this.getHighestVersion}
                  currentTab="storicaReview"
                ></document-list-review-info>
                ${this.reviewRequests?.length > 0
                  ? html`<ing-table-generic
                      ing-generic-table
                      .selectedRow=${this.selectedRequest}
                      @child-data-event="${this._handleChildEvent}"
                      propertyId="id"
                      .tableData="${this.reviewRequests}"
                      .headerData="${reviewRequestHeader}"
                      .contentProperties="${contentData}"
                      @selected-table-row="${this._selectedTableRow}"
                      .additionalStyles=${reviewHistoryTableStyles}
                    ></ing-table-generic>`
                  : ''}
                <div class="ing_standard_bottom_line"></div>
                <collapsible-document-common-details
                  sectionName="Review Inserite"
                  .tableContentData=${this.reviewsList}
                  .headerData="${reviewsHeader}"
                  .contentProperties="${reviewsContentData}"
                  propertyId="id"
                  .additionalStyles=${reviewHistoryTableStyles}
                  @child-data-event="${this._handleChildEvent}"
                >
                </collapsible-document-common-details>
                <div class="document-review-history-btns">
                  <ing-button
                    transparent
                    class="btn"
                    @click="${() => {
                      this.updateDocumentStatus(0, true);
                      this.disableRequestReviewFields = false;
                    }}"
                    ?disabled="${!this.enableInValidaBtn}"
                  >
                    <ing-icon
                      thumbsdown-indigo
                      font14
                      slot="icon-before"
                      icon-id="ing:filledin-social:thumbsDown"
                    ></ing-icon>

                    Invalida</ing-button
                  >
                  <ing-button
                    class="btn"
                    indigo
                    @click="${() => this.updateDocumentStatus(1, true)}"
                    ?disabled="${!this.enableApprovaBtn}"
                  >
                    <ing-icon slot="icon-before" icon-id="ing:filledin-social:thumbsUp"></ing-icon>

                    Approva</ing-button
                  >
                </div>
              </div>
            </ing-tab-panel>
          </ing-tabs>
        </div>
      </div>
      <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Conferma</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>`;
  }
}

customElements.define('document-list-review-page', DocumentListReviewPage);
