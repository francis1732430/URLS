import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngIcon,
  IngCollapsible,
  IngCollapsibleInvoker,
} from 'ing-web';

import styles from './CollapsibleDocumentDetailsStyles.js';

import { DocumentCommonDetailsTable } from './components/tables/DocumentCommonDetailsTable.js';
import { DialogModifySection } from './components/dialog/DialogModifySection.js';
import { IngTable } from './components/tables/IngTable.js';

export class CollapsibleDocumentCommonDetails extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'document-common-details-table': DocumentCommonDetailsTable,
      'dialog-modify-section': DialogModifySection,
      'ing-generic-table': IngTable,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      sectionName: { type: String },
      headerData: { type: Array },
      tableContentData: { type: Array },
      selectedRow: { type: Object },
      propertyId: { type: String },
      contentProperties: Array,
      additionalStyles: { type: Object },
    };
  }

  _handleChildEvents(event) {
    const customEvent = new CustomEvent('child-data-event', {
      detail: event?.detail,
    });
    this.dispatchEvent(customEvent);
  }

  render() {
    return html`
      <ing-collapsible>
        <ing-collapsible-invoker
          slot="invoker"
          class="ing_collapsable"
          ?disabled="${this.tableContentData === undefined || this.tableContentData.length === 0}"
        >
          <span slot="open">${this.sectionName}</span>
          <span slot="close">${this.sectionName}</span>
        </ing-collapsible-invoker>
        ${this.tableContentData !== undefined && this.tableContentData.length > 0
          ? html`
              <div slot="content">
                <div>
                  <ing-generic-table
                    ing-generic-table
                    propertyId="${this.propertyId}"
                    .tableData=${this.tableContentData}
                    .headerData=${this.headerData}
                    .contentProperties="${this.contentProperties}"
                    .additionalStyles=${this.additionalStyles}
                    @child-data-event=${this._handleChildEvents}
                  ></ing-generic-table>
                </div>
              </div>
            `
          : html``}
      </ing-collapsible>
    `;
  }
}
customElements.define('collapsible-document-common-details', CollapsibleDocumentCommonDetails);
