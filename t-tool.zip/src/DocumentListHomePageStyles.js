import {
  css,
  font19BoldMixin,
  black6,
  font16Mixin,
  font14Mixin,
  font14BoldMixin,
  black80,
  orange,
} from 'ing-web';

export default css`
  .my-class {
    background-color: ${orange};
  }

  .container {
    height: 30px;
    position: relative;
  }

  .center {
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    padding-top: 50px;
  }

  ing-input {
    width: 60%;
    flex-grow: 1;
    margin-right: 40px;
    display: inline-block;
    text-align: start;
  }

  ing-select {
    width: 60%;
    flex-grow: 1;
    margin-right: 40px;
    display: inline-block;
    text-align: start;
  }

  .search-button::before {
    margin: 0 0 1.5em 0;
    min-height: 44px;
    width: 188px;
  }

  .search-button {
    width: 188px;
    height: 44px;
    margin-bottom: 40px;
    float: left;
    margin-left: 34px;
    margin-top: 33px;
  }

  .input-group__container {
    width: var(--ing-input-element-width, 40%);
  }

  .search_document_text {
    ${font19BoldMixin()}
  }

  .ing_standard_bottom_line {
    border-bottom: 1px solid #ff6200;
  }

  .main_container {
    background: ${black6};
  }

  .content_body_area {
    margin: 0 auto;
    width: 1232px;
  }

  .select_size {
    width: 300px;
  }

  .select_size_test {
    width: 185px;
    float: left;
  }

  .create_new_component_button {
    width: 188px;
    height: 44px;
    float: left;
    margin-left: 30px;
  }

  .create_new_component_button::before {
    margin: 0 0 1.5em 0;
    min-height: 44px;
    width: 188px;
  }

  .new_component_text {
    ${font16Mixin()}
    color: rgb(51, 51, 51);
  }

  .new_component_content {
    height: 129px;
  }

  .tab_content {
    margin: 0px 0px 0px 104px;
  }

  .chip_choice_filter {
    width: 93px;
    text-align: center;
    height: 28px;
    margin-right: 14px;
    font-size: 12px !important;
    padding-top: 6px;
  }

  .new_component_label {
    margin-bottom: 18px;
  }

  .search_document_label {
    margin-bottom: 31px;
    margin-top: 54px;
  }

  .param_filter_search {
    margin-top: 33px;
    width: 288px;
    height: 40px;
    float: left;
  }

  .view_button::before {
    margin: 0 0 1.5em 0;
    min-height: 32px;
    width: 186px;
  }

  .view_button {
    width: 186px;
    height: 32px;
  }

  .review_button::before {
    margin: 0 0 1.5em 0;
    min-height: 32px;
    width: 188px;
  }

  .review_button {
    width: 188px;
    height: 32px;
    margin-left: 24px;
  }

  .search_document_content {
    min-height: 1350px;
    height: 1000px;
  }

  .grey-empty-area {
    height: 41px;
    background: ${black6};
  }
  .reset-button::before {
    margin: 0 0 1.5em 0;
    min-height: 44px;
    width: 180px;
  }

  .reset-button {
    width: 180px;
    height: 44px;
    margin-bottom: 40px;
    float: left;
    margin-left: 34px;
    margin-top: 33px;
  }
  #pagination-event {
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 35px;
  }
  .close-tab {
    position: absolute;
    top: 2px;
    right: -2px;
    font-size: 12px;
    font-family: inherit;
    color: gray;
    cursor: pointer;
    border: 0;
    text-decoration: none;
    background: transparent;
  }
  [data-tag-name='ing-tab'] {
    position: relative;
  }
  .create-new-button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .create-new-button {
    min-width: 180px;
    height: 32px;
    margin-left: 102px;
    margin-top: 47px;
    margin-bottom: 10px;
    ${font14BoldMixin()}
  }
  .file-upload-title {
    ${font14Mixin()};
    color: ${black80};
  }
  .homelist__table {
    height: 22rem;
    overflow: auto;
    width: 100%;
  }
`;
