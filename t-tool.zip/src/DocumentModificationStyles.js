import { css, black6, orange } from 'ing-web';

export default css`
  .close-tab {
    position: absolute;
    top: 2px;
    right: -2px;
    font-size: 12px;
    font-family: inherit;
    color: gray;
    cursor: pointer;
    border: 0;
    text-decoration: none;
    background: transparent;
  }
  [data-tag-name='ing-tab'] {
    position: relative;
  }
  .back-to-home-icon {
    font-size: 26px;
    position: absolute;
    top: 87px;
    left: 65px;
    cursor: pointer;
  }
  .content_body_area {
    margin: 0px auto;
    width: 1232px;
  }
  .main_container {
    background: ${black6};
  }
  .grey-empty-area {
    height: 41px;
    background: ${black6};
  }
  .full-width-dialog,
  .dialog-frame__wrapper {
    max-height: 100% !important;
    max-width: 100% !important;
    height: 100% !important;
    width: 100% !important;
  }
  .fixed-dialog {
    position: fixed;
    top: 0;
    z-index: 99;
    left: 0;
  }
  .fixed-dialog .close-tab {
    font-size: 24px;
    color: ${orange};
    font-family: sans-serif;
  }
`;
