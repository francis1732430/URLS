import { deriveData } from '../../utils/globalApiKeys.js';
import {
  escapeSlashes,
  restoreSlashes,
  transformDateToBackend,
} from '../../utils/IngFeatTransparencyToolUtils.js';

// Fronted TO Backend START
const transformsubSectionsToBackend = (column, i) => ({
  itemOrder: i + 1,
  itemsVersionsID: column.id,
});

export const transformSectionsToBackend = data => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'SEZIONE',
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.sectionId,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
        data: escapeSlashes(data.description),
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'STILE',
        data: data.sectionStyle,
      },
    ],
    itemChildren: [],
  };
  // eslint-disable-next-line no-unused-expressions
  data.subSections &&
    data.subSections.forEach((d, i) => {
      dataTransformed.itemChildren.push(transformsubSectionsToBackend(d, i));
    });
  return dataTransformed;
};

// Fronted TO Backend END

//  Backend TO Fronted START

const getSubSections = columData => ({
  orderId: columData.itemOrder,
  id: columData.itemsVersionsID,
  name: columData.name,
  description: columData.description,
});
export const transformSectionsToFrontEnd = data => {
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    description: restoreSlashes(
      data.versionDetailL0?.find(d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA')?.data,
    ),
    sectionStyle: data.versionDetailL0?.find(d => d.itemTypeValue === 'STILE')?.data?.toString(),
    validity: data.validity,
    id: data.itemsVersionsID?.toString(),
    name: data.name,
    sectionId: data.itemID?.toString(),
    version: data.versionNumber,
    subSections: [],
    versionDetailLevel0IDStyle: data.versionDetailL0?.find(d => d.itemTypeValue === 'STILE')
      ?.versionDetailLevel0ID,
    versionDetailLevel0IDDescription: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA',
    )?.versionDetailLevel0ID,
  };

  if (!dataTransformed?.description && data?.description) {
    dataTransformed.description = restoreSlashes(data?.description);
  }

  // eslint-disable-next-line no-unused-expressions
  data.itemChildren &&
    data.itemChildren.forEach(column => {
      dataTransformed.subSections.push(getSubSections(column));
    });

  return dataTransformed;
};

//  Backend TO Fronted END

export const transformSectionsToBackendForPatch = data => {
  const dataTransformed = {
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.sectionId,
    versionDetailL0: [
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDStyle,
        data: data.sectionStyle,
      },
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDDescription,
        data: escapeSlashes(data.description),
      },
    ],
  };

  return dataTransformed;
};
