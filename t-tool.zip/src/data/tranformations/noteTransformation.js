// Fronted TO Backend START

import { deriveData } from '../../utils/globalApiKeys.js';
import {
  escapeSlashes,
  restoreSlashes,
  transformDateToBackend,
} from '../../utils/IngFeatTransparencyToolUtils.js';

export const transformNoteToBackend = data => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'NOTA',
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.noteId,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
        data: escapeSlashes(data.description),
      },
    ],
  };
  return dataTransformed;
};

// Fronted TO Backend END

//  Backend TO Fronted START

export const transformNoteToFrontEnd = data => {
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    description: restoreSlashes(
      data.versionDetailL0?.find(d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA')?.data,
    ),
    validity: data.validity,
    id: data.itemsVersionsID?.toString(),
    name: data.name,
    noteId: data.itemID?.toString(),
    version: data.versionNumber,
    versionDetailLevel0ID: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA',
    )?.versionDetailLevel0ID,
  };
  if (!dataTransformed?.description && data?.description) {
    dataTransformed.description = restoreSlashes(data?.description);
  }
  return dataTransformed;
};

//  Backend TO Fronted END

export const transformNotesListToFrontEnd = notesList => {
  const dataList = [];

  notesList.forEach(data => {
    dataList.push(transformNoteToFrontEnd(data));
  });

  return dataList;
};

const transformNotesToBackend = (column, i) => ({
  itemOrder: i + 1,
  itemsVersionsID: column && column.id ? column.id : column,
});

export const transformNotesIdsToBackend = notesList => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'NOTA',
    itemChildren: [],
  };
  // eslint-disable-next-line no-unused-expressions
  notesList.forEach((d, i) => {
    dataTransformed.itemChildren.push(transformNotesToBackend(d, i));
  });
  return dataTransformed;
};

export const transformNoteToBackendForPatch = data => {
  const dataTransformed = {
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.noteId,
    versionDetailL0: [
      {
        versionDetailLevel0ID: data?.versionDetailLevel0ID,
        data: escapeSlashes(data.description),
      },
    ],
  };
  return dataTransformed;
};
