import { deriveData } from '../../utils/globalApiKeys.js';
import {
  escapeSlashes,
  restoreSlashes,
  transformDateToBackend,
} from '../../utils/IngFeatTransparencyToolUtils.js';
import Singleton from '../../utils/SingletonFactory.js';

// eslint-disable-next-line no-unused-vars
const dataB = {
  itemTypeKey: 'DOCUMENT_TYPE',
  itemTypeValue: 'RIGA',
  name: 'name',
  validity: '',
  versionDetailL0: [
    {
      itemTypeKey: 'FIELD',
      itemTypeValue: 'STILE',
      data: 'styleVal',
    },
    {
      itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
      itemTypeValue: 'DETTAGLIO_RIGA',
      data: '',
      versionDetailL1: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'DESCRIZIONE IN STAMPA',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'BOLD',
          data: 'Value from BOLD field',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'ITALIC',
          data: 'italic field val',
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
          itemTypeValue: 'DETTAGLIO_NOTA',
          data: 'Value from NOTE COLONNAfield',
          versionDetailL2: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ID_NOTA',
              data: 'itemsVersionsID related to the note linked to the column',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ID_NOTA',
              data: 'itemsVersionsID related to the note linked to the column',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ID_NOTA',
              data: 'itemsVersionsID related to the note linked to the column',
            },
          ],
        },
      ],
    },
  ],
};

// eslint-disable-next-line no-unused-vars
const dataF = {
  id: '1',
  name: 'Row 1',
  validity: '2022-05-17T05:23:51.150Z',
  style: '1',
  columns: [
    {
      name: 'Col1',
      description: 'desc1',
      style: '1',
      id: 1,
    },
    {
      name: 'Col2',
      description: 'desc2',
      style: '2',
      id: 2,
    },
  ],
  columnNotes: [
    {
      name: 'note1',
      description: '',
      columnId: 1,
      id: 1,
    },
    {
      name: 'note2',
      description: '',
      columnId: 2,
      id: 2,
    },
  ],
};

// Fronted TO Backend START

const transformColumnNotesToBackend = (column, columnNotes) => {
  const dataToReturn = {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
    itemTypeValue: 'DETTAGLIO_NOTA',
    data: column.id,
    versionDetailL2: [],
  };
  // eslint-disable-next-line no-unused-expressions
  columnNotes &&
    columnNotes.forEach(note => {
      dataToReturn.versionDetailL2.push({
        itemTypeKey: 'FIELD',
        itemTypeValue: 'ID_NOTA',
        data: note.id,
      });
    });
  return dataToReturn;
};

const transformColumnsToBackend = (column, notes) => {
  const data = {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'DETTAGLIO_RIGA',
    data: column.name,
    versionDetailL1: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
        data: escapeSlashes(column.description),
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'BOLD',
        data: column.isBold ? 'true' : 'false',
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'ITALIC',
        data: column.isItalic ? 'true' : 'false',
      },
    ],
  };
  const columnNotes = notes.filter(n => n?.columnId?.toString() === column?.id?.toString());
  data.versionDetailL1.push(transformColumnNotesToBackend(column, columnNotes));
  return data;
};

export const transformRowsToBackEnd = data => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'RIGA',
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.rowId,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'STILE',
        data: data.style,
      },
    ],
  };
  // eslint-disable-next-line no-unused-expressions
  data.columns &&
    data.columns.forEach(column => {
      dataTransformed.versionDetailL0.push(transformColumnsToBackend(column, data.columnNotes));
    });
  return dataTransformed;
};
// Fronted TO Backend END

//  Backend TO Fronted START
const getNotes = columData => {
  const newNotes = [];
  columData.versionDetailL1?.forEach(d => {
    if (d.itemTypeKey === 'VERSION_DETAIL_LEVEL_2') {
      // eslint-disable-next-line no-unused-expressions
      d?.versionDetailL2 &&
        d?.versionDetailL2.forEach(n => {
          newNotes.push({
            name: n.data,
            id: n.data,
            columnId: d?.data,
            columnName: columData.data || '',
            versionDetailLevel2ID: n?.versionDetailLevel2ID,
            versionDetailLevel1ID: d?.versionDetailLevel1ID,
          });
        });
    }
  });
  return newNotes || [];
};
const getColumns = columData => ({
  id: columData?.versionDetailL1?.find(d => d.itemTypeKey === 'VERSION_DETAIL_LEVEL_2')?.data,
  name: columData.data,
  description:
    restoreSlashes(
      columData.versionDetailL1?.find(d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA')?.data,
    ) || restoreSlashes(columData?.description),
  isBold: columData.versionDetailL1?.find(d => d.itemTypeValue === 'BOLD')?.data === 'true',
  isItalic: columData.versionDetailL1?.find(d => d.itemTypeValue === 'ITALIC')?.data === 'true',
  versionDetailLevel1IDDescription: columData?.versionDetailL1?.find(
    d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDBold: columData?.versionDetailL1?.find(d => d.itemTypeValue === 'BOLD')
    ?.versionDetailLevel1ID,
  versionDetailLevel1IDItalic: columData?.versionDetailL1?.find(d => d.itemTypeValue === 'ITALIC')
    ?.versionDetailLevel1ID,
  versionDetailLevel1IDColumn: columData?.versionDetailL1?.find(
    d => d.itemTypeKey === 'VERSION_DETAIL_LEVEL_2',
  )?.versionDetailLevel1ID,
  versionDetailLevel0ID: columData?.versionDetailLevel0ID,
});
export const transformRowsToFrontEnd = data => {
  const obj = new Singleton();

  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    id: data.itemsVersionsID?.toString(),
    name: data.name,
    validity: data.validity,
    style: data.versionDetailL0?.find(d => d.itemTypeValue === 'STILE')?.data?.toString(),
    version: data.versionNumber,
    rowId: data.itemID?.toString(),
    styleValue: obj.getLookupValuesByKey(
      data.versionDetailL0?.find(d => d.itemTypeValue === 'STILE')?.data || data?.description,
    ),
    versionDetailLevel0IDStyle: data.versionDetailL0?.find(d => d.itemTypeValue === 'STILE')
      ?.versionDetailLevel0ID,
  };
  const columnsData = data.versionDetailL0?.filter(d => d.itemTypeKey === 'VERSION_DETAIL_LEVEL_1');
  dataTransformed.columns = [];
  dataTransformed.columnNotes = [];
  // eslint-disable-next-line no-unused-expressions
  columnsData &&
    columnsData.forEach(column => {
      dataTransformed.columns.push(getColumns(column));
      dataTransformed.columnNotes.push(...getNotes(column));
    });

  if (dataTransformed?.columns?.length) {
    dataTransformed.columns = dataTransformed.columns.filter(
      col => col?.id && col?.id !== 'undefined',
    );
  }
  return dataTransformed;
};

//  Backend TO Fronted END
export const transformRowsListToFrontEnd = rowsList => {
  const dataList = [];

  rowsList.forEach(data => {
    dataList.push(transformRowsToFrontEnd(data));
  });

  return dataList;
};

const transformNotesToBackend = (column, i) => ({
  itemOrder: i + 1,
  itemsVersionsID: column && column.id ? column.id : column,
});

export const transformRowsIdsToBackend = rowsList => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'RIGA',
    itemChildren: [],
  };
  // eslint-disable-next-line no-unused-expressions
  rowsList.forEach((d, i) => {
    dataTransformed.itemChildren.push(transformNotesToBackend(d, i));
  });
  return dataTransformed;
};

const transformColumnNotesToBackendPatch = (column, columnNotes) => {
  const dataToReturn = {
    data: column.id,
    versionDetailL2: [],
  };
  // eslint-disable-next-line no-unused-expressions
  columnNotes &&
    columnNotes.forEach(note => {
      dataToReturn.versionDetailLevel1ID = note?.versionDetailLevel1ID;
      dataToReturn.versionDetailL2.push({
        versionDetailLevel2ID: note?.versionDetailLevel2ID,
        data: note.id,
      });
    });
  return dataToReturn;
};

const transformColumnsToBackendPatch = (column, notes) => {
  const data = {
    versionDetailLevel0ID: column?.versionDetailLevel0ID,
    data: column?.name,
    versionDetailL1: [
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDDescription,
        data: escapeSlashes(column.description),
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDBold,
        data: column.isBold ? 'true' : 'false',
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDItalic,
        data: column.isItalic ? 'true' : 'false',
      },
    ],
  };
  const columnNotes = notes.filter(n => n?.columnId?.toString() === column?.id?.toString());
  data.versionDetailL1.push(transformColumnNotesToBackendPatch(column, columnNotes));
  return data;
};

export const transformRowsToBackEndForPatch = data => {
  const dataTransformed = {
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.rowId,
    versionDetailL0: [
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDStyle,
        data: data.style,
      },
    ],
  };
  // eslint-disable-next-line no-unused-expressions
  data?.columns &&
    data.columns.forEach(column => {
      dataTransformed?.versionDetailL0.push(
        transformColumnsToBackendPatch(column, data?.columnNotes),
      );
    });
  return dataTransformed;
};
