import { escapeSlashes, restoreSlashes } from '../../utils/IngFeatTransparencyToolUtils.js';

const splitTimeFromDate = name => {
  const val = name?.match(/\b([01]\d|2[0-3]):[0-5]\d:[0-5]\d\b/g)[0]?.split(':');
  return val?.length ? `${val[0]}:${val[1]}` : '';
};

// eslint-disable-next-line
const getFiles = d => {
  return {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'REVIEW_ALLEGATO',
    data: d.id,
    versionDetailL1: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'FILENAME',
        data: d.name,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'FILESIZE',
        data: d.size,
      },
    ],
  };
};

// eslint-disable-next-line
const getEmails = (d, count) => {
  return {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'REVISORI',
    data: count,
    versionDetailL1: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'REVISORE',
        data: d.labelText,
      },
    ],
  };
};

export const transformRequestReviewToBackend = data => {
  const dataTransformed = {
    itemTypeKey: 'REVIEW_TYPE',
    itemTypeValue: 'REVIEW_REQUEST',
    name: data.name,
    validity: data.validity,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_REVISIONE',
        data: escapeSlashes(data.message),
      },
    ],
  };
  // eslint-disable-next-line no-unused-expressions
  data.files &&
    data.files.forEach(d => {
      dataTransformed.versionDetailL0.push(getFiles(d));
    });
  // eslint-disable-next-line no-unused-expressions
  data.emailList &&
    data.emailList.forEach((d, i) => {
      dataTransformed.versionDetailL0.push(getEmails(d, i + 1));
    });
  return dataTransformed;
};

export const transformReviewRequestToFrontEnd = data => {
  const dataTransformed = {
    note: restoreSlashes(data.description),
    reviewer: data?.versionDetailL0
      ?.filter(d => d.itemTypeValue === 'REVISORI')
      ?.flatMap(v => v?.versionDetailL1?.map(d => d.data))
      ?.join(', '),
    attachment: data?.versionDetailL0
      ?.filter(d => d.itemTypeValue === 'REVIEW_ALLEGATO')
      ?.map(d => d.data)
      .join('__'),
    id: data.itemsVersionsID,
    requestId: data.itemsVersionsID,
    user: data.itemUser,
    dateAndTime: `${data.validity} ${splitTimeFromDate(data?.name)}`,
  };
  return dataTransformed;
};
