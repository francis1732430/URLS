import { escapeSlashes, restoreSlashes } from '../../utils/IngFeatTransparencyToolUtils.js';

const splitTimeFromDate = name => {
  const val = name?.match(/\b([01]\d|2[0-3]):[0-5]\d:[0-5]\d\b/g)[0]?.split(':');
  return val?.length ? `${val[0]}:${val[1]}` : '';
};

// eslint-disable-next-line
const getFiles = d => {
  return {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'REVIEW_ALLEGATO',
    data: d.id,
    versionDetailL1: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'FILENAME',
        data: d.name,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'FILESIZE',
        data: d.size,
      },
    ],
  };
};

export const transformInsertReviewToBackend = data => {
  const dataTransformed = {
    itemTypeKey: 'REVIEW_TYPE',
    itemTypeValue: 'REVIEW',
    name: data.name,
    validity: data.validity,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_REVISIONE',
        data: escapeSlashes(data.message),
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'REVISORE',
        data: data.reviewer,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'REVIEW_ESITO',
        data: data.reviewStatus === true ? 1 : 0,
      },
    ],
  };

  // eslint-disable-next-line no-unused-expressions
  data.files &&
    data.files.forEach(d => {
      dataTransformed.versionDetailL0.push(getFiles(d));
    });
  return dataTransformed;
};

export const transformReviewToFrontEnd = data => {
  const dataTransformed = {
    note: restoreSlashes(
      data.versionDetailL0?.find(d => d.itemTypeValue === 'DESCRIZIONE_REVISIONE')?.data,
    ),
    reviewer: data?.versionDetailL0?.find(d => d.itemTypeValue === 'REVISORE')?.data,
    attachment: data?.versionDetailL0
      ?.filter(d => d.itemTypeValue === 'REVIEW_ALLEGATO')
      ?.map(d => d.data)
      .join('__'),
    id: data.itemsVersionsID,
    review:
      data?.versionDetailL0?.find(d => d.itemTypeValue === 'REVIEW_ESITO')?.data === '1'
        ? 'OK'
        : 'KO',
    user: data.itemUser,
    dateAndTime: `${data.validity} ${splitTimeFromDate(data?.name)}`,
  };

  return dataTransformed;
};
