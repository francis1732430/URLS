import { deriveData } from '../../utils/globalApiKeys.js';
import {
  escapeSlashes,
  generateId,
  restoreSlashes,
  transformDateToBackend,
} from '../../utils/IngFeatTransparencyToolUtils.js';

// eslint-disable-next-line no-unused-vars
const backendData = {
  itemTypeKey: 'RULE_TYPE',
  itemTypeValue: 'REGOLA',
  name: 'name',
  validity: 'validity',
  versionDetailL0: [
    {
      itemTypeKey: 'FIELD',
      itemTypeValue: 'DESCRIZIONE_ITEM',
      data: 'DESCRIZIONE REGOLA',
    },
    {
      itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
      itemTypeValue: 'REGOLA_CONDIZIONE',
      data: ' 1 (FROM RIGA N° FIELD)',
      versionDetailL1: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
          data: 'N° CAMPO FILE INDICE',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'RULE_CONDITION_OPERATOR',
          data: 'RULE_CONDITION_OPERATOR',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'VALORE',
          data: 'VALORE',
        },

        {
          // (if not null)
          itemTypeKey: 'FIELD',
          itemTypeValue: 'ASSOCIATO_A_RIGA',
          data: 'IN ASSOCIAZIONE A RIGA N°',
        },
      ],
    },
    {
      itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
      itemTypeValue: 'REGOLA_AZIONE',
      data: 'ITEM_ID (ID of the Item selected in SELEZIONA DDL)',
      versionDetailL1: [
        {
          // if not null (only for item of type ROWS)
          itemTypeKey: 'FIELD',
          itemTypeValue: 'COLONNA_ID',
          data: 'VersionDetailL0_ID for the selected column in COLONNA N° field',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Value from VALORE field',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'VALORE',
          data: 'VALORE',
        },

        {
          // (if visible = false)
          itemTypeKey: 'FIELD',
          itemTypeValue: 'VISIBLE',
          data: 'Value from VISIBLE field°',
        },

        {
          // (if bold = 1)
          itemTypeKey: 'FIELD',
          itemTypeValue: 'BOLD',
          data: 'Value from BOLD field°',
        },

        {
          // (if ITALIC = false)
          itemTypeKey: 'FIELD',
          itemTypeValue: 'ITALIC',
          data: 'Value from ITALIC field°',
        },
      ],
    },
  ],
};

// eslint-disable-next-line no-unused-vars
const frontEndData = {
  id: '12345',
  name: 'Row 1',
  description: 'desc',
  validity: '2022-05-18T12:29:31.125Z',
  actions: [
    {
      appliedToElement: 3,
      appliedToRule: 3,
      appliedToColumn: 3,
      value: '123',
      isVisible: false,
      isBold: true,
      isItalic: false,
      id: 1,
    },
    {
      appliedToElement: '2',
      appliedToRule: 2,
      appliedToColumn: 4,
      value: '1456',
      isVisible: true,
      isBold: false,
      isItalic: true,
      id: 2,
    },
  ],
  conditions: [
    {
      column: 'Col1',
      value: 'desc1',
      operator: '1',
      index: '2',
      id: 1,
    },
    {
      column: 'Col2',
      value: 'desc1',
      operator: '2',
      index: '1',
      id: 2,
    },
  ],
};

// Fronted TO Backend START
const transformConditionsToBackend = (column, rigaN, columns) => {
  const data = {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'REGOLA_CONDIZIONE',
    data: column.id,
    versionDetailL1: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
        data: column.column,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'RULE_CONDITION_OPERATOR',
        data: column.operator,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'VALORE',
        data: column.value,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'ASSOCIATO_A_RIGA',
        // data: column.rowNo,
        data: column.rowNo && column.rowNo !== 'undefined' ? column.rowNo : '0',
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'RULE_CONDITION_INDEX',
        data: columns.findIndex(d => d?.id?.toString() === column?.rowNo?.toString()) + 1,
      },
    ],
  };
  return data;
};

const transformActionsToBackend = column => {
  const data = {
    itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
    itemTypeValue: 'REGOLA_AZIONE',
    data: column.appliedToRule,
    versionDetailL1: [
      ...(column.appliedToColumn && column.appliedToColumn !== 'undefined'
        ? [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'COLONNA_ID',
              data: column.appliedToColumn,
            },
          ]
        : []),
      ...(column.appliedToElement && column.appliedToElement !== 'undefined'
        ? [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'SI_APPLICA_A',
              data: column.appliedToElement,
            },
          ]
        : []),
      ...(column.value && column.value !== 'undefined'
        ? [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: escapeSlashes(column.value),
            },
          ]
        : []),
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'VISIBLE',
        data: column.isVisible ? 'true' : 'false',
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'BOLD',
        data: column.isBold ? 'true' : 'false',
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'ITALIC',
        data: column.isItalic ? 'true' : 'false',
      },
    ],
  };
  return data;
};

export const transformRulesToBackEnd = data => {
  const dataTransformed = {
    itemTypeKey: 'RULE_TYPE',
    itemTypeValue: 'REGOLA',
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.ruleId,
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'DESCRIZIONE_ITEM',
        data: escapeSlashes(data.description),
      },
    ],
  };
  // eslint-disable-next-line no-unused-expressions
  data.conditions &&
    data.conditions.forEach((condition, i, conditions) => {
      dataTransformed.versionDetailL0.push(transformConditionsToBackend(condition, i, conditions));
    });
  // eslint-disable-next-line no-unused-expressions
  data.actions &&
    data.actions.forEach(action => {
      dataTransformed.versionDetailL0.push(transformActionsToBackend(action));
    });
  return dataTransformed;
};
// Fronted TO Backend END

//  Backend TO Fronted START

const getConditions = columData => ({
  column: columData.versionDetailL1?.find(d => d.itemTypeValue === 'NUMERO_CAMPO_FILE_INDICE')
    ?.data,
  value: columData.versionDetailL1?.find(d => d.itemTypeValue === 'VALORE')?.data,
  operator: columData.versionDetailL1
    ?.find(d => d.itemTypeValue === 'RULE_CONDITION_OPERATOR')
    ?.data?.toString(),
  rowNo: columData.versionDetailL1
    ?.find(d => d.itemTypeValue === 'ASSOCIATO_A_RIGA')
    ?.data?.toString(),
  id: columData?.data,
  versionDetailLevel1IDColumn: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'NUMERO_CAMPO_FILE_INDICE',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDValore: columData.versionDetailL1?.find(d => d.itemTypeValue === 'VALORE')
    ?.versionDetailLevel1ID,
  versionDetailLevel1IDRule: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'RULE_CONDITION_OPERATOR',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDRiga: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'ASSOCIATO_A_RIGA',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDIndex: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'RULE_CONDITION_INDEX',
  )?.versionDetailLevel1ID,
  versionDetailLevel0ID: columData?.versionDetailLevel0ID,
});
const getActions = columData => ({
  appliedToElement: columData.versionDetailL1
    ?.find(d => d.itemTypeValue === 'SI_APPLICA_A')
    ?.data?.toString(),
  appliedToRule: columData?.data?.toString(),
  appliedToColumn: columData.versionDetailL1
    ?.find(d => d.itemTypeValue === 'COLONNA_ID')
    ?.data?.toString(),
  value: restoreSlashes(
    columData.versionDetailL1?.find(d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA')?.data,
  ),
  isVisible: columData.versionDetailL1?.find(d => d.itemTypeValue === 'VISIBLE')?.data === 'true',
  isBold: columData.versionDetailL1?.find(d => d.itemTypeValue === 'BOLD')?.data === 'true',
  isItalic: columData.versionDetailL1?.find(d => d.itemTypeValue === 'ITALIC')?.data === 'true',
  id: generateId(),
  versionDetailLevel1IDSIApplica: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'SI_APPLICA_A',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDColonaId: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'COLONNA_ID',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDDescription: columData.versionDetailL1?.find(
    d => d.itemTypeValue === 'DESCRIZIONE_IN_STAMPA',
  )?.versionDetailLevel1ID,
  versionDetailLevel1IDVisible: columData.versionDetailL1?.find(d => d.itemTypeValue === 'VISIBLE')
    ?.versionDetailLevel1ID,
  versionDetailLevel1IDBold: columData.versionDetailL1?.find(d => d.itemTypeValue === 'BOLD')
    ?.versionDetailLevel1ID,
  versionDetailLevel1IDItalic: columData.versionDetailL1?.find(d => d.itemTypeValue === 'ITALIC')
    ?.versionDetailLevel1ID,
  versionDetailLevel0ID: columData?.versionDetailLevel0ID,
});
export const transformRulesToFrontEnd = data => {
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    id: data?.itemsVersionsID?.toString(),
    name: data.name,
    validity: data.validity,
    description: restoreSlashes(
      data.versionDetailL0?.find(d => d.itemTypeValue === 'DESCRIZIONE_ITEM')?.data ||
        data?.description,
    ),
    ruleId: data?.itemID?.toString(),
    version: data.versionNumber,
    versionDetailLevel0IDDescription: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'DESCRIZIONE_ITEM',
    )?.versionDetailLevel0ID,
  };
  const columnsData = data.versionDetailL0?.filter(d => d.itemTypeKey === 'VERSION_DETAIL_LEVEL_1');
  dataTransformed.conditions = [];
  dataTransformed.actions = [];
  // eslint-disable-next-line no-unused-expressions
  columnsData &&
    columnsData.forEach((column, i) => {
      if (column.itemTypeValue === 'REGOLA_CONDIZIONE') {
        dataTransformed.conditions.push(getConditions(column, i));
      } else {
        dataTransformed.actions.push(getActions(column, i));
      }
    });
  return dataTransformed;
};

const transformActionsToBackendForPatch = column => {
  const data = {
    versionDetailLevel0ID: column?.versionDetailLevel0ID,
    data: column.appliedToRule,
    versionDetailL1: [
      ...(column.appliedToColumn && column.appliedToColumn !== 'undefined'
        ? [
            {
              versionDetailLevel1ID: column?.versionDetailLevel1IDColonaId,
              data: column.appliedToColumn,
            },
          ]
        : []),
      ...(column.appliedToElement && column.appliedToElement !== 'undefined'
        ? [
            {
              versionDetailLevel1ID: column?.versionDetailLevel1IDSIApplica,
              data: column.appliedToElement,
            },
          ]
        : []),
      ...(column.value && column.value !== 'undefined'
        ? [
            {
              versionDetailLevel1ID: column?.versionDetailLevel1IDDescription,
              data: escapeSlashes(column.value),
            },
          ]
        : []),
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDVisible,
        data: column.isVisible ? 'true' : 'false',
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDBold,
        data: column.isBold ? 'true' : 'false',
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDItalic,
        data: column.isItalic ? 'true' : 'false',
      },
    ],
  };
  return data;
};

// Fronted TO Backend START
const transformConditionsToBackendPatch = (column, rigaN, columns) => {
  const data = {
    versionDetailLevel0ID: column?.versionDetailLevel0ID,
    data: column.id,
    versionDetailL1: [
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDColumn,
        data: column.column,
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDRule,
        data: column.operator,
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDValore,
        data: column.value,
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDRiga,
        // data: column.rowNo,
        data: column.rowNo && column.rowNo !== 'undefined' ? column.rowNo : '0',
      },
      {
        versionDetailLevel1ID: column?.versionDetailLevel1IDIndex,
        // data: column.rowNo,
        data: columns.findIndex(d => d?.id?.toString() === column?.rowNo?.toString()) + 1,
      },
    ],
  };
  return data;
};

//  Backend TO Fronted END
export const transformRulesToBackEndForPatch = data => {
  const dataTransformed = {
    name: data.name,
    validity: transformDateToBackend(data.validity),
    itemsVersionsID: data?.id,
    itemID: data?.ruleId,
    versionDetailL0: [
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDDescription,
        data: escapeSlashes(data.description),
      },
    ],
  };

  // eslint-disable-next-line no-unused-expressions
  data.conditions &&
    data.conditions.forEach((condition, i) => {
      dataTransformed.versionDetailL0.push(
        transformConditionsToBackendPatch(condition, i, data.conditions),
      );
    });
  // eslint-disable-next-line no-unused-expressions
  data.actions &&
    data.actions.forEach(action => {
      dataTransformed.versionDetailL0.push(transformActionsToBackendForPatch(action));
    });

  return dataTransformed;
};
