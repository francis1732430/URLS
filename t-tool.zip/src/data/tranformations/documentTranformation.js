import { deriveData } from '../../utils/globalApiKeys.js';
import { transformDateToBackend } from '../../utils/IngFeatTransparencyToolUtils.js';
import Singleton from '../../utils/SingletonFactory.js';

// Fronted TO Backend START
const transformRulesToBackend = (column, i) => ({
  itemOrder: i + 1,
  itemsVersionsID: column.id,
});

export const transformDocumentsToBackend = data => {
  const dataTransformed = {
    itemTypeKey: 'DOCUMENT_TYPE',
    itemTypeValue: 'DOCUMENTO',
    name: data.name,
    validity: transformDateToBackend(data.start_date),
    id: data.id,
    ...(data.docId && { itemID: data.docId }),
    ...(data.itemID && { itemID: data.itemID }),
    ...(data.id && { itemsVersionsID: data.id }),
    versionDetailL0: [
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
        data: data.statusId || data.status,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
        data: data.productId || data.product,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'CODICE',
        data: data.code,
      },
      {
        itemTypeKey: 'FIELD',
        itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
        data: data.typeId || data.type,
      },
    ],
    itemChildren: [],
  };
  // eslint-disable-next-line no-unused-expressions
  data.selectedListRule?.[0]?.rules &&
    data.selectedListRule?.[0]?.rules.forEach((rule, i) => {
      dataTransformed.itemChildren.push(transformRulesToBackend(rule, i));
    });

  // eslint-disable-next-line no-unused-expressions
  data.selectedListSection?.[0]?.sections &&
    data.selectedListSection?.[0]?.sections.forEach((section, i) => {
      dataTransformed.itemChildren.push(transformRulesToBackend(section, i));
    });

  return dataTransformed;
};

// Fronted TO Backend END

//  Backend TO Fronted START

const getRules = columData => ({
  name: columData.itemOrder,
  id: columData?.itemsVersionsID?.toString(),
});

const getFiles = fileData => ({
  versionDetailLevel0ID: fileData?.versionDetailLevel0ID?.toString(),
  id: fileData?.data,
  name: fileData?.versionDetailL1?.find(d => d.itemTypeValue === 'FILENAME')?.data,
});

export const transformDocumentsToFrontEnd = data => {
  const obj = new Singleton();
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    status: obj.getLookupValuesByKey(
      data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_STATUS')?.data,
    ),
    product: obj.getLookupValuesByKey(
      data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT')?.data,
    ),
    type: obj.getLookupValuesByKey(
      data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT_TYPE')?.data,
    ),
    code: data.versionDetailL0?.find(d => d.itemTypeValue === 'CODICE')?.data,
    start_date: data.validity,
    id: data.itemsVersionsID?.toString(),
    name: data.name,
    docId: data.itemID?.toString(),
    version: data.versionNumber,
    selectedListRule: [
      {
        rules: [],
      },
    ],
    statusId: data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_STATUS')?.data,
    productId: data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT')?.data,
    typeId: data?.versionDetailL0?.find(d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT_TYPE')
      ?.data,
    versionDetailLevel0IDCodice: data.versionDetailL0?.find(d => d.itemTypeValue === 'CODICE')
      ?.versionDetailLevel0ID,
    versionDetailLevel0IDStatus: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'LOOKUP_DATA_ID_STATUS',
    )?.versionDetailLevel0ID,
    versionDetailLevel0IDProduct: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT',
    )?.versionDetailLevel0ID,
    versionDetailLevel0IDType: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'LOOKUP_DATA_ID_PRODUCT_TYPE',
    )?.versionDetailLevel0ID,
    templateFile: data.versionDetailL0?.find(d => d.itemTypeValue === 'JASPER_TEMPLATE_FILE')?.data,
    versionDetailLevel0IDTemplateFile: data.versionDetailL0?.find(
      d => d.itemTypeValue === 'JASPER_TEMPLATE_FILE',
    )?.versionDetailLevel0ID,
  };
  // eslint-disable-next-line no-unused-expressions
  data.itemChildren &&
    data.itemChildren.forEach(column => {
      dataTransformed.selectedListRule[0].rules.push(getRules(column));
    });

  const filesData = data.versionDetailL0?.filter(d => d.itemTypeKey === 'VERSION_DETAIL_LEVEL_1');
  dataTransformed.files = [];
  // eslint-disable-next-line no-unused-expressions
  filesData &&
    filesData.forEach(file => {
      dataTransformed.files.push(getFiles(file));
    });

  return dataTransformed;
};

export const transformDocumentsListToFrontEnd = documentList => {
  const dataList = [];

  documentList.forEach(data => {
    dataList.push(transformDocumentsToFrontEnd(data));
  });

  return dataList;
};

export const transformParentDocumentsToFrontEnd = data => {
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    status: data.status,
    product: data.product,
    type: data.productType,
    code: data.code,
    start_date: data.validity,
    id: data.itemsVersionsIDParent?.toString(),
    name: data.name,
    docId: data.itemID?.toString(),
    version: data.versionNumber,
  };

  return dataTransformed;
};

export const transformParentDocumentsListToFrontEnd = (documentList = []) => {
  const dataList = [];

  documentList.forEach(data => {
    dataList.push(transformParentDocumentsToFrontEnd(data));
  });

  return dataList;
};
//  Backend TO Fronted END

export const transformLookUpDataToFrontEnd = (datas, type) => {
  // eslint-disable-next-line
  const dataList = datas
    ?.filter(
      data =>
        data.ldKey === type &&
        !(data.ldValue === 'DOCUMENTO' && type === 'DOCUMENT_TYPE') &&
        !(data.ldValue === 'REGOLA' && type === 'DOCUMENT_TYPE') &&
        !(data.ldValue === 'undefined' && type === 'DOCUMENT_TYPE'),
    )
    // eslint-disable-next-line
    ?.map(data => {
      return {
        id: data.lookupDataID?.toString(),
        name: data.ldValue,
      };
    });
  if (dataList && type === 'DOCUMENT_TYPE') {
    const obj = new Singleton();
    obj.createdLookupValues(datas);
  }
  return dataList;
};

export const transformPrintPreviewToFrontEnd = data => {
  const level1 = data?.versionDetailL1;
  // eslint-disable-next-line
  data = deriveData(data);
  const dataTransformed = {
    id: data?.versionDetailLevel0ID?.toString(),
    uuid: data?.data,
    name: level1?.find(d => d.itemTypeValue === 'FILENAME')?.data,
    size: level1?.find(d => d.itemTypeValue === 'FILESIZE')?.data,
    version: level1?.find(d => d.itemTypeValue === 'VERSIONE_DOCUMENTO')?.data,
  };

  return dataTransformed;
};

export const transformDocumentsToBackendForPatch = data => {
  const dataTransformed = {
    name: data.name,
    validity: transformDateToBackend(data.start_date),
    id: data.id,
    ...(data.docId && { itemID: data.docId }),
    ...(data.itemID && { itemID: data.itemID }),
    ...(data.id && { itemsVersionsID: data.id }),
    versionDetailL0: [
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDStatus,
        data: data.statusId || data.status,
      },
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDProduct,
        data: data.productId || data.product,
      },
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDCodice,
        data: data.code,
      },
      {
        versionDetailLevel0ID: data?.versionDetailLevel0IDType,
        data: data.typeId || data.type,
      },
    ],
  };

  if (data?.versionDetailLevel0IDTemplateFile) {
    dataTransformed.versionDetailL0?.push({
      versionDetailLevel0ID: data?.versionDetailLevel0IDTemplateFile,
      data: data?.templateFile,
    });
  }

  return dataTransformed;
};
