export const navigationLinks = [
  {
    label: 'Elenco Documenti',
    redirectToPath: 'list_documents',
    isSelected: true,
    containerClass: 'container_list_documents',
  },
  {
    label: 'Dettaglio Documenti',
    redirectToPath: 'edit_documents',
    isSelected: false,
    containerClass: 'container_edit_documents',
  },
  {
    label: 'Review Documenti',
    redirectToPath: 'reviews_documents',
    isSelected: false,
    containerClass: 'container_review_documents',
  },
];
