export const sectionsHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID',
  },
  {
    headerClass: 'section_header',
    headerValue: 'Nome sezione',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Descrizione in stampa',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Versione',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Valido dal',
  },
];

export const subSectionsHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID',
  },
  {
    headerClass: 'subsection_header',
    headerValue: 'Nome sotto sezione',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Descrizione in stampa',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Versione',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Valido dal',
  },
];

export const rowsHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID',
  },
  {
    headerClass: 'row_header',
    headerValue: 'Nome riga',
  },
  {
    headerClass: 'type_header',
    headerValue: 'Tipo',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Versione',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Valido dal',
  },
];

export const notesHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID',
  },
  {
    headerClass: 'note_header',
    headerValue: 'Nome nota',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Descrizione in stampa',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Versione',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Valido dal',
  },
];

export const prova = [
  {
    propertyName: 'name',
    propertyClass: 'left_text_align',
  },
  {
    propertyName: 'description',
    propertyClass: 'left_text_align',
  },
  {
    propertyName: 'type',
    propertyClass: 'left_text_align',
  },
  {
    propertyName: 'version',
    propertyClass: '',
  },
  {
    propertyName: 'from',
    propertyClass: '',
  },
];

export const rulesHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID',
  },
  {
    headerClass: 'note_header',
    headerValue: 'Nome regola',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Descrizione',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Versione',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Valido dal',
  },
];
