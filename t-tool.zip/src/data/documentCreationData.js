export const versionList = [
  {
    id: '1',
    name: 'VERS 9 DEL 31.10.2021',
  },
  {
    id: '2',
    name: 'VERS 10 DEL 31.11.2021',
  },
];

export const productList = [
  {
    id: '1',
    name: 'Product 1',
  },
  {
    id: '2',
    name: 'Product 2',
  },
];

export const typeList = [
  {
    id: '1',
    name: 'Type 1',
  },
  {
    id: '2',
    name: 'Type 2',
  },
];

export const statusList = [
  {
    id: 1,
    name: 'IN SVILUPPO',
  },
];

export const styleList = [
  {
    id: '1',
    name: 'Style 1',
  },
  {
    id: '2',
    name: 'Style 2',
  },
];
