export const contentData = {
  title: 'DOCUMENTO DI SINTESI',
  subTitle: [
    'N* 1 del 31/12/2020',
    'relativo at',
    'Conto Corrente Arancio al servizi Conto Corrente Arancio',
  ],
  section: 'Condizioni Econimiche',
  subSection: [
    {
      content: 'Spese fisse',
      class: 'document-sub-title-header',
      propertyName: 'title',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 10' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: 'Terunto del conto',
      class: 'sub-title-content orange sub-title-header-font',
      propertyName: 'header',
    },
    {
      content: [
        { desc: 'Spese per operutoro del conto', value: '€ 10' },
        { desc: 'Spese per operutoro del conto', value: '€ 500' },
        { desc: 'Spese per operutoro del conto', value: '€ 20' },
      ],
      parentClass: 'content-multiple-container',
      childClass: 'content-multiple light-grey',
      propertyName: 'content',
      isMultiple: true,
    },
    {
      content: 'Gestinoe liqiudito',
      class: 'sub-title-content orange sub-title-header-font',
      propertyName: 'header',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 10' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 710' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: 'Gestinoe liqiudito',
      class: 'sub-title-content orange sub-title-header-font',
      propertyName: 'header',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 190' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: [{ desc: 'Servizi di pagamento', value: '€ 0' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: 'Home Banking',
      class: 'document-sub-title-header',
      propertyName: 'title',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 10' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: [
        { desc: 'Spese per operutoro del conto', value: '€ 10' },
        { desc: 'Spese per operutoro del conto', value: '€ 500' },
        { desc: 'Spese per operutoro del conto', value: '€ 20' },
      ],
      parentClass: 'content-multiple-container',
      childClass: 'content-multiple light-grey',
      propertyName: 'content',
      isMultiple: true,
    },
    {
      content: 'Gestinoe liqiudito',
      class: 'sub-title-content orange sub-title-header-font',
      propertyName: 'header',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 10' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 710' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: 'Gestinoe liqiudito',
      class: 'sub-title-content orange sub-title-header-font',
      propertyName: 'header',
    },
    {
      content: [{ desc: 'Spese per operutoro del conto', value: '€ 190' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
    {
      content: [{ desc: 'Servizi di pagamento', value: '€ 0' }],
      class: 'sub-title-content light-grey',
      propertyName: 'content',
      isMultiple: false,
    },
  ],
};
