export const messages = {
  newVersion: {
    document: [
      'Sei sicuro di voler creare una nuova versione del documento?',
      `Troverai tutte le versioni del documento nell'elenco documenti.`,
    ],
    Sezioni: [
      'Sei sicuro di voler creare una nuova versione della sezione?',
      `Troverai tutte le versioni della sezione cliccando sul pulsante "Aggiungi".`,
    ],
    'Sotto Sezioni': [
      'Sei sicuro di voler creare una nuova versione della sottosezione?',
      `Troverai tutte le versioni della sottosezione cliccando sul pulsante "Aggiungi".`,
    ],
    Righe: [
      'Sei sicuro di voler creare una nuova versione della riga?',
      `Troverai tutte le versioni della riga cliccando sul pulsante "Aggiungi".`,
    ],
    Nota: [
      'Sei sicuro di voler creare una nuova versione della nota?',
      `Troverai tutte le versioni della nota cliccando sul pulsante "Aggiungi".`,
    ],

    Regola: [
      'Sei sicuro di voler creare una nuova versione della regola?',
      `Troverai tutte le versioni della regola cliccando sul pulsante "Aggiungi".`,
    ],
  },
  newDuplication: {
    document: ['Sei sicuro di voler creare una copia del documento?'],
    Sezioni: ['Sei sicuro di voler creare una copia della sezione?'],
    'Sotto Sezioni': ['Sei sicuro di voler creare una copia della sottosezione?'],
    Righe: ['Sei sicuro di voler creare una copia della riga?'],
    Nota: ['Sei sicuro di voler creare una copia della nota?'],
    Regola: ['Sei sicuro di voler creare una copia della regola?'],
  },
  removeRow: {
    document: [
      `Sei sicuro di voler dismettere il documento?
    'Ricorda che un documento dismesso non è più recuperabile.`,
    ],
    Sezioni: [`Sei sicuro di voler eliminare l'associazione della sezione al documento?`],
    'Sotto Sezioni': [
      `Sei sicuro di voler eliminare l'associazione della sottosezione al documento?`,
    ],
    Righe: [`Sei sicuro di voler eliminare l'associazione della riga al documento?`],
    Regola: [`Sei sicuro di voler eliminare l'associazione della regola al documento?`],
    Nota: [`Sei sicuro di voler eliminare l'associazione della nota al documento?`],
  },
  file: {
    rootPathId: 'DOCUMENTTEMPLATEADMINISTRATION',
    keyType: 'PATH_KEY',
    storage: 'FILESTORE',
    documentTypeId: 'GENERIC_DOCUMENT',
  },
  email: {
    requestReviewSubject: 'REVIEW_REQUEST_EMAIL_SUBJECT',
    requestReviewMessage: 'REVIEW_REQUEST_EMAIL_MESSAGE',
  },
  existingElementAssociation: {
    SezioniToRegola: [
      `Sezione collegata alle Regole. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Regole.`,
    ],
    SottoSezioniToSezioni: [
      `Sottosezione collegata alle Sezioni. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Sezioni.`,
    ],
    SottoSezioniToRegola: [
      `Sottosezione collegata alle Regole. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Regole.`,
    ],
    RigheToSottoSezioni: [
      `Riga collegata alle Sottosezioni. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Sottosezioni.`,
    ],
    RigheToRegola: [
      `Riga collegata alle Regole. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Regole.`,
    ],
    NoteToRighe: [
      `Nota collegata alle Righe. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Righe.`,
    ],
    NoteToRegola: [
      `Nota collegata alle Regole. Se vuoi eliminarla, devi prima rimuovere l'associazione alle Regole.`,
    ],
  },
  reviews: {
    requestReview: {
      requestConfirmation: ['Sei sicuro di voler inviare la richiesta di revisione del documento?'],
      requestReviewExistingError: [
        `Per questo documento non è stata ancora approvata una richiesta di revisione preventiva.`,
        `Si prega di verificare con il recensore.`,
        `Non puoi creare una richiesta di revisione mentre l'approvazione è in attesa.`,
      ],
    },
    insertReview: {
      requestConfirmation: ['Sei sicuro di voler caricare la revisione del documento?'],
    },
  },
  createDocument: {
    requestConfirmation: [
      'Sei sicuro di voler interrompere la creazione del documento?',
      'Ricorda che gli elementi creati saranno in ogni caso recuperabili.',
    ],
  },
  save: {
    success: ['Elemento salvato correttamente!'],
    error: ['Attenzione! L’elemento non è stato salvato'],
  },
  tabClosed: {
    dialog: [
      'Sono state apportate modifiche alla pagina senza salvare.',
      'Se procedi le modifiche saranno annullate.',
      'Intendi procedere?',
    ],
  },
};
