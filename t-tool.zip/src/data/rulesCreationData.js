export const operators = [
  {
    name: '=',
    id: 1,
  },
  {
    name: '<=',
    id: 2,
  },
  {
    name: '>=',
    id: 3,
  },
  {
    name: '!=',
    id: 4,
  },
];

export const appliesToElements = [
  {
    name: 'RIGA',
    id: 1,
  },
  {
    name: 'SEZIONE',
    id: 2,
  },
  {
    name: 'SOTTA SEZIONE',
    id: 3,
  },
  {
    name: 'NOTTA',
    id: 4,
  },
];
export const appliesToRules = [
  {
    name: 'Rule 1',
    id: 1,
    elementId: 1,
  },
  {
    name: 'Rule 2',
    id: 2,
    elementId: 2,
  },
  {
    name: 'Rule 3',
    id: 3,
    elementId: 2,
  },
  {
    name: 'Rule 4',
    id: 4,
    elementId: 4,
  },
];
export const appliesToColumns = [
  {
    name: 'Col 1',
    id: 1,
    ruleId: 1,
  },
  {
    name: 'col 2',
    id: 2,
    ruleId: 2,
  },
  {
    name: 'col 3',
    id: 3,
    ruleId: 4,
  },
  {
    name: 'Col 4',
    id: 4,
    ruleId: 2,
  },
];

export const rulesData = [
  {
    id: '12345',
    name: 'Row 1',
    description: 'desc',
    validity: new Date(),
    conditions: [
      {
        column: 'Col1',
        value: 'desc1',
        operator: '1',
        index: '2',
        id: 1,
      },
      {
        column: 'Col2',
        value: 'desc1',
        operator: '2',
        index: '1',
        id: 2,
      },
    ],
    actions: [
      {
        appliedToElement: 3,
        appliedToRule: 3,
        appliedToColumn: 3,
        value: '123',
        isVisible: false,
        isBold: true,
        isItalic: false,
        id: 1,
      },
      {
        appliedToElement: '2',
        appliedToRule: 2,
        appliedToColumn: 4,
        value: '1456',
        isVisible: true,
        isBold: false,
        isItalic: true,
        id: 2,
      },
    ],
  },
];

export const rulesData1 = {
  id: '98',
  name: 'Rule 1',
  description: 'Rule 1 Desc',
  validity: '2023-01-02',
  actions: [
    {
      appliedToElement: '33',
      appliedToRule: '199',
      appliedToColumn: '6',
      value: '123',
      isVisible: false,
      isBold: false,
      isItalic: false,
      id: '19529-8975-72821',
      versionDetailLevel1IDSIApplica: 33,
      versionDetailLevel1IDColonaId: 7,
      versionDetailLevel1IDDescription: 8,
      versionDetailLevel1IDVisible: 9,
      versionDetailLevel1IDBold: 10,
      versionDetailLevel1IDItalic: 11,
      versionDetailLevel0ID: 6,
    },
    {
      appliedToElement: '34',
      appliedToRule: '98',
      value: '',
      isVisible: false,
      isBold: false,
      isItalic: false,
      id: '18378-13193-6947',
      versionDetailLevel1IDSIApplica: 34,
      versionDetailLevel1IDDescription: 12,
      versionDetailLevel1IDVisible: 13,
      versionDetailLevel1IDBold: 14,
      versionDetailLevel1IDItalic: 15,
      versionDetailLevel0ID: 6,
    },
    {
      appliedToElement: '34',
      appliedToRule: '98',
      value: '9898',
      isVisible: false,
      isBold: false,
      isItalic: false,
      id: '18378-13193-6947',
    },
  ],
  conditions: [
    {
      column: 'Col1',
      value: 'desc1',
      operator: '43',
      rowNo: '2',
      id: '20290-45661-75153',
      versionDetailLevel1IDColumn: 40,
      versionDetailLevel1IDValore: 3,
      versionDetailLevel1IDRule: 43,
      versionDetailLevel1IDRiga: 46,
      versionDetailLevel0ID: 2,
    },
    {
      column: 'Col2',
      value: 'desc1',
      operator: '42',
      rowNo: '1',
      id: '45479-85842-65045',
      versionDetailLevel1IDColumn: 39,
      versionDetailLevel1IDValore: 5,
      versionDetailLevel1IDRule: 42,
      versionDetailLevel1IDRiga: 45,
      versionDetailLevel0ID: 4,
    },
    {
      column: 'Col2',
      value: 'desc1hjhkj',
      operator: '42',
      rowNo: '1',
      id: '45479-85842-65045',
    },
  ],
  isNotSaved: false,
  ruleId: '1',
  versionDetailLevel0IDDescription: 1,
  versionID: 123,
};
