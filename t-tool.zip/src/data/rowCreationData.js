export const rowStyles = [
  {
    name: 'style 1',
    id: 1,
  },
  {
    name: 'Style 2',
    id: 2,
  },
];

export const notes = [
  {
    name: 'note1',
    description: '',
    validity: '2022-01-03',
    id: 1,
  },
  {
    name: 'note2',
    description: '',
    validity: '2022-01-03',
    id: 2,
  },
  {
    name: 'note3',
    description: '',
    validity: '2022-01-03',
    id: 3,
  },
];
export const radioData = [
  {
    name: 'Bold',
    id: 1,
  },
  {
    name: 'Italic',
    id: 2,
  },
];

export const rowData = [
  {
    id: 1,
    name: 'Row 1',
    validity: new Date(),
    style: '1',
    columns: [
      {
        name: 'Col1',
        description: 'desc1',
        style: '1',
        id: 1,
      },
      {
        name: 'Col2',
        description: 'desc2',
        style: '2',
        id: 2,
      },
    ],
    columnNotes: [
      {
        name: 'note1',
        description: '',
        columnId: 1,
        id: 1,
      },
      {
        name: 'note2',
        description: '',
        columnId: 2,
        id: 2,
      },
    ],
    notes: [
      {
        noteId: '1',
        name: 'note1',
        description: 'Descrizione nota sulla riga',
        version: '500',
        from: '30/08/2027',
        id: '1',
      },
      {
        noteId: '2',
        name: 'note2',
        description: 'Descrizione nota sulla riga',
        version: '501',
        from: '30/08/2038',
        id: '2',
      },
    ],
  },
  {
    id: 2,
    name: 'Row 2',
    validity: new Date(),
    style: '1',
    columns: [
      {
        name: 'Col21',
        description: 'desc',
        style: '1',
        id: 1,
      },
      {
        name: 'Col22',
        description: 'desc',
        style: '2',
        id: 2,
      },
    ],
    columnNotes: [
      {
        name: 'note3',
        description: '',
        columnId: 2,
        id: 3,
      },
      {
        name: 'note2',
        description: '',
        columnId: 1,
        id: 2,
      },
    ],
    notes: [
      {
        noteId: '3',
        name: 'note3',
        description: 'Descrizione nota sulla riga',
        version: '500',
        from: '30/08/2027',
        id: '3',
      },
      {
        noteId: '2',
        name: 'Nota sulla riga',
        description: 'Descrizione nota sulla riga',
        version: '501',
        from: '30/08/2038',
        id: 'note2',
      },
    ],
  },
];

export const rowData1 = {
  id: '98',
  name: 'Condizioni economiche',
  validity: '2023-01-02',
  style: '32',
  columns: [
    {
      id: '1',
      name: '1',
      description: 'desc1',
      isBold: true,
      isItalic: false,
      versionDetailLevel1IDDescription: '2',
      versionDetailLevel1IDBold: '3',
      versionDetailLevel1IDItalic: '4',
      versionDetailLevel1IDColumn: '5',
      versionDetailLevel0ID: '1',
    },
    {
      id: '6',
      name: '2',
      description: 'desc2',
      isBold: false,
      isItalic: false,
      versionDetailLevel1IDDescription: '7',
      versionDetailLevel1IDBold: '8',
      versionDetailLevel1IDItalic: '9',
      versionDetailLevel1IDColumn: '10',
      versionDetailLevel0ID: '6',
    },
    {
      id: '7',
      name: '3',
      description: 'desc2',
      isBold: false,
      isItalic: true,
    },
  ],
  columnNotes: [
    {
      name: '765',
      id: '765',
      columnId: '1',
      columnName: '1',
      versionDetailLevel2ID: '765',
      versionDetailLevel1ID: '5',
    },
    {
      name: '798',
      id: '798',
      columnId: '6',
      columnName: '2',
      versionDetailLevel2ID: '798',
      versionDetailLevel1ID: '10',
    },
    {
      name: 'test',
      id: '798',
      columnId: '7',
      columnName: '3',
    },
  ],
  isNotSaved: false,
  rowId: '198',
  versionDetailLevel0IDStyle: '321',
  versionID: 123,
};
