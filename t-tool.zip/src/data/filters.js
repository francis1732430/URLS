export const filters = [
  {
    name: 'docId',
    label: 'ID',
  },
  {
    name: 'product',
    label: 'Prodotto',
  },
  {
    name: 'code',
    label: 'Codice',
  },
  {
    name: 'name',
    label: 'Nome',
  },
  {
    name: 'type',
    label: 'Tipo',
  },
  {
    name: 'start_date',
    label: 'Data inizio',
  },
  {
    name: 'status',
    label: 'Stato',
  },
];
