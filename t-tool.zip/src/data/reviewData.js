// import { IngInput } from 'ing-web';

export const contentData = [
  {
    propertyName: 'requestId',
    propertyClass: 'left_text_align',
  },
  {
    propertyName: 'reviewer',
    propertyClass: 'left_text_align',
    components: [
      {
        componentName: 'tooltip',
        contentHtml: [
          {
            tag: 'div',
            isSelfClosingTag: false,
            innerText: '',
            attributes: {
              slot: 'invoker',
              class: 'text-overflow',
            },
          },
          {
            tag: 'div',
            isSelfClosingTag: false,
            innerText: '',
            attributes: {
              slot: 'content',
            },
          },
        ],
      },
    ],
    // contentHtmlEvents: ['mouseenter', 'keyup'],
    // contentHtml: [
    //   {
    //     tag: 'div',
    //     isSelfClosingTag: false,
    //     innerText: 'Hello', // false
    //     attributes: {
    //       class: 'abc',
    //       custommattr: '',
    //     },
    //     contentHtml: {
    //       tag: 'span',
    //       isSelfClosingTag: false,
    //       innerText: '', // false
    //       attributes: {
    //         class: 'abc',
    //         custommattr: '123',
    //       },
    //     },
    //   },
    //   {
    //     tag: 'div',
    //     isSelfClosingTag: false,
    //     innerText: 'Hello', // false
    //     attributes: {
    //       class: '',
    //       custommattr: '123',
    //     },
    //     contentHtml: {
    //       tag: 'span',
    //       isSelfClosingTag: false,
    //       innerText: false,
    //       attributes: {
    //         class: 'abc',
    //         custommattr: '123',
    //       },
    //     },
    //   },
    // ],
  },
  {
    propertyName: 'note',
    propertyClass: '',
  },
  {
    propertyName: 'attachment',
    propertyClass: '',
    contentHtml: {
      tag: 'a',
      isSelfClosingTag: false,
      innerText: 'Download', // false,
      attributes: {
        id: 'attachment',
        class: 'download-btn',
        href: '',
      },
    },
    contentHtmlEvents: ['click'],
  },
  {
    propertyName: 'dateAndTime',
    propertyClass: '',
  },
];

export const reviewsContentData = [
  {
    propertyName: 'review',
    propertyClass: 'left_text_align',
    contentHtml: {
      tag: 'div',
      isSelfClosingTag: false,
      innerText: '', // false
      attributes: {},
      classCondition: [
        {
          operator: '===',
          text: 'OK',
          className: 'review-cls-green',
        },
        {
          operator: '===',
          text: 'KO',
          className: 'review-cls-orange',
        },
      ],
    },
  },
  {
    propertyName: 'reviewer',
    propertyClass: 'left_text_align',
  },
  {
    propertyName: 'note',
    propertyClass: '',
  },
  {
    propertyName: 'attachment',
    propertyClass: '',
    contentHtml: {
      tag: 'a',
      isSelfClosingTag: false,
      innerText: 'Download', // false
      attributes: {
        id: 'attachment',
        class: 'download-btn',
        href: '',
      },
    },
    contentHtmlEvents: ['click'],
  },
  {
    propertyName: 'dateAndTime',
    propertyClass: '',
  },
];

export const headerData = [
  {
    headerClass: 'id_header',
    headerValue: 'Review',
  },
  {
    headerClass: 'section_header',
    headerValue: 'Revisore',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Nota',
  },
  {
    headerClass: 'version_header',
    headerValue: 'Utente',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Alegati',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Data e ora',
  },
];

export const reviewRequestHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'ID Richiesta',
  },
  {
    headerClass: 'note_header',
    headerValue: 'Revisori',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Modifiche effettuate',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Allegati',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Data e ora',
  },
];

export const reviewsHeader = [
  {
    headerClass: 'id_header',
    headerValue: 'Review',
  },
  {
    headerClass: 'note_header',
    headerValue: 'Revisore',
  },
  {
    headerClass: 'description_header',
    headerValue: 'Nota',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Allegati',
  },
  {
    headerClass: 'from_header',
    headerValue: 'Data e ora',
  },
];
