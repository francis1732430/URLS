import {
  html,
  LitElement,
  ScopedElementsMixin,
  IngTab,
  IngTabs,
  IngTabPanel,
  IngDialog,
  IngDialogFrame,
  IngIcon,
} from 'ing-web';
import pageStyles from './DocumentModificationStyles.js';
import { DocumentDetailsPage } from './DocumentDetailsPage.js';
import { DialogModifySection } from './components/dialog/DialogModifySection.js';
import { ElementFromScratch } from './createElementFromScratch.js';
import { ConfirmationDialog } from './components/dialog/ConfirmationDialog.js';
import { messages } from './data/messages.js';
import {
  transformSectionsToBackend,
  transformSectionsToBackendForPatch,
  transformSectionsToFrontEnd,
} from './data/tranformations/sectionTransformation.js';
import { baseURL, baseURL2, baseURL5, baseURL6, localEnvironment } from './utils/constants.js';
import { ajaxInstance } from './utils/endpoints.js';
import {
  transformRulesToBackEnd,
  transformRulesToBackEndForPatch,
  transformRulesToFrontEnd,
} from './data/tranformations/ruleTransformation.js';
import {
  transformSubSectionsToBackend,
  transformSubSectionsToBackendForPatch,
  transformSubSectionsToFrontEnd,
} from './data/tranformations/subSectionsTransformation.js';
import {
  transformRowsToBackEnd,
  transformRowsToBackEndForPatch,
  transformRowsToFrontEnd,
} from './data/tranformations/rowTransformation.js';
import {
  transformNotesListToFrontEnd,
  transformNoteToBackend,
  transformNoteToBackendForPatch,
  transformNoteToFrontEnd,
} from './data/tranformations/noteTransformation.js';
import {
  transformDocumentsToBackend,
  transformDocumentsToBackendForPatch,
  transformDocumentsToFrontEnd,
  transformPrintPreviewToFrontEnd,
} from './data/tranformations/documentTranformation.js';
import { chunks, fetchChildItems, removeRelations } from './utils/chunks.js';
import { deriveData } from './utils/globalApiKeys.js';
import { PdfGeneration } from './components/pdfGeneration/pdfGeneration.js';

function closeDialog(event) {
  if (event && event.target) {
    event.target.dispatchEvent(
      new Event('close-overlay', {
        bubbles: true,
      }),
    );
  }
}

export class DocumentModification extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-tabs': IngTabs,
      'ing-tab': IngTab,
      'ing-tab-panel': IngTabPanel,
      'document-details-page': DocumentDetailsPage,
      'dialog-modify-section': DialogModifySection,
      'element-from-scratch': ElementFromScratch,
      'confirmation-dialog': ConfirmationDialog,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
      'ing-icon': IngIcon,
      'pdf-generation': PdfGeneration,
    };
  }

  static get properties() {
    return {
      tabsData: { type: String },
      _selectedTabIndex: { type: Number },
      selectedValue: { type: Object },
      selectedSection: { type: Object },
      selectedSubSection: { type: Object },
      selectedRow: { type: Object },
      selectedNote: { type: Object },
      selectedRule: { type: Object },
      confirmationMessageTitle: String,
      confirmationMessageDetail: Object,
      documentData: Object,
      pdfDetails: Object,
      scrollData: Object,
    };
  }

  static get styles() {
    return pageStyles;
  }

  constructor() {
    super();
    this._selectedTabIndex = 0; // tab index to focus
    this.tabsData = [];
    this.elementParentRelationMapper = {
      Sezioni: {
        parentPropertyId: 'docId',
        parentData: 'selectedValue',
        propertyData: 'sections',
        propertyId: 'sectionId',
        childData: 'Sotto Sezioni',
      },
      'Sotto Sezioni': {
        parentPropertyId: 'sectionId',
        parentData: 'selectedSection',
        propertyData: 'subSections',
        propertyId: 'subSectionId',
        childData: 'Righe',
      },
      Righe: {
        parentPropertyId: 'subSectionId',
        parentData: 'selectedSubSection',
        propertyData: 'rows',
        propertyId: 'rowId',
        childData: 'Nota',
      },
      Nota: {
        parentPropertyId: 'rowId',
        parentData: 'selectedRow',
        propertyData: 'notes',
        propertyId: 'noteId',
      },
      Regola: {
        parentPropertyId: 'docId',
        parentData: 'selectedValue',
        propertyData: 'rules',
        propertyId: 'ruleId',
      },
    };
    this.dataTypeMapper = {
      id: 'id',
    };
    this.getAPIMapper = {
      Regola: 'REGOLA',
      Sezioni: 'SEZIONE',
      Righe: 'RIGA',
      Nota: 'NOTA',
      'Sotto Sezioni': 'SOTTOSEZIONE',
    };
    this.messages = messages;
    this.confirmationMessageDetail = {};
    this.ajaxInstance = ajaxInstance;
    this.pdfDetails = {};
    this.scrollData = {};
    this.scrolledCB = this.scrolledCB.bind(this);
    this.openedTabsDataMapper = {};
  }

  connectedCallback() {
    super.connectedCallback();
    document.addEventListener('scroll', this.scrolledCB);
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    document.removeEventListener('scroll', this.scrolledCB);
  }

  async firstUpdated() {
    super.firstUpdated();
    await this.init();
    this.openedTabsDataMapper[this.documentData.docId] = JSON.parse(
      JSON.stringify(this.documentData),
    );
  }

  scrolledCB() {
    clearTimeout(this.scrollData.timer);
    if (
      this.selectedValue &&
      (this.tabsData[this._selectedTabIndex - 2]?.name?.includes('Document') ||
        this._selectedTabIndex === 0)
    ) {
      this.scrollData.timer = setTimeout(() => {
        console.log(window.scrollY);
        this.selectedValue.scrollPosition = window.scrollY || this.selectedValue.scrollPosition;
      }, 100);
    }
  }

  async init(data = {}) {
    delete this.documentData.sections;
    delete this.documentData.rules;
    delete this.documentData.printPreview;
    const document = { ...this.documentData, ...data };
    document.sections = await (
      await this.makeElementsAjaxCall(transformSectionsToFrontEnd, document, 'Sezioni')
    ).list;
    document.rules = await (
      await this.makeElementsAjaxCall(transformRulesToFrontEnd, document, 'Regola')
    ).list;
    document.printPreview = await (await this.makeprintPreviewAjaxCall(document.id)).list;
    this.selectedValue = JSON.parse(JSON.stringify(document));
    return document;
    // this.selectedValue = JSON.parse(JSON.stringify(this.selectedValue));
  }

  _emptySelectedData() {
    this.selectedSection = {};
    this.selectedSubSection = {};
    this.selectedRow = {};
    this.selectedNote = {};
    this.selectedRule = {};
  }

  async makeprintPreviewBase64AjaxCall(uuid) {
    const url = `${baseURL6}/${uuid}/content/base64`;
    try {
      const res = await this.ajaxInstance.get(url);
      let base64Data = '';
      if (typeof res?.data === 'object') {
        const propertiesList = Object.getOwnPropertyNames(res?.data);
        if (propertiesList.length) {
          base64Data = res?.data[propertiesList[0]];
        }
      } else if (typeof res?.data === 'string') {
        base64Data = res?.data;
      }
      const contentDisposition = res?.headers['content-disposition']?.split(';')?.[1] || '';
      return {
        base64Data,
        contentType: res.headers['content-type'],
        fileName: contentDisposition?.slice(
          contentDisposition?.indexOf('filename=') + 9,
          contentDisposition?.length,
        ),
      };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return '';
    }
  }

  async makeprintPreviewAjaxCall(id) {
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL2}/version/${id}/select?itemTypeKey=DOCUMENT_TYPE`;
    } else {
      // FOR MOCK USE
      url = `${baseURL2}/anteprima/select/${id}?itemTypeKey=DOCUMENT_TYPE`;
    }
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      list =
        res?.data?.versionDetailL0?.filter(d => d.itemTypeValue === 'ANTEPRIMA_ALLEGATO') || [];
      list = list?.map(d => transformPrintPreviewToFrontEnd(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async _putDocument(event) {
    const { data: document } = event?.detail;
    const documentBackend = transformDocumentsToBackendForPatch(document);
    try {
      await this.ajaxInstance.patch(`${baseURL2}/version`, documentBackend);
      this.refreshDocumentDetail(document?.id);
      this.openedTabsDataMapper[document?.id] = { ...document, dataChanged: false };
      delete this.openedTabsDataMapper[document?.id];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async makeElementsAjaxCall(transformFn, parent, type) {
    // , type
    // ?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[type]}\
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL2}/version/${parent.id}`;
      if (this.getAPIMapper[type] === 'RIGA') {
        url = `${baseURL2}/version/${parent.id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
      } else if (this.getAPIMapper[type] === 'REGOLA') {
        url = `${baseURL2}/version/${parent.id}/select?itemTypeKeyParent=RULE_TYPE&itemTypeValueChild=DESCRIZIONE_ITEM`;
      }
    } else {
      // FOR MOCK USE
      url = `${baseURL2}/${this.getAPIMapper[type]}/version/${parent.id}`;
    }
    let list;
    try {
      const res = await this.ajaxInstance.get(url);

      list = res.data?.itemChildren || [];

      list = list?.map(d => transformFn(d));

      if (this.getAPIMapper[type] === 'NOTA' && localEnvironment.production) {
        const row = transformRowsToFrontEnd(res?.data);
        if (row?.columnNotes?.length) {
          const ids = row?.columnNotes.map(item3 => item3?.id);
          const dataList = await this._getExistingData(ids);
          list = transformNotesListToFrontEnd(dataList) || [];
        }
      }
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingData(data) {
    let data1 = data;
    data1 = data1.filter((v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i);
    let chunkData = await chunks(data1, fetchChildItems, 50);
    if (!chunkData) {
      chunkData = [];
    }
    chunkData = [
      ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
    ];
    chunkData = chunkData.filter(
      (v, i, a) =>
        a.findIndex(v2 => v2?.itemsVersionsID?.toString() === v?.itemsVersionsID?.toString()) === i,
    );
    return chunkData;
  }

  async makeElementsAjaxCallForExistingElements(transformFn, tabName) {
    // eslint-disable-next-line no-console
    // , pageNumber = 1, searchText= '', total
    // eslint-disable-next-line no-console
    // const url = `${baseURL}/${this.getAPIMapper[tabName]}/all?page=${pageNumber || 1}&searchtext=${searchText}`;
    // eslint-disable-next-line no-console
    // const urlTotal = `${baseURL}/${this.getAPIMapper[tabName]}/total`;

    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
      if (this.getAPIMapper[tabName] === 'REGOLA') {
        url = `${baseURL}s?itemTypeKey=RULE_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
      }
    } else {
      // FOR MOCK USE
      url = `${baseURL}/${this.getAPIMapper[tabName]}/all?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
    }
    // eslint-disable-next-line no-console
    // totalRes = {}
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      // eslint-disable-next-line no-console
      // if(!pageNumber || pageNumber === 1)
      // eslint-disable-next-line no-console
      //   totalRes = await this.ajaxInstance.get(urlTotal);
      list = deriveData(res.data);
      list = list.map(d => transformFn(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  async getDocumentList(tabName, pageNumber, searchText, totalCount) {
    let list = [];

    if (tabName === 'Regola') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformRulesToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
    }
    if (tabName === 'Sezioni') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformSectionsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
    } else if (tabName === 'Sotto Sezioni') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformSubSectionsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
    } else if (tabName === 'Righe') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformRowsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
    } else if (tabName === 'Nota') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformNoteToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
    }
    return { list };
  }

  async _generateTab(event, isAdd) {
    const index = this.tabsData.findIndex(
      td =>
        td?.name?.toString() === event?.detail?.data?.name?.toString() &&
        td?.id?.toString() === event?.detail?.data?.id?.toString(),
    );
    const focusOnTab = () => {
      setTimeout(() => {
        const tabName = event.detail.data.id
          ? `${event.detail.data.name}-${event.detail.data.id}`
          : `Aggiungi ${event.detail.data.name}`;
        this._setTabIndex(this._getTabIndex(tabName))();
        window.scrollTo(0, 0);
      }, 200);
    };
    if (index === -1) {
      const modificationIds = {
        docId: this.selectedValue?.docId,
        sectionId: this.selectedSection?.sectionId,
        subSectionId: this.selectedSubSection?.subSectionId,
        rowId: this.selectedRow?.rowId,
        noteId: this.selectedNote?.noteId,
        ruleId: this.selectedRule?.ruleId,
      };
      if (isAdd) {
        const { list } = await this.getDocumentList(event.detail.data.name);
        // eslint-disable-next-line
        event.detail.data.data.tableContentData = list;
        // eslint-disable-next-line
        event.detail.data.data.total = list.length;
      }

      this.tabsData = [
        ...this.tabsData,
        {
          name: event.detail.data.name,
          id: event.detail.data.id,
          data: event.detail.data.data,
          parentData: this[this.elementParentRelationMapper[event.detail.data.name].parentData],
          ...modificationIds,
          editableActionFields: JSON.parse(
            JSON.stringify(event.detail?.data?.editableActionFields || {}),
          ),
        },
      ];
      focusOnTab();
      this.openedTabsDataMapper[event.detail.data.id || event.detail.data.name] = JSON.parse(
        JSON.stringify(event.detail.data.data),
      );
    } else {
      focusOnTab();
    }
  }

  _addElementTab(event) {
    const e = {
      detail: {
        data: {
          name: event.detail.data.name,
          data: { ...event.detail.data, id: '' },
        },
      },
    };
    this._generateTab(e, true);
  }

  _setTabIndex(index) {
    return () => {
      this._selectedTabIndex = index;
    };
  }

  _getTabIndex(name) {
    const tabs = this.shadowRoot.querySelectorAll(this.getScopedTagName('ing-tab'));
    let index;
    tabs.forEach((t, i) => {
      if (t.getAttribute('name') === name) {
        index = i;
      }
    });
    return index;
  }

  _closeTab(tabName) {
    if (tabName?.detail?.title === 'Modifica documento') {
      this.changeRoute('list_documents')();
      return;
    }
    // eslint-disable-next-line
    return event => {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }

      this.tabsData = this.tabsData.filter(td => {
        const params = td.id ? `${td.name}-${td.id}` : `Aggiungi ${td.name}`;
        return params !== tabName;
      });
      if (tabName.includes('Documento')) {
        this._documentTabIndex = undefined;
        this._emptySelectedData();
        this.init(this.documentData);
      }
      setTimeout(() => this._setTabIndex(this._documentTabIndex || 0)());
      if (this.selectedValue?.scrollPosition) {
        setTimeout(() => {
          window.scrollTo(0, this.selectedValue.scrollPosition);
        }, 300);
      }
    };
  }

  _selectTab(tabName, data) {
    return event => {
      event.preventDefault();
      const index = this._getTabIndex(tabName);
      setTimeout(() => this._setTabIndex(index)());
      if (data && this.selectedValue.id.toString() !== data.id.toString()) {
        this._documentTabIndex = index;
        this._emptySelectedData();
        this.init(data);
        // const document = await this.init(data);
        // const index1 = this.tabsData.findIndex(ta => ta?.id?.toString() === data?.docId?.toString());
        // if (index1 > -1) {
        //   this.tabsData[index1].data = document;
        //   this.tabsData = [
        //     ...this.tabsData
        //   ]
        // }
      }
    };
  }

  async _selectedDataChanged(event, closeTab) {
    this[event.detail.type] = event.detail.data;

    const child = this.elementParentRelationMapper[event.detail.typeName]?.childData;
    if (child) {
      let transformFn;
      switch (child) {
        case 'Sotto Sezioni':
          transformFn = transformSubSectionsToFrontEnd;
          break;
        case 'Righe':
          transformFn = transformRowsToFrontEnd;
          break;
        case 'Nota':
          transformFn = transformNoteToFrontEnd;
          break;
        default:
          break;
      }
      const { list } = await this.makeElementsAjaxCall(transformFn, this[event.detail.type], child);
      this[event.detail.type][this.elementParentRelationMapper[child].propertyData] = JSON.parse(
        JSON.stringify(list),
      );
      const detail = {
        type: child,
        data: this[event.detail.type][this.elementParentRelationMapper[child].propertyData],
        newSectionId: this.selectedSection?.id ? this.selectedSection?.id : 'undefined',
        newSubSectionId: this.selectedSubSection?.id ? this.selectedSubSection?.id : 'undefined',
        newRowId: this.selectedRow?.id ? this.selectedRow?.id : 'undefined',
        newNoteId: this.selectedNote?.id ? this.selectedNote?.id : 'undefined',
        newRuleId: this.selectedRule?.id ? this.selectedRule?.id : 'undefined',
        sectionId: this.selectedSection?.sectionId ? this.selectedSection?.sectionId : 'undefined',
        subSectionId: this.selectedSubSection?.subSectionId
          ? this.selectedSubSection?.subSectionId
          : 'undefined',
        rowId: this.selectedRow?.rowId ? this.selectedRow?.rowId : 'undefined',
        noteId: this.selectedNote?.noteId ? this.selectedNote?.noteId : 'undefined',
        ruleId: this.selectedRule?.ruleId ? this.selectedRule?.ruleId : 'undefined',
        isCopyData: true,
      };
      this._getRecord({ detail }, !closeTab);
      this.selectedValue = JSON.parse(JSON.stringify(this.selectedValue));
    }
  }

  // eslint-disable-next-line class-methods-use-this
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  _getRecord(event, restrictCloseTab) {
    const {
      type,
      data,
      newSectionId,
      newSubSectionId,
      newRowId,
      newNoteId,
      newRuleId,
      isCopyData,
    } = event.detail;
    const documentData = { ...this.selectedValue };

    if (type !== 'Regola') {
      // Sections Start
      if (!documentData.sections) {
        documentData.sections = [];
      }
      const sInex = documentData.sections.findIndex(
        v => v?.id?.toString() === newSectionId?.toString(),
      );
      if (sInex > -1 && type !== 'Sezioni') {
        // subSections Start
        if (!documentData.sections[sInex].subSections) {
          documentData.sections[sInex].subSections = [];
        }
        const ssInex = documentData.sections[sInex].subSections.findIndex(
          v => v?.id?.toString() === newSubSectionId?.toString(),
        );
        if (ssInex > -1 && type !== 'Sotto Sezioni') {
          // row Start
          if (!documentData.sections[sInex].subSections[ssInex].rows) {
            documentData.sections[sInex].subSections[ssInex].rows = [];
          }
          const rIndex = documentData.sections[sInex].subSections[ssInex].rows.findIndex(
            v => v?.id?.toString() === newRowId?.toString(),
          );
          if (rIndex > -1 && type !== 'Righe') {
            // Nota Start
            if (!documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes) {
              documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes = [];
            }
            const nInex = documentData.sections[sInex].subSections[ssInex].rows[
              rIndex
            ].notes.findIndex(v => v?.id?.toString() === newNoteId?.toString());

            if (nInex > -1 && type === 'Nota' && !Array.isArray(data)) {
              this._cloneRecord(
                documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes[nInex],
                data,
              );
              documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes = [
                ...documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes,
              ];
              this.selectedRow = documentData.sections[sInex].subSections[ssInex].rows[rIndex];
            } else if (type === 'Nota' && (nInex === -1 || Array.isArray(data))) {
              if (Array.isArray(data) && data?.length === 0) {
                documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes = [];
              } else {
                if (!isCopyData)
                  documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes =
                    documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes.concat(
                      data,
                    );
                else documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes = data;

                this.selectedRow = documentData.sections[sInex].subSections[ssInex].rows[rIndex];
              }
              this.selectedNote = undefined;
            }
            // Nota End
          } else if (rIndex > -1 && type === 'Righe' && !Array.isArray(data)) {
            this._cloneRecord(documentData.sections[sInex].subSections[ssInex].rows[rIndex], data);
            documentData.sections[sInex].subSections[ssInex].rows = [
              ...documentData.sections[sInex].subSections[ssInex].rows,
            ];
            this.selectedSubSection = documentData.sections[sInex].subSections[ssInex];
          } else if (type === 'Righe' && (rIndex === -1 || Array.isArray(data))) {
            if (Array.isArray(data) && data?.length === 0) {
              documentData.sections[sInex].subSections[ssInex].rows = [];
            } else {
              if (!isCopyData)
                documentData.sections[sInex].subSections[ssInex].rows =
                  documentData.sections[sInex].subSections[ssInex].rows.concat(data);
              else documentData.sections[sInex].subSections[ssInex].rows = data;

              this.selectedSubSection = documentData.sections[sInex].subSections[ssInex];
            }
            this.selectedRow = undefined;
            this.selectedNote = undefined;
          }

          // row Ends
        } else if (ssInex > -1 && type === 'Sotto Sezioni' && !Array.isArray(data)) {
          this._cloneRecord(documentData.sections[sInex].subSections[ssInex], data);
          documentData.sections[sInex].subSections = [...documentData.sections[sInex].subSections];
          this.selectedSection = documentData.sections[sInex];
        } else if (type === 'Sotto Sezioni' && (ssInex === -1 || Array.isArray(data))) {
          if (Array.isArray(data) && data?.length === 0) {
            documentData.sections[sInex].subSections = [];
          } else {
            if (!isCopyData)
              documentData.sections[sInex].subSections =
                documentData.sections[sInex].subSections.concat(data);
            else documentData.sections[sInex].subSections = data;

            this.selectedSection = documentData.sections[sInex];
          }
          this.selectedSubSection = undefined;
          this.selectedRow = undefined;
          this.selectedNote = undefined;
        }
        // subSections End
      } else if (sInex > -1 && type === 'Sezioni' && !Array.isArray(data)) {
        this._cloneRecord(documentData.sections[sInex], data);
        documentData.sections = [...documentData.sections];
      } else if (type === 'Sezioni' && (sInex === -1 || Array.isArray(data))) {
        if (Array.isArray(data) && data?.length === 0) {
          documentData.sections = [];
        } else {
          // eslint-disable-next-line
          if (!isCopyData) documentData.sections = [...documentData.sections.concat(data)];
          else documentData.sections = data;
        }
        this.selectedSection = undefined;
        this.selectedSubSection = undefined;
        this.selectedRow = undefined;
        this.selectedNote = undefined;
      }
      // Sections Ends
    } else {
      // Rule Starts
      if (!documentData.rules) {
        documentData.rules = [];
      }
      const rInex = documentData.rules.findIndex(v => v?.id?.toString() === newRuleId?.toString());
      if (rInex > -1 && !Array.isArray(data)) {
        this._cloneRecord(documentData.rules[rInex], data);
        documentData.rules = [...documentData.rules];
      } else if (type === 'Regola' && (rInex === -1 || Array.isArray(data))) {
        if (Array.isArray(data) && data?.length === 0) {
          documentData.rules = [];
        } else {
          // eslint-disable-next-line
          if (!isCopyData) documentData.rules = documentData.rules.concat(data);
          else documentData.rules = data;
        }
        this.selectedRule = undefined;
      }
      // Rule Ends
    }
    this.selectedValue = JSON.parse(JSON.stringify(documentData));
    this.selectedValue = { ...this.selectedValue };
    const tabId = event.detail[this.elementParentRelationMapper[event.detail.type].propertyId];
    const tabName = tabId ? `${event.detail.type}-${tabId}` : `Aggiungi ${event.detail.type}`;
    if (!restrictCloseTab) this._closeTab(tabName)();
  }

  _deleteRecord(event) {
    const { type, newSectionId, newSubSectionId, newRowId, newNoteId, newRuleId } = event.detail;
    const documentData = { ...this.selectedValue };

    if (type !== 'Regola') {
      // Sections Start
      if (!documentData.sections) {
        documentData.sections = [];
      }
      const sInex = documentData.sections.findIndex(
        v => v?.id?.toString() === newSectionId?.toString(),
      );
      if (sInex > -1 && type !== 'Sezioni') {
        // subSections Start
        if (!documentData.sections[sInex].subSections) {
          documentData.sections[sInex].subSections = [];
        }
        const ssInex = documentData.sections[sInex].subSections.findIndex(
          v => v?.id?.toString() === newSubSectionId?.toString(),
        );
        if (ssInex > -1 && type !== 'Sotto Sezioni') {
          // row Start
          if (!documentData.sections[sInex].subSections[ssInex].rows) {
            documentData.sections[sInex].subSections[ssInex].rows = [];
          }
          const rIndex = documentData.sections[sInex].subSections[ssInex].rows.findIndex(
            v => v?.id?.toString() === newRowId?.toString(),
          );
          if (rIndex > -1 && type !== 'Righe') {
            // Nota Start
            if (!documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes) {
              documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes = [];
            }
            const nInex = documentData.sections[sInex].subSections[ssInex].rows[
              rIndex
            ].notes.findIndex(v => v?.id?.toString() === newNoteId?.toString());

            if (nInex > -1 && type === 'Nota') {
              documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes =
                documentData.sections[sInex].subSections[ssInex].rows[rIndex].notes.filter(
                  item => item?.id?.toString() !== newNoteId?.toString(),
                );
              this.selectedRow = documentData.sections[sInex].subSections[ssInex].rows[rIndex];
              this.selectedNote = undefined;
            }
            // Nota End
          } else if (rIndex > -1 && type === 'Righe') {
            documentData.sections[sInex].subSections[ssInex].rows = documentData.sections[
              sInex
            ].subSections[ssInex].rows.filter(
              item => item?.id?.toString() !== newRowId?.toString(),
            );
            this.selectedSubSection = documentData.sections[sInex].subSections[ssInex];
            this.selectedRow = undefined;
            this.selectedNote = undefined;
          }

          // row Ends
        } else if (ssInex > -1 && type === 'Sotto Sezioni') {
          documentData.sections[sInex].subSections = documentData.sections[
            sInex
          ].subSections.filter(item => item?.id?.toString() !== newSubSectionId?.toString());
          this.selectedSection = documentData.sections[sInex];
          this.selectedSubSection = undefined;
          this.selectedRow = undefined;
          this.selectedNote = undefined;
        }
        // subSections End
      } else if (sInex > -1 && type === 'Sezioni') {
        documentData.sections = documentData.sections.filter(
          item => item?.id?.toString() !== newSectionId?.toString(),
        );
        this.selectedSection = undefined;
        this.selectedSubSection = undefined;
        this.selectedRow = undefined;
        this.selectedNote = undefined;
      }
      // Sections Ends
    } else {
      // Rule Starts
      if (!documentData.rules) {
        documentData.rules = [];
      }
      const rInex = documentData.rules.findIndex(v => v?.id?.toString() === newRuleId?.toString());
      if (rInex > -1) {
        documentData.rules = documentData.rules.filter(
          item => item?.id?.toString() !== newRuleId?.toString(),
        );
        this.selectedRule = undefined;
      }
      // Rule Ends
    }
    this.selectedValue = JSON.parse(JSON.stringify(documentData));
  }

  _dataMapping(data, type) {
    data.forEach(dObj => {
      Object.keys(dObj).forEach(key => {
        if (this.dataTypeMapper[key]) {
          if (key === 'id') {
            // eslint-disable-next-line no-param-reassign
            dObj[this.elementParentRelationMapper[type].propertyId] = dObj.id;
          } else {
            // eslint-disable-next-line no-param-reassign
            dObj[this.dataTypeMapper[key]] = dObj[key];
            // eslint-disable-next-line no-param-reassign
            delete dObj[key];
          }
        }
      });
    });
  }

  _cancelTask(event) {
    const tabId = event.detail[this.elementParentRelationMapper[event.detail.type].propertyId];
    const tabName =
      tabId && tabId !== 'undefined'
        ? `${event.detail.type}-${tabId}`
        : `Aggiungi ${event.detail.type}`;
    this._closeTab(tabName)();
  }

  // eslint-disable-next-line class-methods-use-this
  tranformRelationAPI(parentId, childId, order = 0) {
    return {
      itemsVersionsIDParent: parentId,
      itemsVersionsIDChild: childId,
      itemOrder: order,
    };
  }

  async removeRelationAjaxCall(parentId, childId) {
    try {
      await this.ajaxInstance.delete(
        `${baseURL5}/items-versions-relations?itemsVersionsIDParent=${parentId}&itemsVersionsIDChild=${childId}`,
        {},
      );
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async makeRelationAjaxCall(parentId, childId, order, data) {
    const itemsVersionsRelationsDTO = data || [this.tranformRelationAPI(parentId, childId, order)];
    try {
      await this.ajaxInstance.put(`${baseURL}s/versions/relation`, { itemsVersionsRelationsDTO });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async _creationDataReceived(event) {
    if (this.confirmationMessageDetail?.apiStatus === 'error') {
      return;
    }
    if (event.detail?.data?.length > 0) {
      // eslint-disable-next-line no-param-reassign
      event.detail[this.elementParentRelationMapper[event.detail.type].propertyId] = undefined;
      const parentData = event?.detail?.parentData;
      this._dataMapping(event.detail.data, event.detail.type);
      const list = this.checkIsElementAlreadyAssociatedByParent(event.detail.type, parentData);
      await this.makeRelationAjaxCall(parentData?.id, event.detail?.data[0]?.id, list.length + 1);
      await this.loadNewElementData(event.detail.type, null, parentData);
      if (
        event?.detail?.data[0]?.subSections?.length &&
        event.detail.type === 'Sezioni' &&
        this.selectedSection?.id &&
        this.selectedValue?.id?.toString() === parentData?.id?.toString()
      ) {
        this.loadNewElementData('Sotto Sezioni', null, this.selectedSection);
      }
      if (
        event?.detail?.data[0]?.rows?.length &&
        event.detail.type === 'Sotto Sezioni' &&
        this.selectedSubSection?.id &&
        this.selectedSection?.id?.toString() === parentData?.id?.toString()
      ) {
        this.loadNewElementData('Righe', null, this.selectedSubSection);
      }
      if (
        event?.detail?.data[0]?.subSections?.length &&
        event.detail.type === 'Righe' &&
        this.selectedRow?.id &&
        this.selectedSubSection?.id?.toString() === parentData?.id?.toString()
      ) {
        this.loadNewElementData('Nota', null, this.selectedRow);
      }
      this.openedTabsDataMapper[event.detail.type].dataChanged = false;
      delete this.openedTabsDataMapper[event.detail.type];
    }
    const tabName = `Aggiungi ${event.detail.type}`;
    this._closeTab(tabName)();
  }

  async _existingElementDataReceived(event) {
    if (event?.detail?.type !== 'Nota') {
      const list = this.checkIsElementAlreadyAssociatedByParent(
        event.detail.type,
        event?.detail?.parentData,
      );
      // eslint-disable-next-line
      const isExists = list.some(item => {
        return item?.id?.toString() === event.detail.data?.id?.toString();
      });
      if (!isExists) {
        await this.makeRelationAjaxCall(
          event?.detail?.parentData?.id,
          event.detail.data?.id,
          list.length + 1,
        );
        this.loadNewElementData(event.detail.type, null, event?.detail?.parentData);
      }
    }
    const tabId = event.detail[this.elementParentRelationMapper[event.detail.type].propertyId];
    const tabName = tabId ? `${event.detail.type}-${tabId}` : `Aggiungi ${event.detail.type}`;
    this._closeTab(tabName)();
  }

  async _modificationDataReceived(event) {
    const { id } = event.detail.data;
    const { type, removedIds, parentData } = event.detail;

    if (this.confirmationMessageDetail?.apiStatus === 'error') {
      return;
    }
    // eslint-disable-next-line
    event.detail.id = id;
    // this._modifyElement(data, type);
    if (type === 'Sezioni') {
      if (removedIds && removedIds.length) {
        // eslint-disable-next-line
        const chunkItems = removedIds.map(id1 => {
          return {
            parentId: id,
            childId: id1,
          };
        });
        await chunks(chunkItems, removeRelations, 50);
        removedIds.forEach(id1 => {
          this._deleteRecord({
            detail: {
              type: 'Sotto Sezioni',
              newSectionId: id,
              newSubSectionId: this.selectedSubSection?.id,
            },
          });
          if (this.selectedSubSection?.id?.toString() === id1?.toString()) {
            this.selectedSubSection = undefined;
            this.selectedRow = undefined;
            this.selectedNote = undefined;
          }
        });
      }
      // if (isRefreshed) {
      // } else {
      //   this._selectedDataChanged({ detail: { data, type: 'selectedSection', typeName: 'Sezioni' } });
      // }
    } else if (type === 'Sotto Sezioni') {
      if (removedIds && removedIds.length) {
        // eslint-disable-next-line
        const chunkItems = removedIds.map(id1 => {
          return {
            parentId: id,
            childId: id1,
          };
        });
        await chunks(chunkItems, removeRelations, 50);
        removedIds.forEach(id1 => {
          if (this.selectedSection?.id?.toString() === parentData?.id?.toString()) {
            this._deleteRecord({
              detail: {
                type: 'Righe',
                newSectionId: this.selectedSection?.id,
                newSubSectionId: id,
                newRowId: this.selectedRow?.id,
              },
            });
            if (this.selectedRow?.id?.toString() === id1?.toString()) {
              this.selectedRow = undefined;
              this.selectedNote = undefined;
            }
          }
        });
      }
      // if (isRefreshed) {
      // this.loadNewElementData(type, 'resetSelectedItem');
      // } else {
      //   this._selectedDataChanged({
      //     detail: { data, type: 'selectedSubSection', typeName: 'Sotto Sezioni' },
      //   });
      // }
    } else if (type === 'Righe') {
      if (removedIds && removedIds.length) {
        // eslint-disable-next-line
        const chunkItems = removedIds.map(id1 => {
          return {
            parentId: id,
            childId: id1,
          };
        });
        await chunks(chunkItems, removeRelations, 50);
        removedIds.forEach(id1 => {
          if (this.selectedSubSection?.id?.toString() === parentData?.id?.toString()) {
            this._deleteRecord({
              detail: {
                type: 'Nota',
                newSectionId: this.selectedSection?.id,
                newSubSectionId: this.selectedSubSection?.id,
                newRowId: id,
                newNoteId: this.selectedNote?.id,
              },
            });
            if (this.selectedNote?.id?.toString() === id1?.toString()) {
              this.selectedNote = undefined;
            }
          }
        });
      }
      // if (isRefreshed) {
      // this.loadNewElementData(type, 'resetSelectedItem');
      // } else {
      //   this._selectedDataChanged({ detail: { data, type: 'selectedRow', typeName: 'Righe' } });
      // }
    }
    this.loadNewElementData(type, 'resetSelectedItem', parentData);
    const tabId = event.detail[this.elementParentRelationMapper[event.detail.type].propertyId];
    const tabName = tabId ? `${event.detail.type}-${tabId}` : `Aggiungi ${event.detail.type}`;
    // eslint-disable-next-line
    event?.detail?.type !== 'Regola' && this._closeTab(tabName)();
    this.openedTabsDataMapper[
      event.detail.data[this.elementParentRelationMapper[event.detail.type].propertyId]
    ].dataChanged = false;
    delete this.openedTabsDataMapper[
      event.detail.data[this.elementParentRelationMapper[event.detail.type].propertyId]
    ];
  }

  _existingDataReceived(event) {
    // eslint-disable-next-line no-param-reassign
    event.detail[this.elementParentRelationMapper[event.detail.type].propertyId] = undefined;
    // eslint-disable-next-line no-param-reassign
    delete event.detail.data.documentView;
    // eslint-disable-next-line no-param-reassign
    event.detail.data = [event.detail.data];
    this._dataMapping(event.detail.data, event.detail.type);
    this._getRecord(event);
  }

  _pdfDialog() {
    return html`${this.pdfDetails?.name
      ? html`
          <div aria-modal="true" class="full-width-dialog fixed-dialog">
            <div class="full-width-dialog">
              <button
                aria-label="Close Dialog"
                tabindex="0"
                title="Close Dialog"
                href=""
                class="close-tab"
                @click="${this._closePdfDialog}"
              >
                X
              </button>
              <iframe
                aria-label="Opened Document"
                title=${this.pdfDetails?.name}
                name=${this.pdfDetails?.name}
                src="${this.pdfDetails.data}"
                height="100%"
                width="100%"
              ></iframe>
            </div>
          </div>
        `
      : ''}`;
  }

  _closePdfDialog() {
    this.pdfDetails = {};
  }

  _createNewVersion(event) {
    this.confirmationMessageDetail = {};
    this.confirmationMessageTitle = 'Nuova Versione';
    this.confirmationMessageDetail.detail = event.detail;
    this.confirmationMessageDetail.type = 'newVersion';
    this.confirmationMessageDetail.messages = this.messages.newVersion[event.detail.type];
    this.openDialog();
  }

  _createNewRow(event) {
    this.confirmationMessageDetail = {};
    this.confirmationMessageTitle = 'Nuova Con Duplicazione';
    this.confirmationMessageDetail.detail = event.detail;
    this.confirmationMessageDetail.type = 'newDuplication';
    this.confirmationMessageDetail.messages = this.messages.newDuplication[event.detail.type];
    this.openDialog();
  }

  _deleteRowDetails(event) {
    this.confirmationMessageDetail = {};
    this.confirmationMessageTitle = 'Elimina';
    this.confirmationMessageDetail.detail = event.detail;
    this.confirmationMessageDetail.type = 'removeRow';
    this.confirmationMessageDetail.messages = this.messages.removeRow[event.detail.type];
    this.openDialog();
  }

  _createNewDocument(event) {
    this.confirmationMessageDetail = {};
    if (event.detail.type === 'newDuplication') {
      this.confirmationMessageTitle = 'Nuova Con Duplicazione';
      this.confirmationMessageDetail.type = 'newDocument';
      this.confirmationMessageDetail.messages = this.messages.newDuplication.document;
    } else if (event.detail.type === 'newVersion') {
      this.confirmationMessageTitle = 'Nuova Versione';
      this.confirmationMessageDetail.type = 'newDocumentVersion';
      this.confirmationMessageDetail.messages = this.messages.newVersion.document;
    }
    this.confirmationMessageDetail.detail = event.detail;
    this.openDialog();
  }

  openDialog() {
    const dialog = this.shadowRoot.querySelector('#dialog2');
    dialog.opened = true;
  }

  // eslint-disable-next-line class-methods-use-this
  getElementTransformFn(type) {
    switch (type) {
      case 'Sezioni':
        return transformSectionsToBackend;
      case 'Sotto Sezioni':
        return transformSubSectionsToBackend;
      case 'Righe':
        return transformRowsToBackEnd;
      case 'Nota':
        return transformNoteToBackend;
      case 'Regola':
        return transformRulesToBackEnd;
      default:
        return null;
    }
  }

  // eslint-disable-next-line class-methods-use-this
  getElementTransformFnPatch(type) {
    switch (type) {
      case 'Sezioni':
        return transformSectionsToBackendForPatch;
      case 'Sotto Sezioni':
        return transformSubSectionsToBackendForPatch;
      case 'Righe':
        return transformRowsToBackEndForPatch;
      case 'Nota':
        return transformNoteToBackendForPatch;
      case 'Regola':
        return transformRulesToBackEndForPatch;
      default:
        return null;
    }
  }

  // eslint-disable-next-line
  replaceWithIds(type, data, id, itemId) {
    const data1 = { ...data };
    switch (type) {
      case 'Sezioni':
        data1.newSectionId = id;
        if (itemId) {
          data1.sectionId = itemId;
          data1.data.sectionId = itemId;
        }
        break;
      case 'Sotto Sezioni':
        data1.newSubSectionId = id;
        if (itemId) {
          data1.subSectionId = itemId;
          data1.data.subSectionId = itemId;
        }
        break;
      case 'Righe':
        data1.newRowId = id;
        if (itemId) {
          data1.rowId = itemId;
          data1.data.rowId = itemId;
        }
        break;
      case 'Nota':
        data1.newNoteId = id;
        if (itemId) {
          data1.noteId = itemId;
          data1.data.noteId = itemId;
        }
        break;
      case 'Regola':
        data1.newRuleId = id;
        if (itemId) {
          data1.ruleId = itemId;
          data1.data.ruleId = itemId;
        }
        break;
      default:
        break;
    }
    return data1;
  }

  // eslint-disable-next-line
  getParentId(type) {
    switch (type) {
      case 'Sezioni':
        return this.selectedValue.id;
      case 'Sotto Sezioni':
        return this.selectedSection.id;
      case 'Righe':
        return this.selectedSubSection.id;
      case 'Nota':
        return this.selectedRow.id;
      case 'Regola':
        return this.selectedValue.id;
      default:
        return null;
    }
  }

  // eslint-disable-next-line
  getParentElement(type) {
    switch (type) {
      case 'Sezioni':
        return this.selectedValue;
      case 'Sotto Sezioni':
        return this.selectedSection;
      case 'Righe':
        return this.selectedSubSection;
      case 'Nota':
        return this.selectedRow;
      case 'Regola':
        return this.selectedValue;
      default:
        return null;
    }
  }

  bindAndGetRecord(type, data) {
    const detail = {
      type,
      data,
      newSectionId: this.selectedSection?.id ? this.selectedSection?.id : 'undefined',
      newSubSectionId: this.selectedSubSection?.id ? this.selectedSubSection?.id : 'undefined',
      newRowId: this.selectedRow?.id ? this.selectedRow?.id : 'undefined',
      newNoteId: this.selectedNote?.id ? this.selectedNote?.id : 'undefined',
      newRuleId: this.selectedRule?.id ? this.selectedRule?.id : 'undefined',
      sectionId: this.selectedSection?.sectionId ? this.selectedSection?.sectionId : 'undefined',
      subSectionId: this.selectedSubSection?.subSectionId
        ? this.selectedSubSection?.subSectionId
        : 'undefined',
      rowId: this.selectedRow?.rowId ? this.selectedRow?.rowId : 'undefined',
      noteId: this.selectedNote?.noteId ? this.selectedNote?.noteId : 'undefined',
      ruleId: this.selectedRule?.ruleId ? this.selectedRule?.ruleId : 'undefined',
      isCopyData: true,
    };
    this._getRecord({ detail }, type === 'Regola');
    this.selectedValue = JSON.parse(JSON.stringify(this.selectedValue));
  }

  // eslint-disable-next-line
  async loadNewElementData(type, action, parentData) {
    switch (type) {
      case 'Sezioni':
        this.selectedValue.sections = await (
          await this.makeElementsAjaxCall(
            transformSectionsToFrontEnd,
            this.selectedValue,
            'Sezioni',
          )
        ).list;
        this.bindAndGetRecord(type, this.selectedValue.sections);
        if (action === 'resetSelectedItem') {
          this.selectedSection = undefined;
          this.selectedSubSection = undefined;
          this.selectedRow = undefined;
          this.selectedNote = undefined;
        }
        break;
      case 'Sotto Sezioni':
        if (parentData?.id?.toString() === this.selectedSection?.id?.toString()) {
          await this._selectedDataChanged(
            {
              detail: { data: this.selectedSection, type: 'selectedSection', typeName: 'Sezioni' },
            },
            true,
          );
          if (action === 'resetSelectedItem') {
            this.selectedSubSection = undefined;
            this.selectedRow = undefined;
            this.selectedNote = undefined;
          }
        }
        break;
      case 'Righe':
        if (parentData?.id?.toString() === this.selectedSubSection?.id?.toString()) {
          await this._selectedDataChanged(
            {
              detail: {
                data: this.selectedSubSection,
                type: 'selectedSubSection',
                typeName: 'Sotto Sezioni',
              },
            },
            true,
          );
          if (action === 'resetSelectedItem') {
            this.selectedRow = undefined;
            this.selectedNote = undefined;
          }
        }
        break;
      case 'Nota':
        if (parentData?.id?.toString() === this.selectedRow?.id?.toString()) {
          await this._selectedDataChanged(
            {
              detail: { data: this.selectedRow, type: 'selectedRow', typeName: 'Righe' },
            },
            true,
          );
          if (action === 'resetSelectedItem') {
            this.selectedNote = undefined;
          }
        }
        break;
      case 'Regola':
        this.selectedValue.rules = await (
          await this.makeElementsAjaxCall(transformRulesToFrontEnd, this.selectedValue, 'Regola')
        ).list;
        this.bindAndGetRecord(type, this.selectedValue.rules);
        if (action === 'resetSelectedItem') {
          this.selectedRule = undefined;
        }
        break;
      default:
    }
  }

  // eslint-disable-next-line
  checkIsElementAlreadyAssociated(type) {
    switch (type) {
      case 'Sezioni':
        return this.selectedValue?.sections;
      case 'Sotto Sezioni':
        return this.selectedSection?.subSections;
      case 'Righe':
        return this.selectedSubSection?.rows;
      case 'Nota':
        return this.selectedRow?.notes;
      case 'Regola':
        return this.selectedValue?.rules;
      default:
        return [];
    }
  }

  // eslint-disable-next-line
  checkIsElementAlreadyAssociatedByParent(type, parentData) {
    switch (type) {
      case 'Sezioni':
        return this.selectedValue?.sections;
      case 'Sotto Sezioni':
        return parentData?.subSections;
      case 'Righe':
        return parentData?.rows;
      case 'Nota':
        return parentData?.notes;
      case 'Regola':
        return parentData?.rules;
      default:
        return [];
    }
  }

  async _modifyElement(data, type) {
    const transformFn = this.getElementTransformFnPatch(type);
    const dataBackend = transformFn(data);
    try {
      await this.ajaxInstance.patch(`${baseURL2}/version`, dataBackend);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async _modifyElementVersion(data, type) {
    // const transformFn = this.getElementTransformFn(type);
    // const dataBackend = transformFn(data?.detail?.data);
    const itemId =
      data?.detail?.docId ||
      data?.detail?.sectionId ||
      data?.detail?.ruleId ||
      data?.detail?.subSectionId ||
      data?.detail?.rowId ||
      data?.detail?.noteId;
    const { id } = data.detail;
    try {
      const {
        data: { itemsVersionsID: versionId },
      } = await this.ajaxInstance.post(`${baseURL}/${itemId}/version/${id}/clone-item-version`, {});
      const itemsVersionsIDParent = this.getParentId(type);
      if (itemsVersionsIDParent) {
        await this.removeRelationAjaxCall(itemsVersionsIDParent, id);
        await this.makeRelationAjaxCall(itemsVersionsIDParent, versionId);
      }
      this.loadNewElementData(type, 'resetSelectedItem', this.getParentElement(type));
      // let detail1 = data.detail;
      // detail1.id = versionId?.toString();
      // detail1 = this.replaceWithIds(type, detail1, versionId?.toString(), dupId?.toString());
      // detail1.data.id = versionId?.toString();
      // this._getRecord({ detail: detail1 });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async _duplicateElement(data, type) {
    // const transformFn = this.getElementTransformFn(type);
    // const dataBackend = transformFn(data?.detail?.data);
    const itemId =
      data?.detail?.docId ||
      data?.detail?.sectionId ||
      data?.detail?.ruleId ||
      data?.detail?.subSectionId ||
      data?.detail?.rowId ||
      data?.detail?.noteId;
    const { id } = data.detail;
    try {
      const {
        data: { itemsVersionsID: versionId },
      } = await this.ajaxInstance.post(`${baseURL}/${itemId}/version/${id}/clone-item`, {});
      const itemsVersionsIDParent = this.getParentId(type);
      if (itemsVersionsIDParent) {
        await this.makeRelationAjaxCall(itemsVersionsIDParent, versionId);
      }
      this.loadNewElementData(type, null, this.getParentElement(type));
      // let detail1 = data.detail;
      // detail1.id = versionId?.toString();
      // detail1 = this.replaceWithIds(type, detail1, versionId?.toString(), dupId?.toString());
      // detail1.data.id = versionId?.toString();
      // this._getRecord({ detail: detail1 });
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async deleteTableRow(data, type) {
    const { id } = data.detail.data;
    try {
      const itemsVersionsIDParent = this.getParentId(type);
      if (itemsVersionsIDParent) {
        await this.removeRelationAjaxCall(itemsVersionsIDParent, id);
      }
      this.loadNewElementData(type, null, this.getParentElement(type));
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async _removeElement(event) {
    const { data: document } = event?.detail;
    const documentBackend = transformDocumentsToBackend(document);
    try {
      await this.ajaxInstance.put(`${baseURL}s/${document.id}`, documentBackend);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  _documentDuplicatedVersionedName(data) {
    return `Documento-${data.docId}`;
  }

  _focusDuplicatedVersionedDocument(data) {
    setTimeout(() => {
      const tabName = this._documentDuplicatedVersionedName(data);
      this._documentTabIndex = this._getTabIndex(tabName);
      this._setTabIndex(this._documentTabIndex)();
      this._emptySelectedData();
      this.init(data);
      window.scrollTo(0, 2);
    }, 200);
  }

  async _renderDuplicatedVersionedDocument(doc) {
    this.tabsData = [
      ...this.tabsData,
      {
        name: `Documento`,
        id: doc.docId,
        data: JSON.parse(JSON.stringify(doc)),
        parentData: null,
        isDuplicateVersion: doc?.typeOfAction,
      },
    ];
    this.openedTabsDataMapper[doc.docId] = JSON.parse(JSON.stringify(doc));
  }

  _closeDialog(ev) {
    closeDialog(ev);
    this.confirmationMessageTitle = '';
    if (ev?.detail) {
      const { confirmationMessageDetail } = ev.detail;
      if (confirmationMessageDetail.type === 'newVersion') {
        // eslint-disable-next-line
        confirmationMessageDetail.detail.data.version = (
          parseInt(confirmationMessageDetail.detail.data.version, 10) + 1
        ).toString();
        // eslint-disable-next-line
        confirmationMessageDetail.detail.data.id = confirmationMessageDetail.detail.id;
        // this._getRecord({ detail: confirmationMessageDetail.detail });
        this._modifyElementVersion(
          confirmationMessageDetail,
          confirmationMessageDetail.detail.type,
        );
      } else if (confirmationMessageDetail.type === 'newDuplication') {
        // eslint-disable-next-line
        confirmationMessageDetail.detail.data.id = confirmationMessageDetail.detail.id;
        // eslint-disable-next-line
        confirmationMessageDetail.detail.data[
          this.elementParentRelationMapper[confirmationMessageDetail.detail.type].propertyId
        ] =
          confirmationMessageDetail.detail[
            this.elementParentRelationMapper[confirmationMessageDetail.detail.type].propertyId
          ];
        // this._getRecord({ detail: confirmationMessageDetail.detail });
        this._duplicateElement(confirmationMessageDetail, confirmationMessageDetail.detail.type);
      } else if (confirmationMessageDetail.type === 'removeRow') {
        this.deleteTableRow(confirmationMessageDetail, confirmationMessageDetail.detail.type);
        // this._deleteRecord({ detail: confirmationMessageDetail.detail });
      } else if (confirmationMessageDetail.type === 'newDocument') {
        const ev1 = new CustomEvent('new-duplicate-document', {
          detail: {
            data: JSON.parse(JSON.stringify(confirmationMessageDetail.detail.data)),
            render: this._renderDuplicatedVersionedDocument.bind(this),
            focus: this._focusDuplicatedVersionedDocument.bind(this),
          },
        });
        this.dispatchEvent(ev1);
        // this._renderDuplicatedVersionedDocument(confirmationMessageDetail.detail.data);
        // this._focusDuplicatedVersionedDocument(confirmationMessageDetail.detail.data);
      } else if (confirmationMessageDetail.type === 'newDocumentVersion') {
        const ev1 = new CustomEvent('new-document-version', {
          detail: {
            data: JSON.parse(JSON.stringify(confirmationMessageDetail.detail.data)),
            render: this._renderDuplicatedVersionedDocument.bind(this),
            focus: this._focusDuplicatedVersionedDocument.bind(this),
          },
        });
        this.dispatchEvent(ev1);
        // this._renderDuplicatedVersionedDocument(confirmationMessageDetail.detail.data);
        // this._focusDuplicatedVersionedDocument(confirmationMessageDetail.detail.data);
      }
      if (this.tabChangedClosedFn) {
        this.tabChangedClosedFn();
        this.tabChangedClosedFn = null;
        if (confirmationMessageDetail?.id) {
          this.openedTabsDataMapper[confirmationMessageDetail?.id].dataChanged = false;
          delete this.openedTabsDataMapper[confirmationMessageDetail?.id];
        }
        if (this.clearOpenedTabsData) {
          this.openedTabsDataMapper = {};
          this.clearOpenedTabsData = false;
        }
      }
    } else {
      const tab = this.shadowRoot.querySelectorAll(this.getScopedTagName('ing-tab'))[
        this._selectedTabIndex
      ];
      if (tab) tab?.click();
    }
    this.confirmationMessageDetail = {};
  }

  async _dataOrderChanged(event) {
    const { detail } = event;
    const parentId = this[this.elementParentRelationMapper[event.detail.type]?.parentData]?.id;
    // eslint-disable-next-line no-console
    await this.makeRelationAjaxCall(null, null, null, [
      this.tranformRelationAPI(parentId, detail.swappedData.id, detail.swappedData.order),
      this.tranformRelationAPI(parentId, detail.swappedWithData.id, detail.swappedWithData.order),
    ]);
    // this._getRecord(event);
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  async refreshDocumentDetail(id) {
    try {
      const res = await this._getVersionItemDetail(id);
      const data = transformDocumentsToFrontEnd(res?.data);
      const index = this.tabsData.findIndex(tab => tab?.data?.id?.toString() === id?.toString());
      if (index > -1) {
        this.tabsData[index].data = { ...this.tabsData[index].data, ...data };
        this._cloneRecord(this.tabsData[index].data, data);
        // eslint-disable-next-line no-console
        console.log(this.tabsData, data);
        this.tabsData = [...this.tabsData];
      } else if (this.selectedValue?.id?.toString() === id?.toString()) {
        this._cloneRecord(this.selectedValue, data);
        this.selectedValue = { ...this.selectedValue };
        this._saveDocument(this.selectedValue);
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log(err);
    }
  }

  openDialogForChangedTab(type) {
    this.confirmationMessageDetail = {};
    const dialog = this.shadowRoot.querySelector('#dialog-change-tab');
    this.confirmationMessageDetail.messages = messages?.tabClosed?.dialog;
    this.confirmationMessageDetail.id = type || null;
    dialog.opened = true;
  }

  showModalOnTabChangedClosed(fn, tabName = '') {
    return () => {
      this.tabChangedClosedFn = fn;
      let type;
      if (!tabName.includes('-')) {
        // type = tabName.split(' ')[1].trim();
        type = tabName.split(' ').slice(1).join(' ').trim();
      } else {
        type = tabName.split('-')[1].trim();
      }
      if (this.openedTabsDataMapper[type]?.dataChanged) {
        this.openDialogForChangedTab(type);
      } else {
        this.tabChangedClosedFn();
      }
    };
  }

  showModalOnTabChanged(fn) {
    return () => {
      this.tabChangedClosedFn = fn;
      let dataChanged;
      Object.keys(this.openedTabsDataMapper).forEach(key => {
        if (this.openedTabsDataMapper[key].dataChanged && !dataChanged) dataChanged = true;
      });
      if (dataChanged) {
        this.openDialogForChangedTab();
        this.clearOpenedTabsData = true;
      } else {
        this.tabChangedClosedFn();
      }
    };
  }

  getTabTemplate(tabName, tabTitle, template, showCloseButton) {
    return html` <ing-tab name="${tabName}" @click="${this._selectTab(tabName)}" slot="tab"
        >${tabTitle}
        ${showCloseButton
          ? html`<button
              href=""
              class="close-tab"
              @click="${this.showModalOnTabChangedClosed(this._closeTab(tabName), tabName)}"
            >
              X
            </button>`
          : ''}</ing-tab
      >
      <ing-tab-panel slot="panel"> ${template} </ing-tab-panel>`;
  }

  changeRoute(tabName) {
    return () => {
      const ev = new CustomEvent('navigate-to', {
        detail: {
          route: tabName,
        },
      });
      this.dispatchEvent(ev);
    };
  }

  getDetailsTabTemplate(tabName, tabTitle, template, showCloseButton, data) {
    return html`
      <ing-tab name="${tabName}" @click="${this._selectTab(tabName, data)}" slot="tab"
        >${tabTitle}
        ${showCloseButton
          ? html`<button
              href=""
              class="close-tab"
              @click="${this.showModalOnTabChangedClosed(this._closeTab(tabTitle), tabTitle)}"
            >
              X
            </button>`
          : ''}</ing-tab
      >
      ${showCloseButton
        ? ''
        : html`
            <ing-tab
              slot="tab"
              @click="${this.showModalOnTabChanged(this.changeRoute('create_documents'))}"
              >Crea nuovo documento</ing-tab
            >
          `}

      <ing-tab-panel slot="panel"> ${template} </ing-tab-panel>

      ${showCloseButton ? '' : html` <ing-tab-panel slot="panel"> </ing-tab-panel> `}
    `;
  }

  _saveDocument(data) {
    const ev1 = new CustomEvent('save-document', { detail: { data } });
    this.dispatchEvent(ev1);
  }

  async _handleChildEvents(event) {
    if (event?.detail?.target?.matches('.download-btn')) {
      // eslint-disable-next-line
      let { base64Data, contentType, fileName } = await this.makeprintPreviewBase64AjaxCall(
        event?.detail?.target?.id,
      );
      // const downloadLink = window.document.createElement('a');
      // downloadLink.href = base64Data;
      // downloadLink.download = `${event?.detail?.name}`;
      // document.body.appendChild(downloadLink);
      // downloadLink.click();
      // document.body.removeChild(downloadLink);
      if (base64Data?.indexOf(';base64,') === -1) {
        base64Data = `data:${contentType};base64,${base64Data}`;
      }
      this.pdfDetails.name = fileName || event?.detail?.name;
      this.pdfDetails.data = base64Data;
      this.pdfDetails = { ...this.pdfDetails };
    }
  }

  documentDataChanged(event) {
    const data = event.detail;
    this.openedTabsDataMapper[data.id] = { ...data, dataChanged: true };
  }

  loadDocumentDetailsTab(data) {
    const value = this.selectedValue;
    return this.getDetailsTabTemplate(
      data ? this._documentDuplicatedVersionedName(data) : 'details',
      data
        ? this._documentDuplicatedVersionedName(data)
        : `Documento ${this.documentData?.docId || '..'}`,
      html`
        <ing-icon
          class="back-to-home-icon"
          @click=${this.showModalOnTabChanged(this.changeRoute('list_documents'))}
          icon-id="ing:solid-arrows:arrowLeft"
        ></ing-icon>
        <document-details-page
          .selectedDocument=${value}
          ._selectedSection=${this.selectedSection}
          ._selectedSubsection=${this.selectedSubSection}
          ._selectedRow=${this.selectedRow}
          ._selectedNote=${this.selectedNote}
          ._selectedRule=${this.selectedRule}
          .isDuplicateVersion="${data?.typeOfAction}"
          .elementParentRelationMapper="${this.elementParentRelationMapper}"
          @close-tab-event="${this._closeTab}"
          @modify-selected-section="${this._generateTab}"
          @add-new-element="${this._addElementTab}"
          @selected-data-changed="${this._selectedDataChanged}"
          @new-version-table-row="${this._createNewVersion}"
          @delete-table-row="${this._deleteRowDetails}"
          @new-duplicate-table-row="${this._createNewRow}"
          @new-document-version="${this._createNewDocument}"
          @create-duplicate-document="${this._createNewDocument}"
          @data-order-changed="${this._dataOrderChanged}"
          @save-document="${this._putDocument}"
          @document-version-changed="${this._documentVersionChanged}"
          @child-data-event=${this._handleChildEvents}
          @document-data-changed=${this.documentDataChanged}
        ></document-details-page>
      `,
      !!data,
      data || this.documentData,
    );
  }

  // eslint-disable-next-line
  getSectionName(tabName) {
    if (tabName?.toLowerCase() === 'righe') {
      return 'Riga';
      // eslint-disable-next-line
    } else if (tabName?.toLowerCase() === 'sotto sezioni') {
      return 'Sotto Sezione';
      // eslint-disable-next-line
    } else if (tabName?.toLowerCase() === 'sezioni') {
      return 'Sezione';
      // eslint-disable-next-line
    } else {
      return tabName;
    }
  }

  _fieldsChanged(ev) {
    console.log('fields-changed log', ev.detail, this.openedTabsDataMapper);
    if (!ev?.detail?.type) {
      Object.keys(this.openedTabsDataMapper).forEach(key => {
        if (this.openedTabsDataMapper[key]?.id?.toString() === ev?.detail?.id?.toString()) {
          this.openedTabsDataMapper[key].dataChanged = true;
        }
      });
    } else {
      this.openedTabsDataMapper[ev?.detail?.type].dataChanged = true;
    }
  }

  _previewRule(event) {
    console.log('Print Rule');
    this.tabsData = [
      ...this.tabsData,
      {
        name: 'Anteprima',
        id: event.detail.id,
        data: {
          ...event.detail.data,
          type: this.selectedValue?.type,
          product: this.selectedValue?.product,
        },
        isRulePreview: true,
      },
    ];
    setTimeout(() => {
      const idx = this._getTabIndex(`Anteprima-${event.detail.id}`);
      this._setTabIndex(idx)();
    }, 200);
  }

  loadDocumentElementTabs(
    name,
    id,
    data,
    parentData,
    docId,
    sectionId,
    subSectionId,
    rowId,
    noteId,
    ruleId,
    editableActionFields,
    isRulePreview,
  ) {
    const params = id ? `${name}-${id}` : `Aggiungi ${name}`;
    const params1 = id
      ? `${this.getSectionName(name)}-${id}`
      : `Aggiungi ${this.getSectionName(name)}`;
    return this.getTabTemplate(
      params,
      params1,
      /* eslint-disable */
      html`
        ${isRulePreview && id
          ? html` <pdf-generation .generationData=${data}></pdf-generation> `
          : id
          ? html`<dialog-modify-section
              .selectedRow="${data}"
              name="${name}"
              .parentData="${parentData}"
              docId="${docId}"
              sectionId="${sectionId}"
              subSectionId="${subSectionId}"
              rowId="${rowId}"
              noteId="${noteId}"
              ruleId="${ruleId}"
              docVersionId="${this.selectedValue?.id}"
              docValidityDate="${this.selectedValue?.start_date}"
              .editableActionFields="${editableActionFields}"
              @cancel-action="${this._cancelTask}"
              @data-received="${this._modificationDataReceived}"
              @fields-changed=${this._fieldsChanged}
              @show-status-dialog="${this._showStatusInDialog}"
              @preview-rule=${this._previewRule}
            ></dialog-modify-section>`
          : html`<element-from-scratch
              sectionName=${data.name}
              .headerData=${data.headerData}
              .tableContentData=${data.tableContentData}
              .parentData="${parentData}"
              .parentPropertyId="${this.elementParentRelationMapper[data.name].parentPropertyId}"
              propertyId=${data.propertyId}
              docId="${docId}"
              sectionId="${sectionId}"
              subSectionId="${subSectionId}"
              rowId="${rowId}"
              noteId="${noteId}"
              ruleId="${ruleId}"
              docVersionId="${this.selectedValue?.id}"
              total=${data?.total}
              docName="${this.selectedValue?.name}"
              @cancel-action="${this._cancelTask}"
              @data-received="${this._creationDataReceived}"
              @add-row-elements="${this._existingDataReceived}"
              @existing-data-received="${this._existingElementDataReceived}"
              @show-status-dialog="${this._showStatusInDialog}"
              @fields-changed=${this._fieldsChanged}
            ></element-from-scratch>`}
      `,
      /* eslint-disable */
      true,
    );
  }

  _clicked() {
    const event = new CustomEvent('tab-clicked', {
      detail: {
        tabTitle: this.tabTiltle,
      },
    });
    this.dispatchEvent(event);
  }

  _documentVersionChanged(event) {
    this.selectedValue = event.detail.data;
    this.selectedSection = undefined;
    this.selectedRule = undefined;
    this.selectedSubSection = undefined;
    this.selectedRow = undefined;
    this.selectedNote = undefined;
    const ev = new CustomEvent('save-document', {
      detail: {
        data: this.selectedValue,
      },
    });
    this.dispatchEvent(ev);
    this.selectedValue = { ...this.selectedValue };
  }

  _showStatusInDialog(event) {
    const { data, status, elementType } = event.detail;
    const type = status || data.status === 200 || data.status === 201 ? 'success' : 'error';
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.messages = messages?.save[type];
    this.confirmationMessageDetail.apiStatus = type;
    console.log('data data data', data);
    if (type === 'error' || elementType === 'Regola') {
      const dialog = this.shadowRoot.querySelector('#dialog3');
      dialog.opened = true;
    }
  }

  render() {
    return html`
      <div class="main_container">
        <div class="grey-empty-area"></div>
        <div class="content_body_area">
          ${this._pdfDialog()}
          <ing-tabs id="navigation_tabs" .selectedIndex=${this._selectedTabIndex}>
            ${this.loadDocumentDetailsTab()}
            ${this.tabsData.map(td => {
              if (td.name.indexOf('Documento') === -1) {
                return this.loadDocumentElementTabs(
                  td.name,
                  td.id,
                  td.data,
                  td.parentData,
                  td.docId,
                  td.sectionId,
                  td.subSectionId,
                  td.rowId,
                  td.noteId,
                  td.ruleId,
                  td?.editableActionFields,
                  td.isRulePreview,
                );
              }
              return this.loadDocumentDetailsTab(td.data);
            })}
          </ing-tabs>
        </div>
      </div>

      <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">${this.confirmationMessageTitle}</div>
          <div slot="content">
            ${this.confirmationMessageTitle
              ? html`<confirmation-dialog
                  .confirmationMessageDetail="${this.confirmationMessageDetail}"
                  @close-dialog-event="${this._closeDialog}"
                ></confirmation-dialog>`
              : ''}
          </div>
        </ing-dialog-frame>
      </ing-dialog>
      <ing-dialog id="dialog3">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Salva</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              ?isNormalConfirmation=${true}
              customClasses="message-bold"
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
      <ing-dialog id="dialog-change-tab">
        <ing-dialog-frame slot="content">
          <div slot="header">Salva</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              ?isNormalConfirmation=${false}
              customClasses="message-bold"
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
    `;
  }
}

customElements.define('document-modification', DocumentModification);
