// DocumentReviewHistoryTableStyles.js

import { green, html, orange } from 'ing-web';

export default html`
  <style>
    .review-cls {
      color: ${orange};
    }
    .review-cls-green {
      color: ${green};
      font-weight: bold;
    }
    .review-cls-orange {
      color: ${orange};
      font-weight: bold;
    }
    .previewName {
      width: 350px;
    }
    .text-overflow {
      text-overflow: ellipsis;
      max-width: 125px;
      overflow: hidden;
      white-space: nowrap;
    }
  </style>
`;
