import { ScopedElementsMixin, LitElement, html, IngButton } from 'ing-web';

import { contentData } from './data/documentPreview.js';
import styles from './DocumentPreviewStyles.js';

export class DocumentPreview extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      contentData: Object,
    };
  }

  constructor() {
    super();
    this.contentData = contentData;
  }

  buildInvoiceElement() {
    let htmlData = '';
    this.contentData.subSection.forEach(item => {
      if (item) {
        if (item.propertyName === 'title' || item.propertyName === 'header') {
          htmlData = html`${htmlData}
            <div class="${item.class}">
              <label>${item.content}</label>
            </div>`;
        } else if (item.propertyName === 'content' && !item.isMultiple) {
          htmlData = html`${htmlData}
            <div class="${item.class}">
              <label class="content-label">${item.content[0].desc}</label>
              <label class="content-label">${item.content[0].value}</label>
            </div>`;
        } else if (item.propertyName === 'content' && item.isMultiple) {
          htmlData = html`${htmlData}
            <div class="${item.parentClass}">
              ${item.content.map(
                item1 => html` <div class="${item.childClass}">
                  <label>${item1.desc}</label>
                  <label>${item1.value}</label>
                </div>`,
              )}
            </div>`;
        }
      }
    });
    return htmlData;
  }

  render() {
    return html` <div class="mt-50">
      <div>
        <label class="label-font">TITLE</label>
        <div class="document-title">${this.contentData.title}</div>
        <div class="document-subtitle">
          <div class="label-font">SUBTITLE</div>
          <div class="subtitle-content">
            ${this.contentData.subTitle.map(
              item => html`<label class="subtitle-label">${item}</label>`,
            )}
          </div>
        </div>
      </div>
      <div class="mb-8">
        <label class="label-font">SECTION</label>
        <div class="document-title document-title-section">${this.contentData.section}</div>
      </div>
      <div>
        <label class="label-font">SUB-SECTION</label>
        <div>${this.buildInvoiceElement()}</div>
      </div>
    </div>`;
  }
}
customElements.define('document-preview', DocumentPreview);
