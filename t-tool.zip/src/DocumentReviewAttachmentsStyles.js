import {
  css,
  indigo60,
  indigo15,
  font12BoldMixin,
  font14Mixin,
  font14BoldMixin,
  black80,
} from 'ing-web';

export default css`
  .attachments-container {
    width: 80%;
  }
  .input-area {
    width: 50%;
    display: inline-block;
    vertical-align: middle;
    margin-right: 20px;
    margin-bottom: 11px;
  }
  .save-button [indigo] {
    margin-left: calc(100% - 187px);
    width: 180px;
    height: 25px;
    margin-top: 20px;
    ${font12BoldMixin()}
  }
  [add-button] {
    ${font14BoldMixin()}
    height: 36px;
  }
  badge {
    display: inline-block;
    border: 1px solid ${indigo60};
    background-color: ${indigo15};
    padding: 2px 10px;
    position: relative;
    border-radius: 50px;
    color: ${indigo60};
    margin: 3px;
  }
  .badge .cross {
    font-style: unset;
    font-family: monospace;
    position: relative;
    margin-left: 5px;
    color: ${indigo60};
    font-size: 18px;
    cursor: pointer;
  }
  [inputLabel] label {
    color: ${black80};
    ${font14Mixin()}
    margin-bottom: 8px !important;
    display: block;
  }
`;
