import {
  css,
  black6,
  font14BoldMixin,
  white,
  orange,
  font24BoldMixin,
  font19BoldMixin,
} from 'ing-web';

export default css`
  .main_container {
    background: ${black6};
    width: 100%;
    height: calc(100vh - 100px);
  }

  .content_body_area {
    margin: 0 auto;
    height: 304px;
    width: 30%;
    border-radius: 4px;
    background-color: ${white};
    box-shadow: 0 2px 2px 0 rgb(0 0 0 / 14%), 0 3px 1px -2px rgb(0 0 0 / 12%),
      0 1px 5px 0 rgb(0 0 0 / 20%);
    display: flex;
    align-items: center;
    justify-content: center;
    top: 64px;
    position: relative;
    flex-direction: column;
  }

  .access-button::before {
    margin: 0 0 0 0;
    min-height: 36px;
    width: 190px;
  }

  .access-button {
    min-width: 190px;
    height: 36px;
    ${font14BoldMixin()}
  }
  .label-text {
    color: ${orange};
    font-size: ${font24BoldMixin()};
    text-align: center;
    margin-bottom: 22px;
    font-family: 'ING Me';
  }

  @media only screen and (max-width: 750px) {
    .content_body_area {
      width: 60%;
    }
  }

  @media only screen and (max-width: 350px) {
    .content_body_area {
      width: 70%;
    }

    .label-text {
      font-size: ${font19BoldMixin()};
    }

    .access-button {
      min-width: 150px;
    }
  }
`;
