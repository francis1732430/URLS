import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngIcon,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngDialog,
  IngDialogFrame,
} from 'ing-web';

import styles from './CollapsibleDocumentDetailsStyles.js';

import { IngFeatTransparencyToolUtils } from './utils/index.js';

import { DocumentCommonDetailsTable } from './components/tables/DocumentCommonDetailsTable.js';
import { DialogModifySection } from './components/dialog/DialogModifySection.js';
import { SaveDialog } from './components/dialog/SaveDialog.js';

/* eslint no-param-reassign: ["error", { "props": false }] */
function swapItems(anArray, indexA, indexB) {
  const temp = anArray[indexA];
  anArray[indexA] = anArray[indexB];
  anArray[indexB] = temp;
  return anArray;
}

function closeDialog(event) {
  event.target.dispatchEvent(
    new Event('close-overlay', {
      bubbles: true,
    }),
  );
}

export class CollapsibleDocumentDetails extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'document-common-details-table': DocumentCommonDetailsTable,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
      'dialog-modify-section': DialogModifySection,
      'save-dialog': SaveDialog,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      sectionName: { type: String },
      headerData: { type: Array },
      tableContentData: { type: Array },
      selectedRow: { type: Object },
      propertyId: { type: String },
      nameId: String,
      isEnableAddElement: { type: Boolean, reflect: true },
      isEnableRemoveElement: { type: Boolean, reflect: true },
      isEnableNewVersion: { type: Boolean, reflect: true },
      isEnableDuplicateVersion: { type: Boolean, reflect: true },
      isEnableViewDetails: { type: Boolean, reflect: true },
      isEnableUpArrow: { type: Boolean, reflect: true },
      isEnableDownArrow: { type: Boolean, reflect: true },
      selectedParentData: { type: Object },
    };
  }

  _viewSectionDetails(event) {
    this.selectedRow = event.detail.data;
    // eslint-disable-next-line no-console
    console.log(this.selectedRow);

    const rowClickedEvent = new CustomEvent('selected-table-row', {
      detail: {
        data: this.selectedRow,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _modifySectionDetails() {
    const rowClickedEvent = new CustomEvent('modify-table-row', {
      detail: {
        data: this.selectedRow,
        name: this.sectionName,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _newVersionDetails() {
    const rowClickedEvent = new CustomEvent('new-version-table-row', {
      detail: {
        data: this.selectedRow,
        name: this.sectionName,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _newDuplicateDetails() {
    const rowClickedEvent = new CustomEvent('new-duplicate-table-row', {
      detail: {
        data: this.selectedRow,
        name: this.sectionName,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _deleteRowDetails() {
    const rowClickedEvent = new CustomEvent('delete-table-row', {
      detail: {
        data: this.selectedRow,
        name: this.sectionName,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _moveRow(event) {
    // eslint-disable-next-line no-console
    console.log(event.currentTarget.data);
    const direction = event.currentTarget.data;
    let swapped = false;
    let swappedData = {};
    let swappedWithData = {};
    if (this.selectedRow !== 'undefined') {
      for (let index = 0; index < this.tableContentData.length && !swapped; index += 1) {
        if (
          this.tableContentData[index]?.[this.propertyId] === this.selectedRow?.[this.propertyId]
        ) {
          if (direction === 'up' && index > 0) {
            swappedData = { ...this.tableContentData[index], order: index };
            swappedWithData = { ...this.tableContentData[index - 1], order: index + 1 };
            this.tableContentData = swapItems(this.tableContentData, index, index - 1);
            swapped = true;
          } else if (direction === 'down' && index < this.tableContentData.length - 1) {
            swappedData = { ...this.tableContentData[index], order: index + 2 };
            swappedWithData = { ...this.tableContentData[index + 1], order: index + 1 };
            this.tableContentData = swapItems(this.tableContentData, index, index + 1);
            swapped = true;
            // this.selectedDocument = JSON.parse(JSON.stringify(this.selectedDocument));
          }
          if (swapped) {
            this.tableContentData = IngFeatTransparencyToolUtils.copyByReference(
              this.tableContentData,
            );
            // this.selectedDocument = JSON.parse(JSON.stringify(this.selectedDocument));

            const rowOrderChanged = new CustomEvent('row-order-changed', {
              detail: {
                data: this.tableContentData,
                swappedData,
                swappedWithData,
              },
            });
            this.dispatchEvent(rowOrderChanged);
          }
        }
      }
    }
  }

  _nextDialogPage() {
    const dialogA = this.shadowRoot.querySelector('#dialog1');
    const dialogB = this.shadowRoot.querySelector('#dialog2');

    // open next dialog step
    dialogA.opened = false;
    dialogB.opened = true;
  }

  _addElement() {
    const ev = new CustomEvent('add-new-element', {
      detail: {
        headerData: this.headerData,
        tableContentData: this.tableContentData,
        selectedRow: this.selectedRow,
        name: this.sectionName,
        propertyId: this.nameId,
      },
    });
    this.dispatchEvent(ev);
  }

  getSectionName() {
    if (this.sectionName === 'Nota') {
      return 'Note';
      // eslint-disable-next-line
    } else if (this.sectionName === 'Regola') {
      return 'Regole';
    }
    return this.sectionName;
  }

  updated(changed) {
    if (changed.has('selectedParentData')) {
      const el = this.shadowRoot.querySelector('#title');

      if (this.selectedParentData?.id && el) {
        const a = el.querySelector('.content1');
        if (a) {
          a.style.display = 'block';
        }
      }
      if (!this.selectedParentData?.id && el) {
        const a = el.querySelector('.content1');
        if (a) {
          a.style.display = 'none';
        }
      }
    }
  }

  render() {
    return html` <ing-collapsible ?opened=${!!this.selectedParentData?.id} id="title">
      <ing-collapsible-invoker slot="invoker" class="ing_collapsable">
        <span slot="open">${this.getSectionName()}</span>
        <span slot="close">${this.getSectionName()}</span>
      </ing-collapsible-invoker>

      <div slot="content" class="content1">
        <div class="container">
          <div class="right_alignment">
            <ing-button
              outline
              font12
              class="add_button"
              ?disabled="${this.isEnableAddElement || !this.selectedParentData}"
              @click="${this._addElement}"
              >Aggiungi</ing-button
            >

            <ing-button
              outline
              font12
              class="remove_button"
              @click="${this._deleteRowDetails}"
              ?disabled="${this.isEnableRemoveElement || !this.selectedRow?.id}"
              >Rimuovi</ing-button
            >
            <ing-icon
              class="button-pointer up_arrow ${this.isEnableUpArrow ? 'pointer-events' : ''}"
              icon-id="ing:solid-arrows:arrowUp"
              slot="icon-before"
              aria-label="icon:pointer"
              @click="${this._moveRow}"
              .data="${'up'}"
            ></ing-icon>
            <ing-icon
              class="button-pointer down_arrow ${this.isEnableDownArrow ? 'pointer-events' : ''}"
              icon-id="ing:solid-arrows:arrowDown"
              slot="icon-before"
              aria-label="icon:pointer"
              @click="${this._moveRow}"
              .data="${'down'}"
            ></ing-icon>
          </div>
        </div>
        ${this.tableContentData !== undefined && this.tableContentData.length > 0
          ? html` <div>
                <document-common-details-table
                  .tableData=${this.tableContentData}
                  .headerData=${this.headerData}
                  .propertyId="${this.propertyId}"
                  .nameId="${this.nameId}"
                  .selectedRow="${this.selectedRow}"
                  @selected-table-row="${this._viewSectionDetails}"
                >
                </document-common-details-table>
              </div>
              <div class="container">
                <div class="right_alignment">
                  <ing-button
                    outline
                    indigo
                    font12
                    class="new_version_button"
                    @click="${this._newVersionDetails}"
                    ?disabled="${this.isEnableNewVersion ||
                    this.selectedRow === undefined ||
                    !this.selectedRow?.id}"
                    >Nuova Versione</ing-button
                  >
                  <ing-button
                    outline
                    indigo
                    font12
                    class="new_duplication_button"
                    @click="${this._newDuplicateDetails}"
                    ?disabled="${this.isEnableDuplicateVersion ||
                    this.selectedRow === undefined ||
                    !this.selectedRow?.id}"
                    >Nuova con Duplicazione</ing-button
                  >

                  <ing-button
                    outline
                    indigo
                    font12
                    class="modify_button"
                    @click="${this._modifySectionDetails}"
                    ?disabled="${this.isEnableViewDetails ||
                    this.selectedRow === undefined ||
                    !this.selectedRow?.id}"
                    >Vedi dettaglio</ing-button
                  >
                  <ing-dialog id="dialog2">
                    <ing-dialog-frame slot="content" has-close-button variation="white-19">
                      <div slot="header">Modifica sezione</div>
                      <div slot="content">
                        <save-dialog @close-dialog-event="${closeDialog}"></save-dialog>
                      </div>
                    </ing-dialog-frame>
                  </ing-dialog>
                </div>
              </div>`
          : ''}
      </div>
    </ing-collapsible>`;
  }
}
customElements.define('collapsible-document-details', CollapsibleDocumentDetails);
