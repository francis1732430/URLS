import {
  css,
  font14BoldMixin,
  font14Mixin,
  font16BoldMixin,
  font19BoldMixin,
  green,
  indigo,
  orange,
} from 'ing-web';

export default css`
  .tab_content {
    margin: 0px 0px 0px 108px;
  }

  .document_details_content {
    height: auto;
  }

  .document_details_label {
    margin-top: 29px;
  }

  .document_details_text {
    ${font19BoldMixin()};
  }

  .document_details_name {
    width: 705px;
    display: inline-block;
  }

  .document_details_status {
    margin-top: 32px;
    width: 184px;
    height: 40px;
    display: inline-block;
    margin-left: 100px;
  }

  .document_details_id {
    margin-top: 32px;
    width: 80px;
    height: 40px;
    display: inline-block;
  }

  .document_details_product {
    margin-top: 32px;
    width: 100px;
    height: 40px;
    margin-left: 26px;
    display: inline-block;
  }

  .document_details_code {
    margin-top: 32px;
    width: 80px;
    height: 40px;
    margin-left: 22px;
    display: inline-block;
  }

  .document_details_type {
    margin-top: 32px;
    width: 100px;
    height: 40px;
    margin-left: 26px;
    display: inline-block;
  }

  .document_details_from {
    margin-top: 32px;
    width: 180px;
    height: 40px;
    margin-left: 80px;
    display: inline-block;
    --ing-input-group-width: 180px;
  }

  .document_details_template_file {
    margin-top: 32px;
    width: 290px;
    height: 40px;
  }

  .single {
    position: relative;
  }

  .container {
    height: 110px;
    position: relative;
    margin-top: 34px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 105px;
  }

  .view_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .view_button {
    width: 180px;
    height: 32px;
  }

  .review_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .review_button {
    width: 180px;
    height: 32px;
    margin-left: 24px;
  }

  .ing_standard_section_line {
    border-bottom: 2px solid #ff6200;
    margin-top: 41px;
  }

  .modify_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .modify_button {
    width: 180px;
    height: 28px;
    margin-left: 29px;
  }

  .ing_standard_subsection_line {
    border-bottom: 2px solid #ff6200;
    margin-top: 35px;
  }
  .fileUpload {
    margin-top: 35px;
    width: 70%;
  }
  .separator-scetion {
    box-shadow: 0px 0px 4px grey;
    width: 101%;
    position: relative;
    left: -25px;
    box-sizing: border-box;
    padding: 22px;
    margin: 15px 0;
  }
  .version {
    width: 285px;
    margin-top: 32px;
    height: 64px;
  }
  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
  }
  [colorElement] label {
    color: ${orange};
  }
  .stato {
    width: 183.85px;
    margin-left: 50px;
  }
  .name-box {
    display: flex;
    align-items: center;
    margin-top: 32px;
  }
  .create-new-button::before {
    margin: 0 0 0 0;
    min-height: 40px;
    width: 180px;
  }

  .create-new-button {
    min-width: 180px;
    height: 40px;
    margin-top: 49px;
    margin-bottom: 10px;
    ${font14BoldMixin()}
    float: right;
    margin-right: 105px;
  }

  .status-label {
    ${font16BoldMixin()}
    margin-left: 15px;
    margin-top: 10px;
  }
  .blue-cl {
    color: ${indigo};
  }
  .green-cl {
    color: ${green};
  }
`;
