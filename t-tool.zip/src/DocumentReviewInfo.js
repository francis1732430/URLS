import { ScopedElementsMixin, LitElement, html, IngSelect, formatDate } from 'ing-web';
import { baseURL } from './utils/constants.js';
import { ajaxInstance } from './utils/endpoints.js';

import reviewInfoPageStyles from './DocumentReviewInfoStyles.js';
import { deriveData } from './utils/globalApiKeys.js';

export class DocumentListReviewInfo extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-select': IngSelect,
    };
  }

  static get properties() {
    return {
      reviewData: { type: Object },
      lastRequestDate: String,
      currentTab: String,
      versionList: Array,
      version: String,
      highestVersion: Number,
    };
  }

  static get styles() {
    return reviewInfoPageStyles;
  }

  constructor() {
    super();
    this.version = '0';
    this.versionList = [];
    this.ajaxInstance = ajaxInstance;
    this.highestVersion = 0;
  }

  firstUpdated(changed) {
    super.firstUpdated(changed);
    if (
      this.reviewData?.docId &&
      this.currentTab === 'storicaReview' &&
      !this.versionList?.length
    ) {
      this.getVersionDetails();
    }
  }

  handleChange(event) {
    if (!event.target.name) return;
    this[event.target.name] = event.target.value;
    if (event.target.name === 'version' && this.version) {
      this.changeVersion();
    }
  }

  changeVersion() {
    const ev = new CustomEvent('version-changed', {
      detail: {
        data: this.version,
      },
    });
    this.dispatchEvent(ev);
  }

  // eslint-disable-next-line
  getStatusName(status) {
    if (status && status.toUpperCase() === 'IN SVILUPPO') {
      return 'status_draft';
      // eslint-disable-next-line
    } else if (status && status.toUpperCase() === 'APPROVATO') {
      return 'status_prod';
      // eslint-disable-next-line
    } else if (status && status.toUpperCase() === 'IN REVISIONE') {
      return 'status_review';
    }
    return '';
  }

  async getVersionDetails() {
    try {
      this.versionList = await this.getVersionsList(this.reviewData?.docId);

      if (this.versionList.length > 0) {
        this.versionList = this.versionList.map(ver => {
          if (ver) {
            this.highestVersion =
              +ver.versionNumber > this.highestVersion ? +ver.versionNumber : this.highestVersion;
            // eslint-disable-next-line
            ver.versionName = `Versione ${ver.versionNumber} del ${formatDate(
              new Date(ver.validity || new Date()),
              {
                locale: 'it-It',
              },
            )}`;
          }
          return ver;
        });
        const versionEvent = new CustomEvent('highest-version', {
          detail: this.highestVersion,
        });
        this.dispatchEvent(versionEvent);
        setTimeout(() => {
          const data = this.versionList.find(
            item => item?.itemsVersionsID?.toString() === this.reviewData?.id?.toString(),
          );
          if (data) {
            this.version = data.itemsVersionsID?.toString();
          } else {
            this.version = this.versionList[0]?.itemsVersionsID?.toString();
          }
        });
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
    return res.data ? deriveData(res.data) : [];
  }

  render() {
    return html`<div>
        <p>NOME</p>
        <strong>${this.reviewData?.name}</strong>
      </div>
      <table class="dcouemnt-review-table">
        <tr class="dcouemnt-review-tr">
          <td colspan="3">
            <p>ID</p>
            <strong>${this.reviewData?.docId}</strong>
          </td>
          <td colspan="3">
            <p>VALIDO DAL</p>
            <strong
              >${formatDate(new Date(this.reviewData?.start_date), { locale: 'it-It' })}</strong
            >
          </td>
          <td colspan="3">
            <p>STATO</p>
            <strong class="${this.getStatusName(this.reviewData?.status)}"
              >${this.reviewData?.status}</strong
            >
          </td>
          ${this.lastRequestDate
            ? html`<td colspan="3">
                <p>DATA ULTIMA RICHIESTA</p>
                <strong class="document-review-status last-request-date"
                  >${this.lastRequestDate
                    ? formatDate(new Date(this.lastRequestDate), { locale: 'it-It' })
                    : '-'}</strong
                >
              </td>`
            : ''}
          ${this.currentTab === 'storicaReview'
            ? html`<ing-select
                class="input_value version"
                inputElement
                colorElement
                name="version"
                label="VERSIONE"
                .modelValue="${this.version}"
                @change="${this.handleChange}"
              >
                <select slot="input">
                  ${this.versionList.map(
                    item =>
                      html` <option value="${item.itemsVersionsID}">${item.versionName}</option>`,
                  )}
                </select>
              </ing-select>`
            : ''}
        </tr>
      </table>`;
  }
}

customElements.define('document-list-review-info', DocumentListReviewInfo);
