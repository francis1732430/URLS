import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngTab,
  IngTabs,
  IngTabPanel,
  IngIcon,
  IngLink,
  IngTextarea,
  IngInput,
  IngButton,
} from 'ing-web';
import { RemovableChip } from './components/removableChip/removableChip.js';
import { FileUpload } from './components/fileUpload/fileUpload.js';

import styles from './DocumentListHomePageStyles.js';
import pageStyles from './DocumentReviewAttachmentsStyles.js';
import { generateId, validateEmail } from './utils/IngFeatTransparencyToolUtils.js';

export class DocumentReviewAttachments extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-tabs': IngTabs,
      'ing-tab': IngTab,
      'ing-tab-panel': IngTabPanel,
      'ing-icon': IngIcon,
      'ing-link': IngLink,
      'ing-textarea': IngTextarea,
      'ing-input': IngInput,
      'ing-button': IngButton,
      'removable-chip': RemovableChip,
      'file-upload': FileUpload,
    };
  }

  static get properties() {
    return {
      labelText: { type: String },
      addButtonText: { type: String },
      saveButtonText: { type: String },
      files: { type: Array },
      _data: { type: Array },
      _value: { type: String },
      type: { type: String },
      disableRequestReviewFields: { type: Boolean, reflect: true },
      enableAddField: Boolean,
    };
  }

  static get styles() {
    return [styles, pageStyles];
  }

  constructor() {
    super();
    this._data = [];
    this._value = '';
    this.type = 'text';
    this.disableRequestReviewFields = false;
    this.enableAddField = false;
  }

  _onChange(e) {
    this._value = e.target.value;
    if (e?.target?.name === 'email' && validateEmail(this._value)) {
      this.enableAddField = true;
    } else {
      this.enableAddField = false;
    }
  }

  _onAdd() {
    if (this._value === undefined || this._value.trim() === '') {
      this._value = '';
      return;
    }
    this._data.push({ labelText: this._value, id: generateId() });
    this._value = '';
    this._onSave();
    if (this.type === 'email' && validateEmail(this._value)) {
      this.enableAddField = true;
    } else {
      this.enableAddField = false;
    }
  }

  _onSave() {
    const event = new CustomEvent('data-received', {
      detail: this._data,
    });
    this.dispatchEvent(event);
  }

  _onChipDeleted(e) {
    const { id } = e.detail;
    if (this.type === 'file') {
      this._removedFile(id);
    } else if (this.type === 'email') {
      this._data = this._data.filter(d => d?.id?.toString() !== id?.toString());
      this._onSave();
    } else {
      this._onSave();
    }
  }

  _filesAdded(e) {
    const files = e.detail.map(f => {
      f.id = generateId(); // eslint-disable-line no-param-reassign
      return f;
    });
    this._data = [...this._data, ...files];
    const event = new CustomEvent('files-added', {
      detail: { data: this._data, files },
    });
    this.dispatchEvent(event);
  }

  _removedFile(id) {
    const event = new CustomEvent('data-removed', {
      detail: { id },
    });
    this.dispatchEvent(event);
  }

  render() {
    return html`
      <div class="attachments-container">
        ${this.type === 'file'
          ? html`<file-upload
              @files-added="${this._filesAdded}"
              ?disableFile="${this.disableRequestReviewFields}"
            ></file-upload>`
          : html`<div class="input-area">
                <ing-input
                  ing-input-test
                  inputLabel
                  .modelValue="${this._value}"
                  @keyup="${this._onChange}"
                  label="${this.labelText}"
                  type="${this.type}"
                  name="email"
                  placeholder="example@domain.com"
                  ?disabled="${this.disableRequestReviewFields}"
                ></ing-input>
              </div>
              <ing-button
                add-button
                ?disabled="${this.disableRequestReviewFields || !this.enableAddField}"
                @click="${this._onAdd}"
                >${this.addButtonText}</ing-button
              >`}

        <div class="files">
          ${this._data.map(
            d => html`
              <removable-chip
                @chip-deleted="${this._onChipDeleted}"
                id="${d.id}"
                labelText="${d.labelText || d.name}"
                ?closeIconEnable="${this.disableRequestReviewFields}"
              >
              </removable-chip>
            `,
          )}
        </div>
        ${this.saveButtonText
          ? html`<div class="save-button">
              <ing-button
                @click="${this._onSave}"
                ?disabled="${this.disableRequestReviewFields}"
                indigo
                >${this.saveButtonText}</ing-button
              >
            </div>`
          : ``}
        <div>
          <slot name="end"> </slot>
        </div>
      </div>
    `;
  }
}

customElements.define('document-review-attachments', DocumentReviewAttachments);
