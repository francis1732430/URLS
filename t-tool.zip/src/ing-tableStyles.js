import { black80, css, font16BoldMixin, font19BoldMixin, leaf, orange, sky30 } from 'ing-web';

export default css`
  table,
  table::before,
  table::after {
    box-sizing: border-box;
  }

  caption,
  caption::before,
  caption::after {
    box-sizing: border-box;
  }

  th,
  th::before,
  th::after {
    box-sizing: border-box;
  }

  td,
  td::before,
  td::after {
    box-sizing: border-box;
  }

  .table-th,
  .table-th::before,
  .table-th::after {
    box-sizing: border-box;
  }

  .table-td,
  .table-td::before,
  .table-td::after {
    box-sizing: border-box;
  }

  .table {
    border-collapse: collapse;
    text-align: left;
    display: table;
  }

  .table caption {
    ${font19BoldMixin()}
    padding-top: 0;
    padding-bottom: 24px;
    color: ${orange};
    caption-side: top;
    text-align: left;
  }

  .table tr,
  .table-tr {
    border-bottom: 1px solid #d9d9d9;
  }

  .table thead > tr,
  .table thead > .table-tr,
  .table-header-group > .table-tr {
    border-bottom: 1px solid #ff6200;
  }

  .table thead > tr > :first-child,
  .table tbody > tr > :first-child,
  .table tfoot > tr > :first-child,
  .table-tr > :first-child {
    text-align: center;
  }

  .table th,
  .table-th {
    ${font16BoldMixin()}
    color: ${black80};
    text-align: inherit;
  }

  .table td,
  .table-tr > td,
  .table-td {
    color: ${black80};
    font-family: 'ING Me';
    font-size: 11px;
    letter-spacing: 0.01px;
    line-height: NaNpx;
  }

  .table td.table__cell--numeric,
  .table-td.table__cell--numeric {
    text-align: right;
  }

  .table th,
  .table td,
  .table-th,
  .table-td {
    padding: 8px 22px 8px 0;
  }

  .table-header-group {
    display: table-header-group;
  }

  .table-td,
  .table-th {
    display: table-cell;
    vertical-align: middle;
  }

  .table-tbody {
    display: table-row-group;
  }

  .table-tr {
    display: table-row;
  }

  .table tbody tr:hover {
    background-color: ${sky30};
  }

  .selected-row-class {
    background-color: ${sky30};
  }

  thead {
    text-align: center;
  }

  .id_header {
    width: 80px;
    height: 29px;
  }

  .product_header {
    width: 104px;
    height: 29px;
  }

  .code_header {
    width: 109px;
    height: 29px;
  }

  .name_header {
    width: 335px;
    height: 29px;
  }

  .type_header {
    width: 84px;
    height: 29px;
  }

  .date_header {
    width: 107px;
    height: 29px;
  }

  .status_header {
    width: 106px;
    height: 29px;
  }

  .version_header {
    width: 106px;
    height: 29px;
  }

  .table_default_text_align {
    text-align: center;
  }

  .name_text_align {
    text-align: left;
  }
  .status_draft {
    font-weight: bold;
    color: ${black80} !important;
  }
  .status_prod {
    font-weight: bold;
    color: ${leaf} !important;
  }
  .status_review {
    font-weight: bold;
    color: ${orange} !important;
  }

  [data-tag-name='ing-select'] {
    height: 25px;
    max-height: 25px;
    width: 75px;
  }

  [inputValue] select {
    font-size: 12px !important;
    height: 35px !important;
    width: 75px;
  }

  .pointer-event-curser {
    cursor: pointer;
  }
  .line {
    font-size: 2.5em;
  }
`;
