import { css, orange, black59, font16BoldMixin, black6 } from 'ing-web';

export default css`
  #main_header {
    align-items: center;
    padding: 20px 0;
    top: 0;
    z-index: 100;
    background-color: var(--page-background);
    box-shadow: 0 0 3px rgba(0, 0, 0, 0.3);
  }

  header {
    font-family: INGMe, arial, helvetica, sans-serif;
    background: var(--white);
  }

  #main_header .content_area {
    display: flex;
    justify-content: space-between;
    align-items: center;
    min-height: 30px;
  }

  .demo-container {
    width: 150px;
  }

  .label_test {
    margin-left: 20px;
  }

  .link_content_area {
    margin: 0 auto;
    display: inline-block;
    height: 64px;
    width: 1280px;
  }

  .link_container {
    height: 64px;
  }

  .container_list_documents {
    margin-left: 57px;
    display: inline-block;
    margin-top: 20px;
  }

  .container_edit_documents {
    margin-left: 73px;
    display: inline-block;
    margin-top: 20px;
  }

  .container_review_documents {
    margin-left: 59px;
    display: inline-block;
    margin-top: 20px;
  }

  .link_highlighted {
    --link-color: ${orange};
    ${font16BoldMixin()}
  }

  .link_not_highlighted {
    --link-color: ${black59};
    ${font16BoldMixin()}
  }
  [ingspinnerglobal] {
    position: fixed;
    top: 51%;
    left: 50%;
    z-index: 999;
    transform: translate(-50%, -50%) scale(1.5);
  }
  [document-review-tabs] {
    margin: 0px auto;
    width: 1232px;
  }
  .grey-empty-area {
    height: 41px;
    background: ${black6};
  }
  .main_container {
    background: ${black6};
  }
`;
