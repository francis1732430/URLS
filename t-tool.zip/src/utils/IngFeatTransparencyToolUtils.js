import { localStorageKeysMap } from './constants.js';

export const IngFeatTransparencyToolUtils = {
  copyByReference(value) {
    return JSON.parse(JSON.stringify(value));
  },
};

/* eslint no-param-reassign: ["error", { "props": false }] */
export const swapItems = {
  swapItems(anArray, indexA, indexB) {
    const temp = anArray[indexA];
    anArray[indexA] = anArray[indexB];
    anArray[indexB] = temp;
    return anArray;
  },
};
export const transformDateToBackend = date => {
  if (!date) {
    // eslint-disable-next-line no-param-reassign
    date = new Date();
  } else {
    // eslint-disable-next-line no-param-reassign
    date = new Date(date);
  }
  const year = date.getUTCFullYear();
  const month =
    date.getUTCMonth() + 1 < 10
      ? `0${(date.getUTCMonth() + 1).toString()}`
      : date.getUTCMonth() + 1;
  const day = date.getUTCDate() + 1 < 10 ? `0${date.getUTCDate().toString()}` : date.getUTCDate();
  const formattedDate = `${year}-${month}-${day}`;
  return formattedDate;
};

export const generateId = () =>
  `${Math.floor(Math.random() * (100000 - 1000) + 100)}-${Math.floor(
    Math.random() * (100000 - 1000) + 100,
  )}-${Math.floor(Math.random() * (100000 - 1000) + 100)}`;

export const formatDate = str => {
  const date = new Date(str);
  const year = date.getFullYear().toString().substring(2);
  let month = date.getMonth() + 1;
  let dt = date.getDate();

  if (dt < 10) {
    dt = `0${dt}`;
  }
  if (month < 10) {
    month = `0${month}`;
  }

  return `${dt}/${month}/${year}`;
};

export const escapeSlashes = (str = '') => {
  const regex = /(\r\n|\n|\r|↵)/gi;
  const result = str.replace(regex, '\\n');
  return result;
};

export const restoreSlashes = (str = '') => {
  const regex = /(\\r\\n|\\n|\\r|↵)/gi;
  const result = str.replace(regex, '\n');
  return result;
};

export const getHighestItemVersionId = list =>
  list?.length
    ? list.reduce((prev, current) =>
        +prev?.itemsVersionsID?.toString() > +current?.itemsVersionsID?.toString() ? prev : current,
      )
    : undefined;

export const getHostURL = () => {
  const url = new URL(window.location.href);
  const constructedUrl = `${url.protocol}//${url.hostname}${url.port ? `:${url.port}` : ''}${
    url.pathname
  }${url.search}`;
  return constructedUrl;
};

// eslint-disable-next-line
export const validateEmail = email => {
  return email.match(
    // eslint-disable-next-line
    /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  );
};
export const addElementToLocalStorage = (data, localStorageKey, isObjectType) => {
  if (!window.localStorage) return;
  let lData = localStorage.getItem(localStorageKey);
  if (Array.isArray(data)) {
    if (data && data.length) localStorage.setItem(localStorageKey, JSON.stringify(data));
  } else if (lData && !isObjectType) {
    lData = JSON.parse(lData);
    const idx = lData.findIndex(d => d.id.toString() === data.id.toString());
    if (idx === -1) {
      lData.push(data);
    } else {
      lData[idx] = data;
    }
    localStorage.setItem(localStorageKey, JSON.stringify(lData));
  } else if (!isObjectType) localStorage.setItem(localStorageKey, JSON.stringify([data]));
  else localStorage.setItem(localStorageKey, JSON.stringify(data));
};

export const removeElementFromLocalStorage = (id, localStorageKey, isNotID) => {
  if (!window.localStorage) return;
  let lData = localStorage.getItem(localStorageKey);
  if (lData) {
    lData = JSON.parse(lData);
    let newData = [];
    if (isNotID) {
      newData = lData.filter(d => d?.toString() !== id.toString());
    } else {
      newData = lData.filter(d => d?.id?.toString() !== id.toString());
    }
    if (newData.length) localStorage.setItem(localStorageKey, JSON.stringify(newData));
    else localStorage.removeItem(localStorageKey);
  }
};

export const removeAllElementsFromLocalStorage = () => {
  if (!window.localStorage) return;
  Object.keys(localStorageKeysMap).forEach(key =>
    localStorage.removeItem(localStorageKeysMap[key]),
  );
};

export const removeElementFromLocalStorageByKey = localStorageKey => {
  if (!window.localStorage) return;
  const lData = localStorage.getItem(localStorageKey);
  if (lData) {
    localStorage.removeItem(localStorageKey);
  }
};
/**
 * Map property to source object by matching its identity within list and pluck specific property from matched object
 * @param {Array} list array of elements
 * @param {Object} obj source object
 * @param {String} propertyToMap property within object
 * @param {String} identity identity for matching objects
 */
export const mapPropertyToObjectFromList = (
  list = [],
  obj = {},
  propertyToMap = 'name',
  identity = 'id',
  isDescriptionPropertyToMap = false,
) => {
  if (list && list.length) {
    // eslint-disable-next-line
    for (let index = 0; index < list.length; index++) {
      const element = list[index];
      if (element[identity]?.toString() === obj?.[identity]?.toString()) {
        obj[propertyToMap] = element?.[propertyToMap];
        if (!isDescriptionPropertyToMap && element?.description) {
          obj.description = element?.description;
        }
        break;
      }
    }
  }
};

export const sortArray = (arr = [], key) => {
  if (!Array.isArray(arr)) {
    // eslint-disable-next-line
    arr = [];
  }
  return arr.sort(({ [key]: a }, { [key]: b }) => a - b);
};

// eslint-disable-next-line
export const getSortedList = (data = []) => {
  const labelData = data.find(d => d.id?.toString() === '0');
  let list = data.filter(d => d.id?.toString() !== '0') || [];
  list = list?.sort((a, b) => {
    if (a.name?.toLowerCase() < b.name?.toLowerCase()) {
      return -1;
    }
    if (a.name?.toLowerCase() > b.name?.toLowerCase()) {
      return 1;
    }
    return 0;
  });
  // eslint-disable-next-line
  labelData && list.unshift(labelData);
  return list || [];
};

export const getHighestId = list =>
  list?.length
    ? list.reduce((prev, current) =>
        +prev?.id?.toString() > +current?.id?.toString() ? prev : current,
      )
    : undefined;
