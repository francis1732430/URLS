const apiKeys = [
  'itemsVersionsList',
  'itemsVersionsParentDocumentsList',
  'itemsList',
  'lookupList',
  'lookupRulesList',
];

// global function in utils
export const deriveData = res => {
  let derivedData;
  const index = apiKeys.findIndex(key => res && res[key]);
  if (index > -1) {
    derivedData = res[apiKeys[index]];
  } else {
    derivedData = res;
  }
  return derivedData;
};
