// localEnvironment <development<false | true> | production<false | true>>
export const localEnvironment = { production: false, development: false };

let baseURLPrefix;

if (localEnvironment.production) {
  // FOR ACTUAL USE
  baseURLPrefix = '';
} else {
  // FOR MOCK USE
  baseURLPrefix = 'api/';
}

export const localStorageKeysMap = {
  APPLICATION_NOTES: 'TRANSPARENCY_TOOL_APPLICATION_NOTES',
  APPLICATION_ROWS: 'TRANSPARENCY_TOOL_APPLICATION_ROWS',
  APPLICATION_SUBSECTIONS: 'TRANSPARENCY_TOOL_APPLICATION_SUBSECTIONS',
  APPLICATION_SECTIONS: 'TRANSPARENCY_TOOL_APPLICATION_SECTIONS',
  APPLICATION_RULES: 'TRANSPARENCY_TOOL_APPLICATION_RULES',
  APPLICATION_DOCUMENTS: 'TRANSPARENCY_TOOL_APPLICATION_DOCUMENTS',
  APPLICATION_NOTES_MAPPING: 'TRANSPARENCY_TOOL_APPLICATION_NOTES_MAPPING',
  APPLICATION_ROWS_MAPPING: 'TRANSPARENCY_TOOL_APPLICATION_ROWS_MAPPING',
  APPLICATION_SUBSECTION_MAPPING: 'TRANSPARENCY_TOOL_APPLICATION_SUBSECTION_MAPPING',
  APPLICATION_EXISTING_NOTES_MAPPING: 'TRANSPARENCY_TOOL_APPLICATION_EXISTING_NOTES_MAPPING',
  APPLICATION_EXISTING_ROWS_MAPPING: 'TRANSPARENCY_TOOL_APPLICATION_EXISTING_ROWS_MAPPING',
  APPLICATION_EXISTING_SUBSECTION_MAPPING:
    'TRANSPARENCY_TOOL_APPLICATION_EXISTING_SUBSECTION_MAPPING',
};
export const localStorageValuesMap = {
  notesData: 'APPLICATION_NOTES',
  rowData: 'APPLICATION_ROWS',
  subSectionsList: 'APPLICATION_SUBSECTIONS',
  sectionsList: 'APPLICATION_SECTIONS',
  ruleData: 'APPLICATION_RULES',
  documentData: 'APPLICATION_DOCUMENTS',
  notesMappingList: 'APPLICATION_NOTES_MAPPING',
  rowsMappingList: 'APPLICATION_ROWS_MAPPING',
  subSectionMappingList: 'APPLICATION_SUBSECTION_MAPPING',
  existingElementNotes: 'APPLICATION_EXISTING_NOTES_MAPPING',
  existingElementRows: 'APPLICATION_EXISTING_ROWS_MAPPING',
  existingElementSubsection: 'APPLICATION_EXISTING_SUBSECTION_MAPPING',
};

export const baseURL = `/${baseURLPrefix}v1/document-template-administration/item`;
export const baseURL2 = `/${baseURLPrefix}v1/document-template-administration/item`;
export const baseURL3 = `/${baseURLPrefix}v1/document-template-administration/lookup`;
export const baseURL4 = `/${baseURLPrefix}v1/document-template-administration/rules/lookup`;
export const baseURL5 = `/${baseURLPrefix}v1/document-template-administration`;
export const baseURL6 = `/${baseURLPrefix}v1/documents`;
