import { ajaxInstance } from './endpoints.js';
import { baseURL, baseURL2, baseURL5, baseURL6 } from './constants.js';
import { messages } from '../data/messages.js';

export const fetchChildItems = id => {
  const url = `${baseURL2}/version/${id}`;
  return ajaxInstance.get(url).then(res => res.data);
};

export const fetchChildItemsByStyle = id => {
  const url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
  return ajaxInstance.get(url).then(res => res.data);
};

export const removeRelations = item => {
  const url = `${baseURL5}/items-versions-relations?itemsVersionsIDParent=${item.parentId}&itemsVersionsIDChild=${item.childId}`;
  return ajaxInstance.delete(url, {}).then(res => res.data);
};

export const removeVersionLevels = item => {
  const url = `${baseURL5}/version-detail?versionDetailLevel=${item.level}&versionDetailID=${item.id}`;
  return ajaxInstance.delete(url, {}).then(res => res.data);
};

export const createVersionDetail = item => {
  const url = `${baseURL5}/version-details`;
  return ajaxInstance.post(url, { versionDetailsDTO: item }).then(res => res.data);
};

// eslint-disable-next-line
const tranformRelationAPI = (parentId, childId, order = 0) => {
  return {
    itemsVersionsIDParent: parentId,
    itemsVersionsIDChild: childId,
    itemOrder: order,
  };
};

export const createRelations = item => {
  const itemsVersionsRelationsDTO = [tranformRelationAPI(item.parentId, item.childId, item?.order)];
  return ajaxInstance
    .put(`${baseURL}s/versions/relation`, { itemsVersionsRelationsDTO })
    .then(res => res.data);
};

// eslint-disable-next-line
export const toBase64 = file => {
  // eslint-disable-next-line
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = error => reject(error);
  });
};

// eslint-disable-next-line
const getExt = filepath => filepath.split('?')[0].split('#')[0].split('.').pop();

export const multipleFileUpload = async item => {
  const base64 = await toBase64(item);
  const url = `${baseURL6}/generic-document`;
  return ajaxInstance
    .post(url, {
      metadata: {
        system: {
          isCacheable: false,
          fileName: item?.name,
          size: item?.size,
          accessKey: {
            attachmentFileName: `${Date.now()}_${item?.name}`,
            rootPathId: `${messages.file.rootPathId}/`,
            keyType: messages.file.keyType,
            attachmentPath: `${Date.now()}/`,
          },
          documentTypeId: `${messages.file.documentTypeId}`,
          storage: messages.file.storage,
          contentType: item?.type,
          // contentType: getExt(item?.name),
        },
      },
      content: {
        base64: base64.slice(base64.indexOf(';base64,') + 8),
      },
    })
    .then(res => {
      // eslint-disable-next-line
      item.id = res.data.id;
      // eslint-disable-next-line
      return item;
    });
};

export const allSettled = (items, fn) => {
  const promises = items.map(item => fn(item));
  return Promise.allSettled(promises);
};

export const series = (items, fn) => {
  const result = [];
  return items
    .reduce((acc, item) => {
      // eslint-disable-next-line
      acc = acc.then(() => {
        return fn(item).then(res => result.push(res));
      });
      return acc;
    }, Promise.resolve())
    .then(() => result);
};

export const splitToChunks = (items, chunkSize = 50) => {
  const result = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    result.push(items.slice(i, i + chunkSize));
  }
  return result;
};

export const chunks = (items, fn, chunkSize = 50) => {
  let result = [];
  const chunks1 = splitToChunks(items, chunkSize);
  // eslint-disable-next-line
  return series(chunks1, chunk => {
    // eslint-disable-next-line
    return (
      allSettled(chunk, fn)
        // eslint-disable-next-line
        .then(res => (result = result.concat(res)))
    );
  }).then(() => result);
};
