class Singleton {
  constructor() {
    if (Singleton._instance) {
      return Singleton._instance;
    }

    Singleton._instance = this;

    this._map = new Map();
  }

  static instance() {
    if (!Singleton._instance) {
      return new Singleton();
    }

    return Singleton._instance;
  }

  createdLookupValues(list = []) {
    if (list && list.length > 0) {
      list.forEach(item => {
        this._map.set(item?.lookupDataID?.toString(), item.ldValue);
      });
    }
  }

  getLookupValues() {
    return this._map;
  }

  getLookupValuesByKey(key) {
    return this._map.get(key?.toString());
  }
}

Singleton._instance = null;

export default Singleton;
