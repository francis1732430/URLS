import { ajaxApi } from 'ing-web';

// export const ajaxInstance = new AjaxClass({
//   cancelable: true,
//   headers: {
//     'CUSTOM-HEADER': 'test',
//   },
// });

export const ajaxInstance = ajaxApi;
