import { LocalizeManager } from 'ing-web';

export const ChangeLanguage = lang => {
  const lm = new LocalizeManager();
  lm.locale = lang;
  return lm;
};
