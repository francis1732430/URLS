import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngIcon,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngDialog,
  IngDialogFrame,
  IngInput,
  IngPaginationLinks,
} from 'ing-web';

import styles from './createElementFromScratchStyles.js';

import { DocumentCommonDetailsTable } from './components/tables/DocumentCommonDetailsTable.js';
import { DialogModifySection } from './components/dialog/DialogModifySection.js';
import { NewDocumentCreation } from './components/document/creation/NewDocumentCreation.js';
import { RowCreation } from './components/document/creation/rowCreation.js';
import { RuleCreation } from './components/document/creation/Rules/RuleCreation.js';
import { CreateSubSection } from './components/document/creation/CreateSubSection.js';
import { DocumentRowsDetailsTable } from './components/tables/DocumentRowsDetailsTable.js';
import { generateId, getHostURL } from './utils/IngFeatTransparencyToolUtils.js';
import { IngTable } from './ing-table.js';
import { baseURL, baseURL2, baseURL3, baseURL4 } from './utils/constants.js';
import { ajaxInstance } from './utils/endpoints.js';
import { transformRowsToFrontEnd } from './data/tranformations/rowTransformation.js';
import { transformSectionsToFrontEnd } from './data/tranformations/sectionTransformation.js';
import { transformSubSectionsToFrontEnd } from './data/tranformations/subSectionsTransformation.js';
import { transformNoteToFrontEnd } from './data/tranformations/noteTransformation.js';
import { transformRulesToFrontEnd } from './data/tranformations/ruleTransformation.js';
import {
  transformParentDocumentsListToFrontEnd,
  transformDocumentsToFrontEnd,
  transformLookUpDataToFrontEnd,
} from './data/tranformations/documentTranformation.js';
import { deriveData } from './utils/globalApiKeys.js';

export class ElementFromScratch extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'document-common-details-table': DocumentCommonDetailsTable,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
      'dialog-modify-section': DialogModifySection,
      'ing-input': IngInput,
      'new-document-creation': NewDocumentCreation,
      'row-creation': RowCreation,
      'rule-creation': RuleCreation,
      'create-sub-section': CreateSubSection,
      'document-rows-details-table': DocumentRowsDetailsTable,
      'ing-table': IngTable,
      'ing-pagination-links': IngPaginationLinks,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      sectionName: { type: String },
      headerData: { type: Array },
      tableContentData: { type: Array },
      selectedRow: { type: Object },
      propertyId: { type: String },
      _showCreateForm: { type: Boolean },
      docId: { type: String },
      sectionId: { type: String },
      subSectionId: { type: String },
      rowId: { type: String },
      noteId: { type: String },
      ruleId: { type: String },
      _data: { type: Object },
      searchText: { type: String },
      type: String,
      _displayData: { type: Array },
      headerDataExistingElement: { type: Array },
      _dataDup: Array,
      total: Number,
      docVersionId: String,
      appliesToElements: Array,
      rulesDdl1: Array,
      lookupData: Array,
      totalPage: Number,
      docName: String,
      subSectionList: Array,
      rows: Array,
      notes: Array,
      parentData: Object,
    };
  }

  constructor() {
    super();
    this._showCreateForm = false;
    this._data = [];
    this._dataDup = [];
    this._displayData = [];
    this.headerDataExistingElement = [];
    this.pagePerItem = 25;
    this.currentPage = 1;
    this.ajaxInstance = ajaxInstance;
    this.appliesToElements = [];
    this.rulesDdl1 = [];
    this.lookupData = [];
    this.tableContentData = [];
    this.total = 0;
    this.docName = '';
    this.headerData = [];
    this.getAPIMapper = {
      Regola: 'REGOLA',
      Sezioni: 'SEZIONE',
      Righe: 'RIGA',
      Nota: 'NOTA',
      'Sotto Sezioni': 'SOTTOSEZIONE',
    };
    this.subSectionList = [];
    this.rows = [];
    this.notes = [];
    this.selectedRowChildElement = {};
    this.urlHashed = getHostURL();
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('tableContentData') && changed.has('headerData')) {
      if (this._showCreateForm) {
        this.initShowForm();
      }
      this._dataDup = [...this.tableContentData];
      this.headerDataExistingElement = this.headerData;
      this.selectedRow = undefined;
      this.getTotalPage();
      if (this._selectedValue) {
        const index = this._dataDup.findIndex(
          item => this._selectedValue?.id?.toString() === item?.id?.toString(),
        );
        if (index > -1) {
          this.currentPage = Math.round((index + 1) / this.pagePerItem);
          this.currentPage = this.currentPage ? this.currentPage : 1;
        }
      }
      // if (this.type) {
      this.headerDataExistingElement = [
        ...this.headerDataExistingElement,
        { headerClass: 'document_view_header', headerValue: 'Documenti collegati' },
      ];
      this.viewDocumentAssociatedList();
      // }
      // this._data = [...this._dataDup];
      this.sliceItems();
      // this._getFilteredPaginatedData();
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getLookUpDataList() {
    const url = `${baseURL3}`;
    try {
      return await this.ajaxInstance.get(url);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return {};
    }
  }

  viewDocumentAssociatedList() {
    // if (this.type) {
    this._dataDup = this._dataDup.map(data => {
      const data1 = { ...data };
      data1.documentView = html`<div class="line">-</div>`;
      return data1;
    });
    // }
  }

  openDialog(event, ev) {
    // eslint-disable-next-line
    console.log(ev);
    if (event) {
      event.stopPropagation();
      event.preventDefault();
    }
    this._displayData = [];
    const dialogB = this.shadowRoot.querySelector('#dialog2');
    dialogB.opened = true;
    const eleList = document?.querySelectorAll('[dialog-frame]');
    if (eleList && eleList.length > 0) {
      eleList.forEach(item => {
        item?.shadowRoot
          ?.querySelector('.dialog-frame')
          ?.setAttribute('style', 'max-width: 1000px');
      });
    }

    this.getDocumentDetail(ev);
  }

  _receiveData(type) {
    return event => {
      const { list, data } = event.detail;
      let dataList = list || data;
      const res = event.detail.res && (event.detail.res.data || event.detail.res);
      dataList = dataList.map(item => {
        const item1 = item;
        item1.version = '1';
        // item1.validity = formatDate(new Date(item1.validity), { locale: 'it-It' });
        return item1;
      });
      const id = generateId();
      const ev = new CustomEvent('data-received', {
        detail: {
          type,
          data: dataList,
          docId: this.docId,
          newSectionId: type !== 'Sezioni' ? this.sectionId : id,
          newSubSectionId: type !== 'Sotto Sezioni' ? this.subSectionId : id,
          newRowId: type !== 'Righe' ? this.rowId : id,
          newNoteId: type !== 'Nota' ? this.noteId : id,
          newRuleId: type !== 'Regola' ? this.ruleId : id,
          sectionId: this.sectionId,
          subSectionId: this.subSectionId,
          rowId: this.rowId,
          ruleId: this.ruleId,
          noteId: this.noteId,
          id,
          res,
          order: this.tableContentData.length + 1,
          parentData: this.parentData,
        },
      });
      this.dispatchEvent(ev);
    };
  }

  _cancel() {
    const ev = new CustomEvent('cancel-action', {
      detail: {
        data: this.selectedRow,
        type: this.sectionName,
        docId: this.docId,
        newSectionId: this.sectionId,
        newSubSectionId: this.subSectionId,
        newRowId: this.rowId,
        newNoteId: this.noteId,
        newRuleId: this.ruleId,
        sectionId: '',
        subSectionId: '',
        rowId: '',
        ruleId: '',
        noteId: '',
        parentData: this.parentData,
      },
    });
    this.dispatchEvent(ev);
  }

  _getFilteredPaginatedData() {
    const ev = new CustomEvent('pagination-search-request', {
      detail: {
        pageNumber: this.currentPage,
        tabName: this.sectionName,
        searchText: this.searchText,
        total: this.total,
      },
    });
    this.dispatchEvent(ev);
  }

  _showStatusEvent(event) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data: event.detail.data,
        type: event.detail.type,
      },
    });
    this.dispatchEvent(ev);
  }

  _fieldsChanged(type) {
    return ev => {
      const { detail } = ev;
      const evt = new CustomEvent('fields-changed', {
        detail: { ...detail, type },
      });
      this.dispatchEvent(evt);
    };
  }

  loadCreatForm() {
    switch (this.sectionName) {
      case 'Regola':
        return html`<rule-creation
          ?isExistingDocument=${true}
          .docId="${this.docVersionId}"
          .appliesToElements="${this.appliesToElements}"
          .rulesDdl1="${this.rulesDdl1}"
          .lookupData="${this.lookupData}"
          ?isTempModification=${true}
          @rows-changed="${this._receiveData('Regola')}"
          @field-values-changed=${this._fieldsChanged('Regola')}
          @show-status-dialog="${this._showStatusEvent}"
        ></rule-creation>`;
      case 'Sezioni':
        return html`<create-sub-section
          currentStep="section"
          ?isExistingDocument=${true}
          .lookupData="${this.lookupData}"
          .subSectionsList="${this.subSectionList}"
          @event-section-added="${this._receiveData('Sezioni')}"
          @event-section-removed="${this._receiveData('Sezioni')}"
          @field-values-changed=${this._fieldsChanged('Sezioni')}
          @show-status-dialog="${this._showStatusEvent}"
        ></create-sub-section>`;
      case 'Sotto Sezioni':
        return html`<create-sub-section
          currentStep="subsection"
          ?isExistingDocument=${true}
          .lookupData="${this.lookupData}"
          .rows="${this.rows}"
          @event-section-added="${this._receiveData('Sotto Sezioni')}"
          @event-section-removed="${this._receiveData('Sotto Sezioni')}"
          @field-values-changed=${this._fieldsChanged('Sotto Sezioni')}
          @show-status-dialog="${this._showStatusEvent}"
        ></create-sub-section>`;
      case 'Righe':
        return html`<row-creation
          ?isExistingDocument=${true}
          .lookupData="${this.lookupData}"
          .notes="${this.notes}"
          @rows-changed="${this._receiveData('Righe')}"
          @field-values-changed=${this._fieldsChanged('Righe')}
          @show-status-dialog="${this._showStatusEvent}"
          .rowData="${[]}"
        ></row-creation>`;
      case 'Nota':
        return html`<new-document-creation
          ?isExistingDocument=${true}
          @notes-changed="${this._receiveData('Nota')}"
          @show-status-dialog="${this._showStatusEvent}"
          .notesData="${[]}"
          @field-values-changed=${this._fieldsChanged('Nota')}
        ></new-document-creation>`;
      default:
        return ``;
    }
  }

  async toggleForm() {
    this._showCreateForm = !this._showCreateForm;
    this.initShowForm();
  }

  async initShowForm() {
    if (this._showCreateForm) {
      const res = await this.getLookUpDataList();
      this.lookupData = deriveData(res?.data);
    }
    if (
      this.sectionName === 'Regola' &&
      this._showCreateForm &&
      this.appliesToElements?.length === 0
    ) {
      const { list: rulesDdl } = await this.makeAjaxCall(this.docVersionId);
      this.rulesDdl1 = [...rulesDdl];
      const lookupList = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE');
      this.appliesToElements = [
        {
          id: '0',
          name: 'Select Element',
        },
        ...lookupList,
      ];
    } else if (this.sectionName !== 'Nota' && this._showCreateForm) {
      await this.getChildElementsList(this.sectionName);
    }
  }

  async getChildElementsList(tabName) {
    if (tabName === 'Sezioni') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformSubSectionsToFrontEnd,
        'Sotto Sezioni',
      );
      // this.subSectionList = this.selectedRowChildElement?.subSections ? this.getExistingFilterList(data.list, this.selectedRowChildElement?.subSections) : data.list;
      this.subSectionList = data.list;
    } else if (tabName === 'Sotto Sezioni') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformRowsToFrontEnd,
        'Righe',
      );
      // this.rows = this.selectedRowChildElement?.rows ? this.getExistingFilterList(data.list, this.selectedRowChildElement?.rows) : data.list;
      this.rows = data.list;
    } else if (tabName === 'Righe') {
      const data = await this.makeElementsAjaxCallForExistingElements(
        transformNoteToFrontEnd,
        'Nota',
      );
      // this.notes = this.selectedRowChildElement?.notes ? this.getExistingFilterList(data.list, this.selectedRowChildElement?.notes) : data.list;
      this.notes = data.list;
    }
  }

  // eslint-disable-next-line
  getExistingFilterList(list, children) {
    return list.filter(item => {
      const index = children.findIndex(item1 => item1?.id?.toString() === item?.id?.toString());
      if (index === -1) {
        return true;
      }
      return false;
    });
  }

  // eslint-disable-next-line class-methods-use-this
  async makeElementsAjaxCallForExistingElements(transformFn, elementName) {
    let url;
    if (this.getAPIMapper[elementName] === 'REGOLA') {
      url = `${baseURL}s?itemTypeKey=RULE_TYPE&itemTypeValue=${this.getAPIMapper[elementName]}`;
    } else {
      url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[elementName]}`;
    }
    // eslint-disable-next-line no-console
    // totalRes = {}
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      list = list.map(d => transformFn(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async makeAjaxCall(id) {
    const url = `${baseURL4}?itemsVersionsID=${id}`;
    let list = [];
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      // eslint-disable-next-line no-unused-vars
      // this.data = list;
      return { list };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list };
    }
  }

  handleChange(event) {
    this[event.target.name] = event.target.value;
  }

  _applyFilter() {
    this._dataDup = this.tableContentData
      .filter(d => {
        const val = d.name + d.description;
        return val.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1;
      })
      ?.map(d1 => {
        if (!d1?.documentView) {
          // eslint-disable-next-line
          d1.documentView = html`<div class="line">-</div>`;
        }
        return d1;
      });
    this._selectedValue = undefined;
    this._viewSectionDetails({ detail: { data: undefined } });
    this.currentPage = 1;
    // this.viewDocumentAssociatedList();
    this.getTotalPage();
    this.sliceItems();
    // this._getFilteredPaginatedData();
  }

  _addRowElements() {
    const ev = new CustomEvent('add-row-elements', {
      detail: {
        data: this.selectedRow,
        type: this.sectionName,
        parentData: this.parentData,
      },
    });
    this.dispatchEvent(ev);
  }

  _viewSectionDetails(event) {
    this.selectedRow = event.detail.data;
    const rowClickedEvent = new CustomEvent('selected-table-row', {
      detail: {
        data: this.selectedRow,
        type: this.sectionName,
        parentData: this.parentData,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  get showPagination() {
    return this._dataDup.length > this.pagePerItem;
  }

  getTotalPage() {
    this.totalPage = Math.ceil(this._dataDup.length / this.pagePerItem);
  }

  sliceItems() {
    const indexOfLastItem = this.pagePerItem * this.currentPage;
    const indexOfFirstItem = indexOfLastItem - this.pagePerItem;
    this._data = this._dataDup.slice(indexOfFirstItem, indexOfLastItem);
  }

  _pageChanged(event) {
    const { current } = event.target;
    // eslint-disable-next-line
    this.currentPage = current ? current : 1;
    this.sliceItems();
    // this._getFilteredPaginatedData();
  }

  async getVersionDetails(ev) {
    try {
      const { rowData } = ev.detail;
      if (this.sectionName === 'Sezioni') {
        const versionList = await this.getVersionsList(rowData.sectionId);
        this.bindVersionDetail(rowData.id, versionList);
      } else if (this.sectionName === 'Sotto Sezioni') {
        const versionList = await this.getVersionsList(rowData.subSectionId);
        this.bindVersionDetail(rowData.id, versionList);
      } else if (this.sectionName === 'Righe') {
        const versionList = await this.getVersionsList(rowData.rowId);
        this.bindVersionDetail(rowData.id, versionList);
      } else if (this.sectionName === 'Nota') {
        const versionList = await this.getVersionsList(rowData.noteId);
        this.bindVersionDetail(rowData.id, versionList);
      } else if (this.sectionName === 'Regola' || this.sectionName === 'Regole') {
        const versionList = await this.getVersionsList(rowData.ruleId);
        this.bindVersionDetail(rowData.id, versionList);
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async getDocumentDetail(ev) {
    try {
      const rowData = ev;
      const documentList = await this.getDocumentList(rowData.id);
      // if (this.sectionName === 'Sezioni') {
      //   documentList = await this.getDocumentList(rowData.sectionId);
      // } else if (this.sectionName === 'Sotto Sezioni') {
      //   documentList = await this.getDocumentList(rowData.subSectionId);
      // } else if (this.sectionName === 'Righe') {
      //   documentList = await this.getDocumentList(rowData.rowId);
      // } else if (this.sectionName === 'Nota') {
      //   documentList = await this.getDocumentList(rowData.noteId);
      // } else if (this.sectionName === 'Regola' || this.sectionName === 'Regole') {
      //   documentList = await this.getDocumentList(rowData.ruleId);
      // }

      if (documentList) {
        this._displayData = transformParentDocumentsListToFrontEnd(documentList);
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  bindVersionDetail(id, versionList) {
    const rowDetail = this._data?.find(data => data?.id?.toString() === id?.toString());
    if (rowDetail) {
      rowDetail.versionList = [];
      versionList?.forEach(item => {
        if (rowDetail?.id?.toString() === item?.itemsVersionsID?.toString()) {
          if (rowDetail && item?.hasParentDocuments) {
            rowDetail.documentView = html`<ing-link
              href="#"
              @click="${ev => this.openDialog(ev, rowDetail)}"
              >vedi documenti</ing-link
            >`;
          } else {
            rowDetail.documentView = html`<div class="line">-</div>`;
          }
        }
        rowDetail.versionList.push(item);
      });
      const index1 = this.tableContentData.findIndex(
        tData => tData?.id?.toString() === rowDetail?.id?.toString(),
      );
      if (index1 > -1 && rowDetail?.versionList?.length) {
        this.tableContentData[index1] = rowDetail;
      } else if (index1 > -1) {
        this.tableContentData[index1] = html`<div class="line">-</div>`;
      }
      this._data = [...this._data];
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionsList(id) {
    const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
    return res.data ? deriveData(res.data) : [];
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionItemDetail(id, type) {
    let url = `${baseURL2}/version/${id}`;
    if (this.getAPIMapper[type] === 'RIGA') {
      url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
    }
    const res = await this.ajaxInstance.get(url);
    return res;
  }

  // eslint-disable-next-line class-methods-use-this
  async getDocumentList(id) {
    const res = await this.ajaxInstance.get(`${baseURL2}/version/${id}/parent-documents`);
    return res.data ? deriveData(res.data) : [];
  }

  async changeVersionDetail(event) {
    try {
      const { id } = event.detail;
      if (this.sectionName === 'Sezioni') {
        const res = await this.getVersionItemDetail(id);
        const row = transformSectionsToFrontEnd(res?.data);
        const index = this._data.findIndex(
          item => item?.sectionId?.toString() === row?.sectionId?.toString(),
        );
        if (index > -1) {
          this.appendVersionDetail(row, index);
        }
      } else if (this.sectionName === 'Sotto Sezioni') {
        const res = await this.getVersionItemDetail(id, 'Righe');
        const row = transformSubSectionsToFrontEnd(res?.data);
        const index = this._data.findIndex(
          item => item?.subSectionId?.toString() === row?.subSectionId?.toString(),
        );
        if (index > -1) {
          this.appendVersionDetail(row, index);
        }
      } else if (this.sectionName === 'Righe') {
        const res = await this.getVersionItemDetail(id);
        const row = transformRowsToFrontEnd(res?.data);
        const index = this._data.findIndex(
          item => item?.rowId?.toString() === row?.rowId?.toString(),
        );
        if (index > -1) {
          this.appendVersionDetail(row, index);
        }
      } else if (this.sectionName === 'Nota') {
        const res = await this.getVersionItemDetail(id);
        const row = transformNoteToFrontEnd(res?.data);
        const index = this._data.findIndex(
          item => item?.noteId?.toString() === row?.noteId?.toString(),
        );
        if (index > -1) {
          this.appendVersionDetail(row, index);
        }
      } else if (this.sectionName === 'Regola' || this.sectionName === 'Regole') {
        const res = await this.getVersionItemDetail(id);
        const row = transformRulesToFrontEnd(res?.data);
        const index = this._data.findIndex(
          item => item?.ruleId?.toString() === row?.ruleId?.toString(),
        );
        if (index > -1) {
          this.appendVersionDetail(row, index);
        }
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  appendVersionDetail(row, index) {
    const row1 = { ...row };
    row1.versionList = this._data[index].versionList;
    const versionList = [];
    row1?.versionList?.forEach(item => {
      if (row1?.id?.toString() === item?.itemsVersionsID?.toString()) {
        if (row1 && item?.hasParentDocuments) {
          row1.documentView = html`<ing-link href="#" @click="${ev => this.openDialog(ev, row1)}"
            >vedi documenti</ing-link
          >`;
        } else {
          row1.documentView = html`<div class="line">-</div>`;
        }
        // versionList.unshift(item);
      }
      versionList.push(item);
    });
    row1.versionList = [...versionList];
    const index1 = this.tableContentData.findIndex(
      tData => tData?.id?.toString() === row1?.id?.toString(),
    );
    if (index1 > -1 && row1?.versionList?.length) {
      this.tableContentData[index1] = row1;
    } else if (index1 > -1) {
      this.tableContentData[index1] = html`<div class="line">-</div>`;
    }
    const index2 = this.tableContentData.findIndex(
      item => item?.sectionId?.toString() === row1?.sectionId?.toString(),
    );
    if (index2 > -1) {
      this.tableContentData[index2] = row1;
    }
    row1.isVersionChanged = true;
    this._data[index] = row1;
    this._data = [...this._data];
    this.selectedRow = JSON.parse(JSON.stringify(row1));
  }

  async getDocumentVersion(ev) {
    try {
      const { rowData } = ev.detail;
      const versionList = await this.getVersionsList(rowData.docId);

      const rowDetail = this._displayData?.find(
        data => data?.id?.toString() === rowData?.id?.toString(),
      );
      if (rowDetail) {
        rowDetail.versionList = [...versionList];
        // versionList?.forEach(item => {
        //   if (rowDetail?.id?.toString() === item?.itemsVersionsID?.toString()) {
        //     rowDetail.versionList.unshift(item);
        //   } else {
        //     rowDetail.versionList.push(item);
        //   }
        // });
        this._displayData = [...this._displayData];
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async changeDocumentVersionDetail(event) {
    try {
      const { id } = event.detail;
      const res = await this.getVersionItemDetail(id);
      const row = transformDocumentsToFrontEnd(res?.data);
      const index = this._displayData.findIndex(
        item => item?.docId?.toString() === row?.docId?.toString(),
      );
      if (index > -1) {
        row.versionList = this._displayData[index].versionList;
        row.isVersionChanged = true;
        this._displayData[index] = row;
        this._displayData = [...this._displayData];
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  bindExistingElementEvent() {
    if (this.selectedRow) {
      const ev = new CustomEvent('existing-data-received', {
        detail: {
          type: this.sectionName,
          data: this.selectedRow,
          docId: this.docId,
          parentData: this.parentData,
        },
      });
      this.dispatchEvent(ev);
    }
  }

  _resetFilter() {
    this.searchText = '';
    this.shadowRoot.querySelector('#searchText').value = '';
    this._applyFilter();
  }

  getSectionName() {
    if (this.sectionName.toLowerCase() === 'righe') {
      return 'riga';
      // eslint-disable-next-line
    } else if (this.sectionName.toLowerCase() === 'sotto sezioni') {
      return 'sotto sezione';
      // eslint-disable-next-line
    } else if (this.sectionName.toLowerCase() === 'sezioni') {
      return 'sezione';
      // eslint-disable-next-line
    } else {
      return this.sectionName.toLowerCase();
    }
  }

  render() {
    return html`
      <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" dialog-frame has-close-button>
          <div slot="header">Documenti collegati</div>
          <div slot="content">
            <ing-table
              .displayData="${this._displayData}"
              ?showVersionlist=${true}
              @changed-version-detail="${this.changeDocumentVersionDetail}"
              @version-detail-list="${this.getDocumentVersion}"
            ></ing-table>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
      ${this._showCreateForm
        ? html` ${this.loadCreatForm()} `
        : html` <label class="add-title-margin">${this.docName}</label>
            <label class="add-title">Aggiungi ${this.getSectionName()} esistente</label>
            <form>
              <ing-input
                placeholder="Cerca ${this.getSectionName()}"
                id="searchText"
                name="searchText"
                class="param_filter_search"
                @keyup="${this.handleChange}"
                @click=${this._checkText}
              ></ing-input>
              <ing-button
                id="searchButton"
                class="search-button"
                @click="${this._applyFilter}"
                type="button"
                ?disabled="${!this.searchText}"
                >Cerca</ing-button
              >
              <ing-button
                outline
                indigo
                id="resetFilter"
                class="reset-button"
                type="button"
                @click="${this._resetFilter}"
                ?disabled="${!this.searchText}"
                >Azzera filtri</ing-button
              >
            </form>
            <div class="table-width">
              ${this.sectionName === 'Righe'
                ? html`
                    <document-rows-details-table
                      .tableData=${this._data}
                      .headerData=${this.headerDataExistingElement}
                      propertyId="id"
                      .nameId="${this.propertyId}"
                      .selectedRow="${this.selectedRow}"
                      ?showVersionlist=${true}
                      @selected-table-row="${this._viewSectionDetails}"
                      @changed-version-detail="${this.changeVersionDetail}"
                      @version-detail-list="${this.getVersionDetails}"
                    >
                    </document-rows-details-table>
                  `
                : html`
                    <document-common-details-table
                      .tableData=${this._data}
                      .headerData=${this.headerDataExistingElement}
                      propertyId="id"
                      .nameId="${this.propertyId}"
                      .selectedRow="${this.selectedRow}"
                      ?showVersionlist=${true}
                      @selected-table-row="${this._viewSectionDetails}"
                      @changed-version-detail="${this.changeVersionDetail}"
                      @version-detail-list="${this.getVersionDetails}"
                    >
                    </document-common-details-table>
                  `}
            </div>
            <br />
            <div>
              ${this.showPagination
                ? html`<ing-pagination-links
                    page-url="${this.urlHashed}#"
                    id="pagination-event"
                    count=${this.totalPage}
                    current="${this.currentPage}"
                    @current-changed=${this._pageChanged}
                  ></ing-pagination-links>`
                : ''}
            </div>
            ${!this.type
              ? html`<label class="create-new-button-container">
                    Aggiungi nuova ${this.getSectionName()}
                  </label>
                  <ing-button id="createNew" class="create-new-button" @click="${this.toggleForm}"
                    >Crea nuova</ing-button
                  >`
              : ''}`}

      <br />
      ${!this._showCreateForm
        ? html`<div class="action-button-container">
            <ing-button
              id="cancel"
              class="action-btn"
              outline
              indigo
              font12
              @click="${this._cancel}"
              >Annulla
            </ing-button>
            <ing-button
              id="save"
              class="action-btn"
              indigo
              font12
              @click="${!this.type ? this.bindExistingElementEvent : this._addRowElements}"
              ?disabled="${!this.selectedRow}"
              >Aggiungi e Chiudi
            </ing-button>
          </div>`
        : ''}
    `;
  }
}
customElements.define('element-from-scratch', ElementFromScratch);
