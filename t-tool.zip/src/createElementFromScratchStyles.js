import { css, font14BoldMixin, font16Mixin, font19BoldMixin, black80, font19Mixin } from 'ing-web';

export default css`
  form {
    display: flex;
    margin: 18px 0 35px 103px;
  }
  .search-button {
    width: 188px;
    height: 40px;
    margin-left: 23px;
  }
  .create-new-button {
    height: 32px;
    margin: 10px 0;
    width: 180px;
    ${font14BoldMixin()}
    margin-left: 103px;
  }
  .create-new-button-container {
    margin: 50px 0 10px 103px;
  }
  .action-button-container {
    display: flex;
    width: 94%;
    justify-content: flex-end;
    margin-top: 50px;
  }
  .action-button-container .action-btn {
    margin: 0 10px;
    width: 180px;
    height: 28px;
  }
  .create-new-button-container {
    display: block;
    ${font19BoldMixin()}
    color: ${black80};
  }
  #pagination-event {
    display: flex;
    width: 100%;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
    margin-bottom: 35px;
  }
  .add-title {
    color: ${black80};
    ${font19BoldMixin()}
    display: block;
    margin-left: 103px;
  }
  .add-title-margin {
    margin-top: 56px;
    margin-bottom: 61px;
    color: ${black80};
    ${font19Mixin()}
    display: block;
    margin-left: 103px;
  }
  #searchText {
    color: ${black80};
    width: 288px;
    height: 40px;
    ${font16Mixin()}
  }
  .element-from-scratch-content {
    margin-left: 103px;
  }
  .table-width {
    margin-left: 103px;
    width: 90%;
  }
  .reset-button::before {
    margin: 0 0 1.5em 0;
    min-height: 40px;
    width: 188px;
  }

  .reset-button {
    width: 188px;
    height: 40px;
    float: left;
    margin-left: 34px;
  }
`;
