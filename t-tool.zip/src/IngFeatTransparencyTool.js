import { UrlRouter, routingManager } from '@ing-web/router';
import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngTab,
  IngTabs,
  IngTabPanel,
  IngIcon,
  IngLink,
  IngSpinner,
  registerDefaultIconsets,
} from 'ing-web';

import { documents } from './data/documents.js';
import { filters } from './data/filters.js';

import { DocumentListHomePage } from './DocumentListHomePage.js';
import { TransprencyToolAcess } from './transparencyToolAccess.js';
import { DocumentListReviewPage } from './DocumentListReviewPage.js';
import { DocumentModification } from './DocumentModification.js';

import styles from './IngFeatTransarencyToolStyles.js';

import { navigationLinks } from './data/navigationLinks.js';
import { ChangeLanguage } from './utils/index.js';
import { ajaxInstance } from './utils/endpoints.js';
import { baseURL, baseURL2 } from './utils/constants.js';
import { transformDocumentsToFrontEnd } from './data/tranformations/documentTranformation.js';

export class IngFeatTransparencyTool extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'document-home-page': DocumentListHomePage,
      'document-list-review-page': DocumentListReviewPage,
      'ing-tabs': IngTabs,
      'ing-tab': IngTab,
      'ing-tab-panel': IngTabPanel,
      'ing-icon': IngIcon,
      'ing-link': IngLink,
      'ing-spinner': IngSpinner,
      'document-modification': DocumentModification,
      'transparency-tool-access': TransprencyToolAcess,
    };
  }

  static get properties() {
    return {
      _displayData: { type: Array },
      _selectedValue: { type: Object },
      _searchText: { type: String },
      _navigationLinks: { type: Array },
      documentDupList: Array,
      showLoader: Boolean,
      _selectedTabIndexHomePage: Number,
      isAccessed: { type: Boolean, reflect: true },
      isShowReviewTab: Boolean,
    };
  }

  static get styles() {
    return styles;
  }

  _homePageReview(event) {
    this._selectedValue = event?.detail?.data;
    this.isShowReviewTab = true;
    this.router.navigate('reviews_documents');
  }

  _homePageModify(event) {
    this._selectedValue = event?.detail?.data;
    this.router.navigate('edit_documents');
    this.isShowReviewTab = false;
  }

  // eslint-disable-next-line class-methods-use-this
  async _postDocumentNewVersion(document) {
    // const documentBackend = transformDocumentsToBackend(document);
    let data;
    try {
      data = await ajaxInstance.post(`${baseURL}/${document.docId}/version`, {});
    } catch (error) {
      data = {};
      // eslint-disable-next-line no-console
      console.log(error);
    }
    return data;
  }

  // eslint-disable-next-line class-methods-use-this
  async _postDocumentDuplicate(document) {
    // const documentBackend = transformDocumentsToBackend(document);
    let data;
    try {
      data = await ajaxInstance.post(`${baseURL}/${document.docId}/version/${document.id}`, {});
    } catch (error) {
      data = {};
      // eslint-disable-next-line no-console
      console.log(error);
    }
    return data;
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  async _newDocumentVersion(event) {
    this.documentDupList.unshift(event.detail.data);
    // this._selectedValue = event?.detail?.data;
    // this.router.navigate('list_documents');
    const { data } = await this._postDocumentNewVersion(event.detail.data);
    const res = await this._getVersionItemDetail(data?.itemsVersionsID);
    const newVersionData = transformDocumentsToFrontEnd(res?.data);
    // eslint-disable-next-line
    event.detail.data = {
      ...event.detail.data,
      ...newVersionData,
      ...{ typeOfAction: 'newVersioneDocument' },
    };
    await event.detail.render({ ...event.detail.data, id: data.itemsVersionsID });
    event.detail.focus({ ...event.detail.data, id: data.itemsVersionsID });
    this.isShowReviewTab = false;
  }

  async _newDocumentDuplicate(event) {
    this.documentDupList.unshift(event.detail.data);
    // this._selectedValue = event?.detail?.data;
    // this.router.navigate('list_documents');
    const { data } = await this._postDocumentDuplicate(event.detail.data);
    const res = await this._getVersionItemDetail(data?.itemsVersionsID);
    const newDuplicateData = transformDocumentsToFrontEnd(res?.data);
    // eslint-disable-next-line
    event.detail.data = {
      ...event.detail.data,
      ...newDuplicateData,
      ...{ typeOfAction: 'duplicateDocument' },
    };
    await event.detail.render({
      ...event.detail.data,
      id: data.itemsVersionsID,
      docId: data.itemID,
    });
    event.detail.focus({ ...event.detail.data, id: data.itemsVersionsID, docId: data.itemID });
    this.isShowReviewTab = false;
  }

  // eslint-disable-next-line class-methods-use-this
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  _goToHomePage(ev) {
    if (ev && ev?.detail && ev?.detail?.data) {
      this._cloneRecord(this._selectedValue, ev.detail.data);
      this._selectedValue = { ...this._selectedValue };
    } else {
      this.router.navigate('list_documents');
    }
    this.isShowReviewTab = false;
  }

  _navigateTo(event) {
    const { route } = event.detail;
    if (route === 'create_documents') {
      this.router.navigate('list_documents');
      setTimeout(() => {
        this._selectedTabIndexHomePage = 1;
      });
    } else {
      this.router.navigate(route);
    }
    if (route !== 'reviews_documents') {
      this.isShowReviewTab = false;
    }
  }

  _navigateReviewPageTo(event) {
    const detail = {
      route: event.target.getAttribute('route'),
    };
    this._navigateTo({ detail });
  }

  setDocumentTabIndex(event) {
    const index = event?.detail;
    this._selectedTabIndexHomePage = index;
    this.isShowReviewTab = false;
  }

  _viewDocumentDetails(ev) {
    if (ev && ev?.detail && ev?.detail?.data) {
      this._selectedValue = { ...ev.detail.data };
    }
    this.isShowReviewTab = false;
  }

  _navigateToListPageFromIris() {
    setTimeout(() => {
      this.router.navigate('list_documents');
    });
  }

  constructor() {
    super();
    this.filters = filters;
    this.data = documents;
    this._displayData = [];
    ChangeLanguage('it-IT');
    this._navigationLinks = navigationLinks;
    this.documentDupList = [];
    ajaxInstance.requestInterceptors.push(this._showLoader.bind(this));
    ajaxInstance.responseInterceptors.push(this._hideLoader.bind(this));
    ajaxInstance.requestErrorInterceptors.push(this._hideLoader.bind(this));
    ajaxInstance.responseErrorInterceptors.push(this._hideLoader.bind(this));
    this._selectedTabIndexHomePage = 0;
    this.isShowReviewTab = false;
    this.router = new UrlRouter({
      routes: [
        {
          title: 'Transparency Tool',
          pattern: 'transparency_tool_access',
          render: () =>
            html`<transparency-tool-access
              @access-clicked=${this._navigateToListPageFromIris}
            ></transparency-tool-access>`,
        },
        {
          title: 'Transparency Tool',
          pattern: 'list_documents',
          render: () =>
            html`<document-home-page
              @homepage-review=${this._homePageReview}
              @homepage-modify=${this._homePageModify}
              @set-tab-index-homepage="${this.setDocumentTabIndex}"
              @navigate-to="${this._navigateTo}"
              @select-document="${this._viewDocumentDetails}"
              .documentDupList="${this.documentDupList}"
              ._selectedValue="${this._selectedValue}"
              _selectedTabIndex=${this._selectedTabIndexHomePage}
              .isShowReviewTab=${this.isShowReviewTab}
            ></document-home-page>`,
        },
        {
          title: 'Transparency Tool',
          pattern: 'edit_documents',
          render: () =>
            html`<document-modification
              .documentData="${this._selectedValue}"
              @navigate-to="${this._navigateTo}"
              @new-document-version="${this._newDocumentVersion}"
              @new-duplicate-document="${this._newDocumentDuplicate}"
              @save-document="${this._goToHomePage}"
            ></document-modification>`,
        },
        {
          title: 'Transparency Tool',
          pattern: 'reviews_documents',
          render: () =>
            html` <div class="grey-empty-area"></div>
              <div class="main_container">
                <ing-tabs document-review-tabs id="navigation_tabs" .selectedIndex=${2}>
                  <ing-tab
                    name="tab1"
                    slot="tab"
                    route="list_documents"
                    @click="${this._navigateReviewPageTo}"
                    >Elenco e ricerca</ing-tab
                  >
                  <ing-tab
                    slot="tab"
                    route="create_documents"
                    @click="${this._navigateReviewPageTo}"
                    >Crea nuovo documento</ing-tab
                  >
                  <ing-tab slot="tab" @click="${() => {}}">Review</ing-tab>
                  <ing-tab-panel slot="panel"> </ing-tab-panel>
                  <ing-tab-panel slot="panel"> </ing-tab-panel>
                  <ing-tab-panel slot="panel">
                    <document-list-review-page
                      @go-to-home-page="${this._goToHomePage}"
                      .reviewData=${this._selectedValue}
                    ></document-list-review-page>
                  </ing-tab-panel>
                </ing-tabs>
              </div>`,
        },
      ],
    });

    const homeIndex = 0;
    this.router.route = this.router.routes[homeIndex];

    this.router.addEventListener('updated', () => {
      // eslint-disable-next-line no-console
      console.log('this.router.addEventListener updated', this.router.path);
      for (let i = 0; i < this._navigationLinks.length; i += 1) {
        if (this._navigationLinks[i].redirectToPath !== this.router.path)
          this._navigationLinks[i].isSelected = false;
        else this._navigationLinks[i].isSelected = true;
      }
      this.requestUpdate();
    });

    routingManager.enableSinglePageRouting();
  }

  connectedCallback() {
    super.connectedCallback();
    registerDefaultIconsets();
    // ajaxInstance.get('/api/rows').then(res => {
    //   // eslint-disable-next-line no-console
    //   console.log(res);
    // });
    // ajaxInstance.post('/api/rows/1').then(res => {
    //   // eslint-disable-next-line no-console
    //   console.log(res);
    // });

    if (this.isAccessed) this.router.navigate('list_documents');
  }

  _showLoader(req) {
    this.showLoader = true;
    return req;
  }

  _hideLoader(req) {
    setTimeout(() => {
      this.showLoader = false;
    }, 500);
    return req;
  }

  getSelectedPageTemplate() {
    return html` ${(() => this.router.route?.render())()}`;
  }

  render() {
    return html`
      ${this.router?.route?.pattern !== 'access' ? html`<div class="link_container"></div>` : ''}
      ${this.showLoader ? html`<ing-spinner ingSpinnerGlobal></ing-spinner>` : ''}
      ${this.getSelectedPageTemplate()}
    `;
  }
}
customElements.define('ing-feat-ita-document-template-administration', IngFeatTransparencyTool);
