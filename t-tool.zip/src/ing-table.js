import { LitElement, html, formatDate } from 'ing-web';

import styles from './ing-tableStyles.js';

export class IngTable extends LitElement {
  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      displayData: { type: Array },
      _selectedValue: { type: Object },
      showVersionlist: { type: Boolean, reflect: true },
    };
  }

  _setSelectedElement(event) {
    this._selectedValue = event.currentTarget.data;
    // eslint-disable-next-line no-console
    console.log(this._selectedValue);

    const rowClickedEvent = new CustomEvent('selected-table-row', {
      detail: {
        data: this._selectedValue,
      },
    });
    this.dispatchEvent(rowClickedEvent);
    this.getVersionDetails(event, this._selectedValue);
  }

  // eslint-disable-next-line
  getStatusName(status) {
    if (status && status.toUpperCase() === 'IN SVILUPPO') {
      return 'status_draft';
      // eslint-disable-next-line
    } else if (status && status.toUpperCase() === 'APPROVATO') {
      return 'status_prod';
      // eslint-disable-next-line
    } else if (status && status.toUpperCase() === 'IN REVISIONE') {
      return 'status_review';
    }
    return '';
  }

  async getVersionDetails(ev, row) {
    if (this.showVersionlist) {
      ev.stopPropagation();
      ev.preventDefault();
      const rowClickedEvent = new CustomEvent('version-detail-list', {
        detail: {
          rowData: row,
        },
      });
      this.dispatchEvent(rowClickedEvent);
    }
  }

  changeVersionDetail(event) {
    const rowClickedEvent = new CustomEvent('changed-version-detail', {
      detail: {
        id: event.target.value,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  loadSelectElement(rowData) {
    return this.showVersionlist
      ? // eslint-disable-next-line
        html`<div
          class="pointer-event-curser"
          @click="${ev => this.getVersionDetails(ev, rowData)}"
        >
          ${rowData.version}
        </div>`
      : rowData.version;
  }

  render() {
    return html`
      <table class="table">
        <thead>
          <tr>
            <th class="id_header">ID</th>
            <th class="product_header">Prodotto</th>
            <th class="code_header">Codice</th>
            <th class="name_header">Nome</th>
            <th class="type_header">Tipo</th>
            <th class="date_header">Data inizio</th>
            <th class="status_header">Stato</th>
            <th class="version_header">Versione</th>
          </tr>
        </thead>
        <tbody>
          ${this.displayData.map(
            document =>
              html`<tr
                class="table_default_text_align ${document.id === this._selectedValue?.id
                  ? 'selected-row-class'
                  : undefined}"
                @click="${this._setSelectedElement}"
                .data="${document}"
              >
                <td>${document.docId}</td>
                <td>${document.product}</td>
                <td>${document.code}</td>
                <td class="name_text_align">${document.name}</td>
                <td>${document.type}</td>
                <td>${formatDate(new Date(document.start_date), { locale: 'it-It' })}</td>
                <td class="${this.getStatusName(document.status)}">${document.status}</td>
                <td>
                  ${document?.versionList?.length > 0
                    ? html` <ing-select
                        @click="${event => {
                          event.stopPropagation();
                          event.preventDefault();
                        }}"
                        @change="${this.changeVersionDetail}"
                        name="version"
                        inputValue
                        .modelValue=${document?.id}
                      >
                        <select slot="input">
                          ${document?.versionList.map(
                            d =>
                              html`<option value="${d.itemsVersionsID}">
                                ${d.versionNumber}
                              </option>`,
                          )}
                        </select>
                      </ing-select>`
                    : document?.version}
                </td>
              </tr>`,
          )}
        </tbody>
      </table>
    `;
  }
}
