import { css, orange } from 'ing-web';

export default css`
  .ing_collapsable {
    border-color: ${orange};
  }

  span {
    color: ${orange};
  }

  .container {
    height: 30px;
    position: relative;
    margin-top: 34px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 105px;
  }

  .up_arrow {
    margin-left: 37px;
    margin-top: 6px;
  }

  .down_arrow {
    margin-left: 26px;
    margin-top: 6px;
  }

  .add_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 80px;
  }

  .add_button {
    width: 80px;
    height: 28px;
  }

  .remove_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 80px;
  }

  .remove_button {
    width: 80px;
    height: 28px;
    margin-left: 26px;
  }

  .new_version_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .new_version_button {
    width: 180px;
    height: 28px;
  }

  .new_duplication_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 190px;
  }

  .new_duplication_button {
    width: 190px;
    height: 28px;
    margin-left: 30px;
  }

  .modify_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .modify_button {
    width: 180px;
    height: 28px;
    margin-left: 29px;
  }

  .pointer-events {
    pointer-events: none;
  }
  [data-tag-name='ing-collapsible'] [slot='content'] {
    max-height: unset !important;
  }
`;
