import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngInput,
  IngForm,
  registerDefaultIconsets,
  IngInputDatepicker,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngSelect,
  formatDate,
} from 'ing-web';

import { CollapsibleDocumentDetails } from './CollapsibleDocumentDetails.js';
import { CollapsibleDocumentRowsDetails } from './CollapsibleDocumentRowsDetails.js';
import { FileUpload } from './components/fileUpload/fileUpload.js';
import { RemovableChip } from './components/removableChip/removableChip.js';
import { generateId, getHighestItemVersionId } from './utils/IngFeatTransparencyToolUtils.js';
import { previewDocumentsHeader, contentDataDocumentPreview } from './data/documents.js';
import styles from './DocumentDetailsPageStyles.js';

import {
  sectionsHeader,
  subSectionsHeader,
  rowsHeader,
  notesHeader,
  rulesHeader,
} from './data/documentDetailsHeaders.js';
import { CollapsibleDocumentCommonDetails } from './CollapsibleDocumentCommonDetails.js';
import reviewHistoryTableStyles from './DocumentReviewHistoryTableStyles.js';
import { baseURL, baseURL2, baseURL3, baseURL6, localEnvironment } from './utils/constants.js';
import { ajaxInstance } from './utils/endpoints.js';
import {
  transformDocumentsToFrontEnd,
  transformLookUpDataToFrontEnd,
} from './data/tranformations/documentTranformation.js';
import { transformSectionsToFrontEnd } from './data/tranformations/sectionTransformation.js';
import { transformRulesToFrontEnd } from './data/tranformations/ruleTransformation.js';
import {
  chunks,
  createVersionDetail,
  fetchChildItems,
  multipleFileUpload,
  removeVersionLevels,
} from './utils/chunks.js';
import { deriveData } from './utils/globalApiKeys.js';
import { transformRowsToFrontEnd } from './data/tranformations/rowTransformation.js';
import { transformNotesListToFrontEnd } from './data/tranformations/noteTransformation.js';

export class DocumentDetailsPage extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-form': IngForm,
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'collapsible-document-details': CollapsibleDocumentDetails,
      'collapsible-document-rows-details': CollapsibleDocumentRowsDetails,
      'ing-select': IngSelect,
      'removable-chip': RemovableChip,
      'file-upload': FileUpload,
      'collapsible-document-common-details': CollapsibleDocumentCommonDetails,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      _selectedSection: { type: Object },
      _selectedSubsection: { type: Object },
      _selectedRow: { type: Object },
      _selectedNote: { type: Object },
      selectedDocument: { type: Object },
      _selectedRule: { type: Object },
      _filesData: { type: Array },
      elementParentRelationMapper: { type: Object },
      versionList: Array,
      version: String,
      statusList: Array,
      versionId: String,
      productList: Array,
      typeList: Array,
      status: String,
      editableActionFields: Object,
      oldStatusName: String,
      statusLabel: String,
      isDuplicateVersion: String,
      isDisableVersione: Boolean,
      isDisableId: Boolean,
      templateFile: String,
    };
  }

  constructor() {
    super();
    this._sectionsHeader = sectionsHeader;
    this._subSectionsHeader = subSectionsHeader;
    this._rowsHeader = rowsHeader;
    this._notesHeader = notesHeader;
    this._rulesHeader = rulesHeader;
    this._filesData = [];
    this.oldValueType = null;
    this.elementParentRelationMapper = {
      Sezioni: {
        parentPropertyId: 'docId',
        parentData: 'selectedValue',
        propertyData: 'sections',
        propertyId: 'sectionId',
      },
      'Sotto Sezioni': {
        parentPropertyId: 'sectionId',
        parentData: 'selectedSection',
        propertyData: 'subSections',
        propertyId: 'subSectionId',
      },
      Righe: {
        parentPropertyId: 'subSectionId',
        parentData: 'selectedSubSection',
        propertyData: 'rows',
        propertyId: 'rowId',
      },
      Nota: {
        parentPropertyId: 'rowId',
        parentData: 'selectedRow',
        propertyData: 'notes',
        propertyId: 'noteId',
      },
      Regola: {
        parentPropertyId: 'docId',
        parentData: 'selectedValue',
        propertyData: 'rules',
        propertyId: 'ruleId',
      },
    };
    this.version = '1';
    this.versionVal = 'VERS 9 DEL 31.10.2021';
    this.versionList = [];
    this.statusList = [];
    this.productList = [];
    this.typeList = [];
    this.ajaxInstance = ajaxInstance;
    this.getAPIMapper = {
      Regola: 'REGOLA',
      Sezioni: 'SEZIONE',
      Righe: 'RIGA',
      Nota: 'NOTA',
      'Sotto Sezioni': 'SOTTOSEZIONE',
    };
    this.versionId = '0';
    this.editableActionFields = {
      name: true,
      product: true,
      codice: true,
      type: true,
      validity: true,
      templateFile: true,
      fileUpload: true,
      documentNewVersion: true,
      documentDuplicateVersion: true,
      generateAntePrima: true,
      sectionAdd: true,
      sectionRemove: true,
      sectionNewVersion: true,
      sectionDuplicate: true,
      sectionView: true,
      sectionUpArrow: true,
      sectionDownArrow: true,
      subSectionAdd: true,
      subSectionRemove: true,
      subSectionNewVersion: true,
      subSectionDuplicate: true,
      subSectionView: true,
      subSectionUpArrow: true,
      subSectionDownArrow: true,
      rowAdd: true,
      rowRemove: true,
      rowNewVersion: true,
      rowDuplicate: true,
      rowView: true,
      rowUpArrow: true,
      rowDownArrow: true,
      noteAdd: true,
      noteRemove: true,
      noteNewVersion: true,
      noteDuplicate: true,
      noteView: true,
      noteUpArrow: true,
      noteDownArrow: true,
      ruleAdd: true,
      ruleRemove: true,
      ruleNewVersion: true,
      ruleDuplicate: true,
      ruleView: true,
      ruleUpArrow: true,
      ruleDownArrow: true,
    };
    this.oldStatusName = '';
    this.statusLabel = '';
    this.isDuplicateVersion = '';
    this.isDisableVersione = false;
    this.isDisableId = true;
    this.templateFile = '';
    this.isLoadVersionList = false;
  }

  async firstUpdated(changed) {
    super.firstUpdated(changed);
    try {
      const res = await this.getLookupData();
      this.productList = transformLookUpDataToFrontEnd(deriveData(res?.data), 'PRODUCT');
      this.statusList = transformLookUpDataToFrontEnd(deriveData(res?.data), 'STATUS');
      this.typeList = transformLookUpDataToFrontEnd(deriveData(res?.data), 'TYPE');
      // setTimeout(() => {
      //   if (this.selectedDocument && this.selectedDocument.docId) {
      //     this.getVersionDetails();
      //   }
      // }, 500);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed &&
      (changed.has('statusList') || changed.has('selectedDocument') || changed.has('status')) &&
      this.statusList &&
      this.statusList.length &&
      this.selectedDocument
    ) {
      this.enableFieldsByStatus();
      // Object.keys(this.editableActionFields).forEach(k => this.editableActionFields[k] = false );
    }

    if (changed.has('selectedDocument') && this.selectedDocument?.docId) {
      this.getVersionDetails();
    } else if (
      changed.has('selectedDocument') &&
      this.selectedDocument?.docId &&
      this.versionList?.length &&
      !this.statusLabel
    ) {
      this.setStatusLabel();
    }

    if (
      changed.has('selectedDocument') &&
      this.selectedDocument?.docId &&
      this.versionList?.length &&
      !this.isLoadVersionList
    ) {
      const index = this.versionList.findIndex(
        item6 => item6?.itemsVersionsID?.toString() === this.selectedDocument?.id?.toString(),
      );
      if (index === -1) {
        this.getVersionDetails();
      }
    }

    if (changed.has('selectedDocument') && this.selectedDocument?.docId) {
      this.templateFile = this.selectedDocument?.templateFile;
      if (!this.selectedDocument?.files?.length) {
        this.selectedDocument.files = [];
      }
      this._filesData = [...this.selectedDocument.files];
    }

    // if (
    //   changed.has('selectedDocument') &&
    //   this.selectedDocument?.docId
    // ) {
    //   this.templateFile = this.selectedDocument?.templateFile;
    // }

    if (changed.has('selectedDocument') && this.selectedDocument?.status !== 'APPROVATO') {
      this.statusLabel = '';
    }

    if (this.isDuplicateVersion === 'duplicateDocument') {
      Object.keys(this.editableActionFields).forEach(key => {
        this.editableActionFields[key] = false;
      });
      this.isDisableId = false;
      this.isDisableVersione = true;
    }

    if (this.isDuplicateVersion === 'newVersioneDocument') {
      this.isDisableVersione = true;
    }
  }

  setStatusLabel() {
    if (
      this.selectedDocument?.status === 'APPROVATO' &&
      new Date(this.selectedDocument?.start_date).getTime() <= new Date().getTime()
    ) {
      const versionList = this.versionList.filter(version => version.status === 'APPROVATO');
      const obj = getHighestItemVersionId(versionList || []);
      if (
        +obj?.itemsVersionsID > +this.selectedDocument?.id &&
        obj?.status === 'APPROVATO' &&
        new Date(obj?.validity).getTime() <= new Date().getTime()
      ) {
        this.statusLabel = 'ARCHIVIATO';
      } else {
        this.statusLabel = 'IN PRODUZIONE';
      }
    } else {
      this.statusLabel = '';
    }
  }

  setVersionNumber() {
    setTimeout(() => {
      const data = this.versionList.find(
        item => item?.itemsVersionsID?.toString() === this.selectedDocument?.id?.toString(),
      );
      if (data) {
        this.versionId = data.itemsVersionsID?.toString();
        this.selectedDocument.versionID = data?.versionID;
      } else {
        this.versionId = this.versionList[0]?.itemsVersionsID?.toString();
      }
    });
  }

  enableFieldsByStatus() {
    const statusName = this.statusList.find(
      item => item?.id?.toString() === this.selectedDocument?.statusId?.toString(),
    )?.name;
    this.oldStatusName = statusName;
    if (statusName?.toUpperCase() === 'IN SVILUPPO') {
      Object.keys(this.editableActionFields).forEach(key => {
        if (
          key !== 'name' &&
          key !== 'product' &&
          key !== 'type' &&
          key !== 'documentNewVersion' &&
          key !== 'documentDuplicateVersion'
        ) {
          this.editableActionFields[key] = false;
        }
      });
    } else if (statusName?.toUpperCase() === 'APPROVATO') {
      this.editableActionFields.documentNewVersion = false;
      this.editableActionFields.documentDuplicateVersion = false;
      Object.keys(this.editableActionFields).forEach(key => {
        if (key !== 'documentNewVersion' && key !== 'documentDuplicateVersion') {
          this.editableActionFields[key] = true;
        }
      });
    } else {
      Object.keys(this.editableActionFields).forEach(key => {
        this.editableActionFields[key] = true;
      });
    }
    this.editableActionFields = JSON.parse(JSON.stringify(this.editableActionFields));
  }

  connectedCallback() {
    super.connectedCallback();
    registerDefaultIconsets();
  }

  // eslint-disable-next-line class-methods-use-this
  getLookupData() {
    return ajaxInstance.get(`${baseURL3}`);
  }

  _closeTab() {
    const closeTabEvent = new CustomEvent('close-tab-event', {
      detail: {
        title: 'Modifica documento',
      },
    });
    this.dispatchEvent(closeTabEvent);
  }

  _fireDataSelectedEvent(data, type, typeName) {
    const ev = new CustomEvent('selected-data-changed', {
      detail: {
        data,
        type,
        typeName,
      },
    });
    this.dispatchEvent(ev);
  }

  _selectedTableRowChanged(event) {
    this._selectedSection = { ...event.detail.data };
    // ADDED
    this._selectedSubsection = undefined;
    this._selectedRow = undefined;
    this._selectedNote = undefined;
    this._fireDataSelectedEvent(this._selectedSection, 'selectedSection', 'Sezioni');
  }

  _modifySelectedSection(event) {
    // this._selectedSection = event.detail.data;
    // const { id } = event.detail.data;

    const id =
      event.detail.data.sectionId ||
      event.detail.data.subSectionId ||
      event.detail.data.rowId ||
      event.detail.data.noteId ||
      event.detail.data.ruleId;

    const ev = new CustomEvent('modify-selected-section', {
      detail: {
        data: {
          data: event.detail.data,
          name: event.detail.name,
          id,
          editableActionFields: JSON.parse(JSON.stringify(this.editableActionFields)),
        },
      },
    });
    this.dispatchEvent(ev);
  }

  _createNewVersion(event) {
    const key = this.elementParentRelationMapper[event.detail.name].propertyId;
    const id = event.detail.data[this.elementParentRelationMapper[event.detail.name].propertyId];
    // const gId = { id: generateId() };
    const data = { ...event.detail.data };
    const ev = new CustomEvent('new-version-table-row', {
      detail: {
        data,
        type: event.detail.name,
        [key]: id,
        id: data?.id,
        newSectionId: this._selectedSection?.id,
        newSubSectionId: this._selectedSubsection?.id,
        newRowId: this._selectedRow?.id,
        newNoteId: this._selectedNote?.id,
        newRuleId: this._selectedRule?.id,
      },
    });
    this.dispatchEvent(ev);
  }

  _createDuplicateElement(event) {
    const key = this.elementParentRelationMapper[event.detail.name].propertyId;
    const id = event.detail.data[this.elementParentRelationMapper[event.detail.name].propertyId];
    // const gId = { id: generateId() };
    const data = { ...event.detail.data };
    const ev = new CustomEvent('new-duplicate-table-row', {
      detail: {
        data,
        type: event.detail.name,
        [key]: id,
        id: data?.id,
        newSectionId: this._selectedSection?.id,
        newSubSectionId: this._selectedSubsection?.id,
        newRowId: this._selectedRow?.id,
        newNoteId: this._selectedNote?.id,
        newRuleId: this._selectedRule?.id,
      },
    });
    this.dispatchEvent(ev);
  }

  _deleteRowDetails(event) {
    const key = this.elementParentRelationMapper[event.detail.name].propertyId;
    const id = event.detail.data[this.elementParentRelationMapper[event.detail.name].propertyId];
    const ev = new CustomEvent('delete-table-row', {
      detail: {
        data: event.detail.data,
        type: event.detail.name,
        [key]: id,
        newSectionId: this._selectedSection?.id,
        newSubSectionId: this._selectedSubsection?.id,
        newRowId: this._selectedRow?.id,
        newNoteId: this._selectedNote?.id,
        newRuleId: this._selectedRule?.id,
      },
    });
    this.dispatchEvent(ev);
  }

  _createNewDocumentVersion() {
    const documentData = { ...this.selectedDocument };
    // documentData.version = (parseInt(documentData.version, 10) + 1).toString();
    // documentData.id = generateId();
    // if (!documentData.sections) {
    //   documentData.sections = [];
    // }

    // if (!documentData.rules) {
    //   documentData.rules = [];
    // }
    // documentData.rules = documentData.rules.map(rule => {
    //   const rule1 = { ...rule };
    //   rule1.version = (parseInt(rule1.version, 10) + 1).toString();
    //   rule1.id = generateId();
    //   return rule1;
    // });
    // documentData.sections = documentData.sections.map(section => {
    //   const section1 = { ...section };
    //   section1.version = (parseInt(section1.version, 10) + 1).toString();
    //   section1.id = generateId();

    //   if (!section1.subSections) {
    //     section1.subSections = [];
    //   }

    //   section1.subSections = section1.subSections.map(subsection => {
    //     const subsection1 = { ...subsection };
    //     subsection1.version = (parseInt(subsection1.version, 10) + 1).toString();
    //     subsection1.id = generateId();

    //     if (!subsection1.rows) {
    //       subsection1.rows = [];
    //     }

    //     subsection1.rows = subsection1.rows.map(row => {
    //       const row1 = { ...row };
    //       row1.version = (parseInt(row1.version, 10) + 1).toString();
    //       row1.id = generateId();

    //       if (!row1.notes) {
    //         row1.notes = [];
    //       }

    //       row1.notes = row1.notes.map(note => {
    //         const note1 = { ...note };
    //         note1.version = (parseInt(note1.version, 10) + 1).toString();
    //         note1.id = generateId();
    //         return note1;
    //       });
    //       return row1;
    //     });
    //     return subsection1;
    //   });
    //   return section1;
    // });

    const ev = new CustomEvent('new-document-version', {
      detail: {
        data: documentData,
        type: 'newVersion',
      },
    });
    this.dispatchEvent(ev);
  }

  _createDuplicateDocument() {
    const documentData = { ...this.selectedDocument };
    // documentData.docId = (parseInt(documentData.docId, 10) + 1).toString();
    // documentData.id = generateId();
    // if (!documentData.sections) {
    //   documentData.sections = [];
    // }

    // if (!documentData.rules) {
    //   documentData.rules = [];
    // }
    // documentData.rules = documentData.rules.map(rule => {
    //   const rule1 = { ...rule };
    //   rule1.ruleId = (parseInt(rule1.ruleId, 10) + 1).toString();
    //   rule1.id = generateId();
    //   return rule1;
    // });
    // documentData.sections = documentData.sections.map(section => {
    //   const section1 = { ...section };
    //   section1.sectionId = (parseInt(section1.sectionId, 10) + 1).toString();
    //   section1.id = generateId();

    //   if (!section1.subSections) {
    //     section1.subSections = [];
    //   }

    //   section1.subSections = section1.subSections.map(subsection => {
    //     const subsection1 = { ...subsection };
    //     subsection1.subSectionId = (parseInt(subsection1.subSectionId, 10) + 1).toString();
    //     subsection1.id = generateId();

    //     if (!subsection1.rows) {
    //       subsection1.rows = [];
    //     }

    //     subsection1.rows = subsection1.rows.map(row => {
    //       // eslint-disable-next-line
    //       const row1 = { ...row };
    //       row1.rowId = (parseInt(row1.rowId, 10) + 1).toString();
    //       row1.id = generateId();

    //       if (!row1.notes) {
    //         row1.notes = [];
    //       }

    //       row1.notes = row1.notes.map(note => {
    //         const note1 = { ...note };
    //         note1.noteId = (parseInt(note1.noteId, 10) + 1).toString();
    //         note1.id = generateId();
    //         return note1;
    //       });
    //       return row1;
    //     });
    //     return subsection1;
    //   });
    //   return section1;
    // });
    const ev = new CustomEvent('create-duplicate-document', {
      detail: {
        data: documentData,
        type: 'newDuplication',
      },
    });
    this.dispatchEvent(ev);
  }

  _selectedSubsectionsTableRowChanged(event) {
    this._selectedSubsection = { ...event.detail.data };
    // ADDED
    this._selectedRow = undefined;
    this._selectedNote = undefined;
    this._fireDataSelectedEvent(this._selectedSubsection, 'selectedSubSection', 'Sotto Sezioni');
  }

  _selectedRowsTableRowChanged(event) {
    this._selectedRow = { ...event.detail.data };
    // ADDED
    this._selectedNote = undefined;
    this._fireDataSelectedEvent(this._selectedRow, 'selectedRow', 'Righe');
  }

  _selectedNotesTableRowChanged(event) {
    this._selectedNote = { ...event.detail.data };
    this._fireDataSelectedEvent(this._selectedNote, 'selectedNote', 'Nota');
  }

  _selectedRulesTableRowChanged(event) {
    this._selectedRule = { ...event.detail.data };
    this._fireDataSelectedEvent(this._selectedRule, 'selectedRule', 'Regola');
  }

  _fireDataOrderChangedEvent(type, propertyId, data, restData = {}) {
    const ev = new CustomEvent('data-order-changed', {
      detail: {
        type,
        propertyId,
        data,
        ...restData,
      },
    });
    this.dispatchEvent(ev);
  }

  _rowOrderChanged(event) {
    this.selectedDocument.sections = event.detail.data;
    const { swappedData, swappedWithData } = event.detail;
    this._fireDataOrderChangedEvent(
      'Sezioni',
      'sectionId',
      this.selectedDocument.sections,
      { swappedData, swappedWithData },
      {
        docId: this.selectedDocument.docId,
      },
    );
  }

  _rowSubsectionsOrderChanged(event) {
    this._selectedSection.subSections = event.detail.data;
    const { swappedData, swappedWithData } = event.detail;
    this._fireDataOrderChangedEvent(
      'Sotto Sezioni',
      'subSectionId',
      this._selectedSection.subSections,
      { swappedData, swappedWithData },
      {
        docId: this.selectedDocument.docId,
        sectionId: this._selectedSection.sectionId,
      },
    );
  }

  _rowDocumentRowOrderChanged(event) {
    this._selectedSubsection.rows = event.detail.data;

    const { swappedData, swappedWithData } = event.detail;
    this._fireDataOrderChangedEvent(
      'Righe',
      'rowId',
      this._selectedSubsection.rows,
      { swappedData, swappedWithData },
      {
        docId: this.selectedDocument.docId,
        sectionId: this._selectedSection.sectionId,
        subSectionId: this._selectedSubsection.subSectionId,
      },
    );
  }

  _rowNotesOrderChanged(event) {
    this._selectedRow.notes = event.detail.data;

    const { swappedData, swappedWithData } = event.detail;
    this._fireDataOrderChangedEvent(
      'Nota',
      'noteId',
      this._selectedRow.notes,
      { swappedData, swappedWithData },
      {
        docId: this.selectedDocument.docId,
        sectionId: this._selectedSection.sectionId,
        subSectionId: this._selectedSubsection.subSectionId,
        rowId: this._selectedRow.rowId,
      },
    );
  }

  _rowRulesOrderChanged(event) {
    this.selectedDocument.rules = event.detail.data;

    const { swappedData, swappedWithData } = event.detail;
    this._fireDataOrderChangedEvent(
      'Regola',
      'ruleId',
      this.selectedDocument.rules,
      { swappedData, swappedWithData },
      {
        docId: this.selectedDocument.docId,
      },
    );
  }

  handleChange(event) {
    if (!event.target.name) return;
    if (event.target.name === 'start_date') {
      this.selectedDocument[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else if (event.target.name === 'templateFile') {
      this.templateFile = event.target.value;
    } else {
      this.selectedDocument[event.target.name] = event.target.value;
    }
    // if (event.target.name === 'statusId') {
    //   this.status = event.target.value;
    // }
    const ev = new CustomEvent('document-data-changed', {
      detail: this.selectedDocument,
    });
    this.dispatchEvent(ev);
  }

  // eslint-disable-next-line class-methods-use-this
  toBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  // eslint-disable-next-line class-methods-use-this
  async uploadFiles(payload) {
    // eslint-disable-next-line
    return await this.ajaxInstance.post(`${baseURL6}/generic-document`, payload);
  }

  async _filesAdded(e) {
    if (e) {
      let files = e.detail.map(f => {
        f.id = generateId(); // eslint-disable-line no-param-reassign
        return f;
      });
      try {
        const res = await chunks(files, multipleFileUpload, 50);
        files = [...res.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value)];
        files.forEach(item => {
          const index = this._filesData.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (index > -1) {
            this._filesData[index].id = item.id;
          } else {
            this._filesData.push(item);
          }
        });
        this._filesData = [...this._filesData];
      } catch (err) {
        this._filesData = this._filesData.filter(
          item => item?.id?.toString() !== files[0]?.id?.toString(),
        );
        // eslint-disable-next-line
        console.log('Error', err);
      }
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async deleteLevels(chunkItems) {
    try {
      // eslint-disable-next-line
      chunkItems = chunkItems.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      await chunks(chunkItems, removeVersionLevels, 50);

      // const e = new CustomEvent('row-changed', {});
      // this.dispatchEvent(e);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  async _fileRemoved(ev) {
    const { id } = ev.detail;
    try {
      if (id) {
        const lev0Id = this._filesData.find(
          d => d?.id?.toString() === id?.toString(),
        )?.versionDetailLevel0ID;
        if (lev0Id) {
          await this.deleteLevels([{ level: 0, id: lev0Id }]);
        }
        this._filesData = this._filesData.filter(d => d?.id?.toString() !== id?.toString());
      }
      this._filesData = [...this._filesData];
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  _hydrateSelect(i, d, fieldName, callback) {
    if (!this.selectedDocument[fieldName] && i === 0) {
      this.selectedDocument[fieldName] = d.id;
      if (fieldName === 'statusId') {
        this.status = d.id;
      }
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this.selectedDocument[fieldName]?.toString() === d?.id?.toString()) return true;
    return false;
  }

  _isStatusEnabled(d) {
    // const statusName = this.statusList.find((item) => item?.id?.toString() === this.selectedDocument?.statusId?.toString())?.name;
    if (
      this.oldStatusName?.toUpperCase() === 'IN SVILUPPO' &&
      d?.name?.toUpperCase() === 'DISMESSO'
    )
      return false;
    if (
      this.oldStatusName?.toUpperCase() === 'IN REVISIONE' &&
      d?.name?.toUpperCase() === 'IN SVILUPPO'
    )
      return false;
    if (
      this.oldStatusName?.toUpperCase() === 'APPROVATO' &&
      d?.name?.toUpperCase() === 'IN SVILUPPO' &&
      this.statusLabel !== 'IN PRODUZIONE'
    )
      return false;
    if (
      this.oldStatusName?.toUpperCase() === 'APPROVATO' &&
      d?.name?.toUpperCase() === 'DISMESSO' &&
      this.statusLabel !== 'IN PRODUZIONE'
    )
      return false;
    if (this.oldStatusName?.toUpperCase() === d?.name?.toUpperCase()) return false;
    return true;
  }

  _addElement(event) {
    const ev = new CustomEvent('add-new-element', {
      detail: {
        data: event.detail,
      },
    });
    this.dispatchEvent(ev);
  }

  async saveDocument() {
    if (!this._filesData?.length) {
      this._filesData = [];
    }
    this.selectedDocument.files = this._filesData;
    this.selectedDocument.templateFile = this.templateFile;
    await this.saveNewFields(this.selectedDocument);
    const ev = new CustomEvent('save-document', {
      detail: {
        data: this.selectedDocument,
      },
    });
    this.dispatchEvent(ev);
  }

  async saveNewFields(doc) {
    let versionID;
    if (!doc?.versionID) {
      this.versionList = await this.getVersionsList(doc?.docId);
      if (this.versionList.length > 0) {
        this.versionList = this.versionList.map(ver => {
          if (ver) {
            // eslint-disable-next-line
            ver.versionName = `Versione ${ver.versionNumber} del ${formatDate(new Date(), {
              locale: 'it-It',
            })}`;
          }
          return ver;
        });
        const data = this.versionList.find(
          item => item?.itemsVersionsID?.toString() === doc?.id?.toString(),
        );
        if (data) {
          versionID = data?.versionID;
          // eslint-disable-next-line
          this.selectedDocument.versionID = data?.versionID;
        }
      }
    } else if (doc?.versionID) {
      versionID = doc?.versionID;
    }
    const level0 = {};
    const level0UnSaveItems = [];
    if (!doc?.versionDetailLevel0IDTemplateFile && this.templateFile && versionID) {
      level0UnSaveItems.push(
        this.createToBackEnd(0, versionID, 'FIELD', 'JASPER_TEMPLATE_FILE', this.templateFile),
      );
    }
    const level1UnSaveItems = [];

    doc?.files.forEach(file => {
      if (!file?.versionDetailLevel0ID && versionID) {
        level0UnSaveItems.push(
          this.createToBackEnd(
            0,
            versionID,
            'VERSION_DETAIL_LEVEL_1',
            'TESTFILE_ALLEGATO',
            file?.id,
          ),
        );
        level1UnSaveItems.push(file);
      } else if (file?.versionDetailLevel0ID) {
        level0[file?.id] = file?.versionDetailLevel0ID;
      }
    });

    if (level0UnSaveItems?.length) {
      const level0ResList = await this.addVersionDetails(level0UnSaveItems);
      level0ResList.forEach(item => {
        if (item?.data && item?.versionDetailID) {
          level0[item.data] = item.versionDetailID;
        }
      });
    }

    const level1RequestList = [];
    if (level1UnSaveItems?.length) {
      level1UnSaveItems.forEach(file => {
        if (level0[file?.id]) {
          level1RequestList.push(
            this.createToBackEnd(1, level0[file?.id], 'DETTAGLIO_ALLEGATO', 'FILENAME', file?.name),
          );
          level1RequestList.push(
            this.createToBackEnd(1, level0[file?.id], 'DETTAGLIO_ALLEGATO', 'FILESIZE', file?.size),
          );
        }
      });
    }

    if (level1RequestList?.length) {
      await this.addVersionDetails(level1RequestList);
    }
  }

  // eslint-disable-next-line
  createToBackEnd(level, parentId, key, value, data) {
    return {
      versionDetailLevel: level,
      versionDetailParentID: parentId,
      itemTypeKey: key,
      itemTypeValue: value,
      data,
    };
  }

  // eslint-disable-next-line
  async addVersionDetails(data1) {
    try {
      let chunkData = await chunks([data1], createVersionDetail, 50);
      if (!chunkData) {
        chunkData = [];
      }
      chunkData = [
        ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
      ];

      let chunkData1 = [];
      chunkData.forEach(item => {
        if (item?.versionDetailsDTO) {
          chunkData1 = [...chunkData1, ...item?.versionDetailsDTO];
        }
      });
      return chunkData1;
      // eslint-disable-next-line
      // data1 = data1.map(i => {
      //   // eslint-disable-next-line
      //   i.versionDetailID = generateId();
      //   return i
      // });
      // return data1;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    }
  }

  async getVersionDetails() {
    try {
      this.isLoadVersionList = true;
      this.versionList = await this.getVersionsList(this.selectedDocument.docId);
      this.isLoadVersionList = false;
      if (this.versionList.length > 0) {
        this.versionList = this.versionList.map(ver => {
          if (ver) {
            // eslint-disable-next-line
            ver.versionName = `Versione ${ver.versionNumber} del ${formatDate(
              new Date(ver.validity || new Date()),
              {
                locale: 'it-It',
              },
            )}`;
          }
          return ver;
        });
        this.setVersionNumber();
        this.setStatusLabel();
      }
    } catch (err) {
      this.isLoadVersionList = false;
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async changeVersionDetail(event) {
    try {
      const { value } = event.target;
      this.versionId = value;
      delete this.selectedDocument.sections;
      delete this.selectedDocument.rules;
      // eslint-disable-next-line
      if (this.selectedDocument.hasOwnProperty('subSections')) {
        delete this.selectedDocument.subSections;
      }
      // eslint-disable-next-line
      if (this.selectedDocument.hasOwnProperty('rows')) {
        delete this.selectedDocument.rows;
      }
      // eslint-disable-next-line
      if (this.selectedDocument.hasOwnProperty('notes')) {
        delete this.selectedDocument.notes;
      }
      const res = await this.getVersionItemDetail(value);
      this.selectedDocument = transformDocumentsToFrontEnd(res?.data);

      this.selectedDocument.sections = await (
        await this.makeElementsAjaxCall(
          transformSectionsToFrontEnd,
          this.selectedDocument,
          'Sezioni',
        )
      ).list;
      this.selectedDocument.rules = await (
        await this.makeElementsAjaxCall(transformRulesToFrontEnd, this.selectedDocument, 'Regola')
      ).list;

      this.selectedDocument = JSON.parse(JSON.stringify(this.selectedDocument));
      const data = this.versionList.find(
        item => item?.itemsVersionsID?.toString() === this.selectedDocument?.id?.toString(),
      );
      if (data) {
        this.selectedDocument.versionID = data?.versionID;
      }
      const ev = new CustomEvent('document-version-changed', {
        detail: {
          data: this.selectedDocument,
        },
      });
      this.dispatchEvent(ev);
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    try {
      const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
      return res.data ? deriveData(res.data) : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionItemDetail(id) {
    const res = await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    return res;
  }

  async makeElementsAjaxCall(transformFn, parent, type) {
    // , type
    // ?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[type]}\
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL2}/version/${parent.id}`;
      if (this.getAPIMapper[type] === 'RIGA') {
        url = `${baseURL2}/version/${parent.id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
      } else if (this.getAPIMapper[type] === 'REGOLA') {
        url = `${baseURL2}/version/${parent.id}/select?itemTypeKeyParent=RULE_TYPE&itemTypeValueChild=DESCRIZIONE_ITEM`;
      }
    } else {
      // FOR MOCK USE
      url = `${baseURL2}/${this.getAPIMapper[type]}/version/${parent.id}`;
    }
    let list;
    try {
      const res = await this.ajaxInstance.get(url);

      list = res.data?.itemChildren || [];

      list = list?.map(d => transformFn(d));

      if (this.getAPIMapper[type] === 'NOTA' && localEnvironment.production) {
        const row = transformRowsToFrontEnd(res?.data);
        if (row?.columnNotes?.length) {
          const ids = row?.columnNotes.map(item3 => item3?.id);
          const dataList = await this._getExistingData(ids);
          list = transformNotesListToFrontEnd(dataList) || [];
        }
      }
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingData(data) {
    let data1 = data;
    data1 = data1.filter((v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i);
    let chunkData = await chunks(data1, fetchChildItems, 50);
    if (!chunkData) {
      chunkData = [];
    }
    chunkData = [
      ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
    ];
    chunkData = chunkData.filter(
      (v, i, a) =>
        a.findIndex(v2 => v2?.itemsVersionsID?.toString() === v?.itemsVersionsID?.toString()) === i,
    );
    return chunkData;
  }

  // eslint-disable-next-line
  getStatusClass(label) {
    if (label === 'ARCHIVIATO') {
      this.editableActionFields.documentNewVersion = false;
      this.editableActionFields.documentDuplicateVersion = false;
      return 'blue-cl';
      // eslint-disable-next-line
    } else if (label === 'IN PRODUZIONE') {
      this.editableActionFields.documentNewVersion = false;
      this.editableActionFields.documentDuplicateVersion = false;
      return 'green-cl';
    } else {
      this.editableActionFields.documentNewVersion = true;
      this.editableActionFields.documentDuplicateVersion = true;
      return '';
    }
  }

  _handleChildEvents(event) {
    const customEvent = new CustomEvent('child-data-event', {
      detail: event?.detail,
    });
    this.dispatchEvent(customEvent);
  }

  render() {
    return html`
      <div class="tab_content">
        <div class="document_details_content">
          <div class="document_details_label">
            <label class="document_details_text">Dettaglio documento</label>
          </div>

          <ing-form>
            <form>
              <div>
                <ing-select
                  class="input_value version"
                  inputElement
                  colorElement
                  name="version"
                  label="VERSIONE"
                  .modelValue="${this.versionId}"
                  ?disabled="${this.isDisableVersione}"
                  @change="${this.changeVersionDetail}"
                >
                  <select slot="input">
                    ${this.versionList?.map(
                      item =>
                        html` <option value="${item.itemsVersionsID}">${item.versionName}</option>`,
                    )}
                  </select>
                </ing-select>
              </div>
              <div class="name-box">
                <ing-input
                  id="document_details_name"
                  name="name"
                  class="document_details_name"
                  label="NOME"
                  inputElement
                  .modelValue="${this.selectedDocument?.name}"
                  @change="${this.handleChange}"
                  ?disabled="${this.editableActionFields?.name}"
                ></ing-input>
                <ing-select
                  class="stato input_value"
                  inputElement
                  colorElement
                  name="statusId"
                  label="STATO"
                  @change="${this.handleChange}"
                  ?disabled="${this.editableActionFields?.status}"
                >
                  <select slot="input" name="statusId">
                    ${this.statusList.map(
                      (d, i) =>
                        html`<option
                          ?selected="${this._hydrateSelect(i, d, 'statusId')}"
                          ?disabled="${this._isStatusEnabled(d)}"
                          value="${d.id}"
                        >
                          ${d.name}
                        </option>`,
                    )}
                  </select>
                </ing-select>
                <label class="status-label ${this.getStatusClass(this.statusLabel)}"
                  >${this.statusLabel}</label
                >
              </div>
              <div>
                <ing-input
                  id="document_details_id"
                  name="docId"
                  class="document_details_id"
                  label="ID"
                  inputElement
                  .modelValue="${this.selectedDocument?.docId}"
                  @change="${this.handleChange}"
                  ?disabled="${this.isDisableId}"
                ></ing-input>
                <ing-select
                  class="document_details_product"
                  name="productId"
                  @change="${this.handleChange}"
                  label="PRODOTTO"
                  inputElement
                  ?disabled="${this.editableActionFields?.product}"
                >
                  <select name="product" slot="input">
                    ${this.productList.map(
                      (d, i) =>
                        html`<option
                          ?selected="${this._hydrateSelect(i, d, 'productId')}"
                          value="${d.id}"
                        >
                          ${d.name}
                        </option>`,
                    )}
                  </select>
                </ing-select>
                <ing-input
                  id="document_details_code"
                  name="code"
                  class="document_details_code"
                  label="CODICE"
                  inputElement
                  .modelValue="${this.selectedDocument?.code}"
                  @change="${this.handleChange}"
                  ?disabled="${this.editableActionFields?.codice}"
                ></ing-input>
                <ing-select
                  class="document_details_type"
                  name="typeId"
                  @change="${this.handleChange}"
                  label="TIPO"
                  inputElement
                  ?disabled="${this.editableActionFields?.type}"
                >
                  <select name="type" slot="input">
                    ${this.typeList.map(
                      (d, i) =>
                        html`<option
                          ?selected="${this._hydrateSelect(i, d, 'typeId')}"
                          value="${d.id}"
                        >
                          ${d.name}
                        </option>`,
                    )}
                  </select>
                </ing-select>
                <ing-input-datepicker
                  id="document_details_from"
                  name="start_date"
                  class="document_details_from"
                  label="VALIDO DAL"
                  inputElement
                  colorElement
                  .modelValue=${this.selectedDocument?.start_date
                    ? new Date(this.selectedDocument?.start_date)
                    : new Date()}
                  @change="${this.handleChange}"
                  @click="${this.handleChange}"
                  ?disabled="${this.editableActionFields?.validity}"
                ></ing-input-datepicker>
              </div>
              <div class="single">
                <ing-input
                  id="document_details_template_file"
                  name="templateFile"
                  class="document_details_template_file"
                  label="TEMPLATE FILE"
                  inputElement
                  .modelValue="${this.templateFile}"
                  @change=${this.handleChange}
                  ?disabled="${this.editableActionFields?.templateFile}"
                ></ing-input>
                <div class="fileUpload">
                  <file-upload
                    @files-added="${this._filesAdded}"
                    ?disableFile="${this.editableActionFields?.fileUpload}"
                  ></file-upload>
                </div>
              </div>
              <div class="files">
                ${this._filesData.map(
                  d => html`
                    <removable-chip
                      @chip-deleted="${this._fileRemoved}"
                      id="${d.id}"
                      labelText="${d.labelText || d.name}"
                      ?closeIconEnable="${this.editableActionFields?.fileUpload}"
                    >
                    </removable-chip>
                  `,
                )}
              </div>
              <div class="container">
                <div class="right_alignment">
                  <ing-button
                    outline
                    indigo
                    font12
                    class="view_button"
                    @click="${this._createNewDocumentVersion}"
                    ?disabled="${this.editableActionFields?.documentNewVersion}"
                    >Nuova Versione</ing-button
                  >
                  <ing-button
                    outline
                    indigo
                    font12
                    class="review_button duplicate-btn"
                    @click="${this._createDuplicateDocument}"
                    ?disabled="${this.editableActionFields?.documentDuplicateVersion}"
                    >Nuova con Duplicazione</ing-button
                  >
                  <ing-button
                    indigo
                    font12
                    class="review_button save_btn"
                    @click="${this.saveDocument}"
                    ?disabled="${this.editableActionFields?.documentSave}"
                    >Salva</ing-button
                  >
                </div>
                <ing-button
                  id="createNew"
                  class="create-new-button"
                  ?disabled="${this.editableActionFields?.generateAntePrima ||
                  !this._filesData.length}"
                  >Genera anteprima
                </ing-button>
              </div>
            </form>
          </ing-form>
        </div>

        <div class="ing_standard_section_line"></div>

        <div class="sections_details_content">
          <collapsible-document-details
            sectionName="Sezioni"
            .tableContentData=${this.selectedDocument?.sections}
            .selectedRow=${this._selectedSection}
            .selectedParentData=${this.selectedDocument}
            .headerData="${this._sectionsHeader}"
            propertyId="id"
            nameId="sectionId"
            ?isEnableAddElement="${this.editableActionFields?.sectionAdd}"
            ?isEnableRemoveElement="${this.editableActionFields?.sectionRemove}"
            ?isEnableNewVersion="${this.editableActionFields?.sectionNewVersion}"
            ?isEnableDuplicateVersion="${this.editableActionFields?.sectionDuplicate}"
            ?isEnableViewDetails="${false}"
            ?isEnableUpArrow="${this.editableActionFields?.sectionUpArrow}"
            ?isEnableDownArrow="${this.editableActionFields?.sectionDownArrow}"
            @selected-table-row="${this._selectedTableRowChanged}"
            @row-order-changed="${this._rowOrderChanged}"
            @modify-table-row="${this._modifySelectedSection}"
            @new-version-table-row="${this._createNewVersion}"
            @new-duplicate-table-row="${this._createDuplicateElement}"
            @add-new-element="${this._addElement}"
            @delete-table-row="${this._deleteRowDetails}"
          ></collapsible-document-details>
        </div>

        <div class="ing_standard_subsection_line"></div>

        <div class="sections_details_content">
          <collapsible-document-details
            sectionName="Sotto Sezioni"
            .tableContentData=${this._selectedSection?.subSections}
            .selectedRow=${this._selectedSubsection}
            .selectedParentData=${this._selectedSection}
            .headerData="${this._subSectionsHeader}"
            propertyId="id"
            nameId="subSectionId"
            ?isEnableAddElement="${this.editableActionFields?.subSectionAdd}"
            ?isEnableRemoveElement="${this.editableActionFields?.subSectionRemove}"
            ?isEnableNewVersion="${this.editableActionFields?.subSectionNewVersion}"
            ?isEnableDuplicateVersion="${this.editableActionFields?.subSectionDuplicate}"
            ?isEnableViewDetails="${false}"
            ?isEnableUpArrow="${this.editableActionFields?.subSectionUpArrow}"
            ?isEnableDownArrow="${this.editableActionFields?.subSectionDownArrow}"
            @selected-table-row="${this._selectedSubsectionsTableRowChanged}"
            @row-order-changed="${this._rowSubsectionsOrderChanged}"
            @modify-table-row="${this._modifySelectedSection}"
            @new-version-table-row="${this._createNewVersion}"
            @new-duplicate-table-row="${this._createDuplicateElement}"
            @add-new-element="${this._addElement}"
            @delete-table-row="${this._deleteRowDetails}"
          ></collapsible-document-details>
        </div>

        <div class="ing_standard_subsection_line"></div>

        <div class="sections_details_content">
          <collapsible-document-rows-details
            sectionName="Righe"
            .tableContentData=${this._selectedSubsection?.rows}
            .selectedRow=${this._selectedRow}
            .selectedParentData=${this._selectedSubsection}
            .headerData="${this._rowsHeader}"
            propertyId="id"
            nameId="rowId"
            ?isEnableAddElement="${this.editableActionFields?.rowAdd}"
            ?isEnableRemoveElement="${this.editableActionFields?.rowRemove}"
            ?isEnableNewVersion="${this.editableActionFields?.rowNewVersion}"
            ?isEnableDuplicateVersion="${this.editableActionFields?.rowDuplicate}"
            ?isEnableViewDetails="${false}"
            ?isEnableUpArrow="${this.editableActionFields?.rowUpArrow}"
            ?isEnableDownArrow="${this.editableActionFields?.rowDownArrow}"
            @selected-table-row="${this._selectedRowsTableRowChanged}"
            @row-order-changed="${this._rowDocumentRowOrderChanged}"
            @modify-table-row="${this._modifySelectedSection}"
            @new-version-table-row="${this._createNewVersion}"
            @new-duplicate-table-row="${this._createDuplicateElement}"
            @add-new-element="${this._addElement}"
            @delete-table-row="${this._deleteRowDetails}"
          ></collapsible-document-rows-details>
        </div>

        <div class="ing_standard_subsection_line"></div>

        <div class="sections_details_content">
          <collapsible-document-details
            sectionName="Nota"
            .tableContentData=${this._selectedRow?.notes}
            .selectedRow=${this._selectedNote}
            .selectedParentData=${this._selectedRow}
            .headerData="${this._notesHeader}"
            propertyId="id"
            nameId="noteId"
            ?isEnableAddElement="${this.editableActionFields?.noteAdd}"
            ?isEnableRemoveElement="${this.editableActionFields?.noteRemove}"
            ?isEnableNewVersion="${this.editableActionFields?.noteNewVersion}"
            ?isEnableDuplicateVersion="${this.editableActionFields?.noteDuplicate}"
            ?isEnableViewDetails="${false}"
            ?isEnableUpArrow="${this.editableActionFields?.noteUpArrow}"
            ?isEnableDownArrow="${this.editableActionFields?.noteDownArrow}"
            @selected-table-row="${this._selectedNotesTableRowChanged}"
            @row-order-changed="${this._rowNotesOrderChanged}"
            @modify-table-row="${this._modifySelectedSection}"
            @new-version-table-row="${this._createNewVersion}"
            @new-duplicate-table-row="${this._createDuplicateElement}"
            @add-new-element="${this._addElement}"
            @delete-table-row="${this._deleteRowDetails}"
          ></collapsible-document-details>
        </div>
        <div class="sections_details_content separator-scetion">
          <collapsible-document-details
            sectionName="Regola"
            .tableContentData=${this.selectedDocument?.rules}
            .selectedRow=${this._selectedRule}
            .selectedParentData=${this.selectedDocument}
            .headerData="${this._rulesHeader}"
            propertyId="id"
            nameId="ruleId"
            ?isEnableAddElement="${this.editableActionFields?.ruleAdd}"
            ?isEnableRemoveElement="${this.editableActionFields?.ruleRemove}"
            ?isEnableNewVersion="${this.editableActionFields?.ruleNewVersion}"
            ?isEnableDuplicateVersion="${this.editableActionFields?.ruleDuplicate}"
            ?isEnableViewDetails="${false}"
            ?isEnableUpArrow="${this.editableActionFields?.ruleUpArrow}"
            ?isEnableDownArrow="${this.editableActionFields?.ruleDownArrow}"
            @selected-table-row="${this._selectedRulesTableRowChanged}"
            @row-order-changed="${this._rowRulesOrderChanged}"
            @modify-table-row="${this._modifySelectedSection}"
            @new-version-table-row="${this._createNewVersion}"
            @new-duplicate-table-row="${this._createDuplicateElement}"
            @add-new-element="${this._addElement}"
            @delete-table-row="${this._deleteRowDetails}"
          ></collapsible-document-details>
        </div>
        <div class="sections_details_content separator-scetion">
          <collapsible-document-common-details
            sectionName="Anteprima Di Stampa"
            .tableContentData=${this.selectedDocument?.printPreview}
            .headerData="${previewDocumentsHeader}"
            .contentProperties="${contentDataDocumentPreview}"
            propertyId="id"
            .additionalStyles=${reviewHistoryTableStyles}
            @child-data-event=${this._handleChildEvents}
          >
          </collapsible-document-common-details>
        </div>
        <ing-button outline indigo font14 class="modify_button" @click="${this._closeTab}"
          >Chiudi tab</ing-button
        >
      </div>
    `;
  }
}
customElements.define('document-details-page', DocumentDetailsPage);
