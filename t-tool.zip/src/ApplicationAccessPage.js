import { ScopedElementsMixin, LitElement, html, IngButton } from 'ing-web';

import styles from './ApplicationAccessPageStyles.js';

export class ApplicationAccessPage extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
    };
  }

  static get styles() {
    return styles;
  }

  goToHomePage() {
    const event = new CustomEvent('go-to-home-page');
    this.dispatchEvent(event);
  }

  render() {
    return html` <div class="main_container">
      <div class="content_body_area">
        <div class="label-text"><label>Tool Trasparenza</label></div>
        <div>
          <ing-button class="access-button" @click="${this.goToHomePage}"> Accedi</ing-button>
        </div>
      </div>
    </div>`;
  }
}
customElements.define('application-access-page', ApplicationAccessPage);
