import { css } from 'ing-web';

export default css`
  .container-fluid {
    position: relative;
    width: 20rem;
    height: 376px;
    background: #e8f3fa;
    border-radius: 8px;
    display: inline-block;
    box-sizing: border-box;
    padding: 25px;
    margin-bottom: 20px;
  }
  .d-flex {
    display: flex;
    align-items: center;
  }
  [data-tag-name='ing-checkbox'] {
    width: 1.8rem;
  }
  .col-sm-8 {
    margin-top: 1rem;
  }
  .sub-group {
    margin-bottom: 0.5rem;
    display: block;
  }
  .submit-btn {
    background-color: transparent;
    color: rgb(82, 81, 153);
    width: 5rem;
    font-size: 14px;
    padding: 0;
    border: 1px solid rgb(82, 81, 153);
  }
  .remove-btn {
    background-color: transparent;
    color: rgb(255 98 0);
    width: 5rem;
    font-size: 14px;
    padding: 0px;
    border: 1px solid rgb(255 98 0);
    margin-left: 15px;
  }
  .m-0 {
    margin: 0;
  }
  .form-btns-wrapper {
    bottom: 20px;
    position: absolute;
  }
  .rule-form-textarea textarea {
    height: 68px !important;
    overflow: auto !important;
  }
`;
