import {
  LitElement,
  html,
  ScopedElementsMixin,
  IngIcon,
  IngCheckbox,
  IngTextarea,
  IngButton,
} from 'ing-web';

import styles from './ruleFormStyles.js';

export class RuleForm extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      formData: Object,
      isMultiple: {
        type: Boolean,
        reflect: true,
      },
      disableRemoveButton: {
        type: Boolean,
        reflect: true,
      },
    };
  }

  static get scopedElements() {
    return {
      'ing-checkbox': IngCheckbox,
      'ing-icon': IngIcon,
      'ing-button': IngButton,
      'ing-textarea': IngTextarea,
    };
  }

  constructor() {
    super();
    this.formData = {};
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has('formData') && this.formData === undefined) {
      this.formData = {};
    }
  }

  _handleChange(event) {
    const { name, value, checked } = event.target;
    const isSwitch = event.currentTarget.nodeName.match(/(ing-switch|ing-checkbox)/i);
    clearTimeout(this.debounceTime);
    this.debounceTime = setTimeout(() => {
      this.formData[name] = isSwitch ? checked : value;
    }, 0);
  }

  _submit() {
    const ev = new CustomEvent('form-data-received', {
      detail: this.formData,
    });
    this.dispatchEvent(ev);
  }

  _remove() {
    const ev = new CustomEvent('remove-form-data', {
      detail: this.formData,
    });
    this.dispatchEvent(ev);
  }

  get removeButtonValidty() {
    const validity = !!(
      this.formData?.isBold ||
      this.formData?.isVisible ||
      this.formData?.isItalic ||
      this.formData?.value
    );
    return !validity;
  }

  render() {
    return html`
      <div class="container-fluid">
        <label class="form-group col-sm-8 d-flex">
          <ing-checkbox
            id="${this.id}"
            @change="${this._handleChange}"
            rowElementsCheckbox
            ?checked=${this.formData?.isVisible}
            name="isVisible"
          ></ing-checkbox>
          Visibile
        </label>
        ${this.isMultiple
          ? ''
          : html`
              <div class="form-group col-sm-8">
                <label class="sub-group">Formattazione</label>
                <label class="d-flex">
                  <ing-checkbox
                    id="${this.id}"
                    @change="${this._handleChange}"
                    ?checked=${this.formData?.isItalic}
                    name="isItalic"
                    rowElementsCheckbox
                  ></ing-checkbox>
                  Corsivo
                </label>
              </div>
              <div class="form-group col-sm-8 m-0">
                <label class="d-flex">
                  <ing-checkbox
                    id="${this.id}"
                    @change="${this._handleChange}"
                    ?checked=${this.formData?.isBold}
                    name="isBold"
                    rowElementsCheckbox
                  ></ing-checkbox>
                  Grassetto
                </label>
              </div>
              <div class="form-group col-sm-8">
                <label class="sub-group">Valore</label>
                <ing-textarea
                  class="rule-form-textarea"
                  name="value"
                  .modelValue=${this.formData?.value}
                  @keyup="${this._handleChange}"
                ></ing-textarea>
              </div>
            `}
        <div class="form-group col-sm-8 form-btns-wrapper">
          <ing-button class="submit-btn" @click="${this._submit}">Applica</ing-button>
          <ing-button
            class="remove-btn"
            ?disabled=${this.disableRemoveButton}
            @click="${this._remove}"
            >Svuota</ing-button
          >
        </div>
      </div>
    `;
  }
}
