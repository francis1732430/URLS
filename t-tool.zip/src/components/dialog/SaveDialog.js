import {
  LitElement,
  html,
  ScopedElementsMixin,
  IngButton,
  registerDefaultIconsets,
  IngIcon,
} from 'ing-web';

import styles from './SaveDialogStyles.js';

export class SaveDialog extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
    };
  }

  connectedCallback() {
    super.connectedCallback();
    registerDefaultIconsets();
  }

  _closeDialog() {
    const closeDialogEvent = new CustomEvent('close-dialog-event', {});
    this.dispatchEvent(closeDialogEvent);
  }

  render() {
    return html`
      <div class="container">
        <div class="center_alignment">
          <ing-icon
            class="button-pointer resize_icon"
            icon-id="ing:filledin-notification:notificationSuccess"
            slot="icon-before"
            aria-label="icon:pointer"
          ></ing-icon>
          <div class="document_details_label">
            <label class="document_details_text">Sezione modificata con successo</label>
          </div>
        </div>

        <div class="right_alignment">
          <ing-button indigo font14 class="save_button" @click="${this._closeDialog}"
            >Chiudi</ing-button
          >
        </div>
      </div>
    `;
  }
}
customElements.define('save-dialog', SaveDialog);
