import { css, font14Mixin, font19BoldMixin } from 'ing-web';

export default css`
  .document_details_label {
    margin-top: 29px;
    margin-left: 160px;
  }

  .document_details_text {
    ${font19BoldMixin()};
  }

  .document_details_content {
    height: auto;
  }

  .dialog_document_name {
    width: 480px;
    height: 40px;
    margin-left: 40px;
    margin-top: 20px;
  }

  .dialog_document_description {
    margin-top: 60px;
    width: 480px;
    height: 40px;
    margin-left: 39px;
  }

  .dialog_container {
  }

  .dialog_document_from {
    margin-top: 63px;
    margin-left: 39px;
    width: 180px;
    height: 40px;
    display: inline-block;
    --ing-input-group-width: 180px;
  }

  .dialog_document_style {
    width: 180px;
    margin-left: 100px;
    display: inline-block;
  }

  .version_text {
    color: rgb(255, 98, 0);
    margin-left: 10px;
    display: inline-block;
  }

  .text_container {
    display: inline-block;
    vertical-align: middle;
    margin-left: 90px;
    ${font14Mixin()}
    margin-top: 35px;
  }

  .container {
    height: 30px;
    position: relative;
    margin-top: 34px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 105px;
  }

  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 28px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 28px;
    margin-left: 32px;
  }
  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
  }
  form {
    margin-left: 63px;
  }
  .ml-19 {
    margin-left: 19px;
  }
  .ml-8 {
    margin-left: 8px;
  }
  .ml-80 {
    margin-left: 80px;
  }
`;
