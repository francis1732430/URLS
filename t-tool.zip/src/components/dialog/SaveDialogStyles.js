import { css, font19BoldMixin } from 'ing-web';

export default css`
  .document_details_label {
    margin-top: 29px;
  }

  .document_details_text {
    ${font19BoldMixin()};
    color: rgb(255, 98, 0);
  }

  .container {
    position: relative;
  }

  .center_alignment {
    margin: 0;
    text-align: center;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 28px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 28px;
  }

  .resize_icon {
    max-width: 40px;
    max-height: 40px;
    width: 40px;
    height: 40px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-top: 34px;
  }
`;
