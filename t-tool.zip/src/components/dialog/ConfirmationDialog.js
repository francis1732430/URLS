import {
  LitElement,
  html,
  ScopedElementsMixin,
  IngButton,
  registerDefaultIconsets,
  IngIcon,
} from 'ing-web';

import styles from './ConfirmationDialogStyles.js';

export class ConfirmationDialog extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
    };
  }

  static get properties() {
    return {
      confirmationMessageDetail: Object,
      isNormalConfirmation: { type: Boolean, reflect: true },
      customClasses: { type: String, reflect: true },
    };
  }

  connectedCallback() {
    super.connectedCallback();
    registerDefaultIconsets();
  }

  _closeDialog(type) {
    this.detail = {};
    if (type === 'save') {
      this.detail = {
        detail: {
          confirmationMessageDetail: this.confirmationMessageDetail,
        },
      };
    }
    const closeDialogEvent = new CustomEvent('close-dialog-event', this.detail);
    this.dispatchEvent(closeDialogEvent);
  }

  render() {
    return html`
      <div class="container">
        <div class="message ${this.customClasses || ''}" font14>
          ${this.confirmationMessageDetail?.messages?.map(item => html`<label>${item}</label>`)}
        </div>
        <div mb-20>
          <ing-button
            outline
            indigo
            font14
            class="cancel_button"
            @click="${() => this._closeDialog('cancel')}"
            >${this.isNormalConfirmation ? 'Chiudi' : 'Annulla'}</ing-button
          >
          ${!this.isNormalConfirmation
            ? html`<ing-button
                indigo
                font14
                class="save_button"
                @click="${() => this._closeDialog('save')}"
                >Procedi</ing-button
              >`
            : ''}
        </div>
      </div>
    `;
  }
}
customElements.define('confirmation-dialog', ConfirmationDialog);
