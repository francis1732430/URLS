import { css, font14Mixin } from 'ing-web';

export default css`
  .container {
    display: flex;
    align-items: center;
    flex-direction: column;
    justify-content: center;
  }

  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
  }
  .message {
    width: 80%;
    height: 170px;
    margin-top: 5%;
    display: flex;
    flex-direction: column;
    font-family: INGMe, arial, helvetica, sans-serif;
    -webkit-font-smoothing: antialiased;
    ${font14Mixin()}
    color: rgb(51, 51, 51);
  }
  .mb-20 {
    margin-bottom: 20px;
  }
  .message-bold {
    width: 100%;
    font-weight: bold;
    font-size: 16px;
    height: 5rem;
  }
`;
