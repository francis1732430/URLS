import {
  LitElement,
  html,
  ScopedElementsMixin,
  IngButton,
  IngInput,
  IngForm,
  IngSelect,
  IngInputDatepicker,
} from 'ing-web';

import styles from './DialogModifySectionStyles.js';
import { baseURL, baseURL2, baseURL3, baseURL4 } from '../../utils/constants.js';
import { ajaxInstance } from '../../utils/endpoints.js';
import { transformRowsToFrontEnd } from '../../data/tranformations/rowTransformation.js';
import { transformSectionsToFrontEnd } from '../../data/tranformations/sectionTransformation.js';
import { transformSubSectionsToFrontEnd } from '../../data/tranformations/subSectionsTransformation.js';
import { transformNoteToFrontEnd } from '../../data/tranformations/noteTransformation.js';
import { transformRulesToFrontEnd } from '../../data/tranformations/ruleTransformation.js';
import { transformLookUpDataToFrontEnd } from '../../data/tranformations/documentTranformation.js';
import { RowCreation } from '../document/creation/rowCreation.js';
import { CreateSubSection } from '../document/creation/CreateSubSection.js';
import { NewDocumentCreation } from '../document/creation/NewDocumentCreation.js';
import { RuleCreation } from '../document/creation/Rules/RuleCreation.js';
import { deriveData } from '../../utils/globalApiKeys.js';
import {
  mapPropertyToObjectFromList,
  sortArray,
} from '../../utils/IngFeatTransparencyToolUtils.js';

export class DialogModifySection extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-form': IngForm,
      'ing-input': IngInput,
      'ing-select': IngSelect,
      'ing-input-datepicker': IngInputDatepicker,
      'row-creation': RowCreation,
      'create-sub-section': CreateSubSection,
      'new-document-creation': NewDocumentCreation,
      'rule-creation': RuleCreation,
    };
  }

  static get properties() {
    return {
      selectedRow: { type: Object },
      name: { type: String },
      docId: { type: String },
      sectionId: { type: String },
      subSectionId: { type: String },
      rowId: { type: String },
      ruleId: { type: String },
      noteId: { type: String },
      versionList: Array,
      isSaved: Boolean,
      versionId: String,
      styleList: Array,
      lookupData: Array,
      subSectionMappingList: Array,
      rowsMappingList: Array,
      notesMappingList: Array,
      appliesToElements: Array,
      rulesDdl1: Array,
      docVersionId: String,
      sectionList: Array,
      subSectionList: Array,
      rows: Array,
      notes: Array,
      rules: Array,
      removedIds: Array,
      isVersionChanged: Boolean,
      savedChildList: Array,
      editableActionFields: Object,
      _tempDataCopy: Object,
      parentData: Object,
      docValidityDate: String,
    };
  }

  constructor() {
    super();
    this.ajaxInstance = ajaxInstance;
    this.versionList = [];
    this.dupSelectedRow = {};
    this.versionId = '0';
    this.styleList = [];
    this.lookupData = [];
    this.subSectionMappingList = [];
    this.rowsMappingList = [];
    this.notesMappingList = [];
    this.appliesToElements = [];
    this.rulesDdl1 = [];
    this.sectionList = [];
    this.subSectionList = [];
    this.rows = [];
    this.notes = [];
    this.rules = [];
    this.removedIds = [];
    this.isVersionChanged = false;
    this.getAPIMapper = {
      Regola: 'REGOLA',
      Sezioni: 'SEZIONE',
      Righe: 'RIGA',
      Nota: 'NOTA',
      'Sotto Sezioni': 'SOTTOSEZIONE',
    };
    this.existingChildElementsSubSections = [];
    this.existingChildElementsRows = [];
    this.existingChildElementsNotes = [];
    this.savedChildList = [];
  }

  async firstUpdated(changed) {
    super.firstUpdated(changed);
    try {
      this.dupSelectedRow = { ...this.selectedRow };
      let type = '';
      if (this.name === 'Sotto Sezioni') {
        type = 'Righe';
      }
      const res1 = await this.getVersionItemDetail(this.selectedRow.id, type);
      const tfn = this.getElementTransformFn(this.name);
      this.selectedRow = { ...tfn(res1?.data) };
      this._tempDataCopy = { ...tfn(res1?.data) };
      if (this.name === 'Righe') {
        if (this._tempDataCopy?.columns?.length > 0) {
          // eslint-disable-next-line
          this._tempDataCopy.columns = sortArray(this._tempDataCopy.columns, 'name');
        }
        if (this._tempDataCopy?.columnNotes?.length) {
          const data = await this.makeElementsAjaxCallForExistingElements(
            transformNoteToFrontEnd,
            'Nota',
          );
          this._tempDataCopy.columnNotes.forEach(note => {
            mapPropertyToObjectFromList(data.list, note);
          });
        }
      }
      this.addLinkedElementstoDisabled();
      this.savedChildList = JSON.parse(JSON.stringify([this.selectedRow]));
      this.addLinkedElement(this.name, this.selectedRow);
      this.sectionList = [this.selectedRow];
      this.subSectionList = [this.selectedRow];
      this.rows = [this._tempDataCopy];
      this.notes = [this.selectedRow];
      this.rules = [this.selectedRow];
      setTimeout(async () => {
        if (this.name !== 'Nota') {
          const res = await this.getLookupData();
          this.lookupData = deriveData(res?.data);
          if (this.name !== 'Regola')
            this.styleList = transformLookUpDataToFrontEnd(deriveData(res?.data), 'STILE');
        }
        if (this.name === 'Regola' && this.appliesToElements?.length === 0) {
          const { list: rulesDdl } = await this.makeAjaxCall(this.docVersionId);
          this.rulesDdl1 = [...rulesDdl];
          const lookupList = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE');
          this.appliesToElements = [
            {
              id: '0',
              name: 'Select Element',
            },
            ...lookupList,
          ];
        }
        if (this.selectedRow && this.selectedRow.id) {
          this.getVersionDetails();
        }
        this.selectedRow = { ...this._tempDataCopy };
      }, 1100);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  getLookupData() {
    return ajaxInstance.get(`${baseURL3}`);
  }

  // eslint-disable-next-line class-methods-use-this
  getElementTransformFn(type) {
    switch (type) {
      case 'Sezioni':
        return transformSectionsToFrontEnd;
      case 'Sotto Sezioni':
        return transformSubSectionsToFrontEnd;
      case 'Righe':
        return transformRowsToFrontEnd;
      case 'Nota':
        return transformNoteToFrontEnd;
      case 'Regola':
        return transformRulesToFrontEnd;
      default:
        return null;
    }
  }

  _closeDialog() {
    const closeDialogEvent = new CustomEvent('close-dialog-event', {});
    this.dispatchEvent(closeDialogEvent);
  }

  _save() {
    if (this.name === 'Sezioni' || this.name === 'Sotto Sezioni') {
      this.selectedRow.sectionStyle = this.selectedRow.style;
    }
    this.filterRemovedItems();
    const ev = new CustomEvent('data-received', {
      detail: {
        data: this.selectedRow,
        docId: this.docId,
        newSectionId: this.sectionId,
        newSubSectionId: this.subSectionId,
        newRowId: this.rowId,
        newNoteId: this.noteId,
        newRuleId: this.ruleId,
        sectionId: this.sectionId,
        subSectionId: this.subSectionId,
        rowId: this.rowId,
        ruleId: this.ruleId,
        noteId: this.noteId,
        type: this.name,
        removedIds: [],
        parentData: this.parentData,
      },
    });
    this.dispatchEvent(ev);
    this.dupSelectedRow = { ...this.selectedRow };
  }

  _cancel() {
    this.selectedRow = { ...this.dupSelectedRow };
    const ev = new CustomEvent('cancel-action', {
      detail: {
        data: this.selectedRow,
        type: this.name,
        docId: this.docId,
        newSectionId: this.sectionId,
        newSubSectionId: this.subSectionId,
        newRowId: this.rowId,
        newNoteId: this.noteId,
        newRuleId: this.ruleId,
        sectionId: this.sectionId,
        subSectionId: this.subSectionId,
        rowId: this.rowId,
        ruleId: this.ruleId,
        noteId: this.noteId,
        parentData: this.parentData,
      },
    });
    this.dispatchEvent(ev);
  }

  handleChange(event) {
    if (!event.target.name) return;
    if (event.target.name === 'validity') {
      this.selectedRow[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this.selectedRow[event.target.name] = event.target.value;
      if (event.target.name === 'style') {
        this.selectedRow.styleValue = this.styleList.find(
          item => item.id?.toString() === event.target.value?.toString(),
        )?.name;
      }
    }
  }

  _hydrateSelect(i, d, fieldName, callback) {
    if (!this.selectedRow[fieldName] && i === 0) {
      this.selectedRow[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this.selectedRow[fieldName]?.toString() === d?.id?.toString()) {
      return true;
    }
    return false;
  }

  async getVersionDetails() {
    try {
      if (this.name === 'Sezioni' && this.selectedRow) {
        this.versionList = await this.getVersionsList(this.selectedRow.sectionId);
      } else if (this.name === 'Sotto Sezioni' && this.selectedRow) {
        this.versionList = await this.getVersionsList(this.selectedRow.subSectionId);
      } else if (this.name === 'Righe' && this.selectedRow) {
        this.versionList = await this.getVersionsList(this.selectedRow.rowId);
      } else if (this.name === 'Nota' && this.selectedRow) {
        this.versionList = await this.getVersionsList(this.selectedRow.noteId);
      } else if (this.name === 'Regola' && this.selectedRow) {
        this.versionList = await this.getVersionsList(this.selectedRow.ruleId);
      }
      if (this.versionList.length > 0) {
        setTimeout(() => {
          const data = this.versionList.find(
            item => item?.itemsVersionsID?.toString() === this.selectedRow?.id?.toString(),
          );
          if (data) {
            this.versionId = data.itemsVersionsID?.toString();
          } else {
            this.versionId = this.versionList[0]?.itemsVersionsID?.toString();
          }
        });
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async getVersionsList(id) {
    const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
    return res.data ? deriveData(res.data) : [];
  }

  async changeVersionDetail(event) {
    try {
      const { value } = event.target;
      this.versionId = value;
      if (this.name === 'Sezioni' && value) {
        const res = await this.getVersionItemDetail(value);
        this.selectedRow = transformSectionsToFrontEnd(res?.data);
      } else if (this.name === 'Sotto Sezioni' && value) {
        const res = await this.getVersionItemDetail(value, 'Righe');
        this.selectedRow = transformSubSectionsToFrontEnd(res?.data);
      } else if (this.name === 'Righe' && value) {
        const res = await this.getVersionItemDetail(value);
        this.selectedRow = transformRowsToFrontEnd(res?.data);
      } else if (this.name === 'Nota' && value) {
        const res = await this.getVersionItemDetail(value);
        this.selectedRow = transformNoteToFrontEnd(res?.data);
      } else if (this.name === 'Regola' && value) {
        const res = await this.getVersionItemDetail(value);
        this.selectedRow = transformRulesToFrontEnd(res?.data);
      }
      this.savedChildList = JSON.parse(JSON.stringify([this.selectedRow]));

      this.addLinkedElement(this.name, this.selectedRow);
      if (this.name === 'Righe' && this.selectedRow?.columns?.length > 0) {
        // eslint-disable-next-line
        this.selectedRow.columns = sortArray(this.selectedRow.columns, 'name');
      }
      this.addLinkedElementstoDisabled();
      this.sectionList[0] = this.selectedRow;
      this.subSectionList[0] = this.selectedRow;
      this.rows[0] = this.selectedRow;
      this.notes[0] = this.selectedRow;
      this.rules[0] = this.selectedRow;
      const sectionsList1 = this.sectionList;
      const subSectionList1 = this.subSectionList;
      const rows1 = this.rows;
      const notes1 = this.notes;
      const rules1 = this.rules;

      this.sectionList = [];
      this.subSectionList = [];
      this.rows = [];
      this.notes = [];
      this.rules = [];
      this.isVersionChanged = true;
      setTimeout(() => {
        this.sectionList = [...sectionsList1];
        this.subSectionList = [...subSectionList1];
        this.rows = [...rows1];
        this.notes = [...notes1];
        this.rules = [...rules1];

        this.subSectionMappingList = [...this.subSectionMappingList];
        this.rowsMappingList = [...this.rowsMappingList];
        this.notesMappingList = [...this.notesMappingList];
        this.isVersionChanged = false;
      });
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionItemDetail(id, type) {
    let url = `${baseURL2}/version/${id}`;
    if (this.getAPIMapper[type] === 'RIGA') {
      url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
    }
    const res = await this.ajaxInstance.get(url);
    return res;
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this.selectedRow = { ...this.dupSelectedRow };
  }

  async addLinkedElement(type, data) {
    const data1 = { ...data };
    if (type === 'Sezioni') {
      if (!data1.subSections) {
        data1.subSections = [];
      }
      await this.getChildElementsList(type);
    } else if (type === 'Sotto Sezioni') {
      if (!data1.rows) {
        data1.rows = [];
      }
      await this.getChildElementsList(type);
    } else if (type === 'Righe') {
      if (!data1.columnNotes) {
        data1.columnNotes = [];
      }

      await this.getChildElementsList(type);
    }
  }

  _receiveData() {
    return ev => {
      const { data1, data2 } = ev.detail;
      if (data1 || data2) {
        this.selectedRow = data1 || data2;
        this._save();
      } else {
        this._cancel();
      }
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async makeAjaxCall(id) {
    const url = `${baseURL4}?itemsVersionsID=${id}`;
    let list = [];
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      // eslint-disable-next-line no-unused-vars
      // this.data = list;
      return { list };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list };
    }
  }

  filterRemovedItems() {
    if (this.name === 'Sezioni') {
      const { subSections } = this.selectedRow;
      const dupSubSections = this.dupSelectedRow.subSections;
      if (subSections && dupSubSections && dupSubSections.length && subSections.length) {
        this.selectedRow.subSections = [];
        this.removedIds = dupSubSections
          .filter(item => {
            const index = subSections.findIndex(
              item1 => item?.id?.toString() === item1?.id?.toString(),
            );
            if (index === -1) {
              return true;
              // eslint-disable-next-line
            } else if (index > -1) {
              this.selectedRow.subSections.push(item);
            }
            return false;
          })
          .map(item => item.id);
      } else {
        this.selectedRow.subSections = this.dupSelectedRow.subSections;
      }
      this.sectionList = [this.selectedRow];
    } else if (this.name === 'Sotto Sezioni') {
      const { rows } = this.selectedRow;
      const duprows = this.dupSelectedRow.rows;
      if (rows && duprows && duprows.length && rows.length) {
        this.selectedRow.rows = [];
        this.removedIds = duprows
          .filter(item => {
            const index = rows.findIndex(item1 => item?.id?.toString() === item1?.id?.toString());
            if (index === -1) {
              return true;
              // eslint-disable-next-line
            } else if (index > -1) {
              this.selectedRow.rows.push(item);
            }
            return false;
          })
          .map(item => item.id);
      } else {
        this.selectedRow.rows = this.dupSelectedRow.rows;
      }
      this.subSectionList = [this.selectedRow];
    } else if (this.name === 'Righe') {
      const notes = this.selectedRow.columnNotes;
      const dupnotes = this.dupSelectedRow.notes;
      if (notes && dupnotes && dupnotes.length && notes.length) {
        this.selectedRow.notes = [];
        this.removedIds = dupnotes
          .filter(item => {
            const index = notes.findIndex(item1 => item?.id?.toString() === item1?.id?.toString());
            if (index === -1) {
              return true;
              // eslint-disable-next-line
            } else if (index > -1) {
              this.selectedRow.notes.push(item);
            }
            return false;
          })
          .map(item => item.id);
      } else {
        this.selectedRow.notes = this.dupSelectedRow.notes;
      }
      this.rows = [this.selectedRow];
    }
  }

  _showStatusEvent(event) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data: event.detail.data,
        type: event.detail.type,
        elementType: event.detail.elementType,
      },
    });
    this.dispatchEvent(ev);
  }

  _fieldsChanged(ev) {
    const { detail } = ev;
    const evt = new CustomEvent('fields-changed', {
      detail,
    });
    this.dispatchEvent(evt);
  }

  _previewRule(e) {
    const ev = new CustomEvent('preview-rule', {
      detail: e.detail,
    });
    this.dispatchEvent(ev);
  }

  loadCreatForm() {
    switch (this.name) {
      case 'Sezioni':
        return this.selectedRow && this.selectedRow.id
          ? html`<create-sub-section
              currentStep="section"
              .subSectionsData="${this.sectionList}"
              .subSectionsList="${this.subSectionMappingList}"
              .lookupData="${this.lookupData}"
              .savedChildList="${this.savedChildList}"
              ?isExistingDocument=${true}
              ?isModifiedDocument=${true}
              ?isVersionChanged=${this.isVersionChanged}
              @event-section-added="${this._receiveData('Sezioni')}"
              @event-section-removed="${this._receiveData('Sezioni')}"
              @field-values-changed=${this._fieldsChanged}
              @show-status-dialog="${this._showStatusEvent}"
            ></create-sub-section>`
          : '';
      case 'Sotto Sezioni':
        return this.selectedRow && this.selectedRow.id
          ? html`<create-sub-section
              currentStep="subsection"
              .rows="${this.rowsMappingList}"
              .subSectionsData="${this.subSectionList}"
              .savedChildList="${this.savedChildList}"
              ?isExistingDocument=${true}
              ?isModifiedDocument=${true}
              ?isVersionChanged=${this.isVersionChanged}
              .lookupData="${this.lookupData}"
              @event-section-added="${this._receiveData('Sotto Sezioni')}"
              @event-section-removed="${this._receiveData('Sotto Sezioni')}"
              @field-values-changed=${this._fieldsChanged}
              @show-status-dialog="${this._showStatusEvent}"
            ></create-sub-section>`
          : '';
      case 'Righe':
        return this.selectedRow &&
          this.selectedRow.id &&
          this.rows.length &&
          this.notesMappingList.length &&
          this.lookupData.length
          ? html`<row-creation
              .rowData="${this.rows}"
              .notes="${this.notesMappingList}"
              .savedChildList="${this.savedChildList}"
              ?isExistingDocument=${true}
              ?isModifiedDocument=${true}
              .lookupData="${this.lookupData}"
              @rows-changed="${this._receiveData('Righe')}"
              @field-values-changed=${this._fieldsChanged}
              @row_column_changed="${this._rowColumnChanged}"
              @show-status-dialog="${this._showStatusEvent}"
            ></row-creation>`
          : '';
      case 'Nota':
        return this.selectedRow && this.selectedRow.id
          ? html`<new-document-creation
              ?isExistingDocument=${true}
              ?isModifiedDocument=${true}
              .notesData="${this.notes}"
              @notes-changed="${this._receiveData('Nota')}"
              @field-values-changed=${this._fieldsChanged}
              @show-status-dialog="${this._showStatusEvent}"
            ></new-document-creation>`
          : '';
      case 'Regola':
        return this.selectedRow && this.selectedRow.id
          ? html`<rule-creation
              ?isExistingDocument=${true}
              ?isModifiedDocument=${true}
              .docId="${this.docVersionId}"
              .appliesToElements="${this.appliesToElements}"
              .rulesDdl1="${this.rulesDdl1}"
              .lookupData="${this.lookupData}"
              .rowData="${this.rules}"
              .savedChildList="${this.savedChildList}"
              .docItemId=${this.docId}
              .docValidityDate=${this.docValidityDate}
              @rows-changed="${this._receiveData('Regola')}"
              @field-values-changed=${this._fieldsChanged}
              @row_column_changed="${this._ruleColumnChanged}"
              @show-status-dialog="${this._showStatusEvent}"
              @preview-rule=${this._previewRule}
            ></rule-creation>`
          : '';
      default:
        return '';
    }
  }

  async getChildElementsList(tabName) {
    if (tabName === 'Sezioni') {
      const data =
        this.existingChildElementsSubSections?.length > 0
          ? { list: this.existingChildElementsSubSections }
          : await this.makeElementsAjaxCallForExistingElements(
              transformSubSectionsToFrontEnd,
              'Sotto Sezioni',
            );
      this.existingChildElementsSubSections = data.list;
      if (this.selectedRow?.subSections) {
        this.selectedRow.subSections = this.selectedRow.subSections?.map(childItem => {
          const a = { ...childItem };
          a.parentId = this.selectedRow.id;
          return a;
        });
      }
      this.subSectionMappingList = data.list;
    } else if (tabName === 'Sotto Sezioni') {
      const data =
        this.existingChildElementsRows?.length > 0
          ? { list: this.existingChildElementsRows }
          : await this.makeElementsAjaxCallForExistingElements(transformRowsToFrontEnd, 'Righe');
      this.existingChildElementsRows = data.list;
      if (this.selectedRow?.rows) {
        this.selectedRow.rows = this.selectedRow.rows?.map(childItem => {
          const a = { ...childItem };
          a.parentId = this.selectedRow.id;
          return a;
        });
      }
      this.rowsMappingList = data.list;
      // this.rowsMappingList = this.selectedRow?.rows ? this.getExistingFilterList(data.list, this.selectedRow?.rows, 'rows') : data.list;
    } else if (tabName === 'Righe') {
      const data =
        this.existingChildElementsNotes?.length > 0
          ? { list: this.existingChildElementsNotes }
          : await this.makeElementsAjaxCallForExistingElements(transformNoteToFrontEnd, 'Nota');

      data.list = this.bindNotesVersionLevelsIds(this.selectedRow, data.list);
      this.existingChildElementsNotes = data.list;
      if (this.selectedRow?.columnNotes) {
        this.selectedRow.columnNotes = this.selectedRow?.columnNotes?.map(childItem => {
          const a = { ...childItem };
          return a;
        });
      }
      if (this.selectedRow?.columns) {
        this.selectedRow.columns = this.selectedRow?.columns?.map(childItem => {
          const a = { ...childItem };
          return a;
        });
      }
      this.notesMappingList = data.list;
      this.notesMappingList = [...this.notesMappingList];
    }
  }

  // eslint-disable-next-line
  bindNotesVersionLevelsIds(data1, notesList1) {
    if (!notesList1?.length) {
      // eslint-disable-next-line
      notesList1 = [];
    }
    const notesList = [...notesList1];
    if (data1?.columnNotes && data1?.columnNotes?.length > 0 && notesList?.length > 0) {
      // eslint-disable-next-line
      data1.columnNotes =
        data1?.columnNotes?.map(item1 => {
          const index = notesList.findIndex(
            item2 => item1?.id?.toString() === item2?.id?.toString(),
          );
          if (index > -1) {
            // notesList[index].versionDetailLevel1ID = item1?.versionDetailLevel1ID;
            // notesList[index].versionDetailLevel2ID = item1?.versionDetailLevel2ID;
            // eslint-disable-next-line
            item1.name = notesList[index]?.name;
          }
          return item1;
        }) || [];
    }
    return notesList;
  }

  // eslint-disable-next-line class-methods-use-this
  getExistingFilterList(list, children) {
    return list.filter(item => {
      const index = children.findIndex(item1 => item1?.id?.toString() === item?.id?.toString());
      if (index === -1) {
        return true;
      }
      return false;
    });
  }

  // eslint-disable-next-line class-methods-use-this
  async makeElementsAjaxCallForExistingElements(transformFn, elementName) {
    let url;
    if (this.getAPIMapper[elementName] === 'REGOLA') {
      url = `${baseURL}s?itemTypeKey=RULE_TYPE&itemTypeValue=${this.getAPIMapper[elementName]}`;
    } else {
      url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[elementName]}`;
    }
    // eslint-disable-next-line no-console
    // totalRes = {}
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      list = list.map(d => transformFn(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  _rowColumnChanged(event) {
    const { data } = event.detail;
    this.rows = [...data];
    this.savedChildList = [...this.rows];
  }

  _ruleColumnChanged(event) {
    const { data, index1 } = event.detail;
    const ruleData1 = JSON.parse(JSON.stringify(data));
    const actions = ruleData1[index1]?.actions;
    ruleData1[index1].actions = [];
    this.rules = [...ruleData1];
    setTimeout(() => {
      ruleData1[index1].actions = actions;
      this.rules = [...ruleData1];
    });
  }

  // eslint-disable-next-line
  getSectionName(tabName) {
    if (tabName?.toLowerCase() === 'righe') {
      return 'Riga';
      // eslint-disable-next-line
    } else if (tabName?.toLowerCase() === 'sotto sezioni') {
      return 'Sotto Sezione';
      // eslint-disable-next-line
    } else if (tabName?.toLowerCase() === 'sezioni') {
      return 'Sezione';
      // eslint-disable-next-line
    } else {
      return tabName;
    }
  }

  addLinkedElementstoDisabled() {
    if (
      (this.name === 'Sezioni' && this.editableActionFields?.sectionView) ||
      (this.name === 'Sotto Sezioni' && this.editableActionFields?.subSectionView) ||
      (this.name === 'Nota' && this.editableActionFields?.noteView) ||
      (this.name === 'Regola' && this.editableActionFields?.ruleView)
    ) {
      this.selectedRow.linkedElement = true;
    } else if (this.name === 'Righe' && this.editableActionFields?.rowView) {
      this.selectedRow.linkedElement = true;
      if (!this.selectedRow.columnNotes) {
        this.selectedRow.columnNotes = [];
      }
      this.selectedRow.columnNotes = this.selectedRow.columnNotes.map(note => {
        const a = { ...note };
        a.linkedElement = true;
        return a;
      });
    }
  }

  render() {
    return html`
      <div class="dialog_container">
        <div class="document_details_label ${this.name === 'Regola' ? 'ml-80' : ''}">
          <label class="document_details_text">Modifica ${this.getSectionName(this.name)}</label>
        </div>

        <div class="document_details_content">
          <ing-form>
            <form>
              <div>
                <div class="text_container ${this.name === 'Regola' ? 'ml-8' : ''}">
                  <label class="version_text">Versione</label>
                </div>
                <div>
                  <ing-select
                    class="dialog_document_style ${this.name === 'Regola' ? 'ml-19' : ''}"
                    name="version"
                    inputElement
                    .modelValue="${this.versionId}"
                    @change="${this.changeVersionDetail}"
                  >
                    <select slot="input">
                      ${this.versionList.map(
                        item =>
                          html` <option value="${item.itemsVersionsID}">
                            ${item.versionNumber}
                          </option>`,
                      )}
                    </select>
                  </ing-select>
                </div>
                ${this.loadCreatForm()}
              </div>
            </form>
          </ing-form>
        </div>
      </div>
    `;
  }
}
customElements.define('dialog-modify-section', DialogModifySection);
