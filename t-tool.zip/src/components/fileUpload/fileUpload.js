import { html, LitElement, ScopedElementsMixin, IngButton } from 'ing-web';
import pageStyles from './fileUploadStyles.js';

export class FileUpload extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
    };
  }

  static get properties() {
    return {
      _files: { type: Array },
      dragOverClass: { type: String },
      disableFile: { type: Boolean, reflect: true },
    };
  }

  static get styles() {
    return pageStyles;
  }

  constructor() {
    super();
    this._files = [];
    this.dragOverClass = '';
    this.disableFile = false;
  }

  _onUpload(files) {
    this._files = [...files];
    const event = new CustomEvent('files-added', {
      detail: this._files,
    });
    this.dispatchEvent(event);
  }

  _onDrop(event) {
    event.preventDefault();
    this.dragOverClass = '';
    this._onUpload(event.dataTransfer.files);
  }

  _allowDrop(event) {
    event.preventDefault();
    this.dragOverClass = 'dragged-over';
  }

  _dragLeave(event) {
    event.preventDefault();
    this.dragOverClass = '';
  }

  _change(event) {
    this._onUpload(event.target.files);
    // Below line used for user able to upload same file again
    // eslint-disable-next-line
    event.target.value = '';
  }

  render() {
    return html`
      <label for="file-upload-input">
        <input
          hidden
          id="file-upload-input"
          type="file"
          multiple
          @change="${this._change}"
          ?disabled="${this.disableFile}"
        />
        <div
          @dragleave="${this._dragLeave}"
          @drop="${this._onDrop}"
          @dragover="${this._allowDrop}"
          class="file-upload-drag-drop ${this.dragOverClass}"
        >
          <p>Drag & drop your files here OR</p>
          <ing-button file-pick-button ?disabled="${this.disableFile}">Select Files</ing-button>
        </div>
      </label>
    `;
  }
}

customElements.define('file-upload', FileUpload);
