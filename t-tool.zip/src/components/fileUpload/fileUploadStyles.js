import { css, black34, indigo, font24Mixin } from 'ing-web';

export default css`
  .file-upload-drag-drop {
    padding: 3.5rem;
    text-align: center;
    display: inline-block;
    ${font24Mixin()}
    border: 4px dotted ${black34};
    width: 55%;
    margin: 15px 0;
    transition: border 0.5s ease-in-out;
  }
  [file-pick-button] {
    background-color: transparent;
    border: 1px solid ${indigo};
    color: ${indigo};
  }
  .dragged-over {
    border: 4px dotted ${indigo};
  }
`;
