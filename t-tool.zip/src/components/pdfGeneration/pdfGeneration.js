import { html, LitElement, ScopedElementsMixin, IngButton, unsafeHTML } from 'ing-web';
import pageStyles from './pdfGenerationStyles.js';

export class PdfGeneration extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
    };
  }

  static get properties() {
    return {
      generationData: { type: Array },
      _layoutClassMapper: { type: String },
      _notes: Object,
    };
  }

  static get styles() {
    return pageStyles;
  }

  constructor() {
    super();
    this._layoutClassMapper = {
      4: 'row_4',
      '3_1': 'row_3_1',
      '1_3': 'row_1_3',
      '2_2': 'row_2_2',
      '1_1_2': 'row_1_1_2',
      '2_1_1': 'row_2_1_1',
      '1_1_1_1': 'row_1_1_1_1',
      banner: 'banner',
      intestazione: 'subsection-center',
      'intestazione-dettaglio': 'row-center',
      'section title': 'section-highlighted',
      subtitle: 'row-highlighted',
      DEFAULT: 'row-default',
      legend: 'legend',
      'no-border': 'no-border',
      section_group_header: 'section_group_header',
      'document-title': 'document-title',
    };
    this._notes = [];
    this._notePositionsMapper = {};
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('generationData') && this.generationData?.document && !this._notes?.length) {
      const sections = this.generationData?.document?.sections || [];
      this._notes =
        sections?.[sections?.length - 1]?.subSections?.find(d => d.name === '$__NOTE__$')?.notes ||
        [];
      this._notes?.forEach(d => {
        this._notePositionsMapper[d.id] = d.position;
      });
      if (this.generationData?.product === 'CCA' && this.generationData?.type === 'DDS') {
        this._documentType = 'orange_document';
      } else if (this.generationData?.product === 'CCA' && this.generationData?.type === 'SOF') {
        this._documentType = 'gray_document';
      } else if (this.generationData?.product === 'CCA' && this.generationData?.type === 'EC') {
        this._documentType = 'gray_orange_document';
      } else {
        this._documentType = 'orange_document';
      }
    }
  }

  getColumnBlockClass(row) {
    let className = '';
    if (this._layoutClassMapper[row.layout] !== this._layoutClassMapper[4]) {
      className = `${className} column-border`;
    }
    if (row?.style?.toLowerCase() === 'bold') {
      className = `${className} row-bold`;
    }
    if (
      this._layoutClassMapper[row.layout] === 'no-border' &&
      this._documentType === 'orange_document'
    ) {
      className = `${className} text-left`;
    }
    if (this._layoutClassMapper[row.layout] === this._layoutClassMapper[4]) {
      className = `${className} orange-text-left`;
    }
    return className;
  }

  // eslint-disable-next-line
  setBreakElements(text) {
    if (typeof text === 'string') {
      return text
        ?.replace(/\\n|\n/g, '<br/>')
        ?.replace(/<style size=(\d+)>/g, "<span style='font-size: $1px;'>")
        .replace(/<\/style>/g, '</span>');
    }
    return text;
  }

  makeRowsAndColumns(section, subsection, i) {
    return html`<div class="subsection-wrapper ${i === 0 ? 'mt-8' : ''}">
      ${this._documentType !== 'gray_document'
        ? html`<div
            class="subsection-tile ${this._layoutClassMapper[subsection.layout] ||
            'section-highlighted'}"
          >
            ${html`${unsafeHTML(this.setBreakElements(subsection.name))}`}
          </div>`
        : ''}
      ${subsection?.entries?.map((row, j) =>
        this._layoutClassMapper[row.layout] === 'no-border' &&
        this._documentType === 'gray_document'
          ? html`<div class="no-border-layout"></div>`
          : html`<div
              class="rows-wrapper row-border ${this._layoutClassMapper[row.layout] ||
              'row-default'} ${section?.subSections?.length === i + 1 &&
              subsection?.entries?.length === j + 1
                ? 'bb-1'
                : ''}"
            >
              ${row.column1Id
                ? html`<div class="column-block ${this.getColumnBlockClass(row)}">
                    ${html`${unsafeHTML(this.setBreakElements(row.column1))}`}
                  </div>`
                : ''}
              ${row.column2Id
                ? html`<div class="column-block ${this.getColumnBlockClass(row)}">
                    ${html`${unsafeHTML(this.setBreakElements(row.column2))}`}
                  </div>`
                : ''}
              ${row.column3Id
                ? html`<div class="column-block ${this.getColumnBlockClass(row)}">
                    ${html`${unsafeHTML(this.setBreakElements(row.column3))}`}
                  </div>`
                : ''}
              ${row.column4Id
                ? html`<div class="column-block ${this.getColumnBlockClass(row)}">
                    ${html`${unsafeHTML(this.setBreakElements(row.column4))}`}
                  </div>`
                : ''}
            </div>`,
      )}
    </div>`;
  }

  render() {
    return html`
      <div class="pdf-wrapper ${this._documentType}">
        ${this.generationData?.document?.sections?.map(
          section =>
            html`
              <div class="section-wrapper section-container">
                <div class="section-tile ${this._layoutClassMapper[section.layout] || 'banner'}">
                  ${html`${unsafeHTML(this.setBreakElements(section.description))}`}
                </div>
                ${section?.subSections?.map((subsection, i) =>
                  subsection.name === '$__NOTE__$'
                    ? subsection.notes.map(
                        note =>
                          html`<div class="${this._layoutClassMapper[subsection.layout]}">
                            ${unsafeHTML(this.setBreakElements(note.column1))}
                          </div>`,
                      )
                    : this.makeRowsAndColumns(section, subsection, i),
                )}
              </div>
            `,
        )}
      </div>
    `;
  }
}

customElements.define('pdf-generation', PdfGeneration);
