import { css, orange, white, black80, black34 } from 'ing-web';

export default css`
  .pdf-wrapper {
    padding: 20px 140px;
    font-family: system-ui, system-ui, sans-serif;
  }
  .orange_document .rows-wrapper {
    border-bottom: 1px solid gray;
  }
  .orange_document .row_4 {
    display: grid;
    grid-template-columns: 1fr;
  }
  .orange_document .row_3_1 {
    display: grid;
    grid-template-columns: 3fr 1fr;
  }
  .orange_document .row_1_3 {
    display: grid;
    grid-template-columns: 1fr 3fr;
  }
  .orange_document .row_2_2 {
    display: grid;
    grid-template-columns: 2fr 2fr;
  }
  .orange_document .row_1_1_2 {
    display: grid;
    grid-template-columns: 1fr 1fr 2fr;
  }
  .orange_document .row_2_1_1 {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
  }
  .orange_document .row_1_1_1_1 {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
  }
  .orange_document .banner {
    font-size: 36px;
    text-align: center;
    background-color: ${orange};
    color: ${white};
    border-radius: 18px;
    margin: 5px 0 10px 0;
  }
  .orange_document .subsection-center {
    font-size: 16px;
    text-align: center;
    color: ${orange};
    margin: 5px 0 2px 0;
  }
  .orange_document .row-center {
    font-size: 16px;
    text-align: center;
    color: ${orange};
    margin: 5px 0 2px 0;
  }
  .orange_document .section-highlighted {
    font-size: 16px;
    background-color: ${orange};
    color: ${white};
    border-radius: 18px;
    margin: 5px 0px 10px;
    padding: 3px 10px;
  }
  .orange_document .row-highlighted {
    font-size: 16px;
    color: ${orange};
    margin: 0px 0px 2px;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
  }
  .orange_document
    .section-wrapper
    .rows-wrapper:not(.row-center):not(.row-highlighted)
    .column-block:last-child {
    text-align: right;
    padding-right: 10px;
  }
  .orange_document .section-wrapper .rows-wrapper.row-center {
    border: 0;
  }
  .orange_document .column-block {
    padding: 2px 6px;
    font-size: 14px;
  }
  .orange_document .legend {
    font-size: 12px;
    color: #948e8e;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
    font-family: 'ING Me';
  }
  .orange_document .no-border {
    border-bottom: 0;
  }
  .orange_document .section_group_header {
    font-size: 16px;
    color: ${black80};
    margin: 0px 0px 10px;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
    text-decoration: underline;
  }
  .orange_document .document-title {
    font-size: 36px;
    color: ${orange};
    margin: 0px 0px 10px;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
    border-bottom: 1px solid ${orange};
    text-align: center;
  }
  .orange_document .text-left {
    text-align: left !important;
  }
  .orange_document .orange-text-left {
    text-align: left !important;
  }
  .orange_document .rows-wrapper:not(.row-center):not(.row-highlighted) .column-block:only-child {
    text-align: left !important;
  }
  .gray_orange_document .section-tile {
    background-color: lightgray;
    color: rgb(77, 77, 77);
    height: 25px;
    padding: 6px 5px 15px;
    margin: 20px 0px;
    position: relative;
    font-size: 24px;
  }
  .gray_orange_document .section-tile::before {
    content: '';
    border-color: lightgray;
    position: absolute;
    border-bottom-color: transparent;
    top: 44px;
    left: 30px;
    border-top: 16px solid lightgray;
    border-left: 16px solid transparent;
    border-right: 16px solid transparent;
  }
  .gray_orange_document .subsection-tile {
    font-size: 16px;
    color: #4d4d4d;
  }
  .gray_orange_document .subsection-tile {
    font-size: 18px;
    color: rgb(77, 77, 77);
    margin: 10px 0px;
  }
  .gray_orange_document .rows-wrapper:not(.row-highlighted) .column-block {
    color: rgb(77, 77, 77);
    position: relative;
    padding: 0px 0px 0px 15px;
    font-size: 14px;
    margin: 2px;
  }
  .gray_orange_document .rows-wrapper:not(.row-highlighted) .column-block::before {
    content: '';
    position: absolute;
    left: 2px;
    top: 7px;
    border: 3px solid ${orange};
    display: inline-block;
  }
  .gray_orange_document .row-highlighted .column-block {
    font-size: 16px;
    color: ${orange};
    margin: 10px 0px;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
  }
  .gray_document .section-container {
    border: 2px solid ${black34};
    width: 80%;
    margin: auto;
    padding: 0px;
  }
  .gray_document .banner {
    background-color: ${black34};
    color: ${black80};
    padding-left: 5px;
    font-family: 'ING Me';
    font-size: 16px;
    padding-left: 5px;
    font-weight: bold;
    padding-top: 3px;
    padding-bottom: 3px;
  }
  .gray_document .row_4 {
    display: grid;
    grid-template-columns: 1fr;
  }
  .gray_document .row_3_1 {
    display: grid;
    grid-template-columns: 3fr 1fr;
  }
  .gray_document .row_1_3 {
    display: grid;
    grid-template-columns: 1fr 3fr;
  }
  .gray_document .row_2_2 {
    display: grid;
    grid-template-columns: 2fr 2fr;
  }
  .gray_document .row_1_1_2 {
    display: grid;
    grid-template-columns: 1fr 1fr 2fr;
  }
  .gray_document .row_2_1_1 {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
  }
  .gray_document .row_1_1_1_1 {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr 1fr;
  }
  .gray_document .row-border {
    border: 2px solid ${black34};
    border-bottom: none;
  }
  .gray_document .row-border {
    border: 2px solid ${black34};
    border-bottom: none;
  }
  .gray_document .column-border:not(:last-child) {
    border-right: 2px solid ${black34};
    margin-left: 5px;
  }
  .gray_document .column-border {
    margin-left: 5px;
  }
  .gray_document .subsection-wrapper {
    margin-right: 8px;
    margin-left: 8px;
  }
  .gray_document .mt-8 {
    margin-top: 8px;
  }
  .gray_document .subsection-wrapper:last-child {
    margin-bottom: 8px;
  }
  .gray_document .row-highlighted {
    font-size: 16px;
    color: ${black80};
    font-weight: bold;
    padding: 0px 0px 2px 0px;
    font-family: 'ING Me';
  }
  .gray_document .column-block {
    padding: 2px 6px;
    font-size: 14px;
    font-family: 'ING Me';
  }
  .gray_document .legend {
    font-size: 12px;
    color: lightgray;
    font-weight: bold;
    padding: 0px 0px 2px 0px;
    font-family: 'ING Me';
  }
  .gray_document .no-border {
    border: none;
  }
  .gray_document .no-border-layout {
    display: block;
    padding: 10px;
    border-top: 2px solid ${black34};
  }
  .gray_document .bb-1 {
    border-bottom: 2px solid ${black34} !important;
  }
  .gray_document .row-bold {
    font-weight: bold;
    font-family: 'ING Me';
    font-size: 15px;
  }
`;
