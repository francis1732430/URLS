import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngSteps,
  IngStep,
  IngStepsIndicator,
  IngButton,
  IngIcon,
} from 'ing-web';

import styles from './stepperStyles.js';

export class Stepper extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-steps': IngSteps,
      'ing-step': IngStep,
      'ing-steps-indicator': IngStepsIndicator,
      'ing-button': IngButton,
      'ing-icon': IngIcon,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      stepIndex: { type: Number },
      stepIndexMax: { type: Boolean },
      disableBackButtons: { type: Boolean, reflect: true },
    };
  }

  constructor() {
    super();
    this._stepIndex = 0;
  }

  _previous() {
    const stepsName = this.getScopedTagName('ing-steps');
    const stepElement = this.shadowRoot.querySelector(stepsName);
    if (stepElement.__current > 0) stepElement.previous();
    this.stepIndex = stepElement.__current;
    this.stepIndexMax = false;
    this.changedStepIndex();
  }

  _next() {
    const stepsName = this.getScopedTagName('ing-steps');
    const stepElement = this.shadowRoot.querySelector(stepsName);
    if (stepElement.__current < stepElement._max) stepElement.next();
    if (stepElement.__current === stepElement._max) this.stepIndexMax = true;
    this.stepIndex = stepElement.__current;
    this.changedStepIndex();
  }

  set stepIndex(val) {
    const oldVal = this._stepIndex;
    this._stepIndex = Math.floor(val);
    this.requestUpdate('stepIndex', oldVal);
  }

  get stepIndex() {
    return this._stepIndex;
  }

  changedStepIndex() {
    const e = new CustomEvent('changed-step-index', {
      detail: {
        data: this._stepIndex,
      },
    });
    this.dispatchEvent(e);
  }

  firstUpdated() {
    setTimeout(() => {
      const stepsName = this.getScopedTagName('ing-steps');
      const stepElement = this.shadowRoot.querySelector(stepsName);
      stepElement.current = this._stepIndex;
    });
  }

  render() {
    return html`
      <div class="stepper-wrapper">
        <ing-steps>
          <ing-steps-indicator slot="indicator"></ing-steps-indicator>

          <ing-step initial-step label="NOTE">
            <slot name="step-1"></slot>
            <div class="ing_standard_bottom_line"></div>
          </ing-step>
          <ing-step label="RIGHE">
            <slot name="step-2"></slot>

            <div class="ing_standard_bottom_line"></div>
          </ing-step>
          <ing-step label="SOTTO SEZIONI">
            <slot name="step-3"></slot>

            <div class="ing_standard_bottom_line"></div>
          </ing-step>
          <ing-step label="SEZIONI">
            <slot name="step-4"></slot>
            <div class="ing_standard_bottom_line"></div>
          </ing-step>
          <ing-step label="REGOLE">
            <slot name="step-5"></slot>
            <div class="ing_standard_bottom_line"></div>
          </ing-step>
          <ing-step label="DOCUMENTO">
            <slot name="step-6"></slot>

            <div class="ing_standard_bottom_line"></div>
          </ing-step>
        </ing-steps>
      </div>
      <div class="stepper-buttons">
        <div class="stepper-btn-wrapper">
          <ing-button
            ?disabled="${!this.stepIndex || this.disableBackButtons}"
            @click=${this._previous}
            class="stepper-button pre"
            text
            icon-only
            orange
            icon20
            slot="invoker"
            aria-label="stpper-button"
          >
            <ing-icon class="stepper-icons" icon-id="ing:solid-arrows:arrowCircleLeft"></ing-icon>
          </ing-button>
          <div class="stepper-text">Precedente</div>
        </div>
        <div class="stepper-btn-wrapper">
          <ing-button
            ?disabled="${this.stepIndexMax}"
            @click=${this._next}
            class="stepper-button next"
            text
            icon-only
            orange
            icon20
            slot="invoker"
            aria-label="stpper-button"
          >
            <ing-icon class="stepper-icons" icon-id="ing:solid-arrows:arrowCircleRight"></ing-icon>
          </ing-button>
          <div class="stepper-text">Successivo</div>
        </div>
      </div>
    `;
  }
}
customElements.define('stepper-custom', Stepper);
