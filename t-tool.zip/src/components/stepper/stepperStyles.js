import { css, orange, black15 } from 'ing-web';

export default css`
  .ing_standard_bottom_line {
    border-bottom: 4px solid ${orange};
  }

  .view_button::before {
    margin: 0 0 1.5em 0;
    min-height: 32px;
    width: 86px;
    display: inline-block;
  }

  .view_button {
    width: 86px;
    height: 32px;
    display: inline-block;
  }

  .stepsClass {
    display: inline-block;
  }
  .stepper-button {
    cursor: pointer;
  }
  .stepper-button:first-child {
    margin-left: 2.5rem;
  }
  .stepper-button:hover {
    background: transparent;
    border: 0;
  }
  .stepper-button:focus {
    box-shadow: none;
    border: 0;
  }
  .stepper-icons {
    width: 2rem;
    height: 2rem;
    margin: 0 0 0 1rem;
  }
  .stepper-btn-wrapper {
    display: inline-block;
    text-align: center;
    margin: 5px 0;
  }
  .stepper-text {
    position: relative;
    left: 2rem;
  }
  .stepper-buttons {
    display: block;
    position: absolute;
    border-left: 1px solid ${black15};
    top: 3rem;
    right: 0px;
    width: 17rem;
  }
  .stepper-wrapper {
    display: inline-block;
    vertical-align: top;
    width: 100%;
  }
`;
