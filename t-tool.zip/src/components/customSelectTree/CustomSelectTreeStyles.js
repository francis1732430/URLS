import { css, font16Mixin, black34 } from 'ing-web';

export default css`
  .container-fluid {
    position: relative;
    /* overflow: auto;
    height: 14rem; */
    margin-top: 1.5rem;
    width: 40rem;
    display: inline-block;
    vertical-align: top;
    margin-right: 10px;
  }
  .multiselect {
    max-width: 100%;
  }
  .selectBox {
    position: relative;
  }

  .selectBox select {
    width: 100%;
    border: 1px solid rgb(105, 105, 105);
    height: 40px;
  }

  .overSelect {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }

  #mySelectOptions {
    display: none;
    border: 0.5px #7c7c7c solid;
    background-color: #ffffff;
    max-height: 150px;
    overflow-y: scroll;
    position: absolute;
    z-index: 1;
    width: 100%;
    ${font16Mixin()}
  }

  #mySelectOptions label {
    display: block;
    font-weight: normal;
    display: block;
    white-space: nowrap;
    min-height: 1.2em;
    background-color: #ffffff00;
    padding: 0 2.25rem 0 0.75rem;
    display: flex;
    align-items: center;
  }
  input[type='checkbox'] {
    -ms-transform: scale(1.2); /* IE */
    -moz-transform: scale(1.2); /* FF */
    -webkit-transform: scale(1.2); /* Safari and Chrome */
    -o-transform: scale(1.2); /* Opera */
    padding: 10px;
    margin-right: 7px;
  }

  select option {
    ${font16Mixin()}
  }

  #mySelectOptions label:hover {
    background-color: #1e90ff;
  }

  .pointer-events {
    pointer-events: none;
  }

  .form-select {
    display: block;
    width: 100%;
    padding: 0.375rem 2.25rem 0.375rem 0.75rem;
    -moz-padding-start: calc(0.75rem - 3px);
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-size: 16px 12px;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
  }
  .d-flex {
    display: flex;
    position: relative;
    /* border-bottom: 1px solid ${black34}; */
  }
  .d-flex [data-tag-name='ing-checkbox'] {
    vertical-align: middle;
    display: inline-block;
    height: 20px;
    position: relative;
    top: 0;
  }
  .d-flex [data-tag-name='ing-collapsible'] {
    display: inline-block;
    width: 100%;
    overflow: visible;
  }
  .d-flex [data-tag-name='ing-collapsible-invoker'] {
    border: unset;
    padding-left: 0;
    margin: 5px 0;
  }
  .d-inline-block {
    align-self: center;
    width: 100%;
    display: inline-flex;
    min-height: 2rem;
    padding-top: 8px;
  }
  .border-bottom {
    display: block;
    width: 100%;
    border-bottom: 1px solid ${black34};
    position: absolute;
    left: 0;
  }
  .icons-set {
    display: inline-block;
    position: absolute;
    justify-content: space-around;
    width: 8rem;
    align-items: center;
    height: 2rem;
    overflow: visible;
    right: 0px;
  }
  .demo-tooltip-invoker {
    position: absolute;
    margin: 0px;
    z-index: 10;
  }
  [data-tag-name='ing-icon'] {
    position: relative;
  }
  [data-tag-name='ing-tooltip'] {
    right: 0px;
    height: 10px;
    z-index: 10;
    position: relative;
    overflow: visible;
    width: 1rem;
    vertical-align: middle;
    float: right;
    padding-right: 15px;
  }
  [slot='content'] {
    overflow: visible !important;
  }
  [data-tag-name='ing-collapsible'] [slot='content'] {
    max-height: unset !important;
  }
  [data-tag-name='ing-tooltip'] [slot='content'] {
    width: 7rem;
    text-align: center;
  }
`;
