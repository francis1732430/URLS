import {
  LitElement,
  html,
  ScopedElementsMixin,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngIcon,
  IngCheckbox,
  IngTooltip,
  IngButton,
} from 'ing-web';

import styles from './CustomSelectTreeStyles.js';

export class CustomSelectTree extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      selectedTexts: String,
      selectedOptions: Array,
      displayData: Array,
      propKey: String,
      columnId: String,
      removeColumnNoteId: String,
      linkedElement: Boolean,
      selectedIds: Array,
      isHirarchy: {
        type: Boolean,
        reflect: true,
      },
      isControlled: {
        type: Boolean,
        reflect: true,
      },
    };
  }

  static get scopedElements() {
    return {
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-checkbox': IngCheckbox,
      'ing-icon': IngIcon,
      'ing-tooltip': IngTooltip,
      'ing-button': IngButton,
    };
  }

  constructor() {
    super();

    this.selectedTexts = '';
    this.propKey = '';
    this.selectedOptions = [];
    this.displayData = [];
    this.selectedIds = [];
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has('selectedIds')) {
      this.selectedOptions = this.selectedIds;
    }
  }

  closeAllChildren(item) {
    const children = item.children || [];
    if (!children.length) return;
    item.children.forEach(d => {
      // eslint-disable-next-line
      d.opened = false;
      this.closeAllChildren(d);
    });
  }
  // clicked(item) {
  //   event && event.stopPropagation();
  //   item.opened = !item.opened;
  //   if(!item.opened) {
  //     this.closeAllChildren(item);
  //   } else {
  //     if(!item.children || !item.children?.length) {
  //       const ev = new CustomEvent('expanded-parent', {
  //         detail: item
  //       });
  //       this.dispatchEvent(ev);
  //     }
  //   }
  //   this.displayData = [...this.displayData];
  // }

  clicked(item) {
    return event => {
      // eslint-disable-next-line
      event && event.stopPropagation();
      // eslint-disable-next-line
      item.opened = !event.target.opened;
      // item.opened = !item.opened;
      if (!item.opened) {
        this.closeAllChildren(item);
      } else if (!item.children || !item.children?.length) {
        const ev = new CustomEvent('expanded-parent', {
          detail: { data: item, target: event.target },
        });
        this.dispatchEvent(ev);
      }
      this.displayData = [...this.displayData];
    };
  }

  pushSelected(item, data) {
    return event => {
      const { checked } = event.target;
      let detail;
      if (!this.isControlled) {
        const idx = this.selectedOptions.indexOf(item.id);
        if (checked && idx === -1) {
          this.selectedOptions.push(item.id);
        } else {
          this.selectedOptions.splice(idx, 1);
        }
        detail = this.selectedOptions;
      } else {
        detail = {
          checked,
          id: item.id,
          list: data,
          item,
          isHirarchy: this.isHirarchy,
        };
      }
      const ev = new CustomEvent('nodes-checked', {
        detail,
      });
      this.dispatchEvent(ev);
    };
  }

  getToolTip(content, text, depth) {
    const placementLeftConfig = depth
      ? {
          popperConfig: {
            placement: 'bottom',
          },
        }
      : {};
    return html`
      <ing-tooltip
        style=${this.isHirarchy ? 'top: 10px' : ''}
        invokerRelation="label"
        .config=${placementLeftConfig}
      >
        <div slot="invoker" text icon-only class="demo-tooltip-invoker">${content}</div>
        <div slot="content">${text}</div>
      </ing-tooltip>
    `;
  }

  getIcons(item, depth) {
    return html`
      ${item.showIcons
        ? html`
            <div class="icons-set">
              ${!item.isVisible
                ? this.getToolTip(
                    html`
                      <ing-icon
                        class="button-pointer down_arrow ${this.isEnableDownArrow
                          ? 'pointer-events'
                          : ''}"
                        icon-id="ing:outline-functionalities:hide"
                        slot="icon-before"
                        aria-label="icon:pointer"
                        @click="${this._moveRow}"
                        .data="${'down'}"
                      ></ing-icon>
                    `,
                    'Invisibile',
                    depth,
                  )
                : ''}
              ${item.value
                ? this.getToolTip(
                    html`
                      <ing-icon
                        class="button-pointer down_arrow ${this.isEnableDownArrow
                          ? 'pointer-events'
                          : ''}"
                        icon-id="ing:filledin-functionalities:setting"
                        slot="icon-before"
                        aria-label="icon:pointer"
                        @click="${this._moveRow}"
                        .data="${'down'}"
                      ></ing-icon>
                    `,
                    item.value,
                    depth,
                  )
                : ''}
              ${item.isBold || item.isItalic
                ? this.getToolTip(
                    html`
                      <ing-icon
                        class="button-pointer down_arrow ${this.isEnableDownArrow
                          ? 'pointer-events'
                          : ''}"
                        icon-id="ing:filledin-functionalities:compose"
                        slot="icon-before"
                        aria-label="icon:pointer"
                        @click="${this._moveRow}"
                        .data="${'down'}"
                      ></ing-icon>
                    `,
                    'Corsivo/Grassetto',
                    depth,
                  )
                : ''}
            </div>
          `
        : ''}
    `;
  }

  getTree(data, depth) {
    return data.map(item => {
      // eslint-disable-next-line
      const isLast = !!(item?.children?.length === 0 || !item.children);

      return html`
        <div class="border-bottom"></div>
        <div class="d-flex">
          <ing-checkbox
            style="padding-left: ${depth}px;display: block"
            id="${item.id}"
            ?checked="${this.selectedOptions?.indexOf(item.id) > -1}"
            @change="${this.pushSelected(item, data)}"
          ></ing-checkbox>

          ${this.isHirarchy
            ? html`
                <ing-collapsible>
                  <ing-collapsible-invoker slot="invoker" @click=${this.clicked(item)}>
                    <span slot="open">${item.name}</span>
                    <span slot="close">${item.name}</span>
                  </ing-collapsible-invoker>
                  <div slot="content">
                    ${item.opened && item.children && item.children.length
                      ? this.getTree(item.children, depth + 3)
                      : ''}
                  </div>
                </ing-collapsible>
                ${this.getIcons(item, depth)}
              `
            : html`<span class="d-inline-block"
                ><div style="width:95%">${item.name}</div>
                ${this.getIcons(item)}</span
              >`}
        </div>
        <div class="border-bottom"></div>
      `;
    });
  }

  render() {
    return html`
      <div class="container-fluid">
        <div class="form-group col-sm-8">
          <div id="myMultiselect" class="multiselect">${this.getTree(this.displayData, 0)}</div>
        </div>
      </div>
    `;
  }
}
