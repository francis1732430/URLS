import { css, sky30, font16BoldMixin, font19BoldMixin, black80, orange } from 'ing-web';

export default css`
  table,
  table::before,
  table::after {
    box-sizing: border-box;
  }

  caption,
  caption::before,
  caption::after {
    box-sizing: border-box;
  }

  th,
  th::before,
  th::after {
    box-sizing: border-box;
  }

  td,
  td::before,
  td::after {
    box-sizing: border-box;
  }

  .table-th,
  .table-th::before,
  .table-th::after {
    box-sizing: border-box;
  }

  .table-td,
  .table-td::before,
  .table-td::after {
    box-sizing: border-box;
  }

  .table {
    border-collapse: collapse;
    text-align: left;
    display: table;
  }

  .table caption {
    ${font19BoldMixin()}
    padding-top: 0;
    padding-bottom: 24px;
    color: ${orange};
    caption-side: top;
    text-align: left;
  }

  .table tr,
  .table-tr {
    border-bottom: 1px solid #d9d9d9;
  }

  .table thead > tr,
  .table thead > .table-tr,
  .table-header-group > .table-tr {
    border-bottom: 1px solid #ff6200;
  }

  .table thead > tr > :first-child,
  .table tbody > tr > :first-child,
  .table tfoot > tr > :first-child,
  .table-tr > :first-child {
    text-align: center;
  }

  .table th,
  .table-th {
    ${font16BoldMixin()}
    color: ${black80};
    text-align: inherit;
  }

  .table td,
  .table-tr > td,
  .table-td {
    font-family: INGMe, arial, helvetica, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;

    font-size: 11px;
    line-height: 14px;
    font-weight: normal;
    color: ${black80};
  }

  .table td.table__cell--numeric,
  .table-td.table__cell--numeric {
    text-align: right;
  }

  .table th,
  .table td,
  .table-th,
  .table-td {
    padding: 8px 22px 8px 0;
  }

  .table-header-group {
    display: table-header-group;
  }

  .table-td,
  .table-th {
    display: table-cell;
    vertical-align: middle;
  }

  .table-tbody {
    display: table-row-group;
  }

  .table-tr {
    display: table-row;
  }

  .table tbody tr:hover {
    background-color: ${sky30};
  }

  .selected-row-class {
    background-color: ${sky30};
  }

  thead {
    text-align: center;
  }

  .id_header {
    width: 84px;
    height: 29px;
  }

  .section_header {
    width: 234px;
    height: 29px;
  }

  .description_header {
    width: 421px;
    height: 29px;
  }

  .version_header {
    width: 106px;
    height: 29px;
  }

  .from_header {
    width: 186px;
    height: 29px;
  }

  .table_default_text_align {
    text-align: center;
  }

  .left_text_align {
    text-align: left;
  }

  .subsection_header {
    width: 234px;
    height: 29px;
  }
  .desc,
  .type {
    text-align: center;
  }
  .document_view_header {
    min-width: 160px;
  }

  [data-tag-name='ing-select'] {
    height: 25px;
    max-height: 25px;
    width: 75px;
  }

  [inputValue] select {
    font-size: 12px !important;
    height: 35px !important;
  }

  .pointer-event-curser {
    cursor: pointer;
  }
  .line {
    font-size: 2.5em;
  }
`;
