import { LitElement, html, ScopedElementsMixin, IngLink, IngSelect, formatDate } from 'ing-web';

import styles from './DocumentCommonDetailsTableStyles.js';

export class DocumentCommonDetailsTable extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get scopedElements() {
    return {
      'ing-link': IngLink,
      'ing-select': IngSelect,
    };
  }

  static get properties() {
    return {
      selectedRow: { type: Object },
      headerData: { type: Array },
      tableData: { type: Array },
      propertyId: { type: String },
      nameId: String,
      showVersionlist: { type: Boolean, reflect: true },
    };
  }

  _setSelectedElement(event) {
    this.selectedRow = event.currentTarget.data;
    // eslint-disable-next-line no-console
    console.log(this.selectedRow);

    const rowClickedEvent = new CustomEvent('selected-table-row', {
      detail: {
        data: this.selectedRow,
      },
    });
    this.dispatchEvent(rowClickedEvent);
    this.getVersionDetails(event, this.selectedRow);
  }

  async getVersionDetails(ev, row) {
    if (this.showVersionlist) {
      if (ev) {
        ev.stopPropagation();
        ev.preventDefault();
      }
      const rowClickedEvent = new CustomEvent('version-detail-list', {
        detail: {
          rowData: row,
        },
      });
      this.dispatchEvent(rowClickedEvent);
    }
  }

  changeVersionDetail(event) {
    const rowClickedEvent = new CustomEvent('changed-version-detail', {
      detail: {
        id: event.target.value,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  loadSelectElement(rowData) {
    return this.showVersionlist
      ? // eslint-disable-next-line
        html`<div
          class="pointer-event-curser"
          @click="${ev => this.getVersionDetails(ev, rowData)}"
        >
          ${rowData.version}
        </div>`
      : rowData.version;
  }

  render() {
    return html`
      <table class="table">
        <thead>
          <tr>
            ${this.headerData.map(
              anHeader => html` <th class="${anHeader.headerClass}">${anHeader.headerValue}</th>`,
            )}
          </tr>
        </thead>
        <tbody>
          ${this.tableData?.map(
            rowData =>
              html`<tr
                class="table_default_text_align ${rowData?.[this.propertyId] ===
                this.selectedRow?.[this.propertyId]
                  ? 'selected-row-class'
                  : undefined}"
                @click="${this._setSelectedElement}"
                .data="${rowData}"
              >
                <td>${rowData?.[this.nameId]}</td>
                <td class="left_text_align">${rowData.name}</td>
                <td class="left_text_align desc">${rowData.description}</td>
                <td>
                  ${rowData?.versionList?.length > 0
                    ? html` <ing-select
                        @click="${event => {
                          event.stopPropagation();
                          event.preventDefault();
                        }}"
                        @change="${this.changeVersionDetail}"
                        class="input_value_${rowData?.[this.propertyId]}"
                        name="version"
                        inputValue
                        .modelValue=${rowData?.id}
                      >
                        <select slot="input">
                          ${rowData?.versionList?.map(
                            d =>
                              html`<option value="${d.itemsVersionsID}">
                                ${d.versionNumber}
                              </option>`,
                          )}
                        </select>
                      </ing-select>`
                    : rowData.version}
                </td>
                <td>${formatDate(new Date(rowData.validity), { locale: 'it-It' })}</td>
                <td>${rowData?.documentView}</td>
              </tr>`,
          )}
        </tbody>
      </table>
    `;
  }
}
customElements.define('document-common-details-table', DocumentCommonDetailsTable);
