import { LitElement, html, ScopedElementsMixin, unsafeHTML, IngTooltip, IngButton } from 'ing-web';
import styles from './DocumentRowsDetailsTableStyles.js'; // TODO

export class IngTable extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return [styles];
  }

  static get scopedElements() {
    return {
      'ing-tooltip': IngTooltip,
      'ing-button': IngButton,
    };
  }

  static get properties() {
    return {
      selectedRow: { type: Object },
      headerData: { type: Array },
      tableData: { type: Array },
      propertyId: { type: String },
      contentProperties: { type: Array },
      showPropertyIdData: { type: Boolean },
      _debounceEvent: { type: Object },
      additionalStyles: { type: Object },
    };
  }

  _setSelectedElement(event) {
    this.selectedRow = event.currentTarget.data;

    const rowClickedEvent = new CustomEvent('selected-table-row', {
      detail: {
        data: this.selectedRow,
      },
    });
    this.dispatchEvent(rowClickedEvent);
  }

  _getAttributes(rowData, aProperty) {
    const classes = this.getConditionClass(rowData, aProperty);
    let attributes = aProperty.contentHtml
      ? Object.keys(aProperty.contentHtml?.attributes).reduce((acc, key) => {
          // eslint-disable-next-line no-nested-ternary
          let attrValue = aProperty.contentHtml.attributes[key]
            ? rowData?.[aProperty.contentHtml.attributes[key]]
              ? rowData?.[aProperty.contentHtml.attributes[key]]
              : aProperty.contentHtml.attributes[key]
            : rowData?.[aProperty.propertyName];
          let val = '';
          if (key === 'class' && classes) {
            attrValue = `${attrValue} ${classes}`;
            val = `${acc} ${key}="${attrValue}"`;
          } else {
            val = `${acc} ${key}="${attrValue}"`;
          }
          return val;
        }, '')
      : '';

    if (
      (aProperty.contentHtml && Object.keys(aProperty.contentHtml?.attributes).length === 0) ||
      // eslint-disable-next-line
      !aProperty.contentHtml?.attributes.hasOwnProperty('class')
    ) {
      if (classes) {
        attributes = `${attributes} class="${classes}"`;
      }
    }
    // eslint-disable-next-line no-console
    console.log(this.propertyId);
    return attributes;
  }
  // eslint-disable-next-line
  getConditionClass(rowData, aProperty) {
    let classes = '';
    // eslint-disable-next-line
    aProperty.contentHtml &&
      aProperty.contentHtml.classCondition &&
      aProperty.contentHtml.classCondition.forEach(item => {
        if (item && item.operator === '===' && item.text === rowData?.[aProperty.propertyName]) {
          classes = `${classes} ${item.className}`;
        } else if (
          item &&
          item.operator === '!==' &&
          item.text !== rowData?.[aProperty.propertyName]
        ) {
          classes = `${classes} ${item.className}`;
        }
      });
    // eslint-disable-next-line no-console
    return classes;
  }

  _defineCustomElement(tagName, className) {
    if (!customElements.get(tagName)) customElements.define(tagName, className);
    // eslint-disable-next-line no-console
    console.log(this.propertyId);
  }

  _generateTemplate(rowData, aProperty) {
    if (aProperty.contentHtml.customElement) {
      this._defineCustomElement(aProperty.contentHtml.tag, aProperty.contentHtml.customElement);
    }
    // TODO a function to be passed as a Prop to transform the values, to parse dates or format other data
    // Example: this.transformData(rowData, aProperty.propertyName, aProperty.contentHtml.innerText);

    // eslint-disable-next-line no-nested-ternary
    return `<${aProperty.contentHtml.tag} ${this._getAttributes(rowData, aProperty)} ${
      aProperty.contentHtml.isSelfClosingTag ? '/' : ''
    }>
        
        ${
          // eslint-disable-next-line no-nested-ternary
          aProperty.contentHtml.isSelfClosingTag || aProperty.contentHtml.innerText === false
            ? ''
            : // eslint-disable-next-line no-nested-ternary
            aProperty.contentHtml.innerText
            ? rowData?.[aProperty.contentHtml.innerText]
              ? rowData?.[aProperty.contentHtml.innerText]
              : aProperty.contentHtml.innerText
            : rowData?.[aProperty.propertyName]
        }
        ${
          aProperty.contentHtml.contentHtml
            ? this._getHtmlTemplates(rowData, { ...aProperty, ...aProperty.contentHtml })
            : ''
        }
        ${aProperty.contentHtml.isSelfClosingTag ? '' : `</${aProperty.contentHtml.tag}>`}`;
  }

  _getHtmlTemplates(rowData, aProperty) {
    let htmlStr = '';
    if (Array.isArray(aProperty.contentHtml)) {
      for (const h of aProperty.contentHtml) {
        const obj = { ...aProperty, contentHtml: h };
        htmlStr += this._generateTemplate(rowData, obj);
      }
    } else if (aProperty.contentHtml && typeof aProperty.contentHtml === 'object') {
      htmlStr += this._generateTemplate(rowData, aProperty);
    }
    return htmlStr;
  }

  _handleChildEvents(allowedEvents = []) {
    return event => {
      if (allowedEvents.indexOf(event.type) === -1) return;
      event?.stopPropagation();
      event?.preventDefault();
      const eventData = {
        target: event.target,
        value: event.target.value,
        name: event.target.name,
        type: event.type,
      };
      clearTimeout(this._debounceEvent);
      this._debounceEvent = setTimeout(() => {
        const customEvent = new CustomEvent('child-data-event', {
          detail: eventData,
        });
        this.dispatchEvent(customEvent);
      }, 250);
    };
  }

  getComponentsHtml(rowData, aProperty) {
    const htmlStr = [];
    aProperty.components.forEach(component => {
      if (component.componentName === 'tooltip') {
        const content = unsafeHTML(
          this._getHtmlTemplates(rowData, { ...aProperty, contentHtml: component.contentHtml }),
        );
        htmlStr.push(html`<ing-tooltip .config="$">
          <div slot="invoker"></div>
          <div slot="content" style="display:none"></div>
          ${content}
        </ing-tooltip>`);
      }
    });

    return htmlStr;
  }

  render() {
    return html`
      ${this.additionalStyles || ''}
      <table class="table">
        <thead>
          <tr>
            ${this.headerData.map(
              anHeader => html` <th class="${anHeader.headerClass}">${anHeader.headerValue}</th>`,
            )}
          </tr>
        </thead>
        <tbody>
          ${this.tableData?.map(
            rowData =>
              html`<tr
                class="table_default_text_align ${rowData?.[this.propertyId] ===
                this.selectedRow?.[this.propertyId]
                  ? 'selected-row-class'
                  : undefined}"
                @click="${this._setSelectedElement}"
                .data="${rowData}"
              >
                ${this.showPropertyIdData ? html`<td>${rowData?.[this.propertyId]}</td>` : ''}
                ${this.contentProperties?.map(
                  aProperty =>
                    html`<td
                      @click="${this._handleChildEvents(aProperty.contentHtmlEvents)}"
                      @change="${this._handleChildEvents(aProperty.contentHtmlEvents)}"
                      @keyup="${this._handleChildEvents(aProperty.contentHtmlEvents)}"
                      @mouseenter="${this._handleChildEvents(aProperty.contentHtmlEvents)}"
                      class="${aProperty.propertyClass}"
                    >
                      ${
                        // eslint-disable-next-line no-nested-ternary
                        aProperty.contentHtml
                          ? html`${unsafeHTML(this._getHtmlTemplates(rowData, aProperty))}`
                          : aProperty.components
                          ? this.getComponentsHtml(rowData, aProperty)
                          : rowData?.[aProperty.propertyName]
                      }
                    </td>`,
                )}
              </tr>`,
          )}
        </tbody>
      </table>
    `;
  }
}
customElements.define('ing-generic-table', IngTable);
