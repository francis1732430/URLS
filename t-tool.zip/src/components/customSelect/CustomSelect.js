import { LitElement, html, ScopedElementsMixin } from 'ing-web';

import styles from './CustomSelectStyles.js';

export class CustomSelect extends ScopedElementsMixin(LitElement) {
  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      selectedTexts: String,
      selectedOptions: Array,
      displayData: Array,
      propKey: String,
      columnId: String,
      removeColumnNoteId: String,
      linkedElement: Boolean,
    };
  }

  constructor() {
    super();

    this.selectedTexts = '';
    this.propKey = '';
    this.selectedOptions = [];
    this.displayData = [];

    document.addEventListener('click', evt => {
      const flyoutElement = this.shadowRoot.getElementById('myMultiselect');
      const path = (evt?.composedPath && evt?.composedPath()) || evt?.path;
      // eslint-disable-next-line
      if (path?.findIndex(ii => ii == flyoutElement) === -1) {
        this.toggleCheckboxArea(true);
      }
    });
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    this.initMultiselect();
    if (this.removeColumnNoteId && changedProperties.has('removeColumnNoteId')) {
      setTimeout(() => {
        const checkboxes = this.shadowRoot.querySelectorAll('#mySelectOptions input');
        checkboxes?.forEach(checkBox => {
          // eslint-disable-next-line
          const index = this.selectedOptions?.findIndex(
            // eslint-disable-next-line
            opt => checkBox?.id == `id_${opt.columnNoteId}`,
          );

          if (index > -1 && checkBox) {
            // eslint-disable-next-line
            checkBox.checked = true;
          } else if (checkBox && index === -1) {
            // eslint-disable-next-line
            checkBox.checked = false;
          }
        });
      }, 350);
    }

    if (
      this.selectedOptions?.length &&
      this.displayData?.length > 0 &&
      changedProperties.has('displayData')
    ) {
      this.selectedOptions = this.selectedOptions.map(note => {
        const index = this.displayData.findIndex(
          note1 => note?.id?.toString() === note1?.id?.toString(),
        );

        if (index > -1) {
          // eslint-disable-next-line
          note.name = this.displayData[index].name;
        }
        return note;
      });
    }
  }

  initMultiselect() {
    if (!this.propKey) {
      this.propKey = 'name';
    }
    if (this.selectedOptions?.length && this.propKey) {
      // eslint-disable-next-line
      const options = this.selectedOptions.filter(
        // eslint-disable-next-line
        opt2 => `${this.columnId}_${opt2.id}` == opt2.columnNoteId,
      );
      if (options?.length) {
        this.selectedTexts = options.map(option => option?.[this.propKey])?.join(',');
      } else {
        this.selectedTexts = 'Select Element';
      }
    } else {
      this.selectedTexts = 'Select Element';
    }
  }

  toggleCheckboxArea(onlyHide = false) {
    const checkboxes = this.shadowRoot.getElementById('mySelectOptions');
    const displayValue = checkboxes?.style?.display;
    // eslint-disable-next-line
    if (displayValue != 'block') {
      // eslint-disable-next-line
      if (onlyHide == false) {
        checkboxes.style.display = 'block';
      }
    } else if (checkboxes?.style?.display) {
      checkboxes.style.display = 'none';
    }
  }

  checkboxStatusChange(e, opt) {
    if (!this.selectedOptions) {
      this.selectedOptions = [];
    }
    let unCheckedId = '';
    if (e?.target?.checked === true && opt?.id) {
      if (
        this.selectedOptions?.findIndex(item => item?.id?.toString() === opt?.id?.toString()) === -1
      ) {
        // eslint-disable-next-line
        opt.columnNoteId = `${this.columnId}_${opt.id}`;
        // eslint-disable-next-line
        opt.columnId1 = this.columnId;
        this.selectedOptions = [...this.selectedOptions, opt];
      }
    } else if (e?.target?.checked === false && opt?.id) {
      unCheckedId = opt?.id;
      if (
        this.selectedOptions?.findIndex(item => item?.id?.toString() === opt?.id?.toString()) > -1
      ) {
        this.selectedOptions = this.selectedOptions.filter(
          opt1 => opt1?.id?.toString() !== opt?.id?.toString(),
        );
      }
    }
    const event = new CustomEvent('value-change', {
      detail: {
        // eslint-disable-next-line
        selectedOptions:
          this.selectedOptions?.filter(
            // eslint-disable-next-line
            opt3 => `${this.columnId}_${opt3.id}` == opt3.columnNoteId,
          ) || [],
        unCheckedId,
      },
    });
    this.dispatchEvent(event);
    this.initMultiselect();
  }

  getCheckedResult(id) {
    const checkboxes = this.shadowRoot.querySelector(`#mySelectOptions #id_${this.columnId}_${id}`);
    const index = this.selectedOptions?.findIndex(opt => opt?.id?.toString() === id?.toString());
    if (index > -1 && checkboxes) {
      const { columnNoteId } = this.selectedOptions[index];
      // eslint-disable-next-line
      if (`${this.columnId}_${id}` == columnNoteId && !checkboxes?.checked) {
        checkboxes.checked = true;
        return true;
      }
      // eslint-disable-next-line
      if (`${this.columnId}_${id}` != columnNoteId && checkboxes?.checked) {
        checkboxes.checked = false;
        return false;
      }
    } else if (checkboxes && index === -1) {
      checkboxes.checked = false;
      return false;
    }
    return index > -1;
  }

  getMultiSelectEl() {
    // eslint-disable-next-line
    return html`<div
        id="mySelectLabel"
        class="selectBox ${this.linkedElement ? 'pointer-events' : ''}"
        @click="${() => this.toggleCheckboxArea()}"
      >
        <select class="form-select" ?disabled="${this.linkedElement}">
          <option>${this.selectedTexts}</option>
        </select>
        <div class="overSelect"></div>
      </div>
      <div id="mySelectOptions">
        ${this.displayData.map(
          item =>
            html`<label for="id_${this.columnId}_${item.id}"
              ><input
                type="checkbox"
                id="id_${this.columnId}_${item.id}"
                @change="${e => this.checkboxStatusChange(e, item)}"
                ?checked="${this.getCheckedResult(item.id)}"
              />
              ${item?.[this.propKey || 'name']}</label
            >`,
        )}
      </div>`;
  }

  render() {
    return html`
      <div class="container-fluid">
        <div class="form-group col-sm-8">
          <div id="myMultiselect" class="multiselect">${this.getMultiSelectEl()}</div>
        </div>
      </div>
    `;
  }
}
