import { css, font16Mixin } from 'ing-web';

export default css`
  .container-fluid {
    position: relative;
    max-width: 50%;
  }
  .multiselect {
    max-width: 100%;
  }
  .selectBox {
    position: relative;
  }

  .selectBox select {
    width: 100%;
    border: 1px solid rgb(105, 105, 105);
    height: 40px;
  }

  .overSelect {
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
  }

  #mySelectOptions {
    display: none;
    border: 0.5px #7c7c7c solid;
    background-color: #ffffff;
    max-height: 150px;
    overflow-y: scroll;
    position: absolute;
    z-index: 1;
    width: 100%;
    ${font16Mixin()}
  }

  #mySelectOptions label {
    display: block;
    font-weight: normal;
    display: block;
    white-space: nowrap;
    min-height: 1.2em;
    background-color: #ffffff00;
    padding: 0 2.25rem 0 0.75rem;
    display: flex;
    align-items: center;
  }
  input[type='checkbox'] {
    -ms-transform: scale(1.2); /* IE */
    -moz-transform: scale(1.2); /* FF */
    -webkit-transform: scale(1.2); /* Safari and Chrome */
    -o-transform: scale(1.2); /* Opera */
    padding: 10px;
    margin-right: 7px;
  }

  select option {
    ${font16Mixin()}
  }

  #mySelectOptions label:hover {
    background-color: #1e90ff;
  }

  .pointer-events {
    pointer-events: none;
  }

  .form-select {
    display: block;
    width: 100%;
    padding: 0.375rem 2.25rem 0.375rem 0.75rem;
    -moz-padding-start: calc(0.75rem - 3px);
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-size: 16px 12px;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
  }
`;
