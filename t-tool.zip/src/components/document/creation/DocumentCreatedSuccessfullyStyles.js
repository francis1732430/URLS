import { black80, css, font14BoldMixin, font14Mixin, font24BoldMixin } from 'ing-web';

export default css`
  .display-flex {
    display: flex;
    width: 100%;
  }
  .flex-column {
    display: flex;
    flex-direction: column;
  }
  .container {
    margin-left: 107px;
    margin-top: 71px;
  }
  .title-header {
    color: ${black80};
    ${font24BoldMixin()}
    margin-bottom: 62px;
  }
  .flex-16 {
    flex: 16%;
  }
  .flex-52 {
    flex: 52%;
  }
  .mb-40 {
    margin-bottom: 40px;
  }
  .mb-60 {
    margin-bottom: 60px;
  }
  .label-1 {
    color: ${black80};
    ${font14Mixin()}
  }
  .label-2 {
    color: ${black80};
    ${font14BoldMixin()}
  }
  .mb-6 {
    margin-bottom: 6px;
  }
  .input {
    width: 719px;
    height: 40px;
    margin-bottom: 58px;
  }
  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 105px;
    margin-bottom: 65px;
  }
  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
    margin-right: 28px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
  }

  .create-new-button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .create-new-button {
    min-width: 180px;
    height: 32px;
    ${font14BoldMixin()}
  }
  .flex-20 {
    width: 16%;
  }
`;
