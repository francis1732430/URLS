import { css, font14Mixin, orange } from 'ing-web';

export default css`
  .note_name {
    margin-top: 35px;
    width: 705px;
    height: 40px;
    margin-left: 104px;
  }

  .note_from {
    margin-top: 52px;
    width: 180px;
    height: 40px;
    margin-left: 104px;
    --ing-input-group-width: 180px;
  }

  [noteTextArea] {
    margin-top: 66px;
    width: 705px;
    height: 85px;
    margin-left: 104px;
  }

  .container {
    height: 30px;
    position: relative;
    margin-top: 74px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 384px;
  }

  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
  }

  .ing_standard_bottom_line {
    border-bottom: 1px solid ${orange};
    margin-top: 20px;
  }

  .rightTest {
    margin-right: 120px;
  }

  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
  }
`;
