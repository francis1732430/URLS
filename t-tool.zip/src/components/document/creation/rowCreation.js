import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngInput,
  IngChipFilter,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngIcon,
} from 'ing-web';
import {
  addElementToLocalStorage,
  escapeSlashes,
  generateId,
  mapPropertyToObjectFromList,
  removeElementFromLocalStorage,
  sortArray,
} from '../../../utils/IngFeatTransparencyToolUtils.js';
import { CreateRow } from './CreateNewRow.js';

import styles from './rowCreationStyles.js';
import {
  transformRowsToBackEnd,
  transformRowsToBackEndForPatch,
  transformRowsToFrontEnd,
} from '../../../data/tranformations/rowTransformation.js';
import { ajaxInstance } from '../../../utils/endpoints.js';
import {
  baseURL,
  baseURL2,
  localEnvironment,
  localStorageKeysMap,
} from '../../../utils/constants.js';
import { deriveData } from '../../../utils/globalApiKeys.js';
import { chunks, createVersionDetail } from '../../../utils/chunks.js';
import { transformNoteToFrontEnd } from '../../../data/tranformations/noteTransformation.js';

export class RowCreation extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'create-new-row': CreateRow,
      'chip-filter': IngChipFilter,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-icon': IngIcon,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      rowData: { type: Array },
      isExistingDocument: { type: Boolean, reflect: true },
      notes: Array,
      lookupData: Array,
      ruleData: Array,
      isModifiedDocument: { type: Boolean, reflect: true },
      savedChildList: Array,
    };
  }

  constructor() {
    super();
    this._noteAreaIndex = 0;
    this.ajaxInstance = ajaxInstance;
    this.savedChildList = [];
    this.isRefreshRow = false;
    this.isApiRejected = false;
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed.has('rowData') &&
      (!this.rowData || (this.rowData && !this.rowData.length) || this.rowData === 'undefined')
    ) {
      this.rowData = [
        {
          id: generateId(),
          name: '',
          validity: new Date(),
          style: '',
          columnNotes: [],
          columns: [],
          isNew: true,
          isNotSaved: true,
        },
      ];
    }
  }

  _fireRowsChangedEvent(id, data2) {
    const e = new CustomEvent('rows-changed', {
      detail: {
        data: this.rowData,
        id,
        data2,
        savedChildList: this.savedChildList,
      },
    });
    this.dispatchEvent(e);
  }

  _addRowSection() {
    this.rowData = [
      ...this.rowData,
      {
        id: generateId(),
        name: '',
        validity: new Date(),
        style: '',
        columnNotes: [],
        columns: [],
        isNew: true,
        isNotSaved: true,
      },
    ];
    // this._fireRowsChangedEvent();
  }

  // eslint-disable-next-line class-methods-use-this
  _postRow(row) {
    const rowBackend = transformRowsToBackEnd(row);
    return this.ajaxInstance.post(baseURL, rowBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _putRow(row) {
    const rowBackend = transformRowsToBackEndForPatch(row);
    return this.ajaxInstance.patch(`${baseURL}/version`, rowBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _deleteRow(rowId) {
    return this.ajaxInstance.delete(`${baseURL}/${rowId}`);
  }

  async _removeRowSection(event) {
    const { id } = event.detail;

    const index = this.rowData.findIndex(e => e?.id?.toString() === id?.toString());
    if (!this.rowData[index]?.isNotSaved) {
      // try {
      //   await this._deleteRow(id);
      //   // this.rowData = this.rowData.filter(d => d.id.toString() !== id.toString());
      //   this._fireRowsChangedEvent(id);
      // } catch (e) {
      //   // eslint-disable-next-line no-console
      //   console.log('failed this._deleteRow(data)', e);
      // }
      this._fireRowsChangedEvent(id);
    } else if (this.isExistingDocument) {
      this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
      this._fireRowsChangedEvent(id);
    } else if (this.rowData.length > 1) {
      this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
      const e = new CustomEvent('remove-event', {
        detail: {
          rowData: this.rowData,
        },
      });
      this.dispatchEvent(e);
    }
  }

  async makeNotesAjaxCall(transformFn) {
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=NOTA`;
    } else {
      // FOR MOCK USE
      url = `${baseURL}/NOTA/all?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=NOTA`;
    }

    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      list = list.map(d => transformFn(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  _showStatusEvent(data, type) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data,
        type,
      },
    });
    this.dispatchEvent(ev);
  }

  async _saveRow(event) {
    const elements = [...this.rowData];
    let detail1 = event?.detail;
    const index = elements.findIndex(e => e?.id?.toString() === detail1?.id?.toString());
    if (this.rowData[index]?.versionDetailLevel0IDStyle && detail1) {
      detail1.versionDetailLevel0IDStyle = this.rowData[index]?.versionDetailLevel0IDStyle;
    }
    if (this.rowData[index]?.versionID && detail1) {
      detail1.versionID = this.rowData[index]?.versionID;
    }
    if (index > -1 && !elements[index].isNotSaved) {
      const detail2 = await this.updateLevel1AndLevel2Items(detail1);
      detail1 = { ...detail1, ...detail2 };
    }
    const process = async () => {
      // detail1.id = generateId();
      // detail1.name = detail1.id
      elements[index] = detail1;
      elements[index].isNotSaved = false;
      if (elements[index]?.columnNotes?.length) {
        const notesData = await this.makeNotesAjaxCall(transformNoteToFrontEnd);
        elements[index]?.columnNotes?.forEach(note => {
          mapPropertyToObjectFromList(notesData.list, note);
        });
      }
      this.bindNotesVersionLevelsIds(elements[index]);
      this.rowData = [...elements];
      this.savedChildList = this.rowData;
      this.savedChildList = JSON.parse(JSON.stringify(this.savedChildList));
      this._fireRowsChangedEvent(null, detail1);
      this.isRefreshRow = false;
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(elements[index], localStorageKeysMap.APPLICATION_ROWS);
    };
    if (index > -1 && !elements[index].isNotSaved) {
      try {
        const putData = await this._putRow(detail1);
        this._showStatusEvent(putData);
        if (this.isRefreshRow) {
          const res1 = await this._getVersionItemDetail(detail1?.id);
          detail1 = transformRowsToFrontEnd(res1?.data);
        }
        process();
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._putRow(data)', e);
      }
    } else {
      try {
        // eslint-disable-next-line no-unused-expressions
        !this.isModifiedDocument &&
          !this.isExistingDocument &&
          removeElementFromLocalStorage(event?.detail?.id, localStorageKeysMap.APPLICATION_ROWS);
        const res = await this._postRow(detail1);
        this._showStatusEvent(res);
        const res1 = await this._getVersionItemDetail(res?.data?.itemsVersionsID);
        detail1 = transformRowsToFrontEnd(res1?.data);
        if (res?.data?.versionID) {
          detail1.versionID = res?.data?.versionID;
        }
        process();
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._postRow(data)', e);
      }
    }
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  _fieldValuesChanged(ev) {
    const { id, data } = ev.detail;
    clearTimeout(this.valuesChangedTimeout);
    this.valuesChangedTimeout = setTimeout(() => {
      const eventData = new CustomEvent('field-values-changed', {
        detail: { id },
      });
      this.dispatchEvent(eventData);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(data, localStorageKeysMap.APPLICATION_ROWS);
    }, 300);
  }

  bindNotesVersionLevelsIds(data1) {
    if (data1?.columnNotes && data1?.columnNotes?.length > 0 && this.notes?.length > 0) {
      // eslint-disable-next-line
      data1.columnNotes =
        data1?.columnNotes?.map(item1 => {
          const index = this.notes.findIndex(
            item2 => item1?.id?.toString() === item2?.id?.toString(),
          );
          if (index > -1) {
            // this.notes[index].versionDetailLevel1ID = item1?.versionDetailLevel1ID;
            // this.notes[index].versionDetailLevel2ID = item1?.versionDetailLevel2ID;
            // eslint-disable-next-line
            item1.name = this.notes[index]?.name;
          }
          return item1;
        }) || [];
      this.notes = [...this.notes];
    }

    if (data1?.columns?.length > 0) {
      // eslint-disable-next-line
      data1.columns = sortArray(data1.columns, 'name');
    }
  }

  async _rowChanged(event) {
    if (event?.detail?.id) {
      const elements = [...this.rowData];
      const { id } = event?.detail;
      const index = elements.findIndex(e => e?.id?.toString() === id?.toString());
      const res1 = await this._getVersionItemDetail(id);
      const detail1 = transformRowsToFrontEnd(res1?.data);
      if (Array.isArray(detail1?.columns) && elements[index]?.columns) {
        elements[index].columns = detail1?.columns;
      }
      if (Array.isArray(detail1?.columnNotes) && elements[index]?.columnNotes) {
        elements[index].columnNotes = detail1?.columnNotes;
      }
      // elements[index].isNotSaved = false;
      if (elements[index]?.columns?.length && elements[index]?.columnNotes?.length) {
        elements[index].columns = elements[index]?.columns?.map((col, i) => {
          if (col?.name) {
            // eslint-disable-next-line
            col.name = i + 1;
            elements[index].columnNotes = elements[index]?.columnNotes.map(cn => {
              if (cn?.columnId?.toString() === col?.id?.toString()) {
                // eslint-disable-next-line
                cn.columnName = col.name;
              }
              return cn;
            });
          }
          return col;
        });
      }
      this.bindNotesVersionLevelsIds(elements[index]);
      this.rowData = [...elements];
      if (this.isModifiedDocument) {
        this.rowData = [...this.rowData];
      }
      const e = new CustomEvent('row_column_changed', {
        detail: {
          id,
          data2: elements[index],
          data: this.rowData,
        },
      });
      this.dispatchEvent(e);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(elements[index], localStorageKeysMap.APPLICATION_ROWS);
    }
  }

  async updateLevel1AndLevel2Items(row) {
    let versionID;
    this.isApiRejected = false;
    if (!row?.versionID) {
      const versionList = await this.getVersionsList(row?.rowId);
      if (versionList.length > 0) {
        const data = versionList.find(
          item => item?.itemsVersionsID?.toString() === row?.id?.toString(),
        );
        if (data) {
          versionID = data?.versionID;
          // eslint-disable-next-line
          row.versionID = data?.versionID;
        }
      }
    } else if (row?.versionID) {
      versionID = row?.versionID;
    }
    const level0UnSaveItems = [];
    const level0 = {};
    const level2 = {};
    const createdItems = JSON.parse(JSON.stringify(row?.columns || []));
    const createdItemsNotes = JSON.parse(JSON.stringify(row?.columnNotes || []));
    createdItems.forEach((col1, i) => {
      if (!col1?.name) {
        // eslint-disable-next-line
        col1.name = i + 1;
      }
      if (!col1?.versionDetailLevel0ID && col1?.name) {
        level0UnSaveItems.push(col1?.name);
      } else if (col1?.versionDetailLevel0ID && col1?.name) {
        level0[col1?.name] = col1?.versionDetailLevel0ID;
      }
    });

    createdItemsNotes.forEach(note1 => {
      if (note1) {
        level2[note1.columnId] = note1?.id;
      }
    });

    if (level0UnSaveItems?.length && versionID) {
      // eslint-disable-next-line
      const level0FormatedList = level0UnSaveItems.map(litem0 => {
        return this.createToBackEnd(
          0,
          versionID,
          'VERSION_DETAIL_LEVEL_1',
          'DETTAGLIO_RIGA',
          litem0,
        );
      });
      const resList = await this.addVersionDetails(level0FormatedList);
      if (resList?.length) {
        resList.forEach(res1 => {
          if (res1?.data && res1?.versionDetailID) {
            level0[res1?.data] = res1?.versionDetailID;
          }
        });
      }
    }

    const newLevel1 = {};
    const colToBackEndList = [];
    createdItems.forEach(obj => {
      if (obj?.id) {
        if (obj?.versionDetailLevel1IDColumn) {
          newLevel1[obj?.id] = obj?.versionDetailLevel1IDColumn;
        }
        if (!obj?.versionDetailLevel1IDDescription && level0[obj.name] && obj.description) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj.name],
              'FIELD',
              'DESCRIZIONE_IN_STAMPA',
              escapeSlashes(obj.description),
            ),
          );
        }
        if (!obj?.versionDetailLevel1IDBold && level0[obj.name]) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj.name],
              'FIELD',
              'BOLD',
              obj.isBold && (obj.isBold === 'true' || obj.isBold === true) ? 'true' : 'false',
            ),
          );
        }
        if (!obj?.versionDetailLevel1IDItalic && level0[obj.name]) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj.name],
              'FIELD',
              'ITALIC',
              obj.isItalic && (obj.isItalic === 'true' || obj.isItalic === true) ? 'true' : 'false',
            ),
          );
        }

        if (!obj?.versionDetailLevel1IDColumn && level0[obj.name] && obj.id) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj.name],
              'VERSION_DETAIL_LEVEL_2',
              'DETTAGLIO_NOTA',
              obj.id,
            ),
          );
        }
      }
    });

    if (colToBackEndList?.length) {
      // Api
      const res = await this.addVersionDetails(colToBackEndList);
      res?.forEach(lev1 => {
        if (lev1?.data && level2[lev1?.data]) {
          newLevel1[lev1?.data] = lev1?.versionDetailID;
        }
      });
    }
    const noteToBackEndList = [];
    createdItemsNotes.forEach(note1 => {
      if (note1?.id && !note1?.versionDetailLevel2ID && newLevel1[note1.columnId]) {
        noteToBackEndList.push(
          this.createToBackEnd(2, newLevel1[note1.columnId], 'FIELD', 'ID_NOTA', note1.id),
        );
      }
    });

    if (noteToBackEndList?.length) {
      // Api
      await this.addVersionDetails(noteToBackEndList);
    }

    let row1 = {
      columns: [],
      columnNotes: [],
    };

    this.isRefreshRow = true;
    if (level0UnSaveItems?.length || colToBackEndList?.length || noteToBackEndList?.length) {
      // GET API
      const res3 = await this._getVersionItemDetail(row?.id);
      row1 = transformRowsToFrontEnd(res3?.data);
      if (!this.isApiRejected) {
        this.isRefreshRow = false;
      }
      let columns = [];
      let columnNotes = [];
      const index1 = this.savedChildList.findIndex(
        item => item?.id?.toString() === row?.id?.toString(),
      );
      if (index1 > -1) {
        columns = JSON.parse(JSON.stringify(this.savedChildList[index1]?.columns || []));
        columnNotes = JSON.parse(JSON.stringify(this.savedChildList[index1]?.columnNotes || []));
        columns = columns.map(cond1 => {
          const index2 = row.columns?.findIndex(
            cond2 =>
              cond2?.versionDetailLevel0ID?.toString() === cond1?.versionDetailLevel0ID?.toString(),
          );
          if (index2 > -1) {
            // eslint-disable-next-line
            cond1 = { ...cond1, ...row?.columns?.[index2] };
          }
          return cond1;
        });
        columnNotes = columnNotes.map(cond1 => {
          const index2 = row.columnNotes.findIndex(
            cond2 =>
              cond2?.versionDetailLevel2ID?.toString() ===
                cond1?.versionDetailLevel2ID?.toString() &&
              cond2?.versionDetailLevel1ID?.toString() === cond1?.versionDetailLevel1ID?.toString(),
          );
          if (index2 > -1) {
            // eslint-disable-next-line
            cond1 = { ...cond1, ...row?.columnNotes?.[index2] };
          }
          return cond1;
        });
      }
      if (row1?.columns?.length && columns?.length) {
        row1.columns = row1.columns.map(col1 => {
          const index = columns?.findIndex(
            col2 =>
              col2?.versionDetailLevel0ID?.toString() === col1?.versionDetailLevel0ID?.toString(),
          );
          if (index > -1 && columns?.[index]?.versionDetailLevel0ID) {
            // eslint-disable-next-line
            col1 = { ...columns?.[index] };
          }
          return col1;
        });
      }

      if (row1?.columnNotes?.length && columnNotes?.length) {
        row1.columnNotes = row1.columnNotes.map(col1 => {
          const index = columnNotes?.findIndex(
            col2 =>
              col2?.versionDetailLevel2ID?.toString() === col1?.versionDetailLevel2ID?.toString() &&
              col2?.versionDetailLevel1ID?.toString() === col1?.versionDetailLevel1ID?.toString(),
          );
          if (index > -1 && columnNotes?.[index]?.versionDetailLevel2ID) {
            // eslint-disable-next-line
            col1 = { ...columnNotes?.[index] };
          }
          return col1;
        });
      }

      if (row1?.id) {
        row1.name = row?.name;
        row1.validity = row?.validity;
        row1.style = row?.style;
      }
    } else {
      row1 = { ...row };
    }
    return row1;
  }

  // eslint-disable-next-line
  createToBackEnd(level, parentId, key, value, data) {
    return {
      versionDetailLevel: level,
      versionDetailParentID: parentId,
      itemTypeKey: key,
      itemTypeValue: value,
      data,
    };
  }

  _versionChanged(ev) {
    const { versionID, id } = ev.detail;
    const elements = this.rowData;
    const index = elements.findIndex(e => e?.id?.toString() === id?.toString());
    this.rowData[index].versionID = '';
    elements[index].versionID = versionID;
    this._cloneRecord(this.rowData[index], elements[index]);
  }

  // eslint-disable-next-line
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  // eslint-disable-next-line
  async addVersionDetails(data1) {
    try {
      let chunkData = await chunks([data1], createVersionDetail, 50);
      if (!chunkData) {
        chunkData = [];
      }

      if (!this.isApiRejected && chunkData.findIndex(item2 => item2.status === 'rejected') > -1) {
        this.isApiRejected = true;
      }

      chunkData = [
        ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
      ];

      let chunkData1 = [];
      chunkData.forEach(item => {
        if (item?.versionDetailsDTO) {
          chunkData1 = [...chunkData1, ...item?.versionDetailsDTO];
        }
      });
      return chunkData1;
      // eslint-disable-next-line
      // data1 = data1.map(i => {
      //   // eslint-disable-next-line
      //   i.versionDetailID = generateId();
      //   return i
      // });
      // return data1;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    try {
      const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
      return res.data ? deriveData(res.data) : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  render() {
    return html`
      <div id="note-creation-area">
        ${this.rowData.map(
          d =>
            html`
              ${this.isExistingDocument
                ? html`<create-new-row
                    @save-row="${this._saveRow}"
                    @remove-row="${this._removeRowSection}"
                    @field-values-changed="${this._fieldValuesChanged}"
                    @row-changed="${this._rowChanged}"
                    id="${d.id}"
                    name="${d.name}"
                    .validity="${d.validity}"
                    rowStyle="${d.style}"
                    .columns="${d.columns}"
                    .columnNotes="${d.columnNotes}"
                    isNew="${d.isNew}"
                    .linkedElement="${d.linkedElement}"
                    ?isExistingDocument="${this.isExistingDocument}"
                    ?isNotSaved="${d.isNotSaved}"
                    .notes="${this.notes}"
                    .lookupData="${this.lookupData}"
                    .rowId="${d.rowId}"
                    .versionID="${d?.versionID}"
                    .savedRow="${this.savedChildList}"
                    ?isModifiedDocument=${this.isModifiedDocument}
                    @versionID-changed="${this._versionChanged}"
                  ></create-new-row>`
                : html`<ing-collapsible collapsibleCustom opened>
                    <ing-collapsible-invoker invokerCustom slot="invoker">
                      <span slot="open">
                        <p class="note-number">${d.name}</p>
                      </span>
                      <span slot="close"></span>
                    </ing-collapsible-invoker>
                    <div contetnSlotCollapsible slot="content">
                      <create-new-row
                        @save-row="${this._saveRow}"
                        @remove-row="${this._removeRowSection}"
                        @field-values-changed="${this._fieldValuesChanged}"
                        @row-changed="${this._rowChanged}"
                        .id="${d.id}"
                        name="${d.name}"
                        .validity="${d.validity}"
                        rowStyle="${d.style}"
                        .columns="${d.columns}"
                        .columnNotes="${d.columnNotes ? [...d.columnNotes] : []}"
                        isNew="${d.isNew}"
                        .linkedElement="${d.linkedElement}"
                        ?isNotSaved="${d.isNotSaved}"
                        .notes="${this.notes}"
                        .lookupData="${this.lookupData}"
                        .ruleData="${this.ruleData}"
                        .rowId="${d.rowId}"
                        .versionID="${d?.versionID}"
                        .savedRow="${this.savedChildList}"
                        @versionID-changed="${this._versionChanged}"
                      ></create-new-row>
                    </div>
                  </ing-collapsible>`}
            `,
        )}
        ${!this.isExistingDocument
          ? html`<div>
              <ing-button id="createNew" class="create-new-button" @click="${this._addRowSection}">
                Crea nuova</ing-button
              >
            </div>`
          : ''}
      </div>
    `;
  }
}
customElements.define('row-creation', RowCreation);
