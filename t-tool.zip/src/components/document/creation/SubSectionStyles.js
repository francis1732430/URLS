import { black80, css, font14Mixin, orange } from 'ing-web';

export default css`
  .section-area {
    width: 100%;
  }
  .section-columns {
    margin-left: 103px;
    margin-top: 45px;
    width: 80%;
  }
  .section-date {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    width: 100%;
  }
  .validate-date {
    margin-right: 129px;
  }
  .section_style {
    width: 180px;
  }
  #validate_date {
    --ing-input-group-width: 180px !important;
  }
  .container {
    height: 30px;
    position: relative;
    margin-top: 56px;
  }

  .right_alignment {
    margin-left: 528px;
  }

  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
  }

  .ing_standard_bottom_line {
    border-bottom: 1px solid ${orange};
    margin-top: 40px;
  }

  #section_name {
    width: 812px;
    height: 48px;
  }

  [subSectionTextArea] {
    width: 812px;
  }

  [subsectiontextarea] {
    margin-bottom: 0px !important;
  }
  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
    color: ${black80};
  }
`;
