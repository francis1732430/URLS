import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngInput,
  IngChipFilter,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngIcon,
} from 'ing-web';
import {
  transformSectionsToBackend,
  transformSectionsToBackendForPatch,
  transformSectionsToFrontEnd,
} from '../../../data/tranformations/sectionTransformation.js';
import {
  transformSubSectionsToBackend,
  transformSubSectionsToBackendForPatch,
  transformSubSectionsToFrontEnd,
} from '../../../data/tranformations/subSectionsTransformation.js';
import { baseURL, baseURL2, localStorageKeysMap } from '../../../utils/constants.js';
import { ajaxInstance } from '../../../utils/endpoints.js';
import {
  addElementToLocalStorage,
  generateId,
  removeElementFromLocalStorage,
} from '../../../utils/IngFeatTransparencyToolUtils.js';
import { transformLookUpDataToFrontEnd } from '../../../data/tranformations/documentTranformation.js';

import styles from './CreateSubSectionStyles.js';
import { SubSection } from './SubSection.js';
import { chunks, createRelations, removeRelations } from '../../../utils/chunks.js';

export class CreateSubSection extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'sub-section': SubSection,
      'chip-filter': IngChipFilter,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-icon': IngIcon,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      subSectionsData: Array,
      currentStep: String,
      subSectionsList: Array,
      rows: Array,
      isExistingDocument: { type: Boolean, reflect: true },
      styleList: Array,
      lookupData: Array,
      isModifiedDocument: { type: Boolean, reflect: true },
      isVersionChanged: { type: Boolean, reflect: true },
      savedChildList: Array,
      isSelectedStatus: Boolean,
    };
  }

  constructor() {
    super();
    this.subSectionsData = [];
    this.rows = [];
    this.selectedList = {};
    this.styleList = [];
    this.ajaxInstance = ajaxInstance;
    this.lookupData = [];
    this.savedChildList = [];
    this.isSelectedStatus = false;
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed.has('subSectionsData') &&
      (!this.subSectionsData ||
        (this.subSectionsData && !this.subSectionsData.length) ||
        this.subSectionsData === 'undefined')
    ) {
      this.subSectionsData = [
        {
          id: generateId(),
          name: '',
          description: '',
          validity: new Date(),
          sectionStyle: '',
          isNotSaved: true,
        },
      ];
    } else if (
      (changed.has('subSectionsData') && this.subSectionsData && this.subSectionsData?.length) ||
      (this.subSectionsData !== 'undefined' && this.isSelectedStatus === false)
    ) {
      this.subSectionsData.forEach(item1 => {
        if (item1?.id && this.selectedList[item1?.id] && !item1?.isNotSaved) {
          this.selectedList[item1?.id] = JSON.parse(JSON.stringify([{ ...item1 }]));
        }
      });
    }

    if (changed.has('lookupData') && this.lookupData.length > 0 && this.styleList.length === 0) {
      this.styleList = transformLookUpDataToFrontEnd(this.lookupData, 'STILE');
    }
    if (this.isVersionChanged === true) {
      this.selectedList = [];
    }
  }

  // eslint-disable-next-line class-methods-use-this
  _postData(data, isSubSection) {
    const fn = isSubSection ? transformSubSectionsToBackend : transformSectionsToBackend;
    const dataBackend = fn(data);
    return this.ajaxInstance.post(baseURL, dataBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _putData(data, isSubSection) {
    const fn = isSubSection
      ? transformSubSectionsToBackendForPatch
      : transformSectionsToBackendForPatch;
    const dataBackend = fn(data);
    return this.ajaxInstance.patch(`${baseURL}/version`, dataBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _deleteData(data) {
    return this.ajaxInstance.delete(`${baseURL}/${data}`);
  }

  async _addSubSection(ev) {
    const { data } = ev.detail;
    let data1 = { ...data };
    this.isSelectedStatus = true;
    if (
      this.currentStep === 'section' &&
      this.selectedList[data1.id] &&
      this.selectedList[data1.id].length > 0
    ) {
      data1.subSections = this.selectedList[data1.id][0].subSections;
      if (data1.subSections) {
        data1.subSections = data1.subSections.filter(
          (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
        );
      }
    }
    if (
      this.currentStep === 'subsection' &&
      this.selectedList[data1.id] &&
      this.selectedList[data1.id].length > 0
    ) {
      data1.rows = this.selectedList[data1.id][0].rows;
      if (data1.rows) {
        data1.rows = data1.rows.filter(
          (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
        );
      }
    }
    const index = this.subSectionsData.findIndex(
      subSection => subSection?.id?.toString() === data1?.id?.toString(),
    );
    let removedItems = [];
    let createdItems = [];
    if (this.savedChildList) {
      let currentList = [];
      let savedList = [];
      if (this.currentStep === 'section') {
        currentList = data1?.subSections;
        savedList = this.savedChildList.find(
          item2 => item2?.id?.toString() === data1?.id?.toString(),
        )?.subSections;
      }

      if (this.currentStep === 'subsection') {
        currentList = data1?.rows;
        savedList = this.savedChildList.find(
          item2 => item2?.id?.toString() === data1?.id?.toString(),
        )?.rows;
      }

      currentList = currentList?.length && JSON.parse(JSON.stringify(currentList));
      savedList = savedList?.length && JSON.parse(JSON.stringify(savedList));

      if (currentList?.length && savedList?.length) {
        removedItems = this.getRemovedItems(savedList, currentList);
      } else if (
        (currentList?.length === 0 || currentList?.length === undefined) &&
        savedList?.length
      ) {
        removedItems = savedList;
      }

      if (currentList?.length && savedList?.length) {
        createdItems = this.getNewlyCreatedItems(savedList, currentList);
      } else if (
        currentList?.length > 0 &&
        (savedList?.length === 0 || savedList?.length === undefined)
      ) {
        createdItems = currentList;
      }
    }

    let isPatchRequest = false;
    const process = async res => {
      // data1.id = generateId();
      // data1.name = data1.id
      this.subSectionsData[index] = data1;
      this.subSectionsData[index].isNotSaved = false;
      this.subSectionsData = [...this.subSectionsData];

      if (removedItems?.length) {
        // eslint-disable-next-line
        const chunkItems = removedItems.map(item => {
          return {
            parentId: data1?.id,
            childId: item.id,
          };
        });
        await chunks(chunkItems, removeRelations, 50);
      }

      if (createdItems?.length && isPatchRequest) {
        // eslint-disable-next-line
        const chunkItems = createdItems.map(item => {
          const listDatas =
            this.subSectionsData[index][this.currentStep === 'subsection' ? 'rows' : 'subSections'];
          const index34 = listDatas?.findIndex(
            item11 => item11?.id?.toString() === item?.id?.toString(),
          );
          return {
            parentId: data1?.id,
            childId: item.id,
            order: index34 > -1 ? index34 + 1 : index34,
          };
        });
        await chunks(chunkItems, createRelations, 50);
      }

      this.savedChildList = this.subSectionsData;
      this.savedChildList = JSON.parse(JSON.stringify(this.savedChildList));

      if (removedItems && removedItems?.length) {
        if (this.currentStep === 'section') {
          this.savedChildList[index].subSections = this.savedChildList[index].subSections.filter(
            item3 => {
              const index1 = removedItems.findIndex(
                item4 => item3?.id?.toString() === item4?.id?.toString(),
              );
              if (index1 > -1) {
                return false;
              }
              return true;
            },
          );
        } else if (this.currentStep === 'subsection') {
          this.savedChildList[index].rows = this.savedChildList[index].rows.filter(item3 => {
            const index2 = removedItems.findIndex(
              item4 => item3?.id?.toString() === item4?.id?.toString(),
            );
            if (index2 > -1) {
              return false;
            }
            return true;
          });
        }
      }
      isPatchRequest = false;
      // eslint-disable-next-line no-console
      console.log(createdItems, removedItems, this.savedChildList);
      const eventData = new CustomEvent('event-section-added', {
        detail: {
          list: this.subSectionsData,
          data1: { ...data1 },
          res,
          savedChildList: this.savedChildList,
        },
      });
      this.dispatchEvent(eventData);
      this.isSelectedStatus = false;
      // if (!isPatchRequest) {
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(
          this.savedChildList[index],
          this.currentStep === 'section'
            ? localStorageKeysMap.APPLICATION_SECTIONS
            : localStorageKeysMap.APPLICATION_SUBSECTIONS,
        );
      // }
    };
    if (this.subSectionsData[index]?.versionDetailLevel0IDStyle && data) {
      data1.versionDetailLevel0IDStyle = this.subSectionsData[index]?.versionDetailLevel0IDStyle;
    }
    if (this.subSectionsData[index]?.versionDetailLevel0IDDescription && data) {
      data1.versionDetailLevel0IDDescription =
        this.subSectionsData[index]?.versionDetailLevel0IDDescription;
    }
    if (!this.subSectionsData[index].isNotSaved) {
      try {
        const res = await this._putData(data1, this.currentStep === 'subsection');
        this._showStatusEvent(res);
        isPatchRequest = true;
        process(res);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._putData(data)', e);
      }
    } else {
      try {
        // eslint-disable-next-line no-unused-expressions
        !this.isModifiedDocument &&
          !this.isExistingDocument &&
          removeElementFromLocalStorage(
            this.subSectionsData[index].id,
            this.currentStep === 'section'
              ? localStorageKeysMap.APPLICATION_SECTIONS
              : localStorageKeysMap.APPLICATION_SUBSECTIONS,
          );
        const res = await this._postData(data1, this.currentStep === 'subsection');
        this._showStatusEvent(res);
        const res1 = await this._getVersionItemDetail(res?.data?.itemsVersionsID);
        if (this.currentStep === 'section') {
          data1 = transformSectionsToFrontEnd(res1?.data);
          data1.sectionId = res1?.data?.itemID?.toString();
        } else if (this.currentStep === 'subsection') {
          data1 = transformSubSectionsToFrontEnd(res1?.data);
          data1.subSectionId = res1?.data?.itemID?.toString();
        }
        process(res);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._postData(data)', e);
      }
    }
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      let url = `${baseURL2}/version/${id}`;
      if (this.currentStep === 'subsection') {
        url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
      }
      return await this.ajaxInstance.get(url);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  async _removeSubSection(ev) {
    const { id } = ev.detail;
    const process = () => {
      if (this.isExistingDocument) {
        this.subSectionsData = this.subSectionsData.filter(
          data => data?.id?.toString() !== id?.toString(),
        );
      }
      const eventData = new CustomEvent('event-section-removed', {
        detail: { data: this.subSectionsData, id },
      });
      this.dispatchEvent(eventData);
    };
    // if (!this.subSectionsData[index]?.isNotSaved) {
    //   try {
    //     // await this._deleteData(id);
    //     process();
    //   } catch (e) {
    //     // eslint-disable-next-line no-console
    //     console.log('failed this._deleteData(data)', e);
    //   }
    // } else if (this.subSectionsData.length > 1) {
    //   process();
    // }
    process();
    if (this.currentStep === 'subsection' && this.rows) {
      this.rows = [...this.rows];
    } else if (this.currentStep === 'section' && this.subSectionsList) {
      this.subSectionsList = [...this.subSectionsList];
    }
  }

  _addNewSubSection() {
    this.subSectionsData = [
      ...this.subSectionsData,
      {
        id: generateId(),
        name: '',
        description: '',
        validity: new Date(),
        sectionStyle: '',
        isNotSaved: true,
      },
    ];
  }

  associatedList(ev) {
    const { selectedList, id } = ev.detail;
    this.selectedList[id] = selectedList;
  }

  _fieldValuesChanged(ev) {
    const { id, data } = ev.detail;
    clearTimeout(this.valuesChangedTimeout);
    this.valuesChangedTimeout = setTimeout(() => {
      const eventData = new CustomEvent('field-values-changed', {
        detail: { id },
      });
      this.dispatchEvent(eventData);
      let rows = [];
      let subSections = [];
      if (this.selectedList) {
        const subData = this.selectedList[id];
        if (subData && subData.length) {
          rows = subData[0].rows;
          subSections = subData[0].subSections;
        }
      }
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(
          { ...data, rows, subSections },
          this.currentStep === 'section'
            ? localStorageKeysMap.APPLICATION_SECTIONS
            : localStorageKeysMap.APPLICATION_SUBSECTIONS,
        );
    }, 300);
  }

  _showStatusEvent(data, type) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data,
        type,
      },
    });
    this.dispatchEvent(ev);
  }

  // eslint-disable-next-line
  getRemovedItems(savedList, currentList) {
    return savedList.filter(item => {
      const index = currentList.findIndex(item1 => item1?.id?.toString() === item?.id?.toString());
      if (index === -1) {
        return true;
      }
      return false;
    });
  }

  // eslint-disable-next-line
  getNewlyCreatedItems(savedList, currentList) {
    return currentList.filter(item => {
      const index = savedList.findIndex(item1 => item1?.id?.toString() === item?.id?.toString());
      if (index === -1) {
        return true;
      }
      return false;
    });
  }

  render() {
    return html` <div class="create-sub-section">
      ${this.subSectionsData.map(
        d =>
          html`
            ${this.isModifiedDocument
              ? html`<sub-section
                  ?_isNew=${false}
                  _id="${d.id}"
                  .data="${d}"
                  .rows="${this.rows}"
                  .subSectionsList="${this.subSectionsList}"
                  name="${d.name}"
                  description="${d.description}"
                  validity="${d.validity}"
                  sectionStyle="${d.sectionStyle}"
                  _currentStep="${this.currentStep}"
                  .linkedElement="${d.linkedElement}"
                  .attachedRows="${d.rows}"
                  .attachedSubSections="${d.subSections}"
                  .styleList="${this.styleList}"
                  @new-sub-section-added="${this._addSubSection}"
                  @remove-sub-section="${this._removeSubSection}"
                  @associated-list="${this.associatedList}"
                  @field-values-changed="${this._fieldValuesChanged}"
                  ?isExistingDocument=${this.isExistingDocument}
                  ?isModifiedDocument=${this.isModifiedDocument}
                  ?isNotSaved=${d.isNotSaved}
                ></sub-section>`
              : html`<ing-collapsible collapsibleCustom opened>
                  <ing-collapsible-invoker invokerCustom slot="invoker">
                    <span slot="open">
                      <p class="section-number">${d.name}</p>
                    </span>
                    <span slot="close"></span>
                  </ing-collapsible-invoker>
                  <div contetnSlotCollapsible slot="content">
                    <sub-section
                      ?_isNew=${false}
                      _id="${d.id}"
                      .data="${d}"
                      .rows="${this.rows}"
                      .subSectionsList="${this.subSectionsList}"
                      name="${d.name}"
                      description="${d.description}"
                      validity="${d.validity}"
                      sectionStyle="${d.sectionStyle}"
                      _currentStep="${this.currentStep}"
                      .linkedElement="${d.linkedElement}"
                      .attachedRows="${d.rows}"
                      .attachedSubSections="${d.subSections}"
                      .styleList="${this.styleList}"
                      @new-sub-section-added="${this._addSubSection}"
                      @remove-sub-section="${this._removeSubSection}"
                      @associated-list="${this.associatedList}"
                      @field-values-changed="${this._fieldValuesChanged}"
                      ?isExistingDocument=${this.isExistingDocument}
                      ?isModifiedDocument=${this.isModifiedDocument}
                      ?isNotSaved=${d.isNotSaved}
                    ></sub-section>
                  </div>
                </ing-collapsible>`}
          `,
      )}
      ${!this.isExistingDocument
        ? html`<div>
            <ing-button
              id="createNew"
              class="create-new-button add-btn"
              @click="${this._addNewSubSection}"
            >
              Crea nuova</ing-button
            >
          </div>`
        : ''}
    </div>`;
  }
}
customElements.define('create-sub-section', CreateSubSection);
