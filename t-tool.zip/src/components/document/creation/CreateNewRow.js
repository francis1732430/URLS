import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngButton,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngSelect,
} from 'ing-web';
import { RowDefination } from './RowDefination.js';
import { radioData } from '../../../data/rowCreationData.js';
import styles from './CreateNewRowStyles.js';
import { generateId } from '../../../utils/IngFeatTransparencyToolUtils.js';
import { transformLookUpDataToFrontEnd } from '../../../data/tranformations/documentTranformation.js';

export class CreateRow extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-button': IngButton,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-select': IngSelect,
      'row-defination': RowDefination,
    };
  }

  static get properties() {
    return {
      name: { type: String },
      validity: { type: Object },
      rowStyle: { type: String },
      columns: { type: Array },
      columnNotes: { type: Array },
      linkedElement: Boolean,
      isExistingDocument: { type: Boolean, reflect: true },
      notes: Array,
      rowStyles: Array,
      lookupData: Array,
      ruleData: Array,
      isModifiedDocument: { type: Boolean, reflect: true },
      rowId: String,
      isNotSaved: { type: Boolean, reflect: true },
      versionID: String,
      savedRow: Array,
      _disabledButton: { type: Boolean, reflect: true },
      _disabledDebounce: Array,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.validity = new Date();
    this.rowStyles = [];

    this.radioData = radioData;
    this.columns = [];
    this.lookupData = [];
    this._disabledButton = true;
  }

  firstUpdated() {
    super.firstUpdated();
    if (this.columns.length === 0) {
      this.columns = [
        {
          id: generateId(),
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
        },
      ];
    }
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('validity') && (!this.validity || this.validity === 'undefined')) {
      this.validity = new Date();
    }
    if (changed.has('lookupData') && this.lookupData.length > 0 && this.rowStyles.length === 0) {
      this.rowStyles = transformLookUpDataToFrontEnd(this.lookupData, 'STILE');
    }
    if (changed.has('columns') && this.columns.length === 0) {
      this.columns = [
        {
          id: generateId(),
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
        },
      ];
      this.columnNotes = [];
    }
  }

  handleChange(event) {
    if (event.target.name === 'validity') {
      this[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this[event.target.name] = event.target.value;
    }
    this._fieldValuesChanged();
  }

  columnsChanged(event) {
    let columnNotes = [];
    if (event.detail.data?.length) {
      event.detail.data.forEach(c => {
        columnNotes = [
          ...columnNotes,
          ...this.columnNotes.filter(cn => cn?.columnId?.toString() === c?.id?.toString()),
        ];
      });
    } else {
      columnNotes = [];
    }

    this.columnNotes = [...columnNotes];
    this.columns = this.bindColumnName(event.detail.data);
    if (event.detail?.isDelete) {
      this.columns = this.bindColumnName(event.detail.data);
      const columns1 = this.columns;
      this.columns = [];
      if (this.clearTimeout1) {
        clearTimeout(this.clearTimeout1);
      }
      this.clearTimeout1 = setTimeout(() => {
        this.columnNotes = [...columnNotes];
        this.columns = [...columns1];
        this._fieldValuesChanged();
      }, 350);
    }

    if (this.notes?.length && this.columnNotes?.length) {
      this.notes.forEach(opt => {
        this.columnNotes = this.columnNotes.map(el1 => {
          if (el1?.id?.toString() === opt?.id?.toString()) {
            // eslint-disable-next-line
            el1.name = opt.name;
          }
          return el1;
        });
      });
      this.columnNotes = [...this.columnNotes];
    }

    this._fieldValuesChanged();
  }

  bindColumnName(list) {
    return (
      list?.map((col, i) => {
        if (col?.name) {
          // eslint-disable-next-line
          col.name = i + 1;
          this.columnNotes = this.columnNotes.map(cn => {
            if (cn?.columnId?.toString() === col?.id?.toString()) {
              // eslint-disable-next-line
              cn.columnName = col.name;
            }
            return cn;
          });
        }
        return col;
      }) || []
    );
  }

  _hydrateSelect(i, d, fieldName, callback) {
    if (!this[fieldName] && i === 0) {
      this[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this[fieldName]?.toString() === d?.id?.toString()) return true;
    return false;
  }

  _cancel() {
    const event = new CustomEvent('remove-row', {
      detail: { id: this.id },
    });
    this.dispatchEvent(event);
  }

  _save() {
    if (!this.linkedElement) {
      const event = new CustomEvent('save-row', {
        detail: {
          id: this.id,
          name: this.name,
          validity: this.validity,
          style: this.rowStyle,
          columns: this.columns,
          columnNotes: this.columnNotes,
          isNotSaved: this.isNotSaved,
          rowId: this.rowId,
        },
      });
      this.dispatchEvent(event);
    }
  }

  _columnNotesHandler(event) {
    this.columnNotes = event?.detail?.data;
    this._fieldValuesChanged();
  }

  _fieldValuesChanged() {
    const eventData = new CustomEvent('field-values-changed', {
      detail: {
        id: this.id,
        data: {
          id: this.id,
          name: this.name,
          validity: this.validity,
          style: this.rowStyle,
          columns: this.columns,
          columnNotes: this.columnNotes,
          isNotSaved: this.isNotSaved,
          rowId: this.rowId,
          versionID: this.versionID,
        },
      },
    });
    this._computeDisabledButon(eventData.detail.data);
    this.dispatchEvent(eventData);
  }

  _computeDisabledButon(data) {
    clearTimeout(this._disabledDebounce);
    this._disabledDebounce = setTimeout(() => {
      this._disabledButton = !(data.name && data.columns?.every(d => d.description));
    }, 100);
  }

  getSaveBtnText() {
    if (this.isModifiedDocument) {
      return 'Salva e chiudi';
      // eslint-disable-next-line
    } else if (this.isExistingDocument) {
      return 'Aggiungi e Chiudi';
      // eslint-disable-next-line
    } else {
      return 'Salva';
    }
  }

  _rowChanged() {
    const e = new CustomEvent('row-changed', {
      detail: {
        id: this.id,
      },
    });
    this.dispatchEvent(e);
  }

  _versionChanged(ev) {
    const e = new CustomEvent('versionID-changed', {
      detail: {
        versionID: ev.detail,
        id: this.id,
      },
    });
    this.dispatchEvent(e);
  }

  render() {
    return html`
      <div class="create-row-container">
        ${this.noteAreaIndex}
        <div>
          <ing-input
            @keyup="${this.handleChange}"
            name="name"
            id="note_name"
            .modelValue="${this.name}"
            class="note_name"
            label="NOME"
            inputElement
            ?disabled="${this.linkedElement}"
          ></ing-input>
        </div>
        <div class="container">
          <div class="inline-block-el">
            <ing-input-datepicker
              id="note_from"
              class="note_from"
              label="VALIDO DAL"
              name="validity"
              inputElement
              .modelValue=${new Date(this.validity)}
              ?disabled="${this.linkedElement}"
              @change="${this.handleChange}"
              @click="${this.handleChange}"
            ></ing-input-datepicker>
          </div>
          <div class="inline-block-el select-row">
            <ing-select
              @change="${this.handleChange}"
              name="rowStyle"
              label="STILE"
              inputElement
              ?disabled="${this.linkedElement}"
            >
              <select slot="input" name="rowStyle">
                ${this.rowStyles.map(
                  (d, i) =>
                    html`<option
                      ?selected="${this._hydrateSelect(i, d, 'rowStyle')}"
                      value="${d.id}"
                    >
                      ${d.name}
                    </option>`,
                )}
              </select>
            </ing-select>
          </div>
        </div>
        <div class="seperator"></div>
        <row-defination
          headerText="DEFINIZIONE RIGA"
          column1Text="COLONNA"
          column2Text="DESCRIZIONE IN STAMPA"
          column3Text=""
          radioLabel="radio"
          .radioData="${this.radioData}"
          @columns-changed="${this.columnsChanged}"
          .elementsData="${this.columns}"
          .linkedElement="${this.linkedElement}"
          .ruleData="${this.ruleData}"
          ?isNotSaved="${this.isNotSaved}"
          .versionID="${this.versionID}"
          .rowId="${this.rowId}"
          .id="${this.id}"
          .savedRow="${this.savedRow}"
          @row-changed="${this._rowChanged}"
          @versionID-changed="${this._versionChanged}"
        ></row-defination>
        <row-defination
          headerText="NOTE"
          column1Text="COLONNA"
          column2Text="SCEGLIERE NOTA"
          column3Text=""
          selectLabel="Select"
          .selectData="${this.columns}"
          .select2Data="${this.notes}"
          .columnNotes="${this.columnNotes}"
          .linkedElement="${this.linkedElement}"
          ?isNotSaved="${this.isNotSaved}"
          .versionID="${this.versionID}"
          .rowId="${this.rowId}"
          .id="${this.id}"
          .savedRow="${this.savedRow}"
          @column-notes-changed=${this._columnNotesHandler}
          @row-changed="${this._rowChanged}"
          @versionID-changed="${this._versionChanged}"
        ></row-defination>
      </div>
      <div class="container">
        <div class="right_alignment">
          <ing-button outline indigo font14 class="cancel_button" @click="${this._cancel}"
            >${this.isExistingDocument ? 'Annulla' : 'Cancella'}</ing-button
          >
          <ing-button
            indigo
            ?disabled="${this._disabledButton || this.linkedElement}"
            font14
            class="save_button"
            @click=${this._save}
            >${this.getSaveBtnText()}</ing-button
          >
        </div>
      </div>
    `;
  }
}
customElements.define('create-row', CreateRow);
