import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngRadio,
  IngRadioGroup,
  IngSelect,
  IngButton,
  IngCheckbox,
} from 'ing-web';
import styles from './RowElementsStyles.js';
import { CustomSelect } from '../../customSelect/CustomSelect.js';
import { getSortedList } from '../../../utils/IngFeatTransparencyToolUtils.js';

export class RowElements extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-select': IngSelect,
      'ing-radio-group': IngRadioGroup,
      'ing-radio': IngRadio,
      'ing-button': IngButton,
      'ing-checkbox': IngCheckbox,
      'custom-select': CustomSelect,
    };
  }

  static get properties() {
    return {
      input1Val: { type: String },
      input2Val: { type: String },
      radioVal: { type: String },
      selectVal: { type: String },
      selectLabel: { type: String },
      radioLabel: { type: String },
      selectData: { type: Array },
      radioData: { type: Array },
      isNew: { type: Boolean },
      select2Val: { type: String },
      select2Data: { type: Array },
      debounceTime: { type: Number },
      checkedData: { type: Array },
      linkedElement: Boolean,
      isBold: Boolean,
      isItalic: Boolean,
      selectedNotes: Array,
      tempSelectedNotesList: Array,
      removeColumnNoteId: String,
    };
  }

  constructor() {
    super();
    this.selectData = [];
    this.radioData = [];
    this.selectVal = null;
    this.selectedNotes = [];
    this.isTextAreaFocused = false;
  }

  static get styles() {
    return styles;
  }

  update(changedProps) {
    super.update(changedProps);

    if (changedProps.get('select2Data') && (!this.select2Val || this.select2Val === 'undefined')) {
      this.select2Val = undefined;
    }
    if (
      changedProps.get('selectData') &&
      changedProps.get('selectData').length &&
      this.selectLabel
    ) {
      this.select2Val = undefined;
      // this.selectVal = undefined;
      this.select2Data = [...this.select2Data];
    }

    if (changedProps.has('input2Val') && this.input2Val && !this.isTextAreaFocused) {
      setTimeout(() => {
        const a = this.shadowRoot.querySelector('[rowcolumndescription] textarea');
        if (a && a?.style?.maxHeight?.toString() !== '40px') {
          a.style.maxHeight = '40px';
        }
      });
    }
  }

  handleChange(e) {
    const { name, value, checked } = e.target;
    const isSwitch = e.currentTarget.nodeName.match(/(ing-switch|ing-checkbox)/i);
    clearTimeout(this.debounceTime);
    this.debounceTime = setTimeout(() => {
      this[name] = isSwitch ? checked : value;
      this._addElements();
    }, 0);
  }

  _addElements() {
    const event = new CustomEvent('add-new-elements', {
      detail: {
        isNew: this.isNew,
        data: {
          id: this.id,
          name: this.input1Val,
          description: this.input2Val,
          isBold: this.isBold,
          isItalic: this.isItalic,
          column: this.selectVal || '',
          note: this.select2Val || '',
          notesList:
            this.tempSelectedNotesList?.filter(
              note => note?.columnId1?.toString() === this.selectVal?.toString(),
            ) || [],
        },
      },
    });
    this.dispatchEvent(event);
  }

  _handleCheckboxChange() {
    const event = new CustomEvent('checked-fields', {
      detail: {
        id: this.id,
      },
    });
    this.dispatchEvent(event);
  }

  _hydrateSelect(i, d, fieldName, callback, array) {
    if (!this[fieldName] && i === 0) {
      this[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this[fieldName]?.toString() === d?.id?.toString()) return true;
    if (array && array.length - 1 === i) {
      const ids = array.map(el => el?.id?.toString());
      if (ids.indexOf(this[fieldName].toString()) === -1) {
        this[fieldName] = array[0].id;
        // eslint-disable-next-line no-unused-expressions
        callback && callback(null, this[fieldName]);
      }
    }
    return false;
  }

  _fireColumnChangedEvent(event, id) {
    const e = new CustomEvent('column-select-changed', {
      detail: {
        id: event ? event.target.value : id,
      },
    });
    this.dispatchEvent(e);
  }

  _fireNoteChangedEvent(event, ids, unCheckedId, unCheckedIds) {
    const e = new CustomEvent('note-select-changed', {
      detail: {
        ids: event ? event.target.value : ids,
        unCheckedId,
        columnId1: this.selectVal,
        unCheckedIds,
      },
    });
    this.dispatchEvent(e);
  }

  handleColumnChange(event) {
    this._fireColumnChangedEvent(event);
    this.handleChange(event);
    this.select2Val = undefined;
  }

  handleNoteChange(ev) {
    const { selectedOptions, unCheckedId } = ev.detail;
    this._fireNoteChangedEvent(null, selectedOptions || [], unCheckedId);
    clearTimeout(this.debounceTime);
    this.debounceTime = setTimeout(() => {
      const event = new CustomEvent('add-new-elements', {
        detail: {
          isNew: this.isNew,
          data: {
            id: this.id,
            name: this.input1Val,
            description: this.input2Val,
            isBold: this.isBold,
            isItalic: this.isItalic,
            column: this.selectVal || '',
            note: this.select2Val || '',
            notesList: selectedOptions || [],
          },
        },
      });
      this.dispatchEvent(event);
    }, 350);
  }

  handleSwitchChange(name) {
    return event => {
      // eslint-disable-next-line no-param-reassign
      event.target.name = name;
      this.handleChange(event);
    };
  }

  focusOutTextArea() {
    const a = this.shadowRoot.querySelector('[rowcolumndescription] textarea');
    if (a) {
      a.style.width = '250px';
      a.style.height = '40px';
      a.style['z-index'] = 0;
    }
    if (a && a.style['max-height'] !== '40px') {
      a.style.maxHeight = '40px';
    }
    this.isTextAreaFocused = false;
  }

  focusElement() {
    const a = this.shadowRoot.querySelector('[rowcolumndescription] textarea');
    if (a && a.style['max-height'] !== '162px') {
      a.style.height = '40px';
      a.style.maxHeight = '162px';
    }
    if (a) {
      a.focus();
      a.style['z-index'] = 10;
    }
    this.isTextAreaFocused = true;
  }

  render() {
    return html`
      <div class="container">
        ${!this.selectLabel
          ? html` <ing-checkbox
              id="${this.id}"
              ?checked="${this.checkedData.indexOf(this.id) > -1}"
              @change="${this._handleCheckboxChange}"
              rowElementsCheckbox
              ?disabled="${this.linkedElement}"
            ></ing-checkbox>`
          : ''}

        <div class="inline-block-el ${this.selectLabel ? ' ' : ' short-block'}">
          ${this.selectLabel
            ? html`
                <ing-select
                  name="selectVal"
                  @change="${this.handleColumnChange}"
                  ?disabled="${this.linkedElement}"
                >
                  <select name="selectVal" slot="input">
                    ${this.selectData.map((d, i) =>
                      d.isNew
                        ? ''
                        : html`<option
                            value="${d.id}"
                            ?selected="${this._hydrateSelect(
                              i,
                              d,
                              'selectVal',
                              this._fireColumnChangedEvent.bind(this),
                              this.selectData,
                            )}"
                          >
                            ${d.name}
                          </option>`,
                    )}
                  </select>
                </ing-select>
              `
            : html`<ing-input
                @keyup="${this.handleChange}"
                name="input1Val"
                .modelValue="${this.input1Val}"
                class="note_name short-input"
                ?disabled="${true}"
              ></ing-input>`}
        </div>
        <div class="inline-block-el inline-block-el-col2 ${this.selectLabel ? 'w-50' : ''}">
          ${this.selectLabel
            ? html`
                <custom-select
                  propKey="name"
                  .displayData="${getSortedList(this.select2Data)}"
                  .selectedOptions="${this.selectedNotes}"
                  .columnId="${this.selectVal}"
                  .removeColumnNoteId="${this.removeColumnNoteId}"
                  .linkedElement="${this.linkedElement}"
                  @value-change="${this.handleNoteChange}"
                >
                </custom-select>
              `
            : html`<ing-textarea
                @keyup="${this.handleChange}"
                @blur="${this.focusOutTextArea}"
                @mousedown="${this.focusElement}"
                @mouseup="${this.focusElement}"
                @click="${this.focusElement}"
                name="input2Val"
                rowcolumndescription
                .modelValue="${this.input2Val}"
                ?disabled="${this.linkedElement}"
                class="note_name row_descriptions"
                style="width: 250px;height: 40px;"
              >
              </ing-textarea>`}
        </div>
        ${this.radioLabel
          ? html`
              <div class="inline-block-el checkbox-group">
                <div class="checkbox-item">
                  <label>BOLD</label>
                  <ing-checkbox
                    name="isBold"
                    ?checked=${this.isBold}
                    rule-checkbox
                    @change="${this.handleSwitchChange('isBold')}"
                    ?disabled="${this.linkedElement}"
                    rowElementsCheckbox
                  ></ing-checkbox>
                </div>
                <div class="checkbox-item">
                  <label>ITALIC</label>
                  <ing-checkbox
                    ?checked="${this.isItalic}"
                    name="isItalic"
                    rule-checkbox
                    @change="${this.handleSwitchChange('isItalic')}"
                    rowElementsCheckbox
                    ?disabled="${this.linkedElement}"
                  ></ing-checkbox>
                </div>
              </div>
            `
          : ''}
      </div>
    `;
  }
}
customElements.define('row-elements', RowElements);
