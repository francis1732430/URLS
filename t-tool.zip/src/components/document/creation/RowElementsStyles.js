import { css, font14Mixin } from 'ing-web';

export default css`
  .inline-block-el {
    display: inline-block;
    vertical-align: top;
    margin-top: 10px;
    min-width: 15rem;
  }
  .container::before {
    display: inline-table;
    clear: both;
  }
  [rowRadioGroup] {
    display: inline-flex;
    width: 15rem;
    margin-top: 0.4rem;
  }
  [rowRadioItem] {
    width: 5rem;
    margin: 0px 0px 0px 1.52rem;
    display: inline-flex;
    text-align: center;
    text-indent: 3px;
  }
  [rowElementsCheckbox] {
    display: inline-block;
    margin-top: 16px;
  }
  .inline-block-el-col2 {
    margin-left: 24px;
  }
  [rule-checkbox] {
    position: relative;
    bottom: 14px;
  }
  .checkbox-group {
    display: inline-flex !important;
    width: 15rem !important;
    margin-top: -0.6rem !important;
  }
  .checkbox-group label {
    display: block;
  }
  .checkbox-item {
    width: 200px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    ${font14Mixin()}
  }
  .inline-block-el .short-input {
    width: 82px;
  }
  .inline-block-el.short-block {
    min-width: 5rem;
  }
  [rowcolumndescription] textarea {
    resize: both !important;
    overflow-wrap: break-word;
    width: 250px;
    height: 40px;
    max-height: 162px;
    position: absolute;
    background: white;
    z-index: 0;
    max-width: 866px;
  }
  .textarea-select {
    // width: 500px;
    padding: 8px 16px;
  }
  .textarea-select option {
    font-size: 14px;
    padding: 8px 8px 8px 28px;
    position: relative;
    color: #999;
  }
  .textarea-select option:before {
    content: '';
    position: absolute;
    height: 18px;
    width: 18px;
    top: 0;
    bottom: 0;
    margin: auto;
    left: 0px;
    border: 1px solid #ccc;
    border-radius: 2px;
    z-index: 1;
  }
  .textarea-select option:checked:after {
    content: attr(title);
    background: #fff;
    color: black;
    position: absolute;
    width: 100%;
    height: 100%;
    left: 0;
    top: 0;
    padding: 8px 8px 8px 28px;
    border: none;
  }
  .textarea-select option:checked:before {
    border-color: blue;
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMC42MSA4LjQ4Ij48ZGVmcz48c3R5bGU+LmNscy0xe2ZpbGw6IzNlODhmYTt9PC9zdHlsZT48L2RlZnM+PHRpdGxlPkFzc2V0IDg8L3RpdGxlPjxnIGlkPSJMYXllcl8yIiBkYXRhLW5hbWU9IkxheWVyIDIiPjxnIGlkPSJfMSIgZGF0YS1uYW1lPSIxIj48cmVjdCBjbGFzcz0iY2xzLTEiIHg9Ii0wLjAzIiB5PSI1LjAxIiB3aWR0aD0iNSIgaGVpZ2h0PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg0Ljk3IDAuMDEpIHJvdGF0ZSg0NSkiLz48cmVjdCBjbGFzcz0iY2xzLTEiIHg9IjUuMzYiIHk9Ii0wLjc2IiB3aWR0aD0iMiIgaGVpZ2h0PSIxMCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoNC44NiAtMy4yNikgcm90YXRlKDQ1KSIvPjwvZz48L2c+PC9zdmc+);
    background-size: 10px;
    background-repeat: no-repeat;
    background-position: center;
  }

  .textarea-select {
    max-width: 300px;
    max-height: 90px;
    overflow: auto;
    display: block;
    width: 180px;
  }
  .w-50 {
    width: 50% !important;
  }
`;
