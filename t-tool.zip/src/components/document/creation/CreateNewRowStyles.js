import { css, black15, font14Mixin } from 'ing-web';

export default css`
  .inline-block-el {
    display: inline-block;
    vertical-align: top;
    margin-top: 35px;
  }
  .container::before {
    display: inline-table;
    clear: both;
  }
  .select-row {
    width: 25rem;
    margin-left: 129px;
  }
  .create-row-container {
    margin-left: 103px;
    margin-top: 45px;
  }
  .seperator {
    background-color: ${black15};
    height: 2px;
    margin: 35px 0px;
  }
  .container {
    margin-bottom: 35px;
  }

  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-right: 135px;
  }

  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }
  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
  }

  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
  }
  .note_name {
    width: 65%;
  }

  .note_from {
    --ing-input-group-width: 180px;
  }
`;
