import { black80, css, font12BoldMixin, font14Mixin, font16BoldMixin, orange } from 'ing-web';

export default css`
  .row-defination-icon {
    width: 1.2rem;
    margin: 0 20px;
  }
  .inline-block-el {
    display: inline-block;
    vertical-align: top;
    margin-top: 35px;
    width: 15rem;
    ${font14Mixin()}
  }
  .container::before {
    display: inline-table;
    clear: both;
  }
  .row-defination-btn {
    height: 28px;
    margin: 0 25px 25px 0;
    width: 80px;
    ${font12BoldMixin()}
  }
  .row-defination-btn:not([disabled]) {
    background: transparent;
    border-color: ${orange};
    color: ${orange};
  }
  .margin-left-2 {
    margin-left: 2rem;
  }
  .row-definition-header {
    ${font16BoldMixin()}
    color: ${black80};
  }
  .inline-block-el-col2 {
    margin-left: 24px;
  }
  .ml-30p {
    margin-left: 30px;
  }
  .short-block {
    width: 6rem;
  }
  .short-block-2 {
    margin-left: 12px;
    width: 12rem;
  }
`;
