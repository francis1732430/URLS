import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngButton,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngSelect,
} from 'ing-web';
import { RuleDefination } from './RuleDefination.js';
import styles from './NewRuleStyles.js';
import { transformLookUpDataToFrontEnd } from '../../../../data/tranformations/documentTranformation.js';
import { ajaxInstance } from '../../../../utils/endpoints.js';
import { generateId } from '../../../../utils/IngFeatTransparencyToolUtils.js';
import { baseURL } from '../../../../utils/constants.js';

export class CreateRule extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-button': IngButton,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-select': IngSelect,
      'rule-defination': RuleDefination,
    };
  }

  static get properties() {
    return {
      name: { type: String },
      validity: { type: Object },
      description: { type: String },
      columns: { type: Array },
      actions: { type: Array },
      selectFieldsData: { type: Object },
      isExistingDocument: { type: Boolean, reflect: true },
      isNotSaved: { type: Boolean, reflect: true },
      linkedElement: Boolean,
      appliesToElements: Array,
      operators: Array,
      sectionsList: Array,
      subSectionsList: Array,
      rows: Array,
      notes: Array,
      docId: String,
      rulesDdl1: Array,
      fileIndice: Array,
      associateRigas: Array,
      lookupData: Array,
      isModifiedDocument: { type: Boolean, reflect: true },
      ruleId: String,
      versionID: String,
      _disabledButton: { type: Boolean, reflect: true },
      _disabledDebounce: Array,
      isTempModification: { type: Boolean, reflect: true },
      docItemId: String,
      docValidityDate: String,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.validity = new Date();
    this.appliesToElements = [];
    this.ajaxInstance = ajaxInstance;
    this.lookupData = [];
    this.operators = [];
    this.fileIndice = [];
    this.associateRigas = [];
    this._disabledButton = true;
  }

  async updated(changed) {
    super.updated(changed);
    if (changed.has('validity') && (!this.validity || this.validity === 'undefined')) {
      this.validity = new Date();
    }

    if (changed.has('lookupData') && this.lookupData?.length > 0 && this.operators?.length === 0) {
      this.operators = transformLookUpDataToFrontEnd(this.lookupData, 'RULE_CONDITION_OPERATOR');
    }

    if (changed.has('lookupData') && this.lookupData?.length > 0 && this.fileIndice?.length === 0) {
      this.fileIndice = transformLookUpDataToFrontEnd(this.lookupData, 'NUMERO_CAMPO_FILE_INDICE');
    }

    if (
      changed.has('lookupData') &&
      this.lookupData?.length > 0 &&
      this.associateRigas?.length === 0
    ) {
      this.associateRigas = transformLookUpDataToFrontEnd(this.lookupData, 'ASSOCIATO_A_RIGA');
    }

    if (changed.has('columns') && this.columns.length === 0) {
      this.columns = [
        {
          id: generateId(),
          column: '',
          value: '',
        },
      ];
    }
  }

  handleChange(event) {
    if (event.target.name === 'validity') {
      this[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this[event.target.name] = event.target.value;
    }
    this._fieldValuesChanged();
  }

  columnsChanged(event) {
    this[event.detail.propertyKey] = [...event.detail.data];
    this._fieldValuesChanged();
  }

  _hydrateSelect(i, d, fieldName, callback) {
    if (!this[fieldName] && i === 0) {
      this[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this[fieldName].toString() === d?.id?.toString()) return true;
    return false;
  }

  _cancel() {
    const event = new CustomEvent('remove-row', {
      detail: { id: this.id },
    });
    this.dispatchEvent(event);
  }

  _save() {
    if (!this.linkedElement) {
      const event = new CustomEvent('save-row', {
        detail: {
          id: this.id,
          name: this.name,
          description: this.description,
          validity: this.validity,
          actions: this.actions,
          conditions: this.columns,
          isNotSaved: this.isNotSaved,
          ruleId: this.ruleId,
        },
      });
      this.dispatchEvent(event);
    }
  }

  _columnNotesHandler(event) {
    this.columnNotes = event?.detail?.data;
    this._fieldValuesChanged();
  }

  _fieldValuesChanged() {
    const eventData = new CustomEvent('field-values-changed', {
      detail: {
        id: this.id,
        data: {
          id: this.id,
          name: this.name,
          description: this.description,
          validity: this.validity,
          actions: this.actions,
          conditions: this.columns,
          isNotSaved: this.isNotSaved,
          ruleId: this.ruleId,
          versionID: this.versionID,
        },
      },
    });
    this._computeDisabledButon(eventData.detail.data);
    this.dispatchEvent(eventData);
  }

  _computeDisabledButon(data) {
    clearTimeout(this._disabledDebounce);
    this._disabledDebounce = setTimeout(() => {
      this._disabledButton = !(
        data.name &&
        data.description &&
        data.conditions?.every(d => d.column && d.value)
      );
    }, 100);
  }

  getSaveBtnText() {
    if (this.isModifiedDocument) {
      return 'Salva';
      // eslint-disable-next-line
    } else if (this.isExistingDocument) {
      return 'Aggiungi e Chiudi';
      // eslint-disable-next-line
    } else {
      return 'Salva';
    }
  }

  _rowChanged() {
    const e = new CustomEvent('row-changed', {
      detail: {
        id: this.id,
      },
    });
    this.dispatchEvent(e);
  }

  _versionChanged(ev) {
    const e = new CustomEvent('versionID-changed', {
      detail: {
        versionID: ev.detail,
        id: this.id,
      },
    });
    this.dispatchEvent(e);
  }

  async _getPreviewData(id) {
    try {
      return await this.ajaxInstance.get(
        `${baseURL}/${id}/version/content?ruleID=${this.id}&versionDate=${this.docValidityDate}`,
      );
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
      return {};
    }
  }

  async _previewRule() {
    const data = await this._getPreviewData(this.docItemId);
    const e = new CustomEvent('preview-rule', {
      detail: {
        id: this.ruleId,
        data: data.data,
      },
    });
    this.dispatchEvent(e);
  }

  render() {
    return html`
      <div class="create-row-container ${this.isModifiedDocument ? 'ml-20' : ''}">
        ${this.noteAreaIndex}
        <div class="rule-info-container">
          <ing-input
            @keyup="${this.handleChange}"
            name="name"
            id="note_name"
            .modelValue="${this.name}"
            class="note_name"
            label="NOME REGOLA"
            inputElement
            ?disabled="${this.linkedElement}"
          ></ing-input>
        </div>
        <div class="rule-info-container description">
          <ing-textarea
            name="description"
            noteTextArea
            label="DESCRIZIONE REGOLA"
            rows="4"
            max-rows="4"
            inputElement
            .modelValue="${this.description}"
            @keyup="${this.handleChange}"
            ?disabled="${this.linkedElement}"
          ></ing-textarea>
        </div>
        <div class="container">
          <div class="inline-block-el">
            <ing-input-datepicker
              id="note_from"
              class="note_from"
              label="VALIDO DAL"
              name="validity"
              inputElement
              ?disabled="${this.linkedElement}"
              .modelValue=${new Date(this.validity)}
              @change="${this.handleChange}"
              @click="${this.handleChange}"
            ></ing-input-datepicker>
          </div>
        </div>
        <div class="seperator"></div>
        <rule-defination
          headerText="CONDIZIONI"
          column1Text="N° CAMPO NEL FILE INDICE"
          column2Text="OPERATORE"
          column3Text="VALORE"
          column4Text="RIGA N°"
          column5Text="IN ASSOCIAZIONE A RIGA N°"
          radioLabel="radio"
          .radioData="${this.radioData}"
          @columns-changed="${this.columnsChanged}"
          .elementsData="${this.columns}"
          .selectData="${this.fileIndice}"
          .select2Data="${this.operators}"
          .select3Data="${this.associateRigas}"
          .selectFieldsData=${this.selectFieldsData}
          .linkedElement="${this.linkedElement}"
          .rulesDdl1="${this.rulesDdl1}"
          ?isNotSaved="${this.isNotSaved}"
          .versionID="${this.versionID}"
          .ruleId="${this.ruleId}"
          id="${this.id}"
          @row-changed="${this._rowChanged}"
          @versionID-changed="${this._versionChanged}"
        ></rule-defination>
        <rule-defination
          headerText="AZIONI"
          column1Text="SI APPLICA A"
          column2Text="SELEZIONA"
          column3Text="COLONNA N°"
          column4Text="VALORE"
          column5Text="VISIBLE"
          column6Text="BOLD"
          column7Text="ITALIC"
          selectLabel="Select"
          .elementsData="${this.actions}"
          .selectData="${this.appliesToElements}"
          .columnNotes="${this.columnNotes}"
          ?isTempModification=${this.isTempModification}
          @columns-changed="${this.columnsChanged}"
          .selectFieldsData=${this.selectFieldsData}
          .linkedElement="${this.linkedElement}"
          .sectionsList="${this.sectionsList}"
          .subSectionsList="${this.subSectionsList}"
          .rows="${this.rows}"
          .notes="${this.notes}"
          .docId="${this.docId}"
          .rulesDdl1="${this.rulesDdl1}"
          ?isNotSaved="${this.isNotSaved}"
          .versionID="${this.versionID}"
          .ruleId="${this.ruleId}"
          id="${this.id}"
          ?isModifiedDocument=${this.isModifiedDocument}
          @row-changed="${this._rowChanged}"
          @versionID-changed="${this._versionChanged}"
        ></rule-defination>
      </div>
      <div class="container">
        <div class="right_alignment">
          <ing-button outline indigo font14 class="cancel_button" @click="${this._cancel}"
            >${this.isExistingDocument ? 'Annulla' : 'Cancella'}</ing-button
          >
          <ing-button
            indigo
            ?disabled="${this._disabledButton || this.linkedElement}"
            font14
            class="save_button"
            @click=${this._save}
            >${this.getSaveBtnText()}</ing-button
          >
          ${this.isModifiedDocument
            ? html` <ing-button
                outline
                indigo
                font14
                class="save_button"
                @click="${this._previewRule}"
                >Anteprima</ing-button
              >`
            : ''}
        </div>
      </div>
    `;
  }
}
customElements.define('create-rule', CreateRule);
