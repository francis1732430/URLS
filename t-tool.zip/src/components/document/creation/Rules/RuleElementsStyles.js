import { css, green } from 'ing-web';

export default css`
  .inline-block-el {
    display: inline-block;
    vertical-align: top;
    margin-top: 10px;
    min-width: 10rem;
  }
  .inline-block-small {
    min-width: 8rem;
    text-indent: 1rem;
    text-align: center;
  }
  .text-align-left {
    text-align: left;
  }
  .container::before {
    display: inline-table;
    clear: both;
  }
  [rowRadioGroup] {
    display: inline-flex;
    width: 15rem;
    margin-top: 0.4rem;
  }
  [rowRadioItem] {
    width: 5rem;
    margin: 0px 0px 0px 1.52rem;
    display: inline-flex;
    text-align: center;
    text-indent: 3px;
  }
  [rowElementsCheckbox] {
    display: inline-block;
    margin-top: 16px;
  }
  [review-switch] {
    min-width: 0;
    display: inline-flex;
    transform: scale(0.8);
  }
  .positive-text {
    color: ${green};
    font-weight: bold;
    display: inline-block;
    font-size: 14px;
    position: relative;
    top: 2px;
  }
  .review-switch-label {
    margin: 35px 0;
  }
  [ruleInput] {
    width: 6rem;
  }
  .margin-left-1 {
    margin-left: 1rem;
  }
  [data-tag-name='ing-select'] {
    width: 9.5rem;
  }
  [rule-checkbox] {
    position: relative;
    bottom: 14px;
  }
  [ruleactionvalue] textarea {
    resize: both !important;
    overflow-wrap: break-word;
    width: 140px;
    height: 40px;
    max-height: 162px;
    position: absolute;
    background: white;
    z-index: 0;
    max-width: 590px;
  }
  [ruleactionvalue] {
    width: 9.5rem;
  }
  [column-n-select] {
    width: 6.5rem;
  }
  .column-n-select-wrapper {
    min-width: 7rem;
  }
  .rule-action-value-wrapper {
    width: 3rem !important;
  }
`;
