import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngRadio,
  IngRadioGroup,
  IngSelect,
  IngButton,
  IngCheckbox,
  IngSwitch,
} from 'ing-web';
import styles from './RuleElementsStyles.js';
import { baseURL2 } from '../../../../utils/constants.js';
import { ajaxInstance } from '../../../../utils/endpoints.js';
import { transformRowsToFrontEnd } from '../../../../data/tranformations/rowTransformation.js';
import { getSortedList } from '../../../../utils/IngFeatTransparencyToolUtils.js';

export class RuleElements extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-select': IngSelect,
      'ing-radio-group': IngRadioGroup,
      'ing-radio': IngRadio,
      'ing-button': IngButton,
      'ing-checkbox': IngCheckbox,
      'ing-switch': IngSwitch,
    };
  }

  static get properties() {
    return {
      input1Val: { type: String },
      input2Val: { type: String },
      radioVal: { type: String },
      selectVal: { type: String },
      selectLabel: { type: String },
      radioLabel: { type: String },
      selectData: { type: Array },
      radioData: { type: Array },
      isNew: { type: Boolean },
      isBold: { type: Boolean },
      isVisible: { type: Boolean },
      isItalic: { type: Boolean },
      select2Val: { type: String },
      select2Data: { type: Array },
      select3Val: { type: String },
      select3Data: { type: Array },
      rowNumberVal: { type: String },
      debounceTime: { type: Number },
      checkedData: { type: Array },
      elementsData: { type: Array },
      selectFieldsData: { type: Object },
      linkedElement: Boolean,
      sectionsList: Array,
      subSectionsList: Array,
      rows: Array,
      notes: Array,
      docId: String,
      rulesDdl1: Array,
      select4Data: Array,
      select5Data: Array,
    };
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed.has('selectVal') &&
      this.selectLabel &&
      this.select2Val &&
      !this.select2Data?.filter(item => item?.id?.toString() !== '0').length &&
      !this.select3Data?.filter(item => item?.id?.toString() !== '0').length &&
      this.selectVal !== '0' &&
      this.selectVal &&
      this.selectVal !== 'undefined' &&
      this.select2Val !== 'undefined' &&
      this.select3Val !== 'undefined'
    ) {
      this._fireComponentChangedEvent(null, this.selectVal, true);
    } else if (
      changed.has('selectVal') &&
      changed.get('selectVal') &&
      changed.get('selectVal') !== 0 &&
      changed.get('selectVal') !== undefined &&
      this.selectVal !== '0' &&
      this.selectVal !== 'undefined' &&
      this.select2Val &&
      this.select2Data &&
      this.select2Data?.filter(item => item?.id?.toString() !== '0').length > 0
    ) {
      const applicaType = this.getTypeOfSelection();
      if (
        (applicaType === 'RIGHE' || applicaType === 'RIGA') &&
        this.select2Val &&
        this.select2Val !== '0' &&
        this.select2Val !== 'undefined'
      ) {
        this.select2Data = [];
        this.select2Val = '0';
        this.select3Data = [];
        this.select3Val = '0';
        this._fireComponentChangedEvent(null, this.selectVal);
      } else if (
        (applicaType === 'SEZIONI' || applicaType === 'SEZIONE') &&
        this.select2Val &&
        this.select2Val !== '0' &&
        this.select2Val !== 'undefined' &&
        this.sectionsList &&
        this.sectionsList.findIndex(
          item => item?.id?.toString() === this.select2Val?.toString(),
        ) === -1
      ) {
        this.select2Data = [];
        this.select2Val = '0';
        this._fireComponentChangedEvent(null, this.selectVal);
      } else if (
        (applicaType === 'SOTTA SEZIONI' ||
          applicaType === 'SOTTA SEZIONE' ||
          applicaType === 'SOTTOSEZIONE') &&
        this.select2Val &&
        this.select2Val !== '0' &&
        this.select2Val !== 'undefined' &&
        this.subSectionsList &&
        this.subSectionsList.findIndex(
          item => item?.id?.toString() === this.select2Val?.toString(),
        ) === -1
      ) {
        this.select2Data = [];
        this.select2Val = '0';
        this._fireComponentChangedEvent(null, this.selectVal);
      } else if (
        (applicaType === 'NOTE' || applicaType === 'NOTA') &&
        this.select2Val &&
        this.select2Val !== '0' &&
        this.select2Val !== 'undefined' &&
        this.notes &&
        this.notes.findIndex(item => item?.id?.toString() === this.select2Val?.toString()) === -1
      ) {
        this.select2Data = [];
        this.select2Val = '0';
        this._fireComponentChangedEvent(null, this.selectVal);
      }
    }
    if (
      !this.docId &&
      this.select2Data &&
      this.sectionsList &&
      (changed.has('selectVal') || changed.has('sectionsList'))
    ) {
      const applicaType = this.getTypeOfSelection();
      if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'SEZIONI' || applicaType === 'SEZIONE') &&
        this.sectionsList.length > 0 &&
        this.sectionsList.length !==
          this.select2Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
          ...this.getRulesList(),
        ];
      } else if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'SEZIONI' || applicaType === 'SEZIONE') &&
        this.sectionsList.length === 0
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
    if (
      !this.docId &&
      this.select2Data &&
      this.subSectionsList &&
      (changed.has('selectVal') || changed.has('subSectionsList'))
    ) {
      const applicaType = this.getTypeOfSelection();
      if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'SOTTA SEZIONI' ||
          applicaType === 'SOTTA SEZIONE' ||
          applicaType === 'SOTTOSEZIONE') &&
        this.subSectionsList.length > 0 &&
        this.subSectionsList.length !==
          this.select2Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
          ...this.getRulesList(),
        ];
      } else if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'SOTTA SEZIONI' ||
          applicaType === 'SOTTA SEZIONE' ||
          applicaType === 'SOTTOSEZIONE') &&
        this.subSectionsList.length === 0
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
    if (
      !this.docId &&
      this.select2Data &&
      this.rows &&
      (changed.has('selectVal') || changed.has('rows'))
    ) {
      const applicaType = this.getTypeOfSelection();
      if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'RIGHE' || applicaType === 'RIGA') &&
        this.rows.length > 0 &&
        this.rows.length !== this.select2Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
          ...this.getRulesList(),
        ];
        setTimeout(() => {
          const index = this.select2Data.findIndex(
            item => item?.id?.toString() === this.select2Val?.toString(),
          );
          if (index === -1) {
            this.select3Data = [];
          }
        });
      } else if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'RIGHE' || applicaType === 'RIGA') &&
        this.rows.length === 0
      ) {
        this.select3Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
    if (
      !this.docId &&
      this.select2Data &&
      this.notes &&
      (changed.has('selectVal') || changed.has('notes'))
    ) {
      const applicaType = this.getTypeOfSelection();
      if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'NOTE' || applicaType === 'NOTA') &&
        this.notes.length > 0 &&
        this.notes.length !== this.select2Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
          ...this.getRulesList(),
        ];
      } else if (
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        (applicaType === 'NOTE' || applicaType === 'NOTA') &&
        this.notes.length === 0
      ) {
        this.select2Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
    // console.log(this.select2Data, this.rows, this.select2Val, changed.has('rows'), this.selectVal, this.select3Data, this.select3Val, changed);
    if (
      this.select2Data &&
      this.rows &&
      this.rows.length > 0 &&
      this.select2Val &&
      this.select2Val !== 'undefined'
    ) {
      const index = this.rows.findIndex(
        item => item?.id?.toString() === this.select2Val?.toString(),
      );
      if (
        !changed.has('select3Data') &&
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        index > -1 &&
        this.rows[index] &&
        this.rows[index].columns &&
        this.rows[index].columns.length !==
          this.select3Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.select3Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
          ...this.getColumnList(this.select2Val),
        ];
      } else if (
        !changed.has('select3Data') &&
        this.selectVal &&
        this.selectVal !== 'undefined' &&
        index > -1 &&
        this.rows[index] &&
        this.rows[index].columns &&
        this.rows[index].columns.length === 1 &&
        !this.rows[index].columns[0].name
      ) {
        this.select3Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
    if (
      changed.has('rulesDdl1') &&
      changed.has('selectData') &&
      this.rulesDdl1?.length > 0 &&
      this.selectLabel &&
      this.select2Val &&
      !this.select2Data?.filter(item => item?.id?.toString() !== '0').length &&
      this.selectVal !== '0' &&
      this.selectVal &&
      this.selectVal !== 'undefined' &&
      this.select2Val !== 'undefined'
    ) {
      this._fireComponentChangedEvent(null, this.selectVal, true);
    }

    if (changed.has('input1Val') && this.input1Val && !this.isTextAreaFocused) {
      setTimeout(() => {
        const a = this.shadowRoot.querySelector('[ruleactionvalue] textarea');
        if (a && a?.style?.maxHeight?.toString() !== '40px') {
          a.style.maxHeight = '40px';
        }
      });
    }
  }

  getTypeOfSelection(currentId) {
    if (!this.selectData) {
      this.selectData = [
        {
          id: '0',
          name: 'Select Element',
        },
      ];
    }
    if (currentId) {
      return this.selectData.find(
        item => item?.id?.toString() !== '0' && item.id?.toString() === currentId?.toString(),
      )?.name;
      // eslint-disable-next-line
    } else {
      return this.selectData.find(
        item => item?.id?.toString() !== '0' && item.id?.toString() === this.selectVal?.toString(),
      )?.name;
    }
  }

  constructor() {
    super();
    this.rowIdConstant = '1';
    // this.selectData = [];
    this.select2Data = [];
    this.select3Data = [];
    this.radioData = [];
    this.selectVal = null;
    this.input1Val = '';
    this.input2Val = '';
    this.ajaxInstance = ajaxInstance;
    this.rulesDdl1 = [];
    this.select4Data = [];
    this.select5Data = [];
    this.isTextAreaFocused = false;
  }

  static get styles() {
    return styles;
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionDetail(id) {
    const url = `${baseURL2}/version/${id}`;
    try {
      const res = await this.ajaxInstance.get(url);
      return transformRowsToFrontEnd(res?.data);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return {};
    }
  }

  async firstUpdated(changedProps) {
    super.firstUpdated(changedProps);
    if (changedProps.get('select3Data')) {
      this.select3Val = undefined;
    }
    if (changedProps.get('select2Data')) {
      this.select2Val = undefined;
    }
    if (changedProps.get('selectData')) {
      this.select2Val = undefined;
      this.selectVal = undefined;
      this.select3Val = undefined;
    }
    if (this.selectLabel) {
      // this.select2Data = [...appliesToRules];
      // this.select3Data = [...appliesToColumns];
    }
    if (this.selectVal && this.selectVal !== 'undefined') {
      this._fireComponentChangedEvent(null, this.selectVal, true);
    } else {
      // this.select2Data = [];
    }
  }

  handleChange(e) {
    const { name, value, checked } = e.target;
    const isSwitch = e.currentTarget.nodeName.match(/(ing-switch|ing-checkbox)/i);
    clearTimeout(this.debounceTime);
    this.debounceTime = setTimeout(() => {
      this[name] = isSwitch ? checked : value;
      this._addElements();
    }, 0);
  }

  _addElements() {
    const obj = this.selectLabel
      ? {
          appliedToElement: this.selectVal,
          appliedToRule: this.select2Val,
          appliedToColumn: this.select3Val,
          value: this.input1Val,
          isVisible: this.isVisible,
          isBold: this.isBold,
          isItalic: this.isItalic,
        }
      : {
          operator: this.select2Val,
          index: this.selectVal,
          column: this.input1Val,
          value: this.input2Val,
          rowNo: this.select3Val,
        };
    const event = new CustomEvent('add-new-elements', {
      detail: {
        isNew: this.isNew,
        data: {
          id: this.id,
          ...obj,
        },
      },
    });
    this.dispatchEvent(event);
  }

  _handleCheckboxChange() {
    const event = new CustomEvent('checked-fields', {
      detail: {
        id: this.id,
      },
    });
    this.dispatchEvent(event);
  }

  _hydrateSelect(i, d, fieldName, array, callback) {
    if ((!this[fieldName] || this[fieldName] === 'undefined') && i === 0) {
      this[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this[fieldName]?.toString() === d?.id?.toString()) {
      return true;
    }
    if ((!this[fieldName] || this[fieldName] === 'undefined') && array.length - 1 === i) {
      const ids = array.map(el => el?.id?.toString());
      if (ids.indexOf(this[fieldName].toString()) === -1) {
        this[fieldName] = array[0].id;
      }
    }
    // else if (isTrigger && array && array.length - 1 === i) {
    //   const ids = array.map(el => el?.id?.toString());
    //   if (ids.indexOf(this[fieldName].toString()) === -1) {
    //     this[fieldName] = array[0].id;
    //     // eslint-disable-next-line no-unused-expressions
    //     callback && callback(null, this[fieldName]);
    //   }
    // }
    return false;
  }

  async _fireComponentChangedEvent(event, id, isModify) {
    const e = new CustomEvent('component-select-changed', {
      detail: {
        id: event ? event.target.value : id,
      },
    });
    this.dispatchEvent(e);
    const currentId = e.detail.id;
    this.rowIdConstant = '1';
    // this.selectFieldsData[this.selectLabel ? 'version2': 'version1']['selectData'][Math.random] = [];
    if (this.selectLabel) {
      const data =
        this.selectFieldsData[this.selectLabel ? 'version2' : 'version1'].select2Data[
          `${this.id}_${e.detail.id}`
        ];
      if (
        data &&
        data.length > 0 &&
        data?.filter(item => item?.id?.toString() !== '0').length &&
        this.docId
      ) {
        this.select2Data = [...data];
        this.select2Val = '0';
        this.select3Val = '0';
      } else {
        // this.select2Data = appliesToRules?.filter(
        //   n => e.detail.id.toString() === n.elementId.toString(),
        // );
        // this.select2Data.unshift({
        //   id: '0',
        //   name: 'Select Rule'
        // });
        if (currentId && currentId !== '0' && currentId !== 'undefined') {
          if (this.docId) {
            // eslint-disable-next-line
            const list = this.rulesDdl1
              ?.filter(item => item.lookupDataID?.toString() === currentId?.toString())
              // eslint-disable-next-line
              .map(item => {
                return {
                  id: item.itemsVersionsID?.toString(),
                  name: item.name?.toString(),
                };
              });
            this.select2Data = [
              {
                id: '0',
                name: 'Select Rule',
              },
              ...list,
            ];
            if (!isModify) {
              this.select2Val = '0';
              this.select3Val = '0';
            }
          } else {
            this.select2Data = [
              {
                id: '0',
                name: 'Select Rule',
              },
              ...this.getRulesList(currentId),
            ];
          }
        }
        this.selectFieldsData[this.selectLabel ? 'version2' : 'version1'].select2Data[
          `${this.id}_${e.detail.id}`
        ] = [...this.select2Data];
      }
      await this.updateComplete;
      // (this.select2Val && this.select2Val !== "undefined") && this._fireRuleChangedEvent(null, this.select2Val);

      if (
        this.select2Val &&
        this.select2Val !== 'undefined' &&
        this.select2Data?.filter(item => item?.id?.toString() !== '0').length
      ) {
        this.rowIdConstant = currentId;
        this._fireRuleChangedEvent(null, this.select2Val, currentId, isModify);
      } else {
        this.select3Data = [
          {
            id: '0',
            name: 'Select Rule',
          },
        ];
      }
    }
  }

  async _fireRuleChangedEvent(event, id, componentSelectId, isModify) {
    const e = new CustomEvent('rule-select-changed', {
      detail: {
        id: event ? event.target.value : id,
      },
    });
    this.dispatchEvent(e);
    const currentId = e.detail.id;
    const componentSelectIdActual = componentSelectId || this.selectVal;
    if (this.selectLabel) {
      const data =
        this.selectFieldsData[this.selectLabel ? 'version2' : 'version1'].select3Data[
          `${this.id}_${e.detail.id}`
        ];
      if (
        data &&
        data.length > 0 &&
        data?.filter(item => item?.id?.toString() !== '0').length &&
        this.docId
      ) {
        this.select3Data = [...data];
        this.select3Val = '0';
      } else {
        // this.select3Data = appliesToColumns?.filter(
        //   n => e.detail.id.toString() === n.ruleId.toString(),
        // );
        if (
          componentSelectIdActual === this.rowIdConstant &&
          currentId &&
          currentId !== '0' &&
          currentId !== 'undefined'
        ) {
          let linkedRow = false;
          if (!this.docId) {
            const index = this.rows?.findIndex(
              item => item?.id?.toString() === currentId?.toString(),
            );
            if (
              index > -1 &&
              // eslint-disable-next-line
              !this.rows[index]?.hasOwnProperty('columns') &&
              // eslint-disable-next-line
              !this.rows[index]?.hasOwnProperty('columnNotes') &&
              !this.rows[index]?.columns &&
              !this.rows[index]?.columnNotes
            ) {
              linkedRow = true;
            }
          }
          if (
            (this.docId || linkedRow) &&
            (this.getTypeOfSelection() === 'RIGHE' || this.getTypeOfSelection() === 'RIGA')
          ) {
            const rowData = await this.getVersionDetail(currentId);
            const list =
              rowData && rowData.columns
                ? rowData.columns.map(c => ({
                    ...c,
                    columnId: c.id,
                    id: c.versionDetailLevel0ID,
                  }))
                : [];
            this.select3Data = [
              {
                id: '0',
                name: 'Select Column',
              },
              ...list,
            ];
            if (!isModify) {
              this.select3Val = '0';
            }
          } else {
            this.select3Data = [
              {
                id: '0',
                name: 'Select Column',
              },
              ...this.getColumnList(currentId),
            ];
          }
        } else if (currentId === '0') {
          this.select3Data = [
            {
              id: '0',
              name: 'Select Column',
            },
          ];
        }
        this.selectFieldsData[this.selectLabel ? 'version2' : 'version1'].select3Data[
          `${this.id}_${e.detail.id}`
        ] = [...this.select3Data];
      }
      if (componentSelectIdActual !== this.rowIdConstant) {
        this.input1Val = '';
        this.select3Val = '';
      }
    }
  }

  _handleComponentChange(event) {
    this._fireComponentChangedEvent(event);
    this.handleChange(event);
  }

  _handleRuleChange(event) {
    this.select3Val = '0';
    this._fireRuleChangedEvent(event);
    this.handleChange(event);
  }

  handleSwitchChange(name) {
    return event => {
      // eslint-disable-next-line no-param-reassign
      event.target.name = name;
      this.handleChange(event);
    };
  }

  getRulesList(currentId) {
    const applicaType = this.getTypeOfSelection(currentId);
    if (applicaType === 'RIGHE' || applicaType === 'RIGA') {
      if (!this.rows) {
        this.rows = [];
      }
      // eslint-disable-next-line
      return this.rows.map(item => {
        return { id: item.id, name: item.name, rowId: item?.rowId };
      });
      // eslint-disable-next-line
    } else if (applicaType === 'SEZIONI' || applicaType === 'SEZIONE') {
      if (!this.sectionsList) {
        this.sectionsList = [];
      }
      // eslint-disable-next-line
      return this.sectionsList.map(item => {
        return { id: item.id, name: item.description, sectionId: item?.sectionId };
      });
    } else if (
      applicaType === 'SOTTA SEZIONI' ||
      applicaType === 'SOTTA SEZIONE' ||
      applicaType === 'SOTTOSEZIONE'
    ) {
      if (!this.subSectionsList) {
        this.subSectionsList = [];
      }
      // eslint-disable-next-line
      return this.subSectionsList.map(item => {
        return { id: item.id, name: item.description, subSectionId: item?.subSectionId };
      });
    } else if (applicaType === 'NOTE' || applicaType === 'NOTA') {
      if (!this.notes) {
        this.notes = [];
      }
      // eslint-disable-next-line
      return this.notes.map(item => {
        return { id: item.id, name: item.description || item?.name, noteId: item?.noteId };
      });
    }
    return [];
  }

  getColumnList(currentId) {
    if (currentId && currentId !== 'undefined') {
      if (!this.rows) {
        this.rows = [];
      }
      const index = this.rows.findIndex(item => item?.id?.toString() === currentId?.toString());
      // return index > -1 ? this.rows[index].columns?.filter(item => item?.name).map(c => ({
      //   ...c,
      //   columnId: c.id,
      //   id: c.versionDetailLevel0ID
      // })) : [];
      if (index > -1) {
        let processRows = JSON.parse(
          JSON.stringify(this.rows[index].columns?.filter(item => item?.name)) || [],
        );
        processRows = processRows.map(c => ({
          ...c,
          columnId: c.id,
          id: c.versionDetailLevel0ID,
        }));
        return processRows;
      }
      return [];
    }
    return [];
  }

  get disableRulesSelect() {
    return this.selectLabel && this.selectVal === '0';
  }

  get disableColumnsSelect() {
    return (
      this.selectLabel &&
      (this.select2Val === '0' ||
        (this.selectVal &&
          this.getTypeOfSelection() !== 'RIGHE' &&
          this.getTypeOfSelection() !== 'RIGA'))
    );
  }

  get disableValue() {
    return (
      this.selectLabel &&
      this.selectVal &&
      this.getTypeOfSelection() !== 'RIGHE' &&
      this.getTypeOfSelection() !== 'RIGA'
    );
  }

  _updateRigaElements() {
    clearTimeout(this.debounceTime1);
    this.debounceTime1 = setTimeout(() => {
      const event = new CustomEvent('update-riga-elements', {
        detail: {
          data: {
            id: this.id,
            rowNo: this.select3Val,
          },
        },
      });
      this.dispatchEvent(event);
    }, 350);
  }

  focusOutTextArea() {
    const a = this.shadowRoot.querySelector('[ruleactionvalue] textarea');
    if (a) {
      a.style.width = '140px';
      a.style.height = '40px';
      a.style['z-index'] = 0;
    }

    if (a && a.style['max-height'] !== '40px') {
      a.style.maxHeight = '40px';
    }
    this.isTextAreaFocused = false;
  }

  focusElement() {
    const a = this.shadowRoot.querySelector('[ruleactionvalue] textarea');
    if (a && a.style['max-height'] !== '162px') {
      a.style.height = '40px';
      a.style.maxHeight = '162px';
    }
    if (a) {
      a.focus();
      a.style['z-index'] = 10;
    }
    this.isTextAreaFocused = true;
  }

  render() {
    return html`
      <div class="container">
        <ing-checkbox
          id="${this.id}"
          ?checked="${this.checkedData.indexOf(this.id) > -1}"
          @change="${this._handleCheckboxChange}"
          rowElementsCheckbox
          ?disabled="${this.linkedElement}"
        ></ing-checkbox>

        <div class="inline-block-el">
          ${this.selectLabel
            ? html`<ing-select
                name="selectVal"
                @change="${this._handleComponentChange}"
                ?disabled="${this.linkedElement}"
              >
                <select name="selectVal" slot="input">
                  ${this.selectData.map((d, i) =>
                    d.isNew
                      ? ''
                      : html`<option
                          value="${d.id}"
                          ?selected="${this._hydrateSelect(
                            i,
                            d,
                            'selectVal',
                            this.selectData,
                            this._fireComponentChangedEvent.bind(this),
                          )}"
                        >
                          ${d.name}
                        </option>`,
                  )}
                </select>
              </ing-select>`
            : html`<ing-input
                ruleInput
                @keyup="${this.handleChange}"
                name="input1Val"
                .modelValue="${this.input1Val}"
                class="note_name"
                ?disabled="${this.linkedElement}"
              ></ing-input>`}
        </div>
        <div class="inline-block-el">
          ${this.selectLabel
            ? html`<ing-select
                name="select2Val"
                @change="${this._handleRuleChange}"
                ?disabled="${this.linkedElement || this.disableRulesSelect}"
              >
                <select name="select2Val" slot="input">
                  ${getSortedList(this.select2Data).map((d, i) =>
                    d.isNew
                      ? ''
                      : html`<option
                          value="${d.id}"
                          ?selected="${this._hydrateSelect(
                            i,
                            d,
                            'select2Val',
                            this.select2Data,
                            this._fireRuleChangedEvent.bind(this),
                          )}"
                        >
                          ${d.name}
                        </option>`,
                  )}
                </select>
              </ing-select>`
            : html`<ing-select
                name="select2Val"
                @change="${this.handleChange}"
                ?disabled="${this.linkedElement}"
              >
                <select name="select2Val" slot="input">
                  ${this.select4Data.map(
                    (d, i) =>
                      html`<option
                        value="${d.id}"
                        ?selected="${this._hydrateSelect(i, d, 'select2Val', this.select4Data)}"
                      >
                        ${d.name}
                      </option>`,
                  )}
                </select>
              </ing-select>`}
        </div>
        <div class="inline-block-el ${this.selectLabel ? 'column-n-select-wrapper' : ''}">
          ${this.selectLabel
            ? html`
                <ing-select
                  name="select3Val"
                  column-n-select
                  @change="${this.handleChange}"
                  ?disabled="${this.linkedElement || this.disableColumnsSelect}"
                >
                  <select name="select3Val" slot="input">
                    ${this.select3Data.map(
                      (d, i) =>
                        html`<option
                          value="${d.id}"
                          ?selected="${this._hydrateSelect(i, d, 'select3Val', this.select3Data)}"
                        >
                          ${d.name}
                        </option>`,
                    )}
                  </select>
                </ing-select>
              `
            : html`<ing-input
                ruleInput
                @keyup="${this.handleChange}"
                name="input2Val"
                .modelValue="${this.input2Val}"
                class="note_name"
                ?disabled="${this.linkedElement}"
              ></ing-input>`}
        </div>
        <div
          class="inline-block-el inline-block-small text-align-left ${this.selectLabel
            ? 'rule-action-value-wrapper'
            : ''}"
        >
          ${
            this.selectLabel
              ? html` <ing-textarea
                  ruleInput
                  ruleactionvalue
                  @keyup="${this.handleChange}"
                  @blur="${this.focusOutTextArea}"
                  @mousedown="${this.focusElement}"
                  @mouseup="${this.focusElement}"
                  @click="${this.focusElement}"
                  name="input1Val"
                  .modelValue="${this.input1Val}"
                  class="note_name"
                  ?disabled="${this.linkedElement || this.disableValue}"
                  style="width: 140px;height: 40px;"
                ></ing-textarea>`
              : /* eslint-disable */
                html` <!-- <strong> ${this.rowNumberVal}</strong> --> `
            /* eslint-disable */
          }
        </div>
        <div class="inline-block-el inline-block-small">
          ${
            this.selectLabel
              ? html`
                  <ing-switch
                    ?checked="${this.isVisible}"
                    @click="${this.handleSwitchChange('isVisible')}"
                    name="isVisible"
                    review-switch
                    label="NO"
                    ?disabled="${this.linkedElement}"
                  ></ing-switch>
                  <span class="positive-text">SI</span>
                `
              : /* eslint-disable */
                html`
                  <!-- <ing-select
                  name="select3Val"
                  @change="${this.handleChange}"
                  ?disabled="${this.linkedElement}"
                >
                  <select name="select3Val" slot="input">
                    ${this.select5Data.map(
                    (d, i) =>
                      html`<option
                        value="${d.id}"
                        ?selected="${this._hydrateSelect(
                          i,
                          d,
                          'select3Val',
                          this.select5Data,
                          this._updateRigaElements.bind(this),
                        )}"
                      >
                        ${d.optionLabel}
                      </option>`,
                  )}
                  </select>
                </ing-select> -->
                `
            /* eslint-disable */
          }
        </div>
        <div class="inline-block-el inline-block-small">
          ${this.selectLabel
            ? html` <ing-checkbox
                name="isBold"
                ?checked="${this.isBold}"
                rule-checkbox
                @change="${this.handleSwitchChange('isBold')}"
                ?disabled="${this.linkedElement}"
                rowElementsCheckbox
              ></ing-checkbox>`
            : ''}
        </div>
        <div class="inline-block-el inline-block-small">
          ${this.selectLabel
            ? html` <ing-checkbox
                ?checked="${this.isItalic}"
                name="isItalic"
                rule-checkbox
                @change="${this.handleSwitchChange('isItalic')}"
                rowElementsCheckbox
                ?disabled="${this.linkedElement}"
              ></ing-checkbox>`
            : ''}
        </div>
      </div>
    `;
  }
}
customElements.define('rule-elements', RuleElements);
