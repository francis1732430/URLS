import { ScopedElementsMixin, LitElement, html, IngButton, IngIcon } from 'ing-web';

import styles from './RuleDefinationStyles.js';
import { RuleElements } from './RuleElements.js';
import { generateId } from '../../../../utils/IngFeatTransparencyToolUtils.js';
import { RemovableChip } from '../../../removableChip/removableChip.js';
import { chunks, createVersionDetail, removeVersionLevels } from '../../../../utils/chunks.js';
import { baseURL, baseURL2, localEnvironment } from '../../../../utils/constants.js';
import { deriveData } from '../../../../utils/globalApiKeys.js';
import { ajaxInstance } from '../../../../utils/endpoints.js';
import { CustomSelectTree } from '../../../customSelectTree/CustomSelectTree.js';
import { RuleForm } from '../../../ruleForm/ruleForm.js';
import { transformRowsToFrontEnd } from '../../../../data/tranformations/rowTransformation.js';
import { transformNoteToFrontEnd } from '../../../../data/tranformations/noteTransformation.js';
import { transformSubSectionsToFrontEnd } from '../../../../data/tranformations/subSectionsTransformation.js';

export class RuleDefination extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'rule-elements': RuleElements,
      'removable-chip': RemovableChip,
      'custom-tree': CustomSelectTree,
      'rule-form': RuleForm,
    };
  }

  static get properties() {
    return {
      headerText: { type: String },
      column1Text: { type: String },
      column2Text: { type: String },
      column3Text: { type: String },
      column4Text: { type: String },
      column5Text: { type: String },
      column6Text: { type: String },
      column7Text: { type: String },
      selectLabel: { type: String },
      radioLabel: { type: String },
      selectData: { type: Array },
      select2Data: { type: Array },
      select3Data: { type: Array },
      radioData: { type: Array },
      elementsData: { type: Array },
      columnNotes: { type: Array },
      checkedData: { type: Array },
      selectedComponent: { type: String },
      selectedNote: { type: String },
      selectFieldsData: { type: Object },
      linkedElement: Boolean,
      sectionsList: Array,
      subSectionsList: Array,
      rows: Array,
      notes: Array,
      docId: String,
      rulesDdl1: Array,
      isNotSaved: { type: Boolean, reflect: true },
      versionID: String,
      ruleId: String,
      activeTabButtonId: Object,
      isModifiedDocument: { type: Boolean, reflect: true },
      isTempModification: { type: Boolean, reflect: true },
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.columnNotes = [];
    this.checkedData = [];
    this.checkedDataList = [];
    this.ajaxInstance = ajaxInstance;
    this.activeTabButtonId = 2;
    this.treeChildrenDataMapper = {
      sectionId: {
        list: 'subSectionsList',
        typeName: 'SOTTOSEZIONE',
      },
      subSectionId: {
        list: 'rows',
        typeName: 'RIGA',
      },
      rowId: {
        list: 'columns',
        typeName: 'RIGA',
      },
      colName: {
        list: 'columnNotes',
        typeName: 'NOTA',
      },
    };
    this.treeChildrenModificationMapper = {
      DOCUMENT: 'SEZIONE',
      SEZIONE: 'SOTTOSEZIONE',
      SOTTOSEZIONE: 'RIGA',
      RIGA: 'columns',
      columns: 'columnNotes',
    };

    this.treeData = [
      {
        id: 1,
        columnId: 1,
        name: 'a',
        children: [
          {
            id: 3,
            columnId: 1,
            name: 'aa',
            children: [
              {
                id: 5,
                columnId: 2,
                name: 'aaa',
                children: [],
              },
            ],
          },
        ],
      },
      {
        id: 2,
        columnId: 1,
        name: 'b',
        children: [
          {
            id: 7,
            columnId: 2,
            name: 'bb',
            children: [
              {
                id: 8,
                columnId: 1,
                name: 'bbb',
                children: [],
              },
            ],
          },
        ],
      },
    ];
    this._floatRuleForm = this._floatRuleForm.bind(this);
  }
  /* eslint-disable */
  updated(changedProps) {
    super.updated(changedProps);
    if (this.selectLabel) {
      if (
        (this.isModifiedDocument || this.isTempModification) &&
        (changedProps.has('rulesDdl1') || changedProps.has('selectData')) &&
        this.rulesDdl1?.length &&
        this.selectData?.length
      ) {
        const section = this.sectionsList?.[0].appliedToRule;
        if (!section) {
          const elementType = this.selectData?.find(
            d => d.name === this.treeChildrenModificationMapper.DOCUMENT,
          );
          this.sectionsList = this.rulesDdl1
            ?.filter(d => d.lookupDataID?.toString() === elementType?.id?.toString())
            ?.map(d => ({
              ...d,
              elementType: this.treeChildrenModificationMapper.DOCUMENT,
              appliedToElement: elementType?.id,
              appliedToRule: d.itemsVersionsID,
              id: d.itemsVersionsID,
            }));
        }
      }
      if (
        (changedProps.has('rulesDdl1') || changedProps.has('elementsData')) &&
        (this.isModifiedDocument || this.isTempModification) &&
        this.rulesDdl1?.length &&
        this.elementsData?.length
      ) {
        const element = this.elementsData[0].name;
        if (!element) {
          const elementsData = [...this.elementsData];
          elementsData.forEach(d => {
            this.rulesDdl1.forEach(r => {
              if (d.appliedToRule?.toString() === r.itemsVersionsID?.toString()) {
                d.name = r.name;
                d.showIcons = true;
              }
            });
          });
          setTimeout(() => {
            this.shadowRoot.querySelector('.tab-btn')?.click();
          }, 1000);
        }
        // this.elementsData = [...elementsData];
      }
      if (
        (changedProps.has('sectionsList') || changedProps.has('elementsData')) &&
        this.sectionsList?.length &&
        this.elementsData?.length
      ) {
        const elementsData = [...this.elementsData];
        // const action = elementsData[0]?.name;
        // if(!action) {
        const assignName = (data, obj) => {
          if (!data.children || !data?.children?.length) {
            return;
          }
          data.children.forEach(d => {
            if (
              d.appliedToRule?.toString() === obj.appliedToRule?.toString() &&
              d.appliedToColumn?.toString() === obj.appliedToColumn?.toString()
            ) {
              obj.name = d.name;
              d.id = obj.id;
              d.showIcons = true;
              d.isBold = obj.isBold;
              d.isItalic = obj.isItalic;
              d.isVisible = obj.isVisible;
              d.value = obj.value;
            } else {
              assignName(d, obj);
            }
          });
        };
        elementsData.forEach(d => {
          d.showIcons = true;
          this.sectionsList.forEach(r => {
            if (d.appliedToRule?.toString() === r.appliedToRule?.toString()) {
              d.name = r.name;
              r.id = d.id;
              r.showIcons = true;
              r.isBold = d.isBold;
              r.isItalic = d.isItalic;
              r.isVisible = d.isVisible;
              r.value = d.value;
            } else {
              assignName(r, d);
            }
          });
        });
        // this.elementsData = [...elementsData];
        // }
        const section =
          this.sectionsList[0].isBold ||
          this.sectionsList[0].isItalic ||
          this.sectionsList[0].isVisible ||
          this.sectionsList[0].value;
        if (!section) {
          this.sectionsList.forEach(d => {
            this.elementsData.forEach(r => {
              if (d.appliedToRule?.toString() === r.appliedToRule?.toString()) {
                d.isBold = r.isBold;
                d.isItalic = r.isItalic;
                d.isVisible = r.isVisible;
                d.value = r.value;
                d.id = r.id;
                d.showIcons = true;
              }
            });
          });
          // this.sectionsList = [...this.sectionsList];
        }
        const elementsDataMap = {};
        this.elementsData.forEach(d => {
          const col = d.appliedToColumn ? `_${d.appliedToColumn}` : '';
          elementsDataMap[d.appliedToRule?.toString() + col.toString()] = true;
        });
        const resetUnselected = (data = []) => {
          data.forEach(d => {
            const col = d.appliedToColumn ? `_${d.appliedToColumn}` : '';
            if (!elementsDataMap[d.appliedToRule?.toString() + col.toString()]) {
              d.showIcons = false;
              d.isBold = undefined;
              d.isItalic = undefined;
              d.isVisible = undefined;
              d.value = undefined;
            }
            if (d.children && d?.children?.length) {
              resetUnselected(d.children);
            }
          });
        };
        resetUnselected(this.sectionsList);
      }
      if (
        (changedProps.has('sectionsList') || changedProps.has('selectData')) &&
        this.sectionsList?.length &&
        this.selectData?.length
      ) {
        const section = this.sectionsList[0]?.appliedToRule;
        if (!section) {
          const elementType = this.selectData?.find(
            d => d.name === this.treeChildrenModificationMapper.DOCUMENT,
          );
          this.sectionsList?.forEach(d => {
            (d.elementType = this.treeChildrenModificationMapper.DOCUMENT),
              (d.appliedToElement = elementType?.id),
              (d.appliedToRule = d.id);
          });
        }
      }
    }
  }
  /* eslint-disable */
  firstUpdated(changedProps) {
    super.firstUpdated(changedProps);

    const obj = this.selectLabel
      ? {
          value: '',
        }
      : {
          column: '',
          value: '',
        };
    if (!this.elementsData && !this.selectLabel) {
      this.elementsData = [
        {
          id: generateId(),
          isNew: true,
          ...obj,
        },
      ];
      this._fireColumnsChangedEvent();
    }
    if (this.selectLabel) {
      if (!this.isModifiedDocument) this.elementsData = [];
    }
  }

  connectedCallback() {
    super.connectedCallback();
    if (this.selectLabel) document.addEventListener('scroll', this._floatRuleForm);
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    if (this.selectLabel) document.removeEventListener('scroll', this._floatRuleForm);
  }
  _floatRuleForm(event) {
    if (!this._isFloatScrollProcessing) {
      console.log(event);
      this._isFloatScrollProcessing = true;
      const containerTop = this.shadowRoot
        ?.querySelector('.tree-list-wrapper')
        ?.getBoundingClientRect()?.top;
      const assignTopValue = val => {
        const ruleForm = this.shadowRoot
          ?.querySelector(this?.constructor?.getScopedTagName('rule-form'))
          ?.shadowRoot?.querySelector('.container-fluid');
        if (ruleForm) ruleForm.style.top = Math.abs(Math.round(val)) + 15 + 'px';
      };
      if (containerTop < 0) {
        assignTopValue(containerTop);
      } else {
        assignTopValue(0);
      }
      setTimeout(() => {
        this._isFloatScrollProcessing = false;
      }, 10);
    }
  }
  _fireColumnsChangedEvent() {
    const e = new CustomEvent('columns-changed', {
      detail: {
        data: this.elementsData,
        propertyKey: this.selectLabel ? 'actions' : 'columns',
      },
    });
    this.dispatchEvent(e);
  }

  _fireColumnNotesChangedEvent() {
    const e = new CustomEvent('column-notes-changed', {
      detail: {
        data: this.columnNotes,
      },
    });
    this.dispatchEvent(e);
  }

  mapActionsToTreeData(treeData = []) {
    this.elementsData.forEach(eData => {
      treeData.forEach(tData => {
        if (
          eData.appliedToRule?.toString() === tData.appliedToRule?.toString() &&
          eData.appliedToColumn?.toString() === tData.appliedToColumn?.toString()
        ) {
          tData.isBold = eData.isBold;
          tData.isItalic = eData.isItalic;
          tData.isVisible = eData.isVisible;
          tData.value = eData.value;
          tData.id = eData.id;
          tData.showIcons = true;
        }
      });
    });
    return treeData;
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionDetail(id) {
    const url = `${baseURL2}/version/${id}`;
    try {
      const res = await this.ajaxInstance.get(url);
      return transformRowsToFrontEnd(res?.data);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return {};
    }
  }
  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }
  async makeElementsAjaxCall(transformFn, id, type) {
    // , type
    // ?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[type]}\
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
    } else {
      // FOR MOCK USE
      url = `${baseURL2}/${type}/version/${id}`;
    }
    let list;
    try {
      const res = await this.ajaxInstance.get(url);

      list = res.data?.itemChildren || [];

      list = list?.map(d => transformFn(d));

      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  async _expandedParent(ev) {
    const { data, target } = ev?.detail;
    if (this.isModifiedDocument || this.isTempModification) {
      if (['RIGA', 'columns'].indexOf(data.elementType) === -1) {
        const elementType = this.selectData?.find(
          d => d.name === this.treeChildrenModificationMapper[data.elementType],
        );
        let transformFn, result;
        if (data.elementType === 'SEZIONE') {
          transformFn = transformSubSectionsToFrontEnd;
        } else {
          transformFn = transformRowsToFrontEnd;
        }
        result = await this.makeElementsAjaxCall(transformFn, data.appliedToRule, data.elementType);
        result = result?.list || [];
        // let result = this.rulesDdl1
        //   ?.filter(d => d.lookupDataID?.toString() === elementType?.id?.toString())
        result = result?.map(d => ({
          ...d,
          elementType: this.treeChildrenModificationMapper[data.elementType],
          appliedToElement: elementType?.id,
          itemsVersionsID: d.id,
          appliedToRule: d.itemsVersionsID || d.id,
          id: d.itemsVersionsID || d.id,
          originalId: d.itemsVersionsID || d.id,
        }));
        result = this.mapActionsToTreeData(result);
        data.children = result;
        data.opened = true;
        if (result?.length) {
          target?.click();
          target?.click();
        }
      } else if (data.elementType === 'RIGA') {
        const elementType = this.selectData?.find(d => d.name === data.elementType);
        const row = await this.getVersionDetail(data.itemsVersionsID);
        let result = row[this.treeChildrenModificationMapper[data.elementType]]?.map(d => ({
          ...d,
          colName: d.name,
          name: d.description,
          parentId: data.itemsVersionsID,
          elementType: this.treeChildrenModificationMapper[data.elementType],
          appliedToElement: elementType?.id,
          appliedToRule: row.id,
          appliedToColumn:
            (this.isTempModification || this.isModifiedDocument) && d.versionDetailLevel0ID
              ? d.versionDetailLevel0ID
              : d.id,
          id: d.id,
          originalId: d.id,
        }));
        result = this.mapActionsToTreeData(result);
        data.children = result;
        data.opened = true;
        if (result?.length) {
          target?.click();
          target?.click();
        }
      } else {
        const elementType = this.selectData?.find(d => d.name === 'NOTA');
        const row = await this.getVersionDetail(data.parentId);
        let result = (
          row[this.treeChildrenModificationMapper[data.elementType]]?.filter(
            d => d.columnId?.toString() === data.id?.toString(),
          ) || []
        )?.map(d => ({
          ...d,
          appliedToElement: elementType?.id,
          appliedToRule: d.id,
          id: d.id,
        }));
        result = this.mapActionsToTreeData(result);
        let noteCounter = 0;
        const fetchNote = async (id, obj) => {
          const res = await this._getVersionItemDetail(id);
          const data = transformNoteToFrontEnd(res?.data);
          obj.name = data?.name;
          noteCounter++;
        };
        while (result[noteCounter]) {
          await fetchNote(result[noteCounter]?.appliedToRule, result[noteCounter]);
        }
        data.children = result;
        data.opened = true;
        if (result?.length) {
          target?.click();
          target?.click();
        }
      }
    } else {
      Object.keys(this.treeChildrenDataMapper).forEach(key => {
        if (data[key] !== undefined) {
          if (['rowId', 'colName'].indexOf(key) === -1) {
            const elementType = this.selectData?.find(
              d => d.name === this.treeChildrenDataMapper[key].typeName,
            );

            let result = (this[this.treeChildrenDataMapper[key].list] || [])?.map(d => ({
              ...d,
              appliedToElement: elementType?.id,
              appliedToRule: d.id,
              originalId: d.id,
            }));
            result = this.mapActionsToTreeData(result);
            data.children = result;
          } else if (key === 'rowId') {
            const elementType = this.selectData?.find(
              d => d.name === this.treeChildrenDataMapper[key].typeName,
            );
            const columns = data[this.treeChildrenDataMapper[key].list] || [];

            let result = columns.map(d => ({
              ...d,
              colName: d.name,
              name: d.description,
              parentId: data[key],
              appliedToElement: elementType?.id,
              appliedToRule: data.originalId || data.id,
              appliedToColumn: d.versionDetailLevel0ID || d.id,
              id: d.id,
              originalId: d.id,
            }));
            result = this.mapActionsToTreeData(result);
            data.children = result;
          } else {
            const elementType = this.selectData?.find(
              d => d.name === this.treeChildrenDataMapper[key].typeName,
            );

            const row =
              this.rows?.find(d => d.rowId?.toString() === data?.parentId?.toString()) || {};

            let result = (
              row?.[this.treeChildrenDataMapper[key].list]?.filter(
                d => d.columnId?.toString() === data.id?.toString(),
              ) || []
            )?.map(d => ({
              ...d,
              appliedToElement: elementType?.id,
              appliedToRule: d.id,
            }));
            result = this.mapActionsToTreeData(result);
            data.children = result;
          }
          // this.subSectionsList[0].id = '34';
          // data.children = this.subSectionsList;
        }
      });
    }
  }

  async _addMultipleWithTree(event) {
    if (this.checkedData.length > 1) {
      this.checkedDataList = this.checkedDataList.filter(
        d => d.isVisible !== !!event?.detail?.isVisible,
      );
      await this.checkedDataList.reduce(async (promise, data) => {
        // Wait for the previous item to finish processing
        await promise;
        // Process this item
        data.isVisible = event?.detail?.isVisible;
        this.checkedDataInfo = data;
        return this._addElementsWithTree({ detail: data }, true);
      }, Promise.resolve());
      this.checkedDataList = [];
      this.checkedData = [];
    } else {
      this._addElementsWithTree(event);
    }
  }

  async _addElementsWithTree(event, isMultiple) {
    const data = event.detail;
    if ((this.selectLabel && this.checkedData.length === 1) || isMultiple) {
      const idx = this.elementsData.findIndex(d => d.id?.toString() === data.id?.toString());
      if (this.checkedDataInfo) {
        this.checkedDataInfo.isBold = data.isBold;
        this.checkedDataInfo.isItalic = data.isItalic;
        this.checkedDataInfo.isVisible = data.isVisible;
        this.checkedDataInfo.value = data.value;
        this.checkedDataInfo.showIcons = true;
        data.name = this.checkedDataInfo.name;
        data.showIcons = true;
      }
      if (idx === -1) {
        const gId = await this._addElements(data.id, { ...this.checkedDataInfo, ...data });
        this.checkedDataInfo.id = gId;
      } else {
        const ev = {
          detail: {
            data: { ...this.elementsData[idx], ...data },
          },
        };
        this._updateElement(ev);
      }
      this.checkedData = [];
    }
  }

  async _addElements(checkedId, data = {}) {
    if (!this.linkedElement) {
      let detail;
      const gId = generateId();
      if (this.versionID) {
        const res = await this.addVersionDetails([
          this.createToBackEnd(
            0,
            this.versionID,
            'VERSION_DETAIL_LEVEL_1',
            this.selectLabel === 'Select' ? 'REGOLA_AZIONE' : 'REGOLA_CONDIZIONE',
            this.selectLabel === 'Select' ? '0' : gId,
          ),
        ]);
        detail = res[0]?.versionDetailID;
        this.versionIdChanged(this.versionID);
      } else if (!this.versionID && !this.isNotSaved && this.ruleId) {
        const versionList = await this.getVersionsList(this.ruleId);
        if (versionList.length > 0) {
          const data = versionList.find(
            item => item?.itemsVersionsID?.toString() === this.id?.toString(),
          );
          if (data) {
            this.versionID = data?.versionID;
            const res = await this.addVersionDetails([
              this.createToBackEnd(
                0,
                this.versionID,
                'VERSION_DETAIL_LEVEL_1',
                this.selectLabel === 'Select' ? 'REGOLA_AZIONE' : 'REGOLA_CONDIZIONE',
                this.selectLabel === 'Select' ? '0' : gId,
              ),
            ]);
            detail = res[0]?.versionDetailID;
            this.versionIdChanged(this.versionID);
          }
        }
      }
      this.elementsData = [
        ...this.elementsData,
        {
          value: '',
          column: '',
          isNew: true,
          ...data,
          versionDetailLevel0ID: detail,
          id: gId,
        },
      ];
      this._fireColumnsChangedEvent();
      return gId;
    }
  }

  _updateElement(event) {
    const elements = [...this.elementsData];
    const index = elements.findIndex(
      e => e?.id?.toString() === event?.detail?.data?.id?.toString(),
    );
    elements[index] = this.bindLevelId(event?.detail?.data, elements[index]);
    elements[index].isNew = undefined;
    this.elementsData = [...elements];
    this._fireColumnsChangedEvent();
  }

  _checkedHandler(event) {
    const elements = [...this.checkedData];
    const index = elements.findIndex(e => e === event?.detail?.id);
    if (index > -1) {
      elements.splice(index, 1);
      if (event?.detail?.isHirarchy && !elements.length) {
        this.checkedDataInfo = null;
      }
      this.checkedDataList = this.checkedDataList.filter(
        d =>
          !(
            d.appliedToRule?.toString() === event?.detail?.item?.appliedToRule?.toString() &&
            d.appliedToColumn?.toString() === event?.detail?.item?.appliedToColumn?.toString()
          ),
      );
    } else {
      elements.push(event?.detail?.id);
      if (event?.detail?.isHirarchy && elements.length === 1) {
        this.checkedDataInfo = event?.detail?.item;
      }
      this.checkedDataList.push(event?.detail?.item);
    }
    this.checkedData = [...elements];
  }

  async _removeElements() {
    try {
      let elements = [...this.elementsData];
      const levelIds = [];
      this.checkedData.forEach(id => {
        elements.forEach(e => {
          if (e?.id?.toString() === id?.toString() && e?.versionDetailLevel0ID) {
            levelIds.push({ id: e?.versionDetailLevel0ID, level: 0 });
          }
        });
      });
      if (levelIds?.length) {
        await this.deleteLevels(levelIds);
      }
      this.checkedData.forEach(id => {
        elements = elements.filter(e => {
          if (e?.id?.toString() !== id?.toString()) {
            return true;
            // eslint-disable-next-line
          } else if (e?.id?.toString() === id?.toString()) {
            // eslint-disable-next-line
            if (e?.versionDetailLevel0ID) {
              levelIds.push({ id: e?.versionDetailLevel0ID, level: 0 });
            }
          }
          return false;
        });
      });

      if (elements.length === 0) {
        if (this.headerText === 'CONDIZIONI') {
          elements = [
            {
              id: generateId(),
              column: '',
              value: '',
              rowNo: 0,
            },
          ];
        } else if (this.headerText === 'AZIONI') {
          elements = [
            {
              id: generateId(),
              value: '',
            },
          ];
        }
      }
      if (this.headerText === 'CONDIZIONI' && elements.length === 1) {
        elements[0].rowNo = 0;
      }
      this.elementsData = [...elements];
      this.checkedData = [];
      this.checkedDataList = [];
      this.selectedComponent = null;
      this._fireColumnsChangedEvent();
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  handleComponentChange(event) {
    this.selectedComponent = event.detail.id;
  }

  handleNoteChange(event) {
    this.selectedNote = event.detail.id;
  }

  _getFilteredNotes() {
    const noteIds = this.columnNotes
      .filter(n => n?.columnId?.toString() === this.selectedComponent?.toString())
      .map(n => n?.id?.toString());
    return this.select2Data?.filter(n => noteIds.indexOf(n?.id?.toString()) === -1) || [];
  }

  _onChipDeleted(event) {
    const elements = [...this.columnNotes];
    const index = this.columnNotes.findIndex(
      n =>
        n?.columnId?.toString() === this.selectedComponent?.toString() &&
        event?.detail?.id?.toString() === n?.id?.toString(),
    );
    elements.splice(index, 1);
    this.columnNotes = [...elements];
    // this._fireColumnNotesChangedEvent();
  }

  _getAddbuttonDisabled() {
    if (!this.selectLabel) return false;
    const exp = !!this.selectLabel && !this.selectData?.filter(e => !e.isNew).length;

    return exp;
  }

  // eslint-disable-next-line
  bindLevelId(newObj, originalObj) {
    const newObj1 = newObj;
    if (originalObj?.versionDetailLevel1IDColumn) {
      newObj1.versionDetailLevel1IDColumn = originalObj?.versionDetailLevel1IDColumn;
    }
    if (originalObj?.versionDetailLevel1IDValore) {
      newObj1.versionDetailLevel1IDValore = originalObj?.versionDetailLevel1IDValore;
    }
    if (originalObj?.versionDetailLevel1IDRule) {
      newObj1.versionDetailLevel1IDRule = originalObj?.versionDetailLevel1IDRule;
    }
    if (originalObj?.versionDetailLevel0ID) {
      newObj1.versionDetailLevel0ID = originalObj?.versionDetailLevel0ID;
    }
    if (originalObj?.versionDetailLevel1IDRiga) {
      newObj1.versionDetailLevel1IDRiga = originalObj?.versionDetailLevel1IDRiga;
    }
    if (originalObj?.versionDetailLevel1IDSIApplica) {
      newObj1.versionDetailLevel1IDSIApplica = originalObj?.versionDetailLevel1IDSIApplica;
    }
    if (originalObj?.versionDetailLevel1IDColonaId) {
      newObj1.versionDetailLevel1IDColonaId = originalObj?.versionDetailLevel1IDColonaId;
    }
    if (originalObj?.versionDetailLevel1IDDescription) {
      newObj1.versionDetailLevel1IDDescription = originalObj?.versionDetailLevel1IDDescription;
    }
    if (originalObj?.versionDetailLevel1IDVisible) {
      newObj1.versionDetailLevel1IDVisible = originalObj?.versionDetailLevel1IDVisible;
    }
    if (originalObj?.versionDetailLevel1IDBold) {
      newObj1.versionDetailLevel1IDBold = originalObj?.versionDetailLevel1IDBold;
    }
    if (originalObj?.versionDetailLevel1IDItalic) {
      newObj1.versionDetailLevel1IDItalic = originalObj?.versionDetailLevel1IDItalic;
    }
    if (originalObj?.versionDetailLevel1IDIndex) {
      newObj1.versionDetailLevel1IDIndex = originalObj?.versionDetailLevel1IDIndex;
    }
    return newObj1;
  }

  // eslint-disable-next-line
  async deleteLevels(chunkItems) {
    try {
      // eslint-disable-next-line
      chunkItems = chunkItems.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      await chunks(chunkItems, removeVersionLevels, 50);

      if (this.selectLabel) {
        const e = new CustomEvent('row-changed', {});
        this.dispatchEvent(e);
      }
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line
  async addVersionDetails(data1) {
    try {
      let chunkData = await chunks([data1], createVersionDetail, 50);
      if (!chunkData) {
        chunkData = [];
      }
      chunkData = [
        ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
      ];

      let chunkData1 = [];
      chunkData.forEach(item => {
        if (item?.versionDetailsDTO) {
          chunkData1 = [...chunkData1, ...item?.versionDetailsDTO];
        }
      });
      return chunkData1;
      // eslint-disable-next-line
      // data1 = data1.map(i => {
      //   // eslint-disable-next-line
      //   i.versionDetailID = generateId();
      //   return i
      // });
      // return data1;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    try {
      const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
      return res.data ? deriveData(res.data) : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line
  createToBackEnd(level, parentId, key, value, data) {
    return {
      versionDetailLevel: level,
      versionDetailParentID: parentId,
      itemTypeKey: key,
      itemTypeValue: value,
      data,
    };
  }

  // eslint-disable-next-line
  async versionIdChanged(versionID) {
    const e = new CustomEvent('versionID-changed', {
      detail: versionID,
    });
    this.dispatchEvent(e);
  }

  getRigasList(e) {
    if (!this.selectLabel && this.selectLabel !== 'Select') {
      this.select5Data = this.elementsData
        .map((eData, idx) => ({
          ...eData,

          optionLabel: idx + 1,
        }))
        .filter(eData => eData?.id?.toString() !== e?.id?.toString());
    }
    return this.select5Data;
  }

  _updateRigaElement(event) {
    const elements = [...this.elementsData];
    const index = elements.findIndex(
      e => e?.id?.toString() === event?.detail?.data?.id?.toString(),
    );

    elements[index].rowNo = event?.detail?.data?.rowNo;
    this.elementsData = [...elements];
    this._fireColumnsChangedEvent();
  }

  get ruleFormData() {
    let formData = {};
    if (this.checkedData.length === 1) {
      const prop = 'id';
      formData =
        this.elementsData.find(d => d[prop]?.toString() === this.checkedData[0].toString()) || {};
      if (!formData?.id) {
        formData.id = this.checkedData[0];
        formData.isVisible = true;
      }
    } else {
      const visible = this.checkedDataList?.every(d => d.isVisible);
      if (!formData?.id) {
        formData.id = this.checkedData[0];
      }
      formData.isVisible = !visible ? true : false;
    }
    clearTimeout(this._floatRuleFormTimeout);
    this._floatRuleFormTimeout = setTimeout(() => {
      this._floatRuleForm({});
    }, 300);
    return formData;
  }

  toggleTab(id) {
    return () => {
      this.activeTabButtonId = id;
      this.checkedData = [];
      this.checkedDataList = [];
    };
  }

  render() {
    return html`
          <div>
            ${
              this.headerText
                ? html`<label class="row-definition-header">${this.headerText}</label>`
                : ''
            }
          </div>
          ${
            this.selectLabel
              ? html`
                  <div class="tree-list-wrapper">
                    <div class="tab-btns-wrapper">
                      <ing-button
                        class="tab-btn ${this.activeTabButtonId === 1 ? 'tab-btn-active' : ''}"
                        @click="${this.toggleTab(1)}"
                        >Elementi personalizzati
                      </ing-button>
                      <ing-button
                        class="tab-btn ${this.activeTabButtonId === 2 ? 'tab-btn-active' : ''}"
                        @click="${this.toggleTab(2)}"
                        >Vista completa
                      </ing-button>
                    </div>
                    <custom-tree
                      propKey="name"
                      ?hidden=${this.activeTabButtonId === 1}
                      .selectedIds=${this.checkedData}
                      @nodes-checked=${this._checkedHandler}
                      @expanded-parent=${this._expandedParent}
                      ?isHirarchy=${true}
                      ?isControlled=${true}
                      .displayData="${this.sectionsList}"
                      columnId="1"
                    ></custom-tree>
                    <custom-tree
                      propKey="name"
                      ?hidden=${this.activeTabButtonId === 2}
                      .selectedIds=${this.checkedData}
                      @nodes-checked=${this._checkedHandler}
                      ?isHirarchy=${false}
                      ?isControlled=${true}
                      .displayData="${this.elementsData}"
                      columnId="1"
                    ></custom-tree>
                    ${this.checkedData.length
                      ? html`
                          <rule-form
                            ?isMultiple=${this.checkedData.length > 1}
                            .formData=${this.ruleFormData}
                            @form-data-received=${this._addMultipleWithTree}
                            @remove-form-data=${this._removeElements}
                          ></rule-form>
                        `
                      : ''}
                  </div>
                `
              : html` <div>
                    <div class="inline-block-el margin-left-2">
                      ${this.column1Text ? this.column1Text : ''}
                    </div>
                    <div class="inline-block-el">${this.column2Text ? this.column2Text : ''}</div>
                    <div class="inline-block-el ${this.selectLabel ? 'inline-block-xs' : ''}">
                      ${this.column3Text ? this.column3Text : ''}
                    </div>
                    <!-- <div class="inline-block-el">${this.column4Text
                      ? this.column4Text
                      : ''}</div>
                    <div
                      class="inline-block-el margin-left-1 inline-block-small ${this.selectLabel
                      ? 'ml-1-point-2'
                      : ''}"
                    >
                      ${this.column5Text ? this.column5Text : ''}
                    </div> -->
                    <!-- <div class="inline-block-el margin-left-1 inline-block-small">
                      ${this.column6Text ? this.column6Text : ''}
                    </div>
                    <div class="inline-block-el margin-left-1 inline-block-small">
                      ${this.column7Text ? this.column7Text : ''}
                    </div> -->
                  </div>
                  ${this.elementsData?.map(
                    (e, i) =>
                      html`<rule-elements
                        @checked-fields="${this._checkedHandler}"
                        @add-new-elements="${this._updateElement}"
                        @update-riga-elements="${this._updateRigaElement}"
                        radioLabel="${this.radioLabel || ''}"
                        selectLabel="${this.selectLabel || ''}"
                        .selectData="${this.selectData || []}"
                        .select4Data="${this.select2Data || []}"
                        .select5Data="${this.getRigasList(e)}"
                        .elementsData="${this.elementsData}"
                        id="${e.id}"
                        radioVal="${e.style}"
                        selectVal="${this.selectLabel ? e.appliedToElement : e.index}"
                        select2Val="${this.selectLabel ? e.appliedToRule : e.operator}"
                        select3Val="${this.selectLabel ? e.appliedToColumn : e.rowNo}"
                        input1Val="${this.selectLabel ? e.value : e.column}"
                        input2Val="${e.value}"
                        ?isVisible="${e.isVisible}"
                        ?isBold="${e.isBold}"
                        ?isItalic="${e.isItalic}"
                        .checkedData="${this.checkedData}"
                        rowNumberVal="${i + 1}"
                        ?isNew="${e.isNew}"
                        .selectFieldsData=${this.selectFieldsData}
                        .linkedElement="${this.linkedElement}"
                        .sectionsList="${this.sectionsList}"
                        .subSectionsList="${this.subSectionsList}"
                        .rows="${this.rows}"
                        .notes="${this.notes}"
                        .docId="${this.docId}"
                        .rulesDdl1="${this.rulesDdl1}"
                        @component-select-changed="${this.handleComponentChange}"
                        @note-select-changed="${this.handleNoteChange}"
                      ></rule-elements>`,
                  )}`
          }
          ${
            this.selectLabel
              ? ''
              : html`
                  <div class="margin-left-2">
                    <ing-button
                      ?disabled="${this._getAddbuttonDisabled() || this.linkedElement}"
                      id="add"
                      indigo
                      class="row-defination-btn"
                      @click="${this.selectLabel ? this._addElementsWithTree : this._addElements}"
                    >
                      Aggiungi
                    </ing-button>
                    <ing-button
                      ?disabled="${!this.checkedData.length}"
                      id="remove"
                      class="row-defination-btn"
                      @click="${this._removeElements}"
                      >Rimuovi</ing-button
                    >
                  </div>
                `
          }

           <!-- <ing-icon
                    thumbsdown-indigo
                    slot="icon-before"
                    icon-id="ing:solid-arrows:arrowUp"
                    class="row-defination-icon"
                  ></ing-icon>
            <ing-icon
            thumbsdown-indigo
            slot="icon-before"
            icon-id="ing:solid-arrows:arrowDown"
            class="row-defination-icon"
            ></ing-icon> -->
        </div>
      `;
  }
}
customElements.define('rule-defination', RuleDefination);
