import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngInput,
  IngChipFilter,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngIcon,
} from 'ing-web';
import {
  addElementToLocalStorage,
  escapeSlashes,
  generateId,
  removeElementFromLocalStorage,
} from '../../../../utils/IngFeatTransparencyToolUtils.js';
import { CreateRule } from './NewRule.js';

import styles from './RuleCreationStyles.js';
import { ajaxInstance } from '../../../../utils/endpoints.js';
import { baseURL, baseURL2, localStorageKeysMap } from '../../../../utils/constants.js';
import {
  transformRulesToBackEnd,
  transformRulesToBackEndForPatch,
  transformRulesToFrontEnd,
} from '../../../../data/tranformations/ruleTransformation.js';
import { chunks, createVersionDetail } from '../../../../utils/chunks.js';
import { deriveData } from '../../../../utils/globalApiKeys.js';

export class RuleCreation extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'create-new-rule': CreateRule,
      'chip-filter': IngChipFilter,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-icon': IngIcon,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      rowData: { type: Array },
      isExistingDocument: { type: Boolean, reflect: true },
      sectionsList: Array,
      subSectionsList: Array,
      rows: Array,
      notes: Array,
      docId: String,
      appliesToElements: Array,
      rulesDdl1: Array,
      lookupData: Array,
      isModifiedDocument: { type: Boolean, reflect: true },
      savedChildList: Array,
      isTempModification: { type: Boolean, reflect: true },
      docItemId: String,
      docValidityDate: String,
    };
  }

  constructor() {
    super();
    this._noteAreaIndex = 0;
    //   this.rowData = [{
    //     id: generateId(),
    //     name: '',
    //     validity: '',
    //     style: '',
    //     columnNotes:[],
    //     columns: [],
    //     isNew: true
    //   }];
    this.rowData = [];
    this.selectFieldsData = {
      version1: {
        selectData: {},
        select2Data: {},
      },
      version2: {
        selectData: {},
        select2Data: {},
        select3Data: {},
      },
    };
    this.savedChildList = [];
    this.ajaxInstance = ajaxInstance;
    this.isUpdatePatchAction = false;
    this.isRefreshRow = false;
    this.isApiRejected = false;
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed.has('rowData') &&
      (!this.rowData || (this.rowData && !this.rowData.length) || this.rowData === 'undefined')
    ) {
      this.rowData = [
        {
          id: generateId(),
          name: '',
          description: '',
          validity: new Date(),
          isNew: true,
          isNotSaved: true,
          conditions: [
            {
              id: generateId(),
              column: '',
              value: '',
            },
          ],
          actions: [],
        },
      ];
    }
  }

  _fireRowsChangedEvent(data2, res) {
    const e = new CustomEvent('rows-changed', {
      detail: {
        data: this.rowData,
        res,
        data2,
        savedChildList: this.savedChildList,
      },
    });
    this.dispatchEvent(e);
  }

  // eslint-disable-next-line class-methods-use-this
  _postRule(rule) {
    const ruleBackend = transformRulesToBackEnd(rule);
    return this.ajaxInstance.post(baseURL, ruleBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _putRule(rule) {
    const ruleBackend = transformRulesToBackEndForPatch(rule);
    return this.ajaxInstance.patch(`${baseURL}/version`, ruleBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _deleteRule(ruleId) {
    return this.ajaxInstance.delete(`${baseURL}/${ruleId}`);
  }

  _addRowSection() {
    this.rowData = [
      ...this.rowData,
      {
        id: generateId(),
        name: '',
        description: '',
        validity: new Date(),
        // conditions: [
        // ],
        // actions: [
        // ],
        isNew: true,
        isNotSaved: true,
      },
    ];
    this._fireRowsChangedEvent();
  }

  async _removeRowSection(event) {
    const { id } = event.detail;
    const index = this.rowData.findIndex(e => e?.id?.toString() === id?.toString());
    if (this.rowData[index] && this.rowData[index].linkedElement === true) {
      this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
      this._fireRowsChangedEvent();
    } else if (this.isExistingDocument) {
      this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
      this._fireRowsChangedEvent();
    } else if (!this.rowData[index]?.isNotSaved) {
      try {
        await this._deleteRule(id);
        this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
        this._fireRowsChangedEvent();
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._deleteRule(data)', e);
      }
    } else if (this.rowData[index]?.isNotSaved) {
      this.rowData = this.rowData.filter(d => d?.id?.toString() !== id?.toString());
      const e = new CustomEvent('remove-event', {
        detail: {
          rowData: this.rowData,
        },
      });
      this.dispatchEvent(e);
    }
    // eslint-disable-next-line no-unused-expressions
    !this.isModifiedDocument &&
      !this.isExistingDocument &&
      removeElementFromLocalStorage(id, localStorageKeysMap.APPLICATION_RULES);
  }

  async _saveRow(event) {
    const elements = [...this.rowData];
    let detail1 = event?.detail;
    const index = elements.findIndex(e => e?.id?.toString() === detail1?.id?.toString());
    if (elements[index]?.versionDetailLevel0IDDescription && detail1) {
      detail1.versionDetailLevel0IDDescription = elements[index]?.versionDetailLevel0IDDescription;
    }
    if (elements[index]?.versionID && detail1) {
      detail1.versionID = elements[index]?.versionID;
    }
    if (index > -1 && !elements[index].isNotSaved) {
      const detail2 = await this.updateLevel1AndLevel2Items(detail1);
      detail1 = { ...detail1, ...detail2 };
    }
    const process = res => {
      elements[index] = detail1;
      elements[index].isNotSaved = false;
      elements[index].actions = this.sortActions(detail1.actions || []);
      this.rowData = [...elements];
      this.savedChildList = this.rowData;
      this.savedChildList = JSON.parse(JSON.stringify(this.savedChildList));
      this._fireRowsChangedEvent(detail1, res);
      this.isRefreshRow = false;
      // if (this.isUpdatePatchAction) {
      const e = new CustomEvent('row_column_changed', {
        detail: {
          id: detail1?.id,
          index1: index,
          data: elements,
        },
      });
      this.dispatchEvent(e);
      // }
      this.isUpdatePatchAction = false;
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(elements[index], localStorageKeysMap.APPLICATION_RULES);
    };

    if (index > -1 && !elements[index].isNotSaved) {
      try {
        const res = await this._putRule(detail1);
        this._showStatusEvent(res);
        if (this.isRefreshRow) {
          const res2 = await this._getVersionItemDetail(detail1?.id);
          detail1 = transformRulesToFrontEnd(res2?.data);
        }
        process(res);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._putRule(data)', e);
      }
    } else {
      try {
        // eslint-disable-next-line no-unused-expressions
        !this.isModifiedDocument &&
          !this.isExistingDocument &&
          removeElementFromLocalStorage(event?.detail?.id, localStorageKeysMap.APPLICATION_RULES);
        const res = await this._postRule(detail1);
        this._showStatusEvent(res);
        const res1 = await this._getVersionItemDetail(res?.data?.itemsVersionsID);
        detail1 = transformRulesToFrontEnd(res1?.data);
        if (res?.data?.versionID) {
          detail1.versionID = res?.data?.versionID;
        }
        process(res);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._postRule(data)', e);
      }
    }
  }

  _showStatusEvent(data, type) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data,
        type,
        elementType: 'Regola',
      },
    });
    this.dispatchEvent(ev);
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  _fieldValuesChanged(ev) {
    const { id, data } = ev.detail;
    clearTimeout(this.valuesChangedTimeout);
    this.valuesChangedTimeout = setTimeout(() => {
      const eventData = new CustomEvent('field-values-changed', {
        detail: { id },
      });
      this.dispatchEvent(eventData);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(data, localStorageKeysMap.APPLICATION_RULES);
    }, 300);
  }

  async _rowChanged(event) {
    if (event?.detail?.id) {
      const elements = [...this.rowData];
      const { id } = event?.detail;
      const index = elements.findIndex(e => e?.id?.toString() === id?.toString());
      const res1 = await this._getVersionItemDetail(id);
      const detail1 = transformRulesToFrontEnd(res1?.data);
      if (Array.isArray(detail1?.conditions) && elements[index]?.conditions) {
        elements[index].conditions = detail1?.conditions;
      }
      if (Array.isArray(detail1?.actions) && elements[index]?.actions) {
        elements[index].actions = detail1?.actions;
      }

      this.rowData = [...elements];
      if (this.isModifiedDocument) {
        this.rowData = [...elements];
      }

      const e = new CustomEvent('row_column_changed', {
        detail: {
          id,
          index1: index,
          data: elements,
        },
      });
      this.dispatchEvent(e);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(elements[index], localStorageKeysMap.APPLICATION_RULES);
    }
  }

  async updateLevel1AndLevel2Items(row) {
    let versionID;
    this.isApiRejected = false;
    if (!row?.versionID) {
      const versionList = await this.getVersionsList(row?.ruleId);
      if (versionList.length > 0) {
        const data = versionList.find(
          item => item?.itemsVersionsID?.toString() === row?.id?.toString(),
        );
        if (data) {
          versionID = data?.versionID;
          // eslint-disable-next-line
          row.versionID = data?.versionID;
        }
      }
    } else if (row?.versionID) {
      versionID = row?.versionID;
    }

    const level0UnSaveItems = [];
    const level0 = {};
    let createdItems = JSON.parse(JSON.stringify(row?.conditions || []));
    const createdItemsActions = JSON.parse(JSON.stringify(row?.actions || []));
    createdItems = createdItems.map(cond => {
      // eslint-disable-next-line
      cond.righN = cond.id;
      return cond;
    });

    createdItems.forEach(col1 => {
      if (!col1?.versionDetailLevel0ID && col1?.righN) {
        level0UnSaveItems.push(col1?.righN);
      } else if (col1?.versionDetailLevel0ID && col1?.righN) {
        level0[col1?.righN] = col1?.versionDetailLevel0ID;
      }
    });

    if (level0UnSaveItems?.length && versionID) {
      // Api
      // eslint-disable-next-line
      const level0FormatedList = level0UnSaveItems.map(litem0 => {
        // eslint-disable-next-line
        return this.createToBackEnd(
          0,
          versionID,
          'VERSION_DETAIL_LEVEL_1',
          'REGOLA_CONDIZIONE',
          litem0,
        );
      });
      const resList = await this.addVersionDetails(level0FormatedList);

      if (resList?.length) {
        resList.forEach(res1 => {
          if (res1?.data && res1?.versionDetailID) {
            level0[res1?.data] = res1?.versionDetailID;
          }
        });
      }
    }

    const colToBackEndList = [];
    createdItems.forEach(obj => {
      if (obj?.id) {
        if (!obj?.versionDetailLevel1IDRule && level0[obj?.righN] && obj.operator) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj?.righN],
              'FIELD',
              'RULE_CONDITION_OPERATOR',
              obj.operator,
            ),
          );
        }
        if (!obj?.versionDetailLevel1IDColumn && level0[obj?.righN] && obj.column) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj?.righN],
              'FIELD',
              'NUMERO_CAMPO_FILE_INDICE',
              obj.column,
            ),
          );
        }
        if (!obj?.versionDetailLevel1IDValore && level0[obj?.righN] && obj.value) {
          colToBackEndList.push(
            this.createToBackEnd(1, level0[obj?.righN], 'FIELD', 'VALORE', obj.value),
          );
        }
        if (!obj?.versionDetailLevel1IDRiga && level0[obj?.righN]) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj?.righN],
              'FIELD',
              'ASSOCIATO_A_RIGA',
              obj?.rowNo && obj?.rowNo !== 'undefined' ? obj?.rowNo : '0',
            ),
          );
        }
        if (!obj?.versionDetailLevel1IDIndex && level0[obj?.righN] && obj.rowNo) {
          colToBackEndList.push(
            this.createToBackEnd(
              1,
              level0[obj?.righN],
              'FIELD',
              'RULE_CONDITION_INDEX',
              createdItems.findIndex(d => d?.id?.toString() === obj?.rowNo?.toString()) + 1,
            ),
          );
        }
      }
    });

    if (colToBackEndList.length) {
      // Api
      await this.addVersionDetails(colToBackEndList);
    }

    const level0UnSaveItems1 = [];
    createdItemsActions.forEach(col1 => {
      if (!col1?.versionDetailLevel0ID) {
        level0UnSaveItems1.push(col1);
      }
    });

    let actionToBackEndList = [];
    createdItemsActions.forEach(obj => {
      if (obj?.id && obj?.versionDetailLevel0ID) {
        // eslint-disable-next-line
        obj.parentId = obj?.versionDetailLevel0ID;
        actionToBackEndList = [...actionToBackEndList, ...(this.getActionToBackEnd(obj) || [])];
      }
    });

    if (actionToBackEndList.length) {
      // Api
      await this.addVersionDetails(actionToBackEndList);
      this.isUpdatePatchAction = true;
    }

    if (versionID) {
      level0UnSaveItems1.forEach(async col1 => {
        if (col1?.appliedToRule) {
          const res = await this.addVersionDetails([
            this.createToBackEnd(
              0,
              versionID,
              'VERSION_DETAIL_LEVEL_1',
              'REGOLA_AZIONE',
              col1?.appliedToRule,
            ),
          ]);
          // eslint-disable-next-line
          col1.parentId = res[0]?.versionDetailID;
          const list = this.getActionToBackEnd(col1) || [];
          await this.addVersionDetails(list);
          this.isUpdatePatchAction = true;
        }
      });
    }

    let row1 = {
      conditions: [],
      actions: [],
    };
    this.isRefreshRow = true;
    if (
      level0UnSaveItems?.length ||
      level0UnSaveItems1?.length ||
      colToBackEndList?.length ||
      actionToBackEndList?.length
    ) {
      // GET API
      const res3 = await this._getVersionItemDetail(row?.id);
      row1 = transformRulesToFrontEnd(res3?.data);
      if (row1?.actions?.length) {
        // eslint-disable-next-line
        row1.actions = row.actions.map(item5 => {
          if (item5?.versionDetailLevel0ID) {
            const index = row?.actions?.findIndex(
              item6 =>
                item6?.versionDetailLevel0ID?.toString() ===
                item5?.versionDetailLevel0ID?.toString(),
            );
            if (index > -1) {
              // eslint-disable-next-line
              item5.appliedToRule = row?.actions[index]?.appliedToRule;
            }
            const index2 = row1?.actions?.findIndex(
              item6 =>
                item6?.versionDetailLevel0ID?.toString() ===
                item5?.versionDetailLevel0ID?.toString(),
            );

            if (index2 > -1) {
              // eslint-disable-next-line
              item5.versionDetailLevel1IDColonaId =
                row1?.actions[index2]?.versionDetailLevel1IDColonaId;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDSIApplica =
                row1?.actions[index2]?.versionDetailLevel1IDSIApplica;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDDescription =
                row1?.actions[index2]?.versionDetailLevel1IDDescription;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDVisible =
                row1?.actions[index2]?.versionDetailLevel1IDVisible;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDBold = row1?.actions[index2]?.versionDetailLevel1IDBold;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDItalic =
                row1?.actions[index2]?.versionDetailLevel1IDItalic;
            }
          }
          return item5;
        });
      }
      if (row1?.conditions?.length) {
        // eslint-disable-next-line
        row1.conditions = row.conditions.map(item5 => {
          if (item5?.versionDetailLevel0ID) {
            const index2 = row1?.conditions?.findIndex(
              item6 =>
                item6?.versionDetailLevel0ID?.toString() ===
                item5?.versionDetailLevel0ID?.toString(),
            );

            if (index2 > -1) {
              // eslint-disable-next-line
              item5.versionDetailLevel1IDColumn =
                row1?.conditions[index2]?.versionDetailLevel1IDColumn;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDRule = row1?.conditions[index2]?.versionDetailLevel1IDRule;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDValore =
                row1?.conditions[index2]?.versionDetailLevel1IDValore;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDRiga = row1?.conditions[index2]?.versionDetailLevel1IDRiga;
              // eslint-disable-next-line
              item5.versionDetailLevel1IDIndex =
                row1?.conditions[index2]?.versionDetailLevel1IDIndex;
            }
          }
          return item5;
        });
      }

      if (!this.isApiRejected) {
        this.isRefreshRow = false;
      }
      let conditions = [];
      let actions = [];
      const index1 = this.savedChildList.findIndex(
        item => item?.id?.toString() === row?.id?.toString(),
      );
      if (index1 > -1) {
        conditions = JSON.parse(JSON.stringify(this.savedChildList[index1]?.conditions || []));
        actions = JSON.parse(JSON.stringify(this.savedChildList[index1]?.actions || []));
        conditions = conditions.map(cond1 => {
          const index2 = row.conditions.findIndex(
            cond2 =>
              cond2?.versionDetailLevel0ID?.toString() === cond1?.versionDetailLevel0ID?.toString(),
          );
          if (index2 > -1) {
            // eslint-disable-next-line
            cond1 = { ...cond1, ...row?.conditions?.[index2] };
          }
          return cond1;
        });
        actions = actions.map(cond1 => {
          const index2 = row.actions.findIndex(
            cond2 =>
              cond2?.versionDetailLevel0ID?.toString() === cond1?.versionDetailLevel0ID?.toString(),
          );
          if (index2 > -1) {
            // eslint-disable-next-line
            cond1 = { ...cond1, ...row?.actions?.[index2] };
          }
          return cond1;
        });
      }
      if (row1?.conditions?.length && conditions?.length) {
        row1.conditions = row1.conditions.map(col1 => {
          const index = conditions?.findIndex(
            col2 =>
              col2?.versionDetailLevel0ID?.toString() === col1?.versionDetailLevel0ID?.toString(),
          );
          if (index > -1 && conditions?.[index]?.versionDetailLevel0ID) {
            // eslint-disable-next-line
            col1 = { ...conditions?.[index] };
          }
          return col1;
        });
      }

      if (row1?.actions?.length && actions?.length) {
        row1.actions = row1.actions.map(col1 => {
          const index = actions?.findIndex(
            col2 =>
              col2?.versionDetailLevel0ID?.toString() === col1?.versionDetailLevel0ID?.toString(),
          );
          if (index > -1 && actions?.[index]?.versionDetailLevel0ID) {
            // eslint-disable-next-line
            col1 = { ...actions?.[index] };
          }
          return col1;
        });
      }

      if (row1?.id) {
        row1.name = row?.name;
        row1.validity = row?.validity;
        row1.description = row?.description;
      }
    } else {
      row1 = { ...row };
    }

    return row1;
  }

  getLookupId(key, value) {
    if (this.lookupData?.length) {
      return this.lookupData.find(data => data.ldKey === key && data.ldValue === value)
        ?.lookupDataID;
    }
    return '0';
  }

  getActionToBackEnd(obj) {
    const actionToBackEndList = [];
    if (!obj?.versionDetailLevel1IDSIApplica && obj.parentId && obj.appliedToElement) {
      actionToBackEndList.push(
        this.createToBackEnd(1, obj.parentId, 'FIELD', 'SI_APPLICA_A', obj.appliedToElement),
      );
    }
    if (
      !obj?.versionDetailLevel1IDColonaId &&
      this.getLookupId('DOCUMENT_TYPE', 'RIGA')?.toString() === obj?.appliedToElement?.toString() &&
      obj.parentId &&
      obj.appliedToColumn
    ) {
      actionToBackEndList.push(
        this.createToBackEnd(1, obj.parentId, 'FIELD', 'COLONNA_ID', obj.versionDetailLevel0ID),
      );
    }
    if (
      (!obj?.versionDetailLevel1IDDescription && obj.parentId && obj.value) ||
      (obj.elementType === 'columns' && obj.parentId && obj.value)
    ) {
      actionToBackEndList.push(
        this.createToBackEnd(
          1,
          obj.parentId,
          'FIELD',
          'DESCRIZIONE_IN_STAMPA',
          escapeSlashes(obj.value),
        ),
      );
    }

    if (
      (!obj?.versionDetailLevel1IDVisible && obj.parentId) ||
      (obj.elementType === 'columns' && obj.parentId)
    ) {
      actionToBackEndList.push(
        this.createToBackEnd(
          1,
          obj.parentId,
          'FIELD',
          'VISIBLE',
          obj.isVisible && (obj.isVisible === 'true' || obj.isVisible === true) ? 'true' : 'false',
        ),
      );

      if (
        (!obj?.versionDetailLevel1IDBold && obj.parentId) ||
        (obj.elementType === 'columns' && obj.parentId)
      ) {
        actionToBackEndList.push(
          this.createToBackEnd(
            1,
            obj.parentId,
            'FIELD',
            'BOLD',
            obj.isBold && (obj.isBold === 'true' || obj.isBold === true) ? 'true' : 'false',
          ),
        );
      }
      if (
        (!obj?.versionDetailLevel1IDItalic && obj.parentId) ||
        (obj.elementType === 'columns' && obj.parentId)
      ) {
        actionToBackEndList.push(
          this.createToBackEnd(
            1,
            obj.parentId,
            'FIELD',
            'ITALIC',
            obj.isItalic && (obj.isItalic === 'true' || obj.isItalic === true) ? 'true' : 'false',
          ),
        );
      }
    }
    return actionToBackEndList;
  }

  // eslint-disable-next-line
  createToBackEnd(level, parentId, key, value, data) {
    return {
      versionDetailLevel: level,
      versionDetailParentID: parentId,
      itemTypeKey: key,
      itemTypeValue: value,
      data,
    };
  }

  _versionChanged(ev) {
    const { versionID, id } = ev.detail;
    const elements = this.rowData;
    const index = elements.findIndex(e => e?.id?.toString() === id?.toString());
    this.rowData[index].versionID = '';
    elements[index].versionID = versionID;
    this._cloneRecord(this.rowData[index], elements[index]);
  }

  // eslint-disable-next-line
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  // eslint-disable-next-line
  async addVersionDetails(data1) {
    try {
      let chunkData = await chunks([data1], createVersionDetail, 50);
      if (!chunkData) {
        chunkData = [];
      }

      if (!this.isApiRejected && chunkData.findIndex(item2 => item2.status === 'rejected') > -1) {
        this.isApiRejected = true;
      }

      chunkData = [
        ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
      ];

      let chunkData1 = [];
      chunkData.forEach(item => {
        if (item?.versionDetailsDTO) {
          chunkData1 = [...chunkData1, ...item?.versionDetailsDTO];
        }
      });
      return chunkData1;
      // eslint-disable-next-line
      // data1 = data1.map(i => {
      //   // eslint-disable-next-line
      //   i.versionDetailID = generateId();
      //   return i
      // });
      // return data1;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    try {
      const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
      return res.data ? deriveData(res.data) : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line class-methods-use-this
  sortActions(actions = []) {
    return actions.sort((d1, d2) => d1.versionDetailLevel0ID - d2.versionDetailLevel0ID);
  }

  _previewRule(e) {
    const ev = new CustomEvent('preview-rule', {
      detail: e.detail,
    });
    this.dispatchEvent(ev);
  }

  render() {
    return html`
      <div id="note-creation-area">
        ${this.rowData.map(
          d =>
            html`
              ${this.isExistingDocument
                ? html`<create-new-rule
                    @save-row="${this._saveRow}"
                    @remove-row="${this._removeRowSection}"
                    @field-values-changed="${this._fieldValuesChanged}"
                    @row-changed="${this._rowChanged}"
                    @versionID-changed="${this._versionChanged}"
                    id="${d.id}"
                    name="${d.name}"
                    description="${d.description}"
                    .validity="${d.validity}"
                    .columns="${d.conditions}"
                    .actions="${this.sortActions(d.actions)}"
                    .linkedElement="${d.linkedElement}"
                    isNew="${d.isNew}"
                    .selectFieldsData=${this.selectFieldsData}
                    ?isExistingDocument="${this.isExistingDocument}"
                    ?isNotSaved="${d.isNotSaved}"
                    .docId="${this.docId}"
                    .docItemId=${this.docItemId}
                    .appliesToElements="${this.appliesToElements}"
                    .rulesDdl1="${this.rulesDdl1}"
                    .lookupData="${this.lookupData}"
                    .ruleId="${d?.ruleId}"
                    .versionID="${d?.versionID}"
                    .docValidityDate=${this.docValidityDate}
                    ?isModifiedDocument=${this.isModifiedDocument}
                    ?isTempModification=${this.isTempModification}
                    @preview-rule=${this._previewRule}
                  ></create-new-rule>`
                : html`<ing-collapsible collapsibleCustom opened>
                    <ing-collapsible-invoker invokerCustom slot="invoker">
                      <span slot="open">
                        <p class="note-number">${d.name}</p>
                      </span>
                      <span slot="close"></span>
                    </ing-collapsible-invoker>
                    <div contetnSlotCollapsible slot="content">
                      <create-new-rule
                        @save-row="${this._saveRow}"
                        @remove-row="${this._removeRowSection}"
                        @field-values-changed="${this._fieldValuesChanged}"
                        @row-changed="${this._rowChanged}"
                        @versionID-changed="${this._versionChanged}"
                        id="${d.id}"
                        name="${d.name}"
                        description="${d.description}"
                        .validity="${d.validity}"
                        .columns="${d.conditions}"
                        .actions="${this.sortActions(d.actions)}"
                        .linkedElement="${d.linkedElement}"
                        isNew="${d.isNew}"
                        .selectFieldsData=${this.selectFieldsData}
                        ?isNotSaved="${d.isNotSaved}"
                        .sectionsList="${this.sectionsList}"
                        .subSectionsList="${this.subSectionsList}"
                        .rows="${this.rows}"
                        .notes="${this.notes}"
                        .appliesToElements="${this.appliesToElements}"
                        .rulesDdl1="${this.rulesDdl1}"
                        .lookupData="${this.lookupData}"
                        .ruleId="${d?.ruleId}"
                        .versionID="${d?.versionID}"
                        .docItemId=${this.docItemId}
                        .docValidityDate=${this.docValidityDate}
                        ?isTempModification=${this.isTempModification}
                        @preview-rule=${this._previewRule}
                      ></create-new-rule>
                    </div>
                  </ing-collapsible>`}
            `,
        )}
        ${!this.isExistingDocument
          ? html`<div>
              <ing-button id="createNew" class="create-new-button" @click="${this._addRowSection}">
                Crea nuova</ing-button
              >
            </div>`
          : ''}
      </div>
    `;
  }
}
customElements.define('rule-creation', RuleCreation);
