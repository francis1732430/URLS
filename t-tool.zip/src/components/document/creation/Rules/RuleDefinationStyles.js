import { css, orange, font16BoldMixin, font14Mixin, font12BoldMixin, black80 } from 'ing-web';

export default css`
  .row-defination-icon {
    width: 1.2rem;
    margin: 0 20px;
  }
  .inline-block-el {
    display: inline-block;
    vertical-align: top;
    margin-top: 24px;
    width: 10rem;
    color: ${black80};
    ${font14Mixin()}
  }
  .container::before {
    display: inline-table;
    clear: both;
  }
  .row-defination-btn {
    height: 28px;
    margin: 12px 25px 25px 0;
    width: 80px;
    ${font12BoldMixin()}
  }
  .row-defination-btn:not([disabled]) {
    background: transparent;
    border-color: ${orange};
    color: ${orange};
  }
  .margin-left-2 {
    margin-left: 2rem;
  }
  .margin-left-1 {
    margin-left: 1rem;
  }
  .inline-block-small {
    width: 7rem;
  }
  .row-definition-header {
    ${font16BoldMixin()}
    color: ${black80};
  }
  .inline-block-xs {
    width: 7rem;
  }
  .ml-1-point-2 {
    margin-left: 1.2rem;
  }
  .tab-btns-wrapper {
    border: 1px solid rgb(82, 81, 153);
    width: 20.5rem;
    border-radius: 26px;
    margin: 1rem 0 0 0.5rem;
    display: flex;
    padding: 3px;
    justify-content: center;
  }
  .tab-btn {
    color: rgb(82, 81, 153);
    background: transparent;
    border: 1px solid transparent;
    font-size: 16px;
    padding: 4px 12px;
    height: 36px;
    cursor: pointer;
    font-weight: 500;
  }
  .tab-btn:hover {
    box-shadow: none;
    transform: scale(1.01);
  }
  .tab-btn-active {
    color: white;
    background: #525199;
    border-radius: 26px;
  }
  .tree-list-wrapper {
    margin: 25px auto;
    position: relative;
  }
`;
