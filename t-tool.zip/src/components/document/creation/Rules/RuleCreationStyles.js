import { css, orange, black15, black6, font14BoldMixin, font24Mixin, font16Mixin } from 'ing-web';

export default css`
  .view_button::before {
    margin: 0 0 1.5em 0;
    min-height: 32px;
    width: 86px;
    display: inline-block;
  }

  .view_button {
    width: 86px;
    height: 32px;
    display: inline-block;
  }

  .create-new-button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .create-new-button {
    min-width: 180px;
    height: 32px;
    margin: 50px 0px 50px 103px;
    ${font14BoldMixin()}
  }
  [chipForNotes] {
    pointer-events: none;
    margin: 0;
    background-color: ${black15};
  }
  [invokerCustom] {
    border: 0px;
    ${font24Mixin()}
    position: relative;
    right: 0px;
    display: flex;
    flex-direction: row-reverse;
    justify-content: space-between;
    text-align: center;
  }
  [invokerCustom]:hover {
    background: transparent;
  }
  [invokerCustom]:focus {
    box-shadow: none;
  }
  [collapsibleCustom] {
    min-height: 35px;
  }
  [collapsibleCustom]:not([opened]) {
    border-bottom: 1px solid ${orange};
  }
  .note-seperator {
    height: 1px;
    width: 100%;
    background-color: ${black6};
  }
  .note-number {
    ${font16Mixin()}
    display: inline-block;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    text-align: center;
  }
  [collapsibleCustom][opened] [contetnSlotCollapsible] {
    max-height: unset !important;
    overflow: unset !important;
  }
  span[slot='open'] {
    position: relative;
    left: 50%;
    transform: translate(-50%, 0px);
    text-align: center;
    width: 65%;
  }
`;
