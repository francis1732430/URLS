import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngIcon,
  IngDialog,
  IngDialogFrame,
} from 'ing-web';

import styles from './RowDefinationStyles.js';
import { RowElements } from './RowElements.js';
import { generateId } from '../../../utils/IngFeatTransparencyToolUtils.js';
import { RemovableChip } from '../../removableChip/removableChip.js';
import { ConfirmationDialog } from '../../dialog/ConfirmationDialog.js';
import { messages } from '../../../data/messages.js';
import { chunks, createVersionDetail, removeVersionLevels } from '../../../utils/chunks.js';
import { baseURL } from '../../../utils/constants.js';
import { deriveData } from '../../../utils/globalApiKeys.js';
import { ajaxInstance } from '../../../utils/endpoints.js';

function closeDialog(event) {
  if (event && event.target) {
    event.target.dispatchEvent(
      new Event('close-overlay', {
        bubbles: true,
      }),
    );
  }
}
export class RowDefination extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'row-elements': RowElements,
      'removable-chip': RemovableChip,
      'confirmation-dialog': ConfirmationDialog,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
    };
  }

  static get properties() {
    return {
      headerText: { type: String },
      column1Text: { type: String },
      column2Text: { type: String },
      column3Text: { type: String },
      selectLabel: { type: String },
      radioLabel: { type: String },
      selectData: { type: Array },
      radioData: { type: Array },
      elementsData: { type: Array },
      columnNotes: { type: Array },
      checkedData: { type: Array },
      selectedColumn: { type: String },
      selectedNote: { type: Array },
      linkedElement: Boolean,
      ruleData: Array,
      confirmationMessageDetail: Object,
      isNotSaved: { type: Boolean, reflect: true },
      versionID: String,
      rowId: String,
      savedRow: Array,
      removeColumnNoteId: String,
      select2Data: Array,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.elementsData = [
      {
        id: generateId(),
        name: '',
        description: '',
        isBold: 'false',
        isItalic: 'false',
        note: '',
        column: '',
        isNew: true,
      },
    ];
    this.columnNotes = [];
    this.checkedData = [];
    this.confirmationMessageDetail = {};
    this.selectData = [];
    this.ajaxInstance = ajaxInstance;
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    if (!this.select2Data?.length && changedProperties.has('select2Data')) {
      this.selectedNote = [];
      this.columnNotes = [];
      this.elementsData = this.elementsData.map(el => {
        // eslint-disable-next-line
        el.notesList = [];
        return el;
      });
    } else if (
      this.isNotSaved &&
      this.select2Data?.length > 0 &&
      changedProperties.has('select2Data')
    ) {
      this.filterSelectedOptions();
    }

    if (
      this.selectedNote?.length &&
      this.select2Data?.length > 0 &&
      changedProperties.has('select2Data')
    ) {
      this.selectedNote = this.selectedNote.map(note => {
        const index = this.select2Data.findIndex(
          note1 => note?.id?.toString() === note1?.id?.toString(),
        );

        if (index > -1) {
          // eslint-disable-next-line
          note.name = this.select2Data[index].name;
        }
        return note;
      });
    }
    let isNoteChanged = false;

    if (
      this.select2Data?.length > 0 &&
      this.columnNotes?.length > 0 &&
      changedProperties.has('select2Data')
    ) {
      this.select2Data.forEach(opt => {
        this.columnNotes = this.columnNotes.map(el1 => {
          if (el1?.id?.toString() === opt?.id?.toString()) {
            if (el1?.name && opt?.name && el1?.name !== opt?.name) {
              isNoteChanged = true;
            }
            // eslint-disable-next-line
            el1.name = opt.name;
          }
          return el1;
        });
      });
      if (this.columnNotes?.length > 0 && isNoteChanged) {
        this.columnNotes = [...this.columnNotes];
        this._fireColumnNotesChangedEvent();
        isNoteChanged = false;
      }
    }
  }

  filterSelectedOptions() {
    // if (this.selectedNote?.length) {
    // if (!this.columnNotes) {
    //   this.columnNotes = [];
    // }
    // const colNotes = []
    // this.selectedNote = this.selectedNote.filter(opt => {
    //   const index = this.select2Data.findIndex(item => item?.id?.toString() === opt?.id?.toString());
    //   if (index === -1) {
    //     this.elementsData = this.elementsData.map(el => {
    //       if (el?.notesList?.length) {
    //         // eslint-disable-next-line
    //         el.notesList = el.notesList.filter(el1 => el1?.id?.toString() !== opt?.id?.toString())
    //       }
    //       return el;
    //     });
    //     const cindex = this.columnNotes.findIndex(el1 => el1?.id?.toString() === opt?.id?.toString());
    //     if (cindex > -1) {
    //       colNotes.push(this.columnNotes[cindex]);
    //     }
    //     return false;
    //   }
    //   return true;
    // });
    // this.columnNotes = [...colNotes];
    // } else if (this.isNotSaved) {
    // } else {
    if (!this.selectedNote) {
      this.selectedNote = [];
    }

    if (!this.columnNotes) {
      this.columnNotes = [];
    }
    const colNotes = [];

    this.select2Data.forEach(opt => {
      this.elementsData = this.elementsData.map(el => {
        if (el?.notesList?.length) {
          // eslint-disable-next-line
          el.notesList = el.notesList.filter(el1 => el1?.id?.toString() === opt?.id?.toString());
        }
        return el;
      });
      const cindex = this.columnNotes.findIndex(el1 => el1?.id?.toString() === opt?.id?.toString());
      if (cindex > -1) {
        colNotes.push(this.columnNotes[cindex]);
      }
      // this.columnNotes = this.columnNotes.filter(el1 => el1?.id?.toString() === opt?.id?.toString())
      this.selectedNote = this.selectedNote.filter(
        el1 => el1?.id?.toString() === opt?.id?.toString(),
      );
    });

    this.columnNotes = [...colNotes];
    // const obj = new Singleton();
    // obj.setNotesRemoved();
    // }
  }

  _fireColumnsChangedEvent(isDelete) {
    const e = new CustomEvent('columns-changed', {
      detail: {
        data: this.elementsData,
        isDelete,
      },
    });
    this.dispatchEvent(e);
  }

  _fireColumnNotesChangedEvent() {
    const e = new CustomEvent('column-notes-changed', {
      detail: {
        data: this.columnNotes,
      },
    });
    this.dispatchEvent(e);
  }

  async _addElements() {
    if (!this.linkedElement) {
      if (!this.selectLabel) {
        let detail;
        if (this.versionID) {
          const res = await this.addVersionDetails([
            this.createToBackEnd(
              0,
              this.versionID,
              'VERSION_DETAIL_LEVEL_1',
              'DETTAGLIO_RIGA',
              this.elementsData.length + 1,
            ),
          ]);
          detail = res[0]?.versionDetailID;
          this.versionIdChanged(this.versionID);
        } else if (!this.versionID && !this.isNotSaved && this.rowId) {
          const versionList = await this.getVersionsList(this.rowId);
          if (versionList.length > 0) {
            const data = versionList.find(
              item => item?.itemsVersionsID?.toString() === this.id?.toString(),
            );
            if (data) {
              this.versionID = data?.versionID;
              const res = await this.addVersionDetails([
                this.createToBackEnd(
                  0,
                  this.versionID,
                  'VERSION_DETAIL_LEVEL_1',
                  'DETTAGLIO_RIGA',
                  this.elementsData.length + 1,
                ),
              ]);
              detail = res[0]?.versionDetailID;
              this.versionIdChanged(this.versionID);
            }
          }
        }
        this.elementsData = [
          ...this.elementsData,
          {
            id: generateId(),
            name: '',
            description: '',
            isBold: 'false',
            isItalic: 'false',
            note: '',
            column: '',
            isNew: true,
            versionDetailLevel0ID: detail,
          },
        ];
        this._fireColumnsChangedEvent();
      } else {
        const elements = [...this.columnNotes];
        this.getStatusOfSelectedListbyColumn().forEach(sNote => {
          let note = this.select2Data.find(n => n?.id?.toString() === sNote?.id?.toString());
          note = JSON.parse(JSON.stringify(note));
          note.columnId = this.selectedColumn;
          note.columnName = this.selectData?.find(
            d => d?.id?.toString() === this.selectedColumn?.toString(),
          )?.name;
          if (this.savedRow?.length) {
            this.savedRow.forEach(row => {
              if (row?.columnNotes?.length) {
                const index1 = row.columnNotes.findIndex(
                  col =>
                    col?.columnId?.toString() === this.selectedColumn?.toString() &&
                    col?.id?.toString() === note?.id?.toString(),
                );
                if (index1 > -1) {
                  note.versionDetailLevel1ID = row.columnNotes[index1]?.versionDetailLevel1ID;
                  note.versionDetailLevel2ID = row.columnNotes[index1]?.versionDetailLevel2ID;
                }
              }
            });
          }
          elements.push({ ...note });
          this.elementsData = this.elementsData.map(item3 => {
            if (item3?.column?.toString() === note?.columnId?.toString()) {
              // eslint-disable-next-line
              item3.notesList = [];
            }
            return item3;
          });
          this.selectedNote =
            this.selectedNote?.filter(
              note2 => note2?.columnId1?.toString() !== note?.columnId?.toString(),
            ) || [];
        });
        this.columnNotes = [...elements];
        // this.selectedNote = [];
        this._fireColumnNotesChangedEvent();
      }
    }
  }

  _updateElement(event) {
    const elements = [...this.elementsData];
    const index = elements.findIndex(
      e => e?.id?.toString() === event?.detail?.data?.id?.toString(),
    );
    elements[index] = this.bindLevelId(event?.detail?.data, elements[index]);
    elements[index].isNew = undefined;
    this.elementsData = [...elements];
    this.removeColumnNoteId = '';
    this._fireColumnsChangedEvent();
  }

  _checkedHandler(event) {
    const elements = [...this.checkedData];
    const index = elements.findIndex(e => e === event?.detail?.id?.toString());
    if (index > -1) {
      elements.splice(index, 1);
    } else {
      elements.push(event?.detail?.id);
    }
    this.checkedData = [...elements];
  }

  async _removeElements() {
    try {
      let isExists = false;
      if (this.ruleData) {
        const typeId = this.selectData?.find(item => item?.name?.toString() === 'RIGA')?.id;
        // eslint-disable-next-line
        isExists = this.checkedData.some(id => {
          return this.ruleData.some(item2 => {
            const id1 = this.elementsData.find(
              el => el?.id?.toString() === id?.toString(),
            )?.versionDetailLevel0ID;
            const index = item2?.actions?.findIndex(
              // eslint-disable-next-line
              item1 => id1?.toString() === item1?.appliedToColumn?.toString(),
            );
            if (index > -1 && item2?.appliedToElement?.toString() === typeId?.toString()) {
              return true;
            }
            return false;
          });
        });
      }
      if (!isExists) {
        let elements = [...this.elementsData];
        const levelIds = [];
        this.checkedData.forEach(id => {
          elements.forEach(e => {
            if (e?.id?.toString() === id?.toString() && e?.versionDetailLevel0ID) {
              levelIds.push({ id: e?.versionDetailLevel0ID, level: 0, colId: e?.id });
            }
          });
        });
        if (levelIds?.length) {
          await this.deleteLevels(levelIds);
        }
        this.checkedData.forEach(id => {
          elements = elements.filter((e, i) => {
            if (e?.id?.toString() !== id?.toString()) {
              e.name = i + 1;
              return true;
              // eslint-disable-next-line
            }
            return false;
          });
        });
        if (levelIds?.length) {
          const elements1 = this.columnNotes.filter(n => {
            const index = levelIds.findIndex(
              lev1 => lev1?.colId?.toString() === n?.columnId?.toString(),
            );
            if (index > -1) {
              return false;
            }
            return true;
          });
          this.columnNotes = [...elements1];
        }
        if (elements.length === 0) {
          if (this.headerText === 'DEFINIZIONE RIGA') {
            elements = [
              {
                id: generateId(),
                name: '',
                description: '',
                isBold: 'false',
                isItalic: 'false',
                note: '',
                column: '',
                isNew: true,
              },
            ];
          }
        }
        this.elementsData = [...elements];
        this.checkedData = [];
        this.selectedColumn = elements[0].id;
        this._fireColumnsChangedEvent(true);
      } else if (isExists) {
        this.confirmationMessageDetail = {};
        this.confirmationMessageDetail.messages =
          messages?.existingElementAssociation?.NoteToRegola || [];
        this.openDialog();
      }
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  handleColumnChange(event) {
    this.selectedColumn = event.detail.id;
    if (!this.selectedNote) {
      this.selectedNote = [];
    }
    this.selectedNote =
      this.selectedNote?.filter(note1 => {
        // eslint-disable-next-line
        const index1 = this.columnNotes.findIndex(
          // eslint-disable-next-line
          n => `${n?.columnId}_${n?.id}` == note1?.columnNoteId,
        );
        if (index1 === -1) {
          return true;
        }
        return false;
      }) || [];
    let isNoteChanged = false;
    if (this.select2Data?.length > 0 && this.columnNotes?.length > 0) {
      this.select2Data.forEach(opt => {
        this.columnNotes = this.columnNotes.map(el1 => {
          if (el1?.id?.toString() === opt?.id?.toString()) {
            if (el1?.name && opt?.name && el1?.name !== opt?.name) {
              isNoteChanged = true;
            }
            // eslint-disable-next-line
            el1.name = opt.name;
          }
          return el1;
        });
      });
      if (this.columnNotes?.length > 0 && isNoteChanged) {
        this.columnNotes = [...this.columnNotes];
        this._fireColumnNotesChangedEvent();
        isNoteChanged = false;
      }
    }
    this.removeColumnNoteId = '';
  }

  handleNoteChange(event) {
    let selectedNote = event.detail.ids;
    if (selectedNote) {
      selectedNote = JSON.parse(JSON.stringify(selectedNote));
    }
    const { unCheckedId, columnId1 } = event.detail;
    this.removeColumnNoteId = '';
    if (!this.selectedNote) {
      this.selectedNote = [];
    }

    if (unCheckedId) {
      this.selectedNote = this.selectedNote?.filter(
        note2 => `${columnId1}_${unCheckedId}` !== note2?.columnNoteId?.toString(),
      );
    } else {
      selectedNote?.forEach(note1 => {
        const index = this.selectedNote?.findIndex(
          note2 =>
            note1?.id?.toString() === note2?.id?.toString() &&
            note1?.columnId1?.toString() === note2?.columnId1?.toString(),
        );
        // eslint-disable-next-line
        const index1 = this.columnNotes.findIndex(
          // eslint-disable-next-line
          n => `${n?.columnId}_${n?.id}` == note1?.columnNoteId,
        );
        if (index1 === -1) {
          if (index > -1) {
            this.selectedNote[index] = note1;
          } else {
            this.selectedNote.push(note1);
          }
        }
      });
      this.selectedNote = JSON.parse(JSON.stringify(this.selectedNote));
    }
  }

  _getFilteredNotes() {
    const noteIds = this.columnNotes
      ?.filter(n => n?.columnId?.toString() === this.selectedColumn?.toString())
      .map(n => n?.id?.toString());
    return this.select2Data?.filter(n => noteIds.indexOf(n?.id?.toString()) === -1) || [];
  }

  async _onChipDeleted(event) {
    try {
      const elements = [...this.columnNotes];
      const index = this.columnNotes.findIndex(
        n =>
          n.columnId === this.selectedColumn && event?.detail?.id?.toString() === n?.id?.toString(),
      );

      if (index > -1 && elements[index]?.versionDetailLevel2ID) {
        await this.deleteLevels([
          {
            id: elements[index]?.versionDetailLevel2ID,
            level: 2,
          },
        ]);
      }

      elements.splice(index, 1);
      this.columnNotes = [...elements];
      this.removeColumnNoteId = `${this.selectedColumn}_${event?.detail?.id}`;
      this._fireColumnNotesChangedEvent();
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  _getAddbuttonDisabled() {
    if (!this.selectLabel) return false;
    const exp =
      !!this.selectLabel &&
      (!this.selectData.filter(e => !e.isNew).length ||
        !this.getStatusOfSelectedList() ||
        !this._getFilteredNotes().length);

    return exp;
  }

  _closeDialog(ev) {
    this.confirmationMessageDetail = {};
    closeDialog(ev);
  }

  openDialog() {
    const dialog = this.shadowRoot.querySelector('#dialog2');
    dialog.opened = true;
  }

  // eslint-disable-next-line
  bindLevelId(newObj, originalObj) {
    const newObj1 = newObj;
    if (originalObj?.versionDetailLevel1IDDescription) {
      newObj1.versionDetailLevel1IDDescription = originalObj?.versionDetailLevel1IDDescription;
    }
    if (originalObj?.versionDetailLevel1IDBold) {
      newObj1.versionDetailLevel1IDBold = originalObj?.versionDetailLevel1IDBold;
    }
    if (originalObj?.versionDetailLevel1IDItalic) {
      newObj1.versionDetailLevel1IDItalic = originalObj?.versionDetailLevel1IDItalic;
    }
    if (originalObj?.versionDetailLevel1IDColumn) {
      newObj1.versionDetailLevel1IDColumn = originalObj?.versionDetailLevel1IDColumn;
    }
    if (originalObj?.versionDetailLevel0ID) {
      newObj1.versionDetailLevel0ID = originalObj?.versionDetailLevel0ID;
    }
    // if (originalObj?.versionDetailLevel1ID) {
    //   newObj1.versionDetailLevel1ID = originalObj?.versionDetailLevel1ID;
    // }
    // if (originalObj?.versionDetailLevel2ID) {
    //   newObj1.versionDetailLevel2ID = originalObj?.versionDetailLevel2ID;
    // }
    return newObj1;
  }

  // eslint-disable-next-line
  async deleteLevels(chunkItems) {
    try {
      // eslint-disable-next-line
      chunkItems = chunkItems.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      await chunks(chunkItems, removeVersionLevels, 50);

      const e = new CustomEvent('row-changed', {});
      this.dispatchEvent(e);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line
  async addVersionDetails(data1) {
    try {
      let chunkData = await chunks([data1], createVersionDetail, 50);
      if (!chunkData) {
        chunkData = [];
      }
      chunkData = [
        ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
      ];

      let chunkData1 = [];
      chunkData.forEach(item => {
        if (item?.versionDetailsDTO) {
          chunkData1 = [...chunkData1, ...item?.versionDetailsDTO];
        }
      });
      return chunkData1;
      // eslint-disable-next-line
      // data1 = data1.map(i => {
      //   // eslint-disable-next-line
      //   i.versionDetailID = generateId();
      //   return i
      // });
      // return data1;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return [];
    }
  }

  // eslint-disable-next-line
  async getVersionsList(id) {
    try {
      const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
      return res.data ? deriveData(res.data) : [];
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log('Error', error);
    }
  }

  // eslint-disable-next-line
  createToBackEnd(level, parentId, key, value, data) {
    return {
      versionDetailLevel: level,
      versionDetailParentID: parentId,
      itemTypeKey: key,
      itemTypeValue: value,
      data,
    };
  }

  // eslint-disable-next-line
  async versionIdChanged(versionID) {
    const e = new CustomEvent('versionID-changed', {
      detail: versionID,
    });
    this.dispatchEvent(e);
  }

  getStatusOfSelectedList() {
    return (
      this.elementsData.find(item => item?.column?.toString() === this.selectedColumn?.toString())
        ?.notesList?.length > 0
    );
  }

  getStatusOfSelectedListbyColumn() {
    return (
      this.elementsData.find(item => item?.column?.toString() === this.selectedColumn?.toString())
        ?.notesList || []
    );
  }

  render() {
    return html`
    <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Cancella Errore</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              ?isNormalConfirmation=${true}
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
    <div class="${this.selectLabel ? 'ml-30p' : ''}">
          <div class="${!this.selectLabel ? 'ml-30p' : ''}">
            ${
              this.headerText
                ? html`<label class="row-definition-header">${this.headerText}</label>`
                : ''
            }
          </div>
          <div>
            <div class="inline-block-el ${!this.selectLabel ? 'margin-left-2 short-block' : ''}">
              ${this.column1Text ? this.column1Text : ''}
            </div>
            <div class="inline-block-el inline-block-el-col2 ${
              this.selectLabel ? '' : 'short-block-2'
            }">
              ${this.column2Text ? this.column2Text : ''}
            </div>
            <div class="inline-block-el">
              ${this.column3Text ? this.column3Text : ''}
            </div>
          </div>

          ${this.elementsData.map(
            (e, i) =>
              html`<row-elements
                @checked-fields="${this._checkedHandler}"
                @add-new-elements="${this._updateElement}"
                radioLabel="${this.radioLabel || ''}"
                selectLabel="${this.selectLabel || ''}"
                .selectData="${this.selectData || []}"
                .select2Data="${this._getFilteredNotes() || []}"
                .radioData="${this.radioData || []}"
                .id="${e.id}"
                input1Val="${this.selectLabel ? e.name : i + 1}"
                input2Val="${e.description}"
                .isBold="${
                  // eslint-disable-next-line
                  e.isBold == true ? true : false
                }"
                .isItalic="${
                  // eslint-disable-next-line
                  e.isItalic == true ? true : false
                }"
                selectVal="${e.column}"
                select2Val="${e.note}"
                .selectedNotes="${e.notesList}"
                .tempSelectedNotesList="${this.selectedNote}"
                .checkedData="${this.checkedData}"
                ?isNew="${e.isNew}"
                .linkedElement="${this.linkedElement}"
                .removeColumnNoteId="${this.removeColumnNoteId}"
                @column-select-changed="${this.handleColumnChange}"
                @note-select-changed="${this.handleNoteChange}"
              ></row-elements>`,
          )}
           <div class="${!this.selectLabel ? 'margin-left-2' : ''}">
            <ing-button ?disabled="${
              this._getAddbuttonDisabled() || this.linkedElement
            }" id="add" indigo class="row-defination-btn" @click="${
      this._addElements
    }"> Aggiungi </ing-button>
            ${
              !this.selectLabel
                ? html`<ing-button
                    ?disabled="${!this.checkedData.length}"
                    id="remove"
                    class="row-defination-btn"
                    @click="${this._removeElements}"
                    >Rimuovi</ing-button
                  >`
                : ''
            }
            
           </div>
           <div>
            ${this.columnNotes
              .filter(n => n?.columnId?.toString() === this.selectedColumn?.toString())
              .map(
                d => html`
                  <removable-chip
                    @chip-deleted="${this._onChipDeleted}"
                    id="${d.id}"
                    labelText="${`${d.columnName} ${d.labelText || d.name}`}"
                    ?closeIconEnable="${this.linkedElement}"
                  >
                  </removable-chip>
                `,
              )}
           </div>
           <!-- <ing-icon
                    thumbsdown-indigo
                    slot="icon-before"
                    icon-id="ing:solid-arrows:arrowUp"
                    class="row-defination-icon"
                  ></ing-icon>
            <ing-icon
            thumbsdown-indigo
            slot="icon-before"
            icon-id="ing:solid-arrows:arrowDown"
            class="row-defination-icon"
            ></ing-icon> -->
        </div>
        </div>
      `;
  }
}
customElements.define('row-defination', RowDefination);
