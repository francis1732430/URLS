import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngInput,
  IngChipFilter,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngIcon,
} from 'ing-web';
import {
  transformNoteToBackend,
  transformNoteToBackendForPatch,
  transformNoteToFrontEnd,
} from '../../../data/tranformations/noteTransformation.js';
import { baseURL, baseURL2, localStorageKeysMap } from '../../../utils/constants.js';
import { ajaxInstance } from '../../../utils/endpoints.js';
import {
  addElementToLocalStorage,
  generateId,
  removeElementFromLocalStorage,
} from '../../../utils/IngFeatTransparencyToolUtils.js';
import { CreateNewNote } from './CreateNewNote.js';

import styles from './NewDocumentCreationStyles.js';

export class NewDocumentCreation extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'create-new-note': CreateNewNote,
      'chip-filter': IngChipFilter,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-icon': IngIcon,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      notesData: { type: Array },
      isExistingDocument: { type: Boolean, reflect: true },
      isModifiedDocument: { type: Boolean, reflect: true },
    };
  }

  constructor() {
    super();
    this._noteAreaIndex = 0;
    this.ajaxInstance = ajaxInstance;
  }

  updated(changed) {
    super.updated(changed);
    if (
      changed.has('notesData') &&
      (!this.notesData ||
        (this.notesData && !this.notesData.length) ||
        this.notesData === 'undefined')
    ) {
      this.notesData = [
        {
          id: generateId(),
          name: '',
          description: '',
          validity: new Date(),
          isNotSaved: true,
        },
      ];
    }
  }

  _fireNotesChangedEvent(id, data2, res) {
    const e = new CustomEvent('notes-changed', {
      detail: {
        data: this.notesData,
        id,
        data2,
        res,
      },
    });
    this.dispatchEvent(e);
  }

  // eslint-disable-next-line class-methods-use-this
  _postNote(note) {
    const noteBackend = transformNoteToBackend(note);
    return this.ajaxInstance.post(baseURL, noteBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _putNote(note) {
    const noteBackend = transformNoteToBackendForPatch(note);
    return this.ajaxInstance.patch(`${baseURL}/version`, noteBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _deleteNote(noteId) {
    return this.ajaxInstance.delete(`${baseURL}/${noteId}`);
  }

  _showStatusEvent(data, type) {
    const ev = new CustomEvent('show-status-dialog', {
      detail: {
        data,
        type,
      },
    });
    this.dispatchEvent(ev);
  }

  async _addNoteSection(event) {
    let { data } = event.detail;
    const index = this.notesData.findIndex(d => d?.id?.toString() === data?.id?.toString());
    const process = res => {
      // data.id = generateId();
      // data.name = data.id
      this.notesData[index] = data;
      this.notesData[index].isNotSaved = false;
      this.notesData = [...this.notesData];
      this._fireNotesChangedEvent(undefined, data, res);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(this.notesData[index], localStorageKeysMap.APPLICATION_NOTES);
    };
    if (this.notesData[index]?.versionDetailLevel0ID && data) {
      data.versionDetailLevel0ID = this.notesData[index]?.versionDetailLevel0ID;
    }
    if (index > -1 && !this.notesData[index].isNotSaved) {
      try {
        const res = await this._putNote(data);
        this._showStatusEvent(res);
        process(res);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._putNote(data)', e);
      }
    } else {
      try {
        // eslint-disable-next-line no-unused-expressions
        !this.isModifiedDocument &&
          !this.isExistingDocument &&
          removeElementFromLocalStorage(data.id, localStorageKeysMap.APPLICATION_NOTES);
        const res = await this._postNote(data);
        this._showStatusEvent(res);
        const res1 = await this._getVersionItemDetail(res?.data?.itemsVersionsID);
        data = transformNoteToFrontEnd(res1?.data);
        process(data);
      } catch (e) {
        if (
          e?.config?.url?.includes('/document-template-administration/item') &&
          (e?.config?.method === 'post' ||
            e?.config?.method === 'put' ||
            e?.config?.method === 'patch')
        ) {
          this._showStatusEvent({});
        }
        // eslint-disable-next-line no-console
        console.log('failed this._postNote(data)', e);
      }
    }
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id) {
    try {
      return await this.ajaxInstance.get(`${baseURL2}/version/${id}`);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  async _removeNoteSection(event) {
    const { data } = event.detail;
    const index = this.notesData.findIndex(d => d?.id?.toString() === data?.toString());
    if (!this.notesData[index]?.isNotSaved) {
      // try {
      //   await this._deleteNote(data);
      //   // this.notesData = this.notesData.filter(d => d.id.toString() !== data.toString());
      // } catch (e) {
      //   // eslint-disable-next-line no-console
      //   console.log('failed this._deleteNote(data)', e);
      // }
      this._fireNotesChangedEvent(data);
    } else if (this.isExistingDocument) {
      this.notesData = this.notesData.filter(d => d?.id?.toString() !== data?.toString());
      this._fireNotesChangedEvent(data);
    } else if (this.notesData.length > 1) {
      this.notesData = this.notesData.filter(d => d?.id?.toString() !== data?.toString());
      const e = new CustomEvent('remove-event', {
        detail: {
          notesData: this.notesData,
        },
      });
      this.dispatchEvent(e);
    }
  }

  _addNewNoteSection() {
    this.notesData = [
      ...this.notesData,
      {
        id: generateId(),
        name: '',
        description: '',
        validity: new Date(),
        isNotSaved: true,
      },
    ];
  }

  _fieldValuesChanged(ev) {
    const { id, data } = ev.detail;
    clearTimeout(this.valuesChangedTimeout);
    this.valuesChangedTimeout = setTimeout(() => {
      const eventData = new CustomEvent('field-values-changed', {
        detail: { id },
      });
      this.dispatchEvent(eventData);
      // eslint-disable-next-line no-unused-expressions
      !this.isModifiedDocument &&
        !this.isExistingDocument &&
        addElementToLocalStorage(data, localStorageKeysMap.APPLICATION_NOTES);
    }, 300);
  }

  render() {
    return html`
      <div id="note-creation-area">
        ${this.notesData &&
        this.notesData.map(
          d =>
            html`
              ${this.isModifiedDocument
                ? html`<create-new-note
                    id="${d.id}"
                    @remove-note-section="${this._removeNoteSection}"
                    @add-note-section="${this._addNoteSection}"
                    @field-values-changed="${this._fieldValuesChanged}"
                    name="${d.name}"
                    .validity="${d.validity}"
                    description="${d.description}"
                    .linkedElement="${d.linkedElement}"
                    .noteId="${d.noteId}"
                    ?isExistingDocument="${this.isExistingDocument}"
                    ?isModifiedDocument=${this.isModifiedDocument}
                    ?isNotSaved=${d.isNotSaved}
                  ></create-new-note>`
                : html`<ing-collapsible collapsibleCustom opened>
                    <ing-collapsible-invoker invokerCustom slot="invoker">
                      <span slot="open">
                        <p class="note-number">${d.name}</p>
                      </span>
                      <span slot="close"></span>
                    </ing-collapsible-invoker>
                    <div contetnSlotCollapsible slot="content">
                      <create-new-note
                        id="${d.id}"
                        @remove-note-section="${this._removeNoteSection}"
                        @add-note-section="${this._addNoteSection}"
                        @field-values-changed="${this._fieldValuesChanged}"
                        name="${d.name}"
                        .validity="${d.validity}"
                        description="${d.description}"
                        .linkedElement="${d.linkedElement}"
                        .noteId="${d.noteId}"
                        ?isExistingDocument="${this.isExistingDocument}"
                        ?isNotSaved=${d.isNotSaved}
                      ></create-new-note>
                    </div>
                  </ing-collapsible>`}
            `,
        )}
        ${this.isExistingDocument
          ? ''
          : html`<div>
              <ing-button
                id="createNew"
                class="create-new-button"
                @click="${this._addNewNoteSection}"
              >
                Crea nuova</ing-button
              >
            </div>`}
      </div>
    `;
  }
}
customElements.define('new-document-creation', NewDocumentCreation);
