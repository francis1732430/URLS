import { css, orange, font12BoldMixin, font14Mixin, black80 } from 'ing-web';

export default css`
  .dropdown-container {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-start;
  }
  .dropdown-box {
    margin-top: 30px;
    width: 100%;
  }
  .row-defination-btn {
    height: 28px;
    margin: 0 25px 25px 0;
    width: 80px;
    ${font12BoldMixin()}
  }
  .row-defination-btn:not([disabled]) {
    background: transparent;
    border-color: ${orange};
    color: ${orange};
  }
  .add-btn {
    margin-top: 15px;
  }
  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    width: 376px;
    color: ${black80};
    ${font14Mixin()}
  }
  [inputElement] {
    margin-bottom: 8px !important;
    display: block;
    width: 376px;
    color: ${black80};
    ${font14Mixin()}
  }

  .w-50 {
    width: 50% !important;
  }
`;
