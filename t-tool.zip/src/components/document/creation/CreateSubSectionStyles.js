import { css, black15, orange, font14BoldMixin, font24Mixin, font16Mixin } from 'ing-web';

export default css`
  .create-sub-section {
    width: 100%;
  }
  .create-new-button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .create-new-button {
    min-width: 180px;
    height: 32px;
    ${font14BoldMixin()}
  }
  [chipForSections] {
    pointer-events: none;
    margin: 0;
    background-color: ${black15};
  }
  [invokerCustom] {
    border: 0px;
    ${font24Mixin()}
    position: relative;
    right: 0px;
    display: flex;
    flex-direction: row-reverse;
    justify-content: space-between;
    text-align: center;
  }
  [invokerCustom]:hover {
    background: transparent;
  }
  [invokerCustom]:focus {
    box-shadow: none;
  }
  [collapsibleCustom] {
    min-height: 35px;
  }
  [collapsibleCustom]:not([opened]) {
    border-bottom: 1px solid ${orange};
  }
  .section-number {
    ${font16Mixin()}
    display: inline-block;
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    text-align: center;
  }
  [collapsibleCustom][opened] [contetnSlotCollapsible] {
    max-height: unset !important;
    overflow: unset !important;
  }
  .add-btn {
    margin: 27px 32px 27px 130px;
  }
  span[slot='open'] {
    position: relative;
    left: 50%;
    transform: translate(-50%, 0px);
    text-align: center;
    width: 65%;
  }
`;
