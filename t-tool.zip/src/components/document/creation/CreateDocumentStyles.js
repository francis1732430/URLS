import { black80, css, font14BoldMixin, font14Mixin, font19BoldMixin, orange } from 'ing-web';

export default css`
  .display-flex {
    display: flex;
  }
  .container {
    margin-top: 31px;
    margin-left: 108px;
  }
  .document-detail {
    color: ${black80};
    ${font19BoldMixin()}
    margin-bottom: 15px;
  }
  .document_details_name {
    height: 64px;
    width: 705px;
    margin-bottom: 58px;
  }
  .stato {
    height: 64px;
    width: 183.85px;
    margin-left: 131px;
  }
  .document_details_box {
    height: 64px;
    width: 150px;
    margin-left: 25px;
  }
  .document_details_id {
    height: 64px;
    width: 150px;
  }
  .input_value {
    color: ${black80};
    ${font14Mixin()}
  }
  .mt-56 {
    margin-top: 56px;
  }
  .right_alignment {
    margin: 0;
    display: flex;
    justify-content: right;
    margin-top: 50px;
    margin-bottom: 50px;
    width: 69%;
  }
  .cancel_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .cancel_button {
    width: 180px;
    height: 32px;
    margin-right: 28px;
    ${font14BoldMixin()}
  }

  .save_button::before {
    margin: 0 0 0 0;
    min-height: 32px;
    width: 180px;
  }

  .save_button {
    width: 180px;
    height: 32px;
    margin-left: 28px;
    ${font14BoldMixin()}
  }
  [inputElement] label {
    margin-bottom: 8px !important;
    display: block;
    ${font14Mixin()}
  }
  .flex-column {
    flex-direction: column;
  }
  .version {
    width: 285px;
    margin-bottom: 24px;
    height: 64px;
  }
  [colorElement] label {
    color: ${orange};
  }
  .document_details_template {
    width: 285px;
    height: 64px;
    margin-top: 63px;
  }
`;
