import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngButton,
  IngIcon,
  IngForm,
  IngSelect,
  IngInputDatepicker,
  IngDialogFrame,
  IngDialog,
} from 'ing-web';

import styles from './CreateDocumentStyles.js';
import { FileUpload } from '../../fileUpload/fileUpload.js';
import { RemovableChip } from '../../removableChip/removableChip.js';
import {
  addElementToLocalStorage,
  generateId,
} from '../../../utils/IngFeatTransparencyToolUtils.js';
import { ComponentAssociation } from './ComponentAssociation.js';
import {
  transformDocumentsToBackend,
  transformLookUpDataToFrontEnd,
} from '../../../data/tranformations/documentTranformation.js';
import { ajaxInstance } from '../../../utils/endpoints.js';
import { baseURL, localStorageKeysMap } from '../../../utils/constants.js';
import { ConfirmationDialog } from '../../dialog/ConfirmationDialog.js';
import { messages } from '../../../data/messages.js';
// import { chunks, createRelations } from '../../../utils/chunks.js';

function closeDialog(event) {
  if (event && event.target) {
    event.target.dispatchEvent(
      new Event('close-overlay', {
        bubbles: true,
      }),
    );
  }
}

export class CreateDocument extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'ing-icon': IngIcon,
      'ing-select': IngSelect,
      'ing-form': IngForm,
      'file-upload': FileUpload,
      'ing-input-datepicker': IngInputDatepicker,
      'removable-chip': RemovableChip,
      'component-association': ComponentAssociation,
      'confirmation-dialog': ConfirmationDialog,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
    };
  }

  static get properties() {
    return {
      name: String,
      product: String,
      type: String,
      code: String,
      start_date: String,
      status: String,
      _data: Array,
      templateFile: String,
      documentData: Object,
      productList: Array,
      typeList: Array,
      statusList: Array,
      sectionsList: Array,
      documentSectionList: Array,
      documentRuleList: Array,
      rulesData: Array,
      selectedListSection: Array,
      selectedListRule: Array,
      isNotSaved: Boolean,
      lookupData: Array,
      confirmationMessageDetail: Object,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.start_date = new Date();
    this._data = [];
    this.product = '';
    this.type = '';
    this.status = '';
    this.productVal = '';
    this.typeVal = '';
    this.statusVal = '';
    this.templateFile = 'dds_cca_2021.jrxml';
    this.productList = [];
    this.typeList = [];
    this.statusList = [];
    this.rulesData = [];
    this.sectionsList = [];
    this.selectedListSection = [{ id: '1', name: this.name }];
    this.selectedListRule = [{ id: '1', name: this.name }];
    this.isNotSaved = true;
    this.lookupData = [];
    this.confirmationMessageDetail = {};
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('lookupData') && this.lookupData?.length > 0) {
      this.productList = transformLookUpDataToFrontEnd(this.lookupData, 'PRODUCT');
      this.statusList = transformLookUpDataToFrontEnd(this.lookupData, 'STATUS');
      this.typeList = transformLookUpDataToFrontEnd(this.lookupData, 'TYPE');

      if (this.productList && this.productList.length > 0) {
        this.product = this.productList[0].id;
        this.productVal = this.productList[0].name;
      }

      if (this.statusList && this.statusList.length > 0) {
        this.status = this.statusList.find(item => item?.name === 'IN SVILUPPO')?.id;
        this.statusVal = this.statusList.find(item => item?.name === 'IN SVILUPPO')?.name;
      }

      if (this.typeList && this.typeList.length > 0) {
        this.type = this.typeList[0].id;
        this.typeVal = this.typeList[0].name;
      }
    }
  }

  _filesAdded(e) {
    const files = e.detail.map(f => {
      f.id = generateId(); // eslint-disable-line no-param-reassign
      return f;
    });
    this._data = [...this._data, ...files];
  }

  handleChange(event) {
    if (event.target.name === 'start_date') {
      this[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this[event.target.name] = event.target.value;
    }
    this._fieldValuesChanged();
  }

  _fieldValuesChanged() {
    const statusObj = this.statusList?.find(item => item?.name?.toUpperCase() === 'IN SVILUPPO');
    const productObj = this.productList?.find(
      item => item.id.toString() === this.product.toString(),
    );
    const typeObj = this.typeList?.find(item => item.id.toString() === this.type.toString());
    const data = {
      name: this.name,
      status: this.status,
      statusVal: statusObj?.name,
      product: this.product,
      productVal: productObj?.name,
      type: this.type,
      typeVal: typeObj?.name,
      start_date: this.start_date,
      code: this.code,
      templateFile: this.templateFile,
      selectedListSection: this.selectedListSection,
      selectedListRule: this.selectedListRule,
    };
    clearTimeout(this.valuesChangedTimeout);
    this.valuesChangedTimeout = setTimeout(() => {
      const eventData = new CustomEvent('field-values-changed', {
        detail: { data },
      });
      this.dispatchEvent(eventData);
      addElementToLocalStorage(data, localStorageKeysMap.APPLICATION_DOCUMENTS, true);
    }, 300);
  }

  _onChipDeleted(e) {
    const { id } = e.detail;
    this._data = this._data.filter(d => d?.id?.toString() !== id?.toString());
  }

  // eslint-disable-next-line class-methods-use-this
  _postDocument(document) {
    const documentBackend = transformDocumentsToBackend(document);
    return ajaxInstance.post(baseURL, documentBackend);
  }

  // eslint-disable-next-line class-methods-use-this
  _putDocument(document) {
    const documentBackend = transformDocumentsToBackend(document);
    return ajaxInstance.patch(`${baseURL}/version`, documentBackend);
  }

  // eslint-disable-next-line
  normalizeSections(selectedListSection) {
    // eslint-disable-next-line no-unused-expressions
    selectedListSection?.[0]?.sections &&
      selectedListSection?.[0]?.sections.forEach(section => {
        // eslint-disable-next-line
        section.id = section?.appliedToRule || section?.id;
      });
  }

  async _save() {
    const statusObj = this.statusList.find(item => item?.name?.toUpperCase() === 'IN SVILUPPO');
    const productObj = this.productList.find(
      item => item?.id?.toString() === this.product?.toString(),
    );
    const typeObj = this.typeList.find(item => item?.id?.toString() === this.type?.toString());
    this.selectedListRule[0].rules = this.rulesData;
    this.selectedListSection[0].sections = this.sectionsList;
    const documentEvent = new CustomEvent('added-document', {
      detail: {
        name: this.name,
        status: this.status,
        statusVal: statusObj.name,
        product: this.product,
        productVal: productObj.name,
        type: this.type,
        typeVal: typeObj.name,
        start_date: this.start_date,
        data: this._data,
        code: this.code,
        templateFile: this.templateFile,
        selectedListSection: this.selectedListSection,
        selectedListRule: this.selectedListRule,
      },
    });

    if (!this.isNotSaved) {
      try {
        this.normalizeSections(this.selectedListSection);
        const data1 = await this._putDocument(documentEvent.detail);
        documentEvent.detail.id = data1?.data?.itemsVersionsID;
        documentEvent.detail.docId = data1?.data?.itemID;
        this.addRelationShip(
          this.selectedListRule,
          this.selectedListSection,
          documentEvent.detail.id,
        );
        this.dispatchEvent(documentEvent);
        addElementToLocalStorage(
          documentEvent.detail,
          localStorageKeysMap.APPLICATION_DOCUMENTS,
          true,
        );
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._putDocument(data)', e);
      }
    } else {
      try {
        this.normalizeSections(this.selectedListSection);
        const data1 = await this._postDocument(documentEvent.detail);
        documentEvent.detail.id = data1?.data?.itemsVersionsID;
        documentEvent.detail.docId = data1?.data?.itemID;
        this.addRelationShip(
          this.selectedListRule,
          this.selectedListSection,
          documentEvent.detail.id,
        );
        this.isNotSaved = false;
        this.dispatchEvent(documentEvent);
        addElementToLocalStorage(
          documentEvent.detail,
          localStorageKeysMap.APPLICATION_DOCUMENTS,
          true,
        );
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._postDocument(data)', e);
      }
    }
  }

  // eslint-disable-next-line
  async addRelationShip(selectedListRule, selectedListSection, id) {
    const rulesList = [];
    const sectionList = [];
    // eslint-disable-next-line no-unused-expressions
    selectedListRule?.[0]?.rules &&
      selectedListRule?.[0]?.rules.forEach((rule, i) => {
        rulesList.push({
          parentId: id,
          childId: rule?.id,
          order: i + 1,
        });
      });

    // eslint-disable-next-line no-unused-expressions
    selectedListSection?.[0]?.sections &&
      selectedListSection?.[0]?.sections.forEach((section, i) => {
        sectionList.push({
          parentId: id,
          childId: section?.appliedToRule || section?.id,
          order: i + 1,
        });
      });

    // if (sectionList?.length) {
    //   await chunks(sectionList, createRelations, 50);
    // }

    // if (rulesList?.length) {
    //   await chunks(rulesList, createRelations, 50);
    // }
  }

  get disableSaveBtn() {
    return (
      !this.name || !this.status || !this.product || !this.code || !this.type || !this.start_date
    );
  }

  async firstUpdated() {
    if (this.documentData && this.documentData.name) {
      this.start_date = this.documentData.start_date;
      this._data = this.documentData.data;
      this.product = this.documentData.product;
      this.productVal = this.documentData.productVal;
      this.type = this.documentData.type;
      this.typeVal = this.documentData.typeVal;
      this.status = this.documentData.status;
      this.statusVal = this.documentData.statusVal;
      this.templateFile = this.documentData?.templateFile;
      this.name = this.documentData.name;
      this.code = this.documentData.code;
      this.selectedListSection = this.documentData.selectedListSection;
      this.selectedListRule = this.documentData.selectedListRule;
      if (this.selectedListRule?.[0]?.rules?.length > 0) {
        this.rulesData = [...this.rulesData];
      }
      if (this.selectedListSection?.[0]?.sections?.length > 0) {
        this.sectionsList = [...this.sectionsList];
      }
    }
  }

  _associatedEventSection(ev) {
    const { selectedList } = ev.detail;
    this.selectedListSection = selectedList;
    this._fieldValuesChanged();
  }

  _associatedEventRule(ev) {
    const { selectedList } = ev.detail;
    this.selectedListRule = selectedList;
    this._fieldValuesChanged();
  }

  get hideAssociationComponent() {
    if (this.sectionsList && this.sectionsList.length > 0) {
      return true;
    }
    return false;
  }

  get hideRulesAssociationComponent() {
    if (this.rulesData && this.rulesData.length > 0) {
      return true;
    }
    return false;
  }

  openDialog() {
    const dialog = this.shadowRoot.querySelector('#dialog2');
    dialog.opened = true;
  }

  _closeDialog(ev) {
    this.confirmationMessageDetail = {};
    closeDialog(ev);
    if (ev?.detail) {
      const cancelEvent = new CustomEvent('cancel-document', {});
      this.dispatchEvent(cancelEvent);
    }
  }

  cancel() {
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.messages = messages?.createDocument?.requestConfirmation || [];
    this.openDialog();
  }

  render() {
    if (this.documentData?.name) {
      this.name = this.documentData?.name;
      this.selectedListSection[0].name = this.name;
      this.selectedListRule[0].name = this.name;
    }
    return html`
        <div class="container">
          <div class="document-detail">
          Dettaglio documento
          </div>
          <ing-form>
            <form>
          <div class="display-flex">
            <div>
            <ing-input
            id="document_details_name"
            name="name"
            class="document_details_name input_value"
            label="NOME"
            inputElement
            .modelValue="${this.name}"
            @keyup="${this.handleChange}"
          ></ing-input>
            </div>
            <div>
            <ing-input
            id="status"
            name="status"
            class="stato input_value"
            label="STATO"
            inputElement
            value="IN SVILUPPO"
            disabled
          ></ing-input>
            </div>
          </div>
          <div class="display-flex">

        <ing-select
            class="prodotto input_value"
            inputElement
            name="product"
            label="PRODOTTO"
            .modelValue="${this.product}"
            @change="${this.handleChange}"
          >
            <select slot="input">
            ${this.productList.map(item => html` <option value="${item.id}">${item.name}</option>`)}
            </select>
          </ing-select>
        <ing-input
          id="document_details_code"
          name="code"
          class="document_details_code input_value document_details_box"
          label="CODICE"
          .modelValue="${this.code}"
          inputElement
          @keyup="${this.handleChange}"
        ></ing-input>
        <ing-select
            class="tipo input_value document_details_box"
            inputElement
            name="type"
            label="TIPO"
            .modelValue="${this.type}"
            @change="${this.handleChange}"
          >
            <select slot="input">
            ${this.typeList.map(item => html` <option value="${item.id}">${item.name}</option>`)}
            </select>
          </ing-select>
        <ing-input-datepicker
          id="document_details_from"
          name="start_date"
          class="document_details_from input_value document_details_box"
          label="VALIDO DAL"
          inputElement
          colorElement
          .modelValue=${new Date(this.start_date)}
          @change="${this.handleChange}"
          @click="${this.handleChange}"
        ></ing-input-datepicker>
          </div>
          <div>
          <div class="right_alignment">
            <ing-button outline indigo font14 class="cancel_button" @click="${this.cancel}"
            >Elimina documento</ing-button>
          <ing-button
            indigo
            font14
            class="save_button"
            ?disabled="${this.disableSaveBtn}"
            @click="${this._save}"
            >Salva</ing-button
          >
        </div>
          </div>
          </ing-form>            </form>
        </div>
        <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Conferma</div>
          <div slot="content">
          <confirmation-dialog
          .confirmationMessageDetail="${this.confirmationMessageDetail}"
          @close-dialog-event="${this._closeDialog}"
        ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>`;
  }
}

customElements.define('create-document', CreateDocument);
