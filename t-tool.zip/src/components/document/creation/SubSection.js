import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngButton,
  IngCollapsible,
  IngCollapsibleInvoker,
  IngSelect,
} from 'ing-web';

import styles from './SubSectionStyles.js';
import { ComponentAssociation } from './ComponentAssociation.js';

export class SubSection extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-button': IngButton,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
      'ing-select': IngSelect,
      'component-association': ComponentAssociation,
    };
  }

  static get properties() {
    return {
      _id: String,
      name: String,
      description: String,
      validity: Object,
      sectionStyle: String,
      _isNew: { type: Boolean, reflect: true },
      _currentStep: String,
      styleList: Array,
      linkedElement: Boolean,
      subSectionsList: Array,
      rows: Array,
      data: Object,
      attachedSubSections: Array,
      attachedRows: Array,
      isExistingDocument: { type: Boolean, reflect: true },
      isModifiedDocument: { type: Boolean, reflect: true },
      isNotSaved: { type: Boolean, reflect: true },
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.validity = !this.validity ? new Date() : this.validity;
    this.styleList = [];
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('validity') && (!this.validity || this.validity === 'undefined')) {
      this.validity = new Date();
    }
  }

  _add() {
    if (!this.linkedElement) {
      const createSubSectionEvent = new CustomEvent('new-sub-section-added', {
        detail: {
          data: {
            id: this._id,
            name: this.name,
            description: this.description,
            validity: this.validity,
            sectionStyle: this.sectionStyle,
            isNotSaved: this.isNotSaved,
            rows: this.attachedRows,
            subSections: this.attachedSubSections,
            sectionId: this.data?.sectionId,
            subSectionId: this.data?.subSectionId,
          },
        },
      });
      this.dispatchEvent(createSubSectionEvent);
      if (this._isNew) {
        this.name = '';
        this.description = '';
        this.validity = new Date();
        this.sectionStyle = '';
      }
    }
  }

  _cancel() {
    const removeSubSectionEvent = new CustomEvent('remove-sub-section', {
      detail: {
        id: this._id,
      },
    });
    this.dispatchEvent(removeSubSectionEvent);
  }

  get _disabledButton() {
    return !this.name || !this.description;
  }

  handleChange(event) {
    if (event.target.name === 'validity') {
      this[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this[event.target.name] = event.target.value;
    }
    this.fieldValuesChanged();
  }

  associatedList(ev) {
    const associatedListEvent = new CustomEvent('associated-list', {
      detail: {
        selectedList: ev.detail.selectedList,
        id: this._id,
      },
    });
    this.dispatchEvent(associatedListEvent);
    this.fieldValuesChanged();
  }

  get hideAssociationComponent() {
    if (
      (this.rows && this.rows.length > 0 && this._currentStep === 'subsection') ||
      (this.subSectionsList && this.subSectionsList.length > 0 && this._currentStep === 'section')
    ) {
      return true;
    }
    return false;
  }

  fieldValuesChanged() {
    const fieldValuesChanged = new CustomEvent('field-values-changed', {
      detail: {
        id: this._id,
        data: {
          id: this._id,
          name: this.name,
          description: this.description,
          validity: this.validity,
          sectionStyle: this.sectionStyle,
          isNotSaved: this.isNotSaved,
          rows: this.attachedRows,
          subSections: this.attachedSubSections,
          sectionId: this.data?.sectionId,
          subSectionId: this.data?.subSectionId,
          versionDetailLevel0IDStyle: this.data?.versionDetailLevel0IDStyle,
          versionDetailLevel0IDDescription: this.data?.versionDetailLevel0IDDescription,
        },
      },
    });
    this.dispatchEvent(fieldValuesChanged);
  }

  _hydrateSelect(i, d, fieldName, callback) {
    if (!this[fieldName] && i === 0) {
      this[fieldName] = d.id;
      // eslint-disable-next-line no-unused-expressions
      callback && callback(null, d.id);
    }
    if (this[fieldName].toString() === d?.id?.toString()) return true;
    return false;
  }

  getSaveBtnText() {
    if (this.isModifiedDocument) {
      return 'Salva e chiudi';
      // eslint-disable-next-line
    } else if (this.isExistingDocument) {
      return 'Aggiungi e Chiudi';
      // eslint-disable-next-line
    } else {
      return 'Salva';
    }
  }

  render() {
    return html` <div class="section-area">
      <div class="section-columns">
        <ing-input
          @keyup="${this.handleChange}"
          name="name"
          inputElement
          id="section_name"
          .modelValue="${this.name}"
          class="section_name"
          ?disabled="${this.linkedElement}"
          label="${this._currentStep === 'subsection' ? 'NOME SOTTO SEZIONE' : 'NOME SEZIONE'}"
        >
        </ing-input>
      </div>
      <div class="section-columns">
        <ing-textarea
          name="description"
          inputElement
          subSectionTextArea
          label="DESCRIZIONE IN STAMPA"
          rows="4"
          max-rows="4"
          .modelValue="${this.description}"
          @keyup="${this.handleChange}"
          ?disabled="${this.linkedElement}"
        ></ing-textarea>
      </div>
      <div class="section-columns section-date">
        <div class="validate-date">
          <ing-input-datepicker
            id="validate_date"
            inputElement
            label="VALIDO DAL"
            name="validity"
            .modelValue=${new Date(this.validity)}
            @change="${this.handleChange}"
            @click="${this.handleChange}"
            ?disabled="${this.linkedElement}"
          ></ing-input-datepicker>
        </div>
        <div>
          <ing-select
            class="section_style"
            inputElement
            name="sectionStyle"
            @change="${this.handleChange}"
            label="STILE"
            ?disabled="${this.linkedElement}"
          >
            <select slot="input">
              ${this.styleList.map(
                (item, i) => html` <option
                  ?selected="${this._hydrateSelect(i, item, 'sectionStyle')}"
                  value="${item.id}"
                >
                  ${item.name}
                </option>`,
              )}
            </select>
          </ing-select>
        </div>
      </div>
      <div>
        ${this.hideAssociationComponent
          ? html`<component-association
              ._arrList1="${[this.data]}"
              ._arrList2="${this._currentStep === 'subsection' ? this.rows : this.subSectionsList}"
              _currentStep="${this._currentStep}"
              @associated-list="${this.associatedList}"
            >
            </component-association>`
          : ''}
      </div>
      <div class="container">
        <div class="right_alignment">
          <ing-button outline indigo font14 class="cancel_button" @click="${this._cancel}"
            >${this.isExistingDocument ? 'Annulla' : 'Cancella'}</ing-button
          >
          <ing-button
            indigo
            ?disabled="${this._disabledButton || this.linkedElement}"
            font14
            class="save_button"
            @click=${this._add}
            >${this.getSaveBtnText()}</ing-button
          >
        </div>
      </div>
      <div class="ing_standard_bottom_line"></div>
    </div>`;
  }
}
customElements.define('sub-section', SubSection);
