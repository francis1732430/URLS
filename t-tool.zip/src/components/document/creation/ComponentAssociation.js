import { ScopedElementsMixin, LitElement, html, IngSelect, IngButton, styleMap } from 'ing-web';

import { RemovableChip } from '../../removableChip/removableChip.js';

import styles from './ComponentAssociationStyles.js';
import { CustomSelect } from '../../customSelect/CustomSelect.js';
import { getSortedList } from '../../../utils/IngFeatTransparencyToolUtils.js';

export class ComponentAssociation extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-select': IngSelect,
      'ing-button': IngButton,
      'removable-chip': RemovableChip,
      'custom-select': CustomSelect,
    };
  }

  static get properties() {
    return {
      _arrList1: Array,
      _arrList2: { type: Array, reflect: true },
      _currentStep: String,
      filterArrList2: Array,
      filterChipsList: Array,
      str1: String,
      str2: String,
      selectedDocumentSection: Array,
      selectedDocumentRule: Array,
      linkedElement: Boolean,
      selectedNotes: Array,
      removeColumnNoteId: String,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.filterArrList2 = [];
    this.filterChipsList = [];
    this.selectedNotes = [];
    this.currentLabels = {
      section: 'subSections',
      subsection: 'rows',
      'document-section': 'sections',
      'document-rules': 'rules',
    };
    this.label = '';
  }

  filterSelectedRows(id) {
    this.filterChipsList = [];
    this.filterArrList2 = [];
    const arrListData1 = this._arrList1.find(item2 => item2?.id?.toString() === id?.toString());
    if (!arrListData1[this.label]) {
      arrListData1[this.label] = [];
    }
    this.filterChipsList = arrListData1[this.label];
    this._arrList2.forEach(item => {
      const index = arrListData1[this.label].findIndex(
        item2 => item2?.id?.toString() === item?.id?.toString(),
      );
      const obj = this._arrList1.find(item2 => item2.id === id);
      if (obj) {
        this.linkedElement = obj.linkedElement;
      }
      if (index === -1) {
        this.filterArrList2.push(item);
        this.filterArrList2 = JSON.parse(JSON.stringify(this.filterArrList2));
      }

      if (index > -1 && arrListData1[this.label]?.[index]?.name) {
        arrListData1[this.label][index].name = item.name;
      }
    });
    setTimeout(() => {
      this.str2 =
        this.filterArrList2 && this.filterArrList2.length > 0
          ? this.filterArrList2[0]?.id?.toString()
          : '';
    });
  }

  add() {
    if (!this.linkedElement) {
      if (!this.selectedNotes) {
        this.selectedNotes = [];
      }

      this.selectedNotes.forEach(note1 => {
        const arrList2Data = this.filterArrList2.find(
          item => item?.id?.toString() === note1?.id?.toString(),
        );
        this._arrList1 = this._arrList1.map(item => {
          let item1 = {};
          item1 = { ...item };
          if (!item1[this.label]) {
            // eslint-disable-next-line
            item1[this.label] = [];
          }
          item1[this.label].push(arrList2Data);
          return item1;
        });
      });
      this.filterSelectedRows(this.str1);
      this.associatedList();
      this.selectedNotes = [];
    }
  }

  _onChipDeleted(e) {
    const { id } = e.detail;
    this.filterChipsList = this.filterChipsList.filter(
      item => item?.id?.toString() !== id?.toString(),
    );
    const index = this._arrList1.findIndex(
      item2 => item2?.id?.toString() === this.str1?.toString(),
    );
    if (!(this._arrList1[index] && this._arrList1[index][this.label])) {
      this._arrList1[index][this.label] = [];
    }
    this._arrList1[index] = { ...this._arrList1[index] };
    this._arrList1[index][this.label] = this._arrList1[index][this.label].filter(
      item2 => item2?.id?.toString() !== id?.toString(),
    );
    this.filterSelectedRows(this.str1);
    this.associatedList();
    this.removeColumnNoteId = `1_${id}`;
  }

  associatedList() {
    const associatedListEvent = new CustomEvent('associated-list', {
      detail: {
        selectedList: this._arrList1,
      },
    });
    this.dispatchEvent(associatedListEvent);
  }

  handleChange(event) {
    this[event.target.name] = event.target.value;
    if (event.target.name === 'str1') {
      this.filterSelectedRows(event.target.value);
    }
  }

  handleNoteChange(event) {
    let { selectedOptions } = event.detail;
    if (selectedOptions) {
      selectedOptions = JSON.parse(JSON.stringify(selectedOptions));
    }
    this.selectedNotes = [...selectedOptions];
    this.removeColumnNoteId = '';
  }

  filterSelectedOptions() {
    if (this.selectedNotes?.length) {
      this.selectedNotes = this.selectedNotes.filter(opt => {
        const index = this._arrList2.findIndex(
          item => item?.id?.toString() === opt?.id?.toString(),
        );
        if (index === -1) {
          return false;
        }
        return true;
      });
    }
  }

  selectedSubsections(id) {
    const arrListData1 = this._arrList1.find(item2 => item2?.id?.toString() === id?.toString());
    if (!arrListData1[this.label]) {
      arrListData1[this.label] = [];
    }

    arrListData1[this.label] = arrListData1[this.label].filter(chips => {
      const index = this._arrList2.findIndex(arr => arr?.id?.toString() === chips?.id?.toString());
      return index > -1;
    });
  }

  changeSelectedOptionsNames() {
    if (this.selectedNotes?.length && this._arrList2?.length > 0) {
      this.selectedNotes = this.selectedNotes.map(note => {
        const index = this._arrList2.findIndex(
          note1 => note?.id?.toString() === note1?.id?.toString(),
        );

        if (index > -1) {
          // eslint-disable-next-line
          note.name = this._arrList2[index].name;
        }
        return note;
      });
    }
  }

  filterSelectedNotes() {
    if (this.filterChipsList?.length) {
      if (!this.selectedNotes) {
        this.selectedNotes = [];
      }
      this.filterChipsList.forEach(opt => {
        this.selectedNotes = this.selectedNotes.filter(
          item => item?.id?.toString() !== opt?.id?.toString(),
        );
      });
    }
  }

  updated(changedProperties) {
    super.updated(changedProperties);
    this.label = this.currentLabels[this._currentStep];
    changedProperties.forEach((oldValue, propName) => {
      if (propName === '_arrList2' && this._arrList2 && this._arrList2.length > 0) {
        this.str1 = this._arrList1 && this._arrList1.length > 0 ? this._arrList1[0].id : '';
        this.linkedElement =
          this._arrList1 && this._arrList1.length > 0 ? this._arrList1[0].linkedElement : '';
        this.selectedSubsections(this.str1);
        this.filterSelectedRows(this.str1);
        this.filterSelectedNotes();
        this.changeSelectedOptionsNames();
        this.filterSelectedOptions();
      } else if (propName === '_arrList2' && this._arrList2 && this._arrList2.length === 0) {
        this.filterChipsList = [];
        this.filterArrList2 = [];
        this.selectedNotes = [];
      }
      if (propName === '_arrList1' && this._arrList1 && this._arrList1.length > 0) {
        this.str1 = this._arrList1 && this._arrList1.length > 0 ? this._arrList1[0].id : '';
        this.linkedElement =
          this._arrList1 && this._arrList1.length > 0 ? this._arrList1[0].linkedElement : '';
      }
    });
    return true;
  }

  get labelOfSecondOptions() {
    if (this._currentStep === 'document-section') {
      return 'SELEZIONA LE SEZIONI DA INCLUDERE NELLA DOCUMENTO';
    } // eslint-disable-next-line
    else if (this._currentStep === 'document-rules') {
      return 'SELEZIONA LE REGOLE DA INCLUDERE NELLA DOCUMENTO';
    } else if (this._currentStep === 'section') {
      return 'SELEZIONA LE SOTTO-SEZIONI DA INCLUDERE NELLA SEZIONE';
    }
    return 'SELEZIONA LE RIGA DA INCLUDERE NELLA SOTTO - SEZIONE';
  }

  render() {
    return html`
      <div>
        <div class="dropdown-container">
          ${this._currentStep === 'document-section' &&
          this._currentStep === 'document-rules' &&
          this._currentStep === 'Sotto-Sezioni' &&
          this._currentStep === 'Sezioni'
            ? html`<div class="dropdown-box" style="margin-left: 106px">
                <ing-select
                  style="width: 180px"
                  class="section_style"
                  inputElement
                  name="str1"
                  @change="${this.handleChange}"
                  .modelValue="${this.str1}"
                  label=${this._currentStep === 'subsection' ? 'Sotto-Sezioni' : 'Sezioni'}
                >
                  <select slot="input">
                    ${this._arrList1 &&
                    this._arrList1.length > 0 &&
                    this._arrList1.map(
                      item => html`<option value="${item.id}">${item.name}</option>`,
                    )}
                  </select>
                </ing-select>
              </div> `
            : ''}
          <div
            class="dropdown-box w-50"
            style="${styleMap({
              'margin-left':
                this._currentStep !== 'document-section' && this._currentStep !== 'document-rules'
                  ? '106px'
                  : '0px',
            })}"
          >
            <label inputElement>${this.labelOfSecondOptions}</label>
            <custom-select
              style="${styleMap({
                width:
                  this._currentStep === 'document-section' &&
                  this._currentStep === 'document-rules' &&
                  this._currentStep === 'Sotto-Sezioni' &&
                  this._currentStep === 'Sezioni'
                    ? '180px'
                    : '250px',
              })}"
              propKey="name"
              .displayData="${getSortedList(this.filterArrList2)}"
              .selectedOptions="${this.selectedNotes}"
              columnId="1"
              .removeColumnNoteId="${this.removeColumnNoteId}"
              .linkedElement="${this.linkedElement}"
              @value-change="${this.handleNoteChange}"
            >
            </custom-select>
          </div>
        </div>
        <div
          class="add-btn"
          style="${styleMap({
            'margin-left':
              this._currentStep !== 'document-section' && this._currentStep !== 'document-rules'
                ? '106px'
                : '0px',
          })}"
        >
          ${this.filterChipsList.map(
            d =>
              html`<removable-chip
                @chip-deleted="${this._onChipDeleted}"
                id="${d.id}"
                ?closeIconEnable="${this.linkedElement}"
                labelText="${d.name}"
              >
              </removable-chip>`,
          )}
        </div>
        <div
          class="add-btn"
          style="${styleMap({
            'margin-left':
              this._currentStep !== 'document-section' && this._currentStep !== 'document-rules'
                ? '106px'
                : '0px',
          })}"
        >
          <ing-button
            id="add"
            indigo
            class="row-defination-btn"
            ?disabled="${this.selectedNotes.length === 0 || this.linkedElement}"
            @click="${this.add}"
          >
            Aggiungi
          </ing-button>
        </div>
      </div>
    `;
  }
}

customElements.define('component-association', ComponentAssociation);
