import { ScopedElementsMixin, LitElement, html, IngInput, IngButton, IngIcon } from 'ing-web';
import { formatDate } from '../../../utils/IngFeatTransparencyToolUtils.js';

import styles from './DocumentCreatedSuccessfullyStyles.js';

export class DocumentCreatedSuccessfully extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-button': IngButton,
      'ing-icon': IngIcon,
    };
  }

  static get properties() {
    return {
      documentData: Object,
    };
  }

  static get styles() {
    return styles;
  }

  _cancel() {
    const cancelEvent = new CustomEvent('cancel-document');
    this.dispatchEvent(cancelEvent);
  }

  _viewDocument() {
    const viewEvent = new CustomEvent('document-view', {
      detail: this.documentData.id,
    });
    this.dispatchEvent(viewEvent);
  }

  render() {
    return html` <div class="container">
      <div class="title-header">Documento creato con successo</div>
      <div class="display-flex mb-40">
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">ID</label>
          </div>
          <div>
            <label class="label-2">${this.documentData.docId}</label>
          </div>
        </div>
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">PRODOTTO</label>
          </div>
          <div>
            <label class="label-2">${this.documentData.productVal}</label>
          </div>
        </div>
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">CODICE</label>
          </div>
          <div>
            <label class="label-2">${this.documentData.code}</label>
          </div>
        </div>
        <div class="flex-column flex-52">
          <div class="mb-6">
            <label class="label-1">NOME</label>
          </div>
          <div>
            <label class="label-2">${this.documentData.name}</label>
          </div>
        </div>
      </div>
      <div class="display-flex mb-40">
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">TIPO</label>
          </div>
          <div>
            <label class="label-2">${this.documentData.typeVal}</label>
          </div>
        </div>
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">VALIDO DAL</label>
          </div>
          <div>
            <label class="label-2">${formatDate(new Date(this.documentData.start_date))}</label>
          </div>
        </div>
        <div class="flex-column flex-20">
          <div class="mb-6">
            <label class="label-1">VERSIONE</label>
          </div>
          <div>
            <label class="label-2"
              >Versione 1 del
              ${formatDate(new Date(), {
                locale: 'it-IT',
              })}</label
            >
          </div>
        </div>
        <div class="flex-column flex-20"></div>
      </div>
      <div class="right_alignment">
        <ing-button id="createNew" class="create-new-button add-btn" @click="${this._viewDocument}">
          Visualizza documento</ing-button
        >
      </div>
    </div>`;
  }
}

customElements.define('document-created-successfully', DocumentCreatedSuccessfully);
