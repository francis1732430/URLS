import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngInput,
  IngInputDatepicker,
  IngTextarea,
  IngButton,
  IngCollapsible,
  IngCollapsibleInvoker,
} from 'ing-web';

import styles from './CreateNewNoteStyles.js';

export class CreateNewNote extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-input': IngInput,
      'ing-input-datepicker': IngInputDatepicker,
      'ing-textarea': IngTextarea,
      'ing-button': IngButton,
      'ing-collapsible': IngCollapsible,
      'ing-collapsible-invoker': IngCollapsibleInvoker,
    };
  }

  static get properties() {
    return {
      noteAreaIndex: { type: Number },
      name: { type: String },
      description: { type: String },
      validity: { type: Object },
      isNew: { type: Boolean },
      linkedElement: Boolean,
      isExistingDocument: { type: Boolean, reflect: true },
      isNotSaved: { type: Boolean, reflect: true },
      isModifiedDocument: { type: Boolean, reflect: true },
      noteId: String,
    };
  }

  static get styles() {
    return styles;
  }

  constructor() {
    super();
    this.validity = new Date();
  }

  updated(changed) {
    super.updated(changed);
    if (changed.has('validity') && (!this.validity || this.validity === 'undefined'))
      this.validity = new Date();
  }

  _cancel() {
    const noteRemoveEvent = new CustomEvent('remove-note-section', {
      detail: {
        data: this.id,
      },
    });
    this.dispatchEvent(noteRemoveEvent);
  }

  _add() {
    if (!this.linkedElement) {
      const noteCreateEvent = new CustomEvent('add-note-section', {
        detail: {
          data: {
            name: this.name,
            description: this.description,
            validity: new Date(this.validity),
            id: this.id,
            isNotSaved: this.isNotSaved,
            noteId: this.noteId,
          },
        },
      });
      this.dispatchEvent(noteCreateEvent);
      if (this.isNew) {
        this.name = '';
        this.description = '';
        this.validity = new Date();
      }
    }
  }

  get _disabledButton() {
    return !this.name || !this.description;
  }

  handleChange(event) {
    if (event.target.name === 'validity') {
      this[event.target.name] = event.target.value.split(/\D/).reverse().join('-');
    } else {
      this[event.target.name] = event.target.value;
    }

    this.fieldValuesChanged();
  }

  fieldValuesChanged() {
    const fieldValuesChanged = new CustomEvent('field-values-changed', {
      detail: {
        id: this.id,
        data: {
          name: this.name,
          description: this.description,
          validity: new Date(this.validity),
          id: this.id,
          isNotSaved: this.isNotSaved,
          noteId: this.noteId,
        },
      },
    });
    this.dispatchEvent(fieldValuesChanged);
  }

  getSaveBtnText() {
    if (this.isModifiedDocument) {
      return 'Salva e chiudi';
      // eslint-disable-next-line
    } else if (this.isExistingDocument) {
      return 'Aggiungi e Chiudi';
      // eslint-disable-next-line
    } else {
      return 'Salva';
    }
  }

  render() {
    return html`
      <div>
        ${this.noteAreaIndex}
        <div>
          <ing-input
            @keyup="${this.handleChange}"
            name="name"
            id="note_name"
            .modelValue="${this.name}"
            class="note_name"
            label="NOME"
            inputElement
            ?disabled="${this.linkedElement}"
          ></ing-input>
        </div>
        <div>
          <ing-input-datepicker
            id="note_from"
            class="note_from"
            label="VALIDO DAL"
            name="validity"
            inputElement
            .modelValue=${new Date(this.validity)}
            @change="${this.handleChange}"
            @click="${this.handleChange}"
            ?disabled="${this.linkedElement}"
          ></ing-input-datepicker>
        </div>
        <div>
          <ing-textarea
            name="description"
            noteTextArea
            label="DESCRIZIONE"
            inputElement
            rows="4"
            max-rows="4"
            .modelValue="${this.description}"
            @keyup="${this.handleChange}"
            ?disabled="${this.linkedElement}"
          ></ing-textarea>
        </div>
        <div class="container">
          <div class="right_alignment">
            <ing-button outline indigo font14 class="cancel_button" @click="${this._cancel}"
              >${this.isExistingDocument ? 'Annulla' : 'Cancella'}</ing-button
            >
            <ing-button
              indigo
              ?disabled="${this._disabledButton || this.linkedElement}"
              font14
              class="save_button"
              @click=${this._add}
              >${this.getSaveBtnText()}</ing-button
            >
          </div>
        </div>
        <div class="ing_standard_bottom_line"></div>
      </div>
    `;
  }
}
customElements.define('create-new-note', CreateNewNote);
