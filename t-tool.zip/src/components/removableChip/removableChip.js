import { html, LitElement } from 'ing-web';
import pageStyles from './removableChipStyles.js';

export class RemovableChip extends LitElement {
  static get properties() {
    return {
      labelText: { type: String },
      id: { type: String },
      closeIconEnable: { type: Boolean, reflect: true },
    };
  }

  static get styles() {
    return pageStyles;
  }

  _onRemove() {
    const event = new CustomEvent('chip-deleted', {
      detail: { id: this.id },
    });
    this.dispatchEvent(event);
  }

  render() {
    return html`
      <span class="badge"
        >${this.labelText}
        ${!this.closeIconEnable
          ? html`<i class="cross" @keydown="${this._onRemove}" @click="${this._onRemove}">x</i></span
          >`
          : ''}
      </span>
    `;
  }
}

customElements.define('removable-chip', RemovableChip);
