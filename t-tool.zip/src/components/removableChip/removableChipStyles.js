import { css, indigo15, indigo, font14Mixin } from 'ing-web';

export default css`
  .badge {
    display: inline-block;
    border: 1px solid ${indigo};
    background-color: ${indigo15};
    padding: 2px 10px;
    position: relative;
    border-radius: 50px;
    color: ${indigo};
    margin: 3px;
    ${font14Mixin()}
  }
  .badge .cross {
    font-style: unset;
    font-family: monospace;
    position: relative;
    margin-left: 5px;
    color: ${indigo};
    font-size: 18px;
    cursor: pointer;
  }
`;
