import { black80, css, font14BoldMixin, font14Mixin, leaf, orange } from 'ing-web';

export default css`
  .dcouemnt-review-tr td {
    min-width: 200px;
  }
  .document-review-status {
    color: ${orange};
  }
  .dcouemnt-review-table {
    margin-top: 20px;
  }
  p {
    color: ${black80};
    ${font14Mixin()}
  }
  strong {
    ${font14BoldMixin()}
  }
  [inputElement] label {
    color: ${black80};
    ${font14Mixin()}
    margin-bottom: 8px !important;
    display: block;
  }
  [colorElement] label {
    color: ${orange};
  }
  [inputElement] {
    width: 260px;
  }
  .status_draft {
    font-weight: bold;
    color: ${black80} !important;
  }
  .status_prod {
    font-weight: bold;
    color: ${leaf} !important;
  }
  .status_review {
    font-weight: bold;
    color: ${orange} !important;
  }
`;
