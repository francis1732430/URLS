import { black80, css, orange } from 'ing-web';

export default css`
  .document-title {
    width: 100%;
    background: ${orange};
    border-radius: 12px;
    font-size: 2.3rem;
    text-align: center;
    margin-top: 8px;
    color: #f1eaea;
    font-family: 'ING Me';
  }
  .mt-50 {
    margin-top: 50px;
  }
  .label-font {
    color: ${black80};
    font-family: 'ING Me';
    font-size: 15px;
    font-weight: bold;
    letter-spacing: 0;
    line-height: 24px;
  }
  .document-subtitle {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 30px;
  }
  .subtitle-content {
    display: flex;
    flex-direction: column;
    margin-left: 50px;
    align-items: center;
    justify-content: center;
    color: ${orange};
    font-family: 'ING Me';
    font-weight: bold;
    font-size: 12px;
  }
  .mb-8 {
    margin-bottom: 8px;
  }
  .document-sub-title-header {
    width: 100%;
    background: rgb(255, 98, 0);
    border-radius: 6px;
    font-size: 13px;
    color: rgb(241, 234, 234);
    font-family: 'ING Me';
    padding-left: 5px;
    display: flex;
    justify-content: space-between;
  }
  .orange {
    color: ${orange};
  }
  .light-grey {
    color: #b4b3b0;
  }
  .sub-title-content {
    display: flex;
    justify-content: space-between;
    margin-top: 4px;
    border-bottom: 1.5px solid #a9a9a8;
    font-family: 'ING Me';
    font-size: 14px;
  }
  .sub-title-header-font {
    font-weight: bold;
    font-size: 16px;
  }
  .content-multiple-container {
    display: flex;
    border-bottom: 1.5px solid #a9a9a8;
    flex-direction: column;
  }
  .content-multiple {
    display: flex;
    justify-content: space-between;
    margin-top: 4px;
    font-family: 'ING Me';
    font-size: 14px;
  }
`;
