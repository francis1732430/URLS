import { expect, fixture, html, unsafeStatic, defineCE, fixtureCleanup } from '@open-wc/testing';
import { CollapsibleDocumentCommonDetailsCE } from './test-class.js';

describe('CollapsibleDocumentCommonDetails Tests', () => {
  const tag = unsafeStatic(defineCE(CollapsibleDocumentCommonDetailsCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It should bind section name', async () => {
      const el = await element?.shadowRoot?.querySelector('span');
      expect(el.textContent).to.equal(element.sectionName);
    });

    it('It should bind ing generic table', async () => {
      const el = await element?.shadowRoot?.querySelector('[ing-generic-table]');
      expect(el).to.exist;
    });
  });
});
