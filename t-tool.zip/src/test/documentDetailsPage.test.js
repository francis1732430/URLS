import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  oneEvent,
  elementUpdated,
  aTimeout,
} from '@open-wc/testing';
import Sinon from 'sinon';

import { DocumentDetailsPageCE } from './test-class.js';
import { documents } from '../data/documents.js';

describe('DocumentDetailsPage Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentDetailsPageCE));

  describe('Structure', () => {
    let element;
    const receiveEventWithData = async (
      customEventName,
      dataName,
      dataId,
      actualData,
      restData = {},
    ) => {
      await setTimeout(() =>
        element._fireMockEvent(element, customEventName, {
          data: {
            name: dataName,
            id: dataId,
            data: { ...actualData, headerData: [], tableContentData: [] },
            ...restData,
          },
        }),
      );
    };

    const isCheckDisabled = async tagItem => {
      const el = await element?.shadowRoot?.querySelector(tagItem);
      await expect(el.disabled).to.equal(true);
    };

    const isCheckEnabled = async tagItem => {
      const el = await element?.shadowRoot?.querySelector(tagItem);
      await expect(el.disabled).to.equal(false);
    };

    const isCheckEnabledForAll = async (tagItem, num = 0) => {
      const el = await element?.shadowRoot?.querySelectorAll(tagItem)[num];
      await expect(el.disabled).to.equal(false);
    };

    const isCheckDisabledForAll = async (tagItem, num = 0) => {
      const el = await element?.shadowRoot?.querySelectorAll(tagItem)[num];
      await expect(el.disabled).to.equal(true);
    };

    beforeEach(async () => {
      element = await fixture(html`<${tag} .selectedValue="${documents[0]}"></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It receives id in modify-selected-section', async () => {
      await receiveEventWithData('modify-selected-section', 'Sezioni', 1, documents[0].sections[0]);

      const { detail } = await oneEvent(element, 'modify-selected-section');
      expect(detail.data.data.name).to.equal(documents[0].sections[0].name);
    });

    it('It receives id in add-new-element', async () => {
      await receiveEventWithData('add-new-element', 'Sezioni', 1, documents[0].sections[0]);

      const { detail } = await oneEvent(element, 'add-new-element');
      expect(detail.data.data.name).to.equal(documents[0].sections[0].name);
    });
    it('It receives selected-data-changed', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'selected-data-changed', {
          name: 'Sezioni',
          id: 1,
          data: documents[0].sections[0],
          type: 'selectedSection',
        }),
      );
      const { detail } = await oneEvent(element, 'selected-data-changed');
      expect(detail.data.name).to.equal(documents[0].sections[0].name);
    });
    it('It receives new-version-table-row', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'new-version-table-row', {
          name: 'Sezioni',
          id: 1345345,
          data: documents[0].sections[0],
          type: 'selectedSection',
          sectionId: documents[0].sections[0].id,
          newSectionId: documents[0].sections[0].id,
        }),
      );
      const { detail } = await oneEvent(element, 'new-version-table-row');
      expect(detail.data.name).to.equal(documents[0].sections[0].name);
    });
    it('It receives new-duplicate-table-row', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'new-duplicate-table-row', {
          name: 'Sezioni',
          id: 1345345,
          data: documents[0].sections[0],
          type: 'selectedSection',
          sectionId: documents[0].sections[0].id,
          newSectionId: documents[0].sections[0].id,
        }),
      );
      const { detail } = await oneEvent(element, 'new-duplicate-table-row');
      expect(detail.data.name).to.equal(documents[0].sections[0].name);
    });
    it('It receives delete-table-row', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'delete-table-row', {
          name: 'Sezioni',
          id: 1345345,
          data: documents[0].sections[0],
          type: 'selectedSection',
          sectionId: documents[0].sections[0].id,
          newSectionId: documents[0].sections[0].id,
        }),
      );
      const { detail } = await oneEvent(element, 'delete-table-row');
      expect(detail.data.name).to.equal(documents[0].sections[0].name);
    });
    it('It receives create-duplicate-document', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'create-duplicate-document', {
          name: 'Sezioni',
          id: 1345345,
          data: documents[0],
        }),
      );
      const { detail } = await oneEvent(element, 'create-duplicate-document');
      expect(detail.data.name).to.equal(documents[0].name);
    });
    it('It receives new-document-version', async () => {
      await setTimeout(() =>
        element._fireMockEvent(element, 'new-document-version', {
          name: 'Sezioni',
          id: 1345345,
          data: documents[0],
        }),
      );
      const { detail } = await oneEvent(element, 'new-document-version');
      expect(detail.data.name).to.equal(documents[0].name);
    });

    it('If version-detail-list event is fired it should get all detail of versions list for documents', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element.selectedDocument = { docId: 1, start_date: '2021-01-01' };
      await elementUpdated(element);
      element.getVersionDetails();
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for documents', async () => {
      element.ajaxInstance.get = Sinon.stub();

      element.ajaxInstance.get.resolves({ data: { itemChildren: [element.section] } });

      element.getVersionItemDetail = Sinon.stub();
      element.getVersionItemDetail.resolves({ data: element.documentData });
      element.version = 1;
      element.selectedDocument = { docId: 1, start_date: '2021-01-01' };
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(`[name="version"]`);
      el.dispatchEvent(new Event('change'));
      await aTimeout(200);
      // await element.updateComplete;
      await expect(element.selectedDocument.sections.length).to.be.eq(1);
      Sinon.restore();
    });

    it('It should changed status value', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          lookupList: [
            {
              lookupDataID: 27,
              ldKey: 'STATUS',
              ldValue: 'IN REVISIONE',
            },
          ],
        },
      });
      element.statusList = [
        {
          id: 27,
          name: 'Test',
        },
      ];
      element.selectedDocument = { docId: 1, start_date: '2021-01-01' };
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(`[name="statusId"]`);
      el.modelValue = '27';
      el.dispatchEvent(new Event('change'));
      await aTimeout(200);
      await elementUpdated(element);
      await expect(element.selectedDocument.statusId).to.be.eq('27');
      Sinon.restore();
    });

    it('It should disabled name field', async () => {
      element.editableActionFields.name = true;
      await elementUpdated();
      await isCheckDisabled('#document_details_name');
    });

    it('It should disabled status field', async () => {
      element.editableActionFields.status = true;
      await elementUpdated();
      const el = await element?.shadowRoot?.querySelector('.stato');
      await expect(el.disabled).to.equal(false);
    });

    it('It should disabled product field', async () => {
      element.editableActionFields.product = true;
      await elementUpdated();
      await isCheckDisabled('.document_details_product');
    });

    it('It should disabled code field', async () => {
      element.editableActionFields.code = true;
      await elementUpdated();
      await isCheckDisabled('.document_details_code');
    });

    it('It should disabled type field', async () => {
      element.editableActionFields.type = true;
      await elementUpdated();
      await isCheckDisabled('.document_details_type');
    });

    it('It should disabled validity field', async () => {
      element.editableActionFields.validity = true;
      await elementUpdated();
      await isCheckDisabled('.document_details_from');
    });

    it('It should disabled template file field', async () => {
      element.editableActionFields.templateFile = true;
      await elementUpdated();
      await isCheckDisabled('.document_details_template_file');
    });

    it('It should disabled view btn', async () => {
      element.editableActionFields.documentNewVersion = true;
      await elementUpdated();
      await isCheckDisabled('.view_button');
    });

    it('It should disabled duplicate version btn', async () => {
      element.editableActionFields.documentDuplicateVersion = true;
      await elementUpdated();
      await isCheckDisabled('.duplicate-btn');
    });

    it('It should disabled save btn', async () => {
      element.editableActionFields.documentSave = true;
      await elementUpdated();
      const el = await element?.shadowRoot?.querySelector('.save_btn');
      await expect(el.disabled).to.equal(false);
    });

    it('It should disabled Anteprima btn', async () => {
      element.editableActionFields.generateAntePrima = true;
      await elementUpdated();
      await isCheckDisabled('.create-new-button');
    });

    it('It should enable some fields when status is IN SVILUPPO', async () => {
      element.statusList = [
        {
          id: 1,
          name: 'IN SVILUPPO',
        },
        {
          id: 2,
          name: 'DISMESSO',
        },
        {
          id: 3,
          name: 'IN REVISIONE',
        },
        {
          id: 4,
          name: 'APPROVATO',
        },
      ];
      element.selectedDocument = { docId: 1, start_date: '2021-01-01', statusId: 1 };
      await elementUpdated(element);
      await isCheckEnabled('.stato');
      await isCheckEnabled('.document_details_code');
      await isCheckEnabled('.document_details_from');
      await isCheckEnabled('.document_details_template_file');
      await isCheckDisabledForAll('.stato .form-control option', 2);
      await isCheckDisabledForAll('.stato .form-control option', 3);
      await isCheckEnabledForAll('.stato .form-control option', 0);
      await isCheckEnabledForAll('.stato .form-control option', 1);
    });

    it('It should enable some fields when status is IN SVILUPPO', async () => {
      element.statusList = [
        {
          id: 1,
          name: 'IN SVILUPPO',
        },
        {
          id: 2,
          name: 'DISMESSO',
        },
        {
          id: 3,
          name: 'IN REVISIONE',
        },
        {
          id: 4,
          name: 'APPROVATO',
        },
      ];
      element.selectedDocument = { docId: 1, start_date: '2021-01-01', statusId: 4 };
      await elementUpdated(element);
      await isCheckDisabled('.view_button');
      await isCheckDisabled('.duplicate-btn');
      await isCheckDisabledForAll('.stato .form-control option', 2);
      await isCheckEnabledForAll('.stato .form-control option', 3);
      await isCheckEnabledForAll('.stato .form-control option', 0);
      await isCheckEnabledForAll('.stato .form-control option', 1);
    });

    it('It receives update data through save-row event', async () => {
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'DETTAGLIO_RIGA',
              data: 5,
            },
          ],
        },
      });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsVersionsList: [
            {
              itemsVersionsID: 1,
              versionID: 98,
              versionNumber: 15,
              hasParentDocuments: true,
              status: 'APPROVATO',
              validity: '2023-01-01',
            },
          ],
        },
      });
      element.templateFile = 'test.xslx';
      element._filesData = [
        {
          id: 1,
          name: '2',
        },
        {
          id: 2,
          name: '3',
          versionDetailLevel0ID: 34,
        },
      ];
      element.selectedDocument = { id: 1, docId: 1, start_date: '2021-01-01' };
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector('.save_btn');
      el.click();
      aTimeout(200);
      expect(element?.selectedDocument?.id).to.equal(1);
      Sinon.restore();
    });
    it('It should set correct status of Document', async () => {
      element.selectedDocument = { id: 1, status: 'APPROVATO', start_date: '2021-01-01' };
      const obj = element.versionList.find(d => d.itemsVersionsID === 101);
      obj.status = '';
      element.versionList = [...element.versionList.filter(d => d.itemsVersionsID !== 101), obj];
      await elementUpdated(element);
      element.setStatusLabel();
      expect(element?.statusLabel).to.equal('IN PRODUZIONE');
    });
    it('It should set correct status of Document to Archiviato', async () => {
      element.selectedDocument = { id: 1, status: 'APPROVATO', start_date: '2021-01-01' };
      await elementUpdated(element);
      await element.setStatusLabel();
      expect(element?.statusLabel).to.equal('ARCHIVIATO');
    });
    it('It should set correct version of Document', async () => {
      element.selectedDocument = { id: '98', status: 'APPROVATO', start_date: '2021-01-01' };
      await elementUpdated(element);
      await element.setVersionNumber();
      await aTimeout(300);
      expect(element?.versionId).to.equal('98');
    });
  });
});
