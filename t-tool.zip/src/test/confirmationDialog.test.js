import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  elementUpdated,
} from '@open-wc/testing';

import { ConfirmationDialogCE } from './test-class.js';

describe('ConfirmationDialog Tests', () => {
  const tag = unsafeStatic(defineCE(ConfirmationDialogCE));

  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It binds the label field', async () => {
      const labels = await element?.shadowRoot?.querySelectorAll('label');
      expect(labels.length).to.eq(2);
    });

    it('Save button should work', async () => {
      const saveButton = await element?.shadowRoot?.querySelector('.save_button');
      saveButton.click();
      aTimeout(200);
      await elementUpdated();
      expect(element.detail.detail.confirmationMessageDetail).to.equal(
        element.confirmationMessageDetail,
      );
    });

    it('Cancel button should work', async () => {
      const cancelButton = await element?.shadowRoot?.querySelector('.cancel_button');
      cancelButton.click();
      aTimeout(200);
      await elementUpdated();
      expect(element.detail.detail).to.not.exist;
    });
  });
});
