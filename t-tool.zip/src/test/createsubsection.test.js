import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import Sinon from 'sinon';

import { CreateSubSectionCE, DocumentListHomePageComponentCE } from './test-class.js';

describe('CreateSubSection Tests', () => {
  const tag = unsafeStatic(defineCE(CreateSubSectionCE));
  const documentHome = unsafeStatic(defineCE(DocumentListHomePageComponentCE));

  describe('Structure', () => {
    let element;
    let documentHomeTag;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
      documentHomeTag = await fixture(html`<${documentHome}></${documentHome}>`);
      documentHomeTag._selectedTabIndex = 1;
      await elementUpdated();
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('subsection component should be exists', async () => {
      const createSubSectionElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('sub-section'),
      );
      await expect(createSubSectionElements).to.exist;
    });

    it('It should add new section component when add event is fired', async () => {
      // element._putData = Sinon.stub();
      // element._putData.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.patch = Sinon.stub();
      element.ajaxInstance.patch.resolves({ text: 'saved succesfully' });
      element.requestUpdate();
      const createNew = await element?.shadowRoot?.querySelector('#createNew');
      setTimeout(() => {
        createNew?.click();
      });
      await aTimeout(300);
      await element.updateComplete;
      await expect(element.subSectionsData.length).to.be.eq(3);
      const createSubSectionElementsNew = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('sub-section'),
      );
      await expect(createSubSectionElementsNew.length).to.be.eq(3);
      Sinon.restore();
    });

    it('It should remove the section component when remove event is fired', async () => {
      // element._deleteData = Sinon.stub();
      // element._deleteData.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.delete = Sinon.stub();
      element.ajaxInstance.delete.resolves({ text: 'saved succesfully' });
      element.requestUpdate();
      const createSubSectionElements = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('sub-section'),
      );
      setTimeout(() => {
        createSubSectionElements.dispatchEvent(
          new CustomEvent('remove-sub-section', { detail: { id: 1 } }),
        );
      });
      aTimeout(200);
      await oneEvent(createSubSectionElements, 'remove-sub-section');
      aTimeout(200);
      const createSubSectionElementsNew = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('sub-section'),
      );
      await expect(createSubSectionElementsNew.length).to.be.eq(2);
      Sinon.restore();
    });

    it('It should update the section component when add event is fired', async () => {
      // element._putData = Sinon.stub();
      // element._putData.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.patch = Sinon.stub();
      element.ajaxInstance.patch.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.sectionBackend });
      element.requestUpdate();
      const createSubSectionElements = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('sub-section'),
      );
      setTimeout(() => {
        createSubSectionElements.dispatchEvent(
          new CustomEvent('new-sub-section-added', {
            detail: {
              data: {
                id: 1,
                name: 'test1',
                description: 'test description',
                validity: new Date(),
                sectionStyle: '',
              },
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(createSubSectionElements, 'new-sub-section-added');
      await expect(element.subSectionsData.length).to.be.eq(2);
      const createSubSectionElementsNew = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('sub-section'),
      );
      await expect(createSubSectionElementsNew.length).to.be.eq(2);
      Sinon.restore();
    });

    it('Documentlisthome page should bind the subsection component', async () => {
      const createSubSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="subsection"]`,
      );
      await expect(createSubSectionElements).to.exist;
    });

    it('It should update the subsection list when add event is fired', async () => {
      const createSubSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="subsection"]`,
      );
      const data1 = {
        id: 1,
        name: 'test1',
        description: 'test description',
        validity: new Date(),
        sectionStyle: '',
      };
      setTimeout(() => {
        createSubSectionElements.dispatchEvent(
          new CustomEvent('event-section-added', {
            detail: { list: [data1], data1, savedChildList: [] },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(createSubSectionElements, 'event-section-added');
      await expect(documentHomeTag.subSectionsList.length).to.be.eq(1);
    });

    it('Documentlisthome page should bind the section component', async () => {
      const createSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="section"]`,
      );

      await expect(createSectionElements).to.exist;
    });

    it('It should update the subsection list when add event is fired', async () => {
      const createSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="section"]`,
      );
      const data1 = {
        id: 1,
        name: 'test1',
        description: 'test description',
        validity: new Date(),
        sectionStyle: '',
      };
      setTimeout(() => {
        createSectionElements.dispatchEvent(
          new CustomEvent('event-section-added', {
            detail: { list: [data1], data1, savedChildList: [] },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(createSectionElements, 'event-section-added');
      await expect(documentHomeTag.sectionsList.length).to.be.eq(1);
    });

    it('It should bind correct subsections options', async () => {
      const createSubSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="subsection"]`,
      );
      aTimeout(2000);
      const subSection = createSubSectionElements?.shadowRoot?.querySelector(
        '[_currentstep="subsection"]',
      );
      await expect(subSection).to.exist;
    });

    it('It should bind correct sections options', async () => {
      const createSectionElements = await documentHomeTag?.shadowRoot?.querySelector(
        `[currentStep="section"]`,
      );
      aTimeout(2000);
      const section = createSectionElements?.shadowRoot?.querySelector('[_currentstep="section"]');
      await expect(section).to.exist;
    });

    it('Association component shoud not exist when subsection length is 0', async () => {
      const componentAssociationElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('component-association'),
      );
      await expect(componentAssociationElements).to.not.exist;
    });

    it('It should hide the create new button', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('#createNew');
      await expect(btn).to.not.exist;
    });
  });
});
