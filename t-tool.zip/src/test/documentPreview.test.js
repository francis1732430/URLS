import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
} from '@open-wc/testing';

import { DocumentPreviewCE } from './test-class.js';

describe('DocumentPreviewCE Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentPreviewCE));

  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It should bind the title data', async () => {
      element.contentData = {
        title: 'DOCUMENTO DI SINTESI',
      };
      await elementUpdated();
      const titleText = element.shadowRoot.querySelector('.document-title');
      await expect(element.contentData.title).equal(titleText.innerText);
    });

    it('It should bind the subTitle data', async () => {
      element.contentData = {
        subTitle: [
          'N* 1 del 31/12/2020',
          'relativo at',
          'Conto Corrente Arancio al servizi Conto Corrente Arancio',
        ],
      };
      await elementUpdated();
      const subTitle = element.shadowRoot.querySelectorAll('.subtitle-label');
      await expect(element.contentData.subTitle.length).equal(subTitle.length);
    });

    it('It should bind the section data', async () => {
      element.contentData = {
        section: 'Condizioni Econimiche',
      };
      await elementUpdated();
      const sectionText = element.shadowRoot.querySelector('.document-title-section');
      await expect(element.contentData.section).equal(sectionText.innerText);
    });

    it('It should bind the subsection title data', async () => {
      element.contentData = {
        subSection: [
          {
            content: 'Spese fisse',
            class: 'document-sub-title-header',
            propertyName: 'title',
          },
        ],
      };
      await elementUpdated();
      const sectionText = element.shadowRoot.querySelector('.document-sub-title-header label');
      await expect(element.contentData.subSection[0].content).equal(sectionText.innerText);
    });

    it('It should bind the subsection header data', async () => {
      element.contentData = {
        subSection: [
          {
            content: 'Terunto del conto',
            class: 'sub-title-content orange sub-title-header-font',
            propertyName: 'header',
          },
        ],
      };
      await elementUpdated();
      const sectionText = element.shadowRoot.querySelector('.sub-title-header-font label');
      await expect(element.contentData.subSection[0].content).equal(sectionText.innerText);
    });
  });
});
