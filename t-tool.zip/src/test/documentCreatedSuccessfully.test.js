import { expect, fixture, html, unsafeStatic, defineCE, fixtureCleanup } from '@open-wc/testing';

import { DocumentCreatedSuccessfullyCE } from './test-class.js';

describe('DocumentCreatedSuccessfully Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentCreatedSuccessfullyCE));

  describe('Structure', () => {
    let element;
    const testFields = async list => {
      list.forEach(item => {
        describe('Field Test', () => {
          it(`It binds the ${item.name} field`, async () => {
            await expect(item.innerText).to.exist;
          });
        });
      });
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
      const list = element.shadowRoot.querySelectorAll('.label-2');
      testFields(list);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
  });
});
