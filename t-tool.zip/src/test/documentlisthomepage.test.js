import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
  aTimeout,
  oneEvent,
} from '@open-wc/testing';
import Sinon from 'sinon';
import {
  DocumentListHomePageComponentCE,
  DocumentListHomePageSelectedRowValueComponentCE,
} from './test-class.js';
import Singleton from '../utils/SingletonFactory.js';
import { localStorageKeysMap } from '../utils/constants.js';
import {
  addElementToLocalStorage,
  getSortedList,
  removeElementFromLocalStorage,
} from '../utils/IngFeatTransparencyToolUtils.js';

describe('DocumentListHomePage', () => {
  const tag = unsafeStatic(defineCE(DocumentListHomePageComponentCE));
  const tagRowSelected = unsafeStatic(defineCE(DocumentListHomePageSelectedRowValueComponentCE));

  describe('Structure wihout tab opened', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('is accessible', async () => {
      const el = element;
      await expect(el).to.exist;

      const stepsEl = element.shadowRoot.querySelector(
        element.constructor.getScopedTagName('ing-table'),
      );
      expect(stepsEl).to.exist;
    });

    it('button view is accessible and disabled', async () => {
      const el = element;
      await expect(el).to.exist;
      element._displayData = [
        {
          id: 1,
          docId: 1,
          name: 'test',
        },
      ];
      await elementUpdated(element);
      const viewBtn = element.shadowRoot.querySelector('[data-tag-id="viewRowBtn"]');
      expect(viewBtn).to.exist;
      expect(viewBtn.textContent.trim()).to.be.equal('Vedi dettaglio');
      expect(viewBtn).to.have.attribute('disabled');
    });

    it('button review is accessible and disabled', async () => {
      const el = element;
      await expect(el).to.exist;
      element._displayData = [
        {
          id: 1,
          docId: 1,
          name: 'test',
        },
      ];
      await elementUpdated(element);
      const viewBtn = element.shadowRoot.querySelector('[data-tag-id="reviewRowBtn"]');
      expect(viewBtn).to.exist;
      expect(viewBtn.textContent.trim()).to.be.equal('Review');
      expect(viewBtn).to.have.attribute('disabled');
    });

    it('document successfull component should exist', async () => {
      element.showSuccessStep = true;
      element._selectedTabIndex = 1;
      await elementUpdated();
      const comp = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-created-successfully'),
      );
      expect(comp).to.exist;
    });

    it('create document component should exist', async () => {
      element.showSuccessStep = false;
      element._selectedTabIndex = 1;
      await elementUpdated();
      const comp = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-document'),
      );
      expect(comp).to.exist;
    });

    it('reset filter event should fired', async () => {
      element._setFilter({
        name: 'docId',
        label: 'ID',
      });
      const component = element.shadowRoot.getElementById('searchText');
      component.modelValue = 'Test';
      await elementUpdated();
      const ele = element.shadowRoot.getElementById('resetFilter');
      expect(ele.disabled).false;
      ele.dispatchEvent(new Event('click'));
      await elementUpdated();
      expect(element._filter).to.not.exist;
      expect(element.searchText).equal('');
      expect(ele.disabled).true;
    });

    it('Add note action should work', async () => {
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = element.shadowRoot.querySelector('.add-note');
      setTimeout(() => ele.dispatchEvent(new Event('click')));
      await elementUpdated(element);
      await aTimeout(200);
      expect('Nota').equal(element.tabsData[0].name);
      const scratchElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      expect(scratchElement).to.exist;
      Sinon.restore();
    });

    it('Add Row action should work', async () => {
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = element.shadowRoot.querySelector('.add-row');
      setTimeout(() => ele.dispatchEvent(new Event('click')));
      await elementUpdated(element);
      await aTimeout(200);
      expect('Righe').equal(element.tabsData[0].name);
      const scratchElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      expect(scratchElement).to.exist;
      Sinon.restore();
    });

    it('Add Sub-Section action should work', async () => {
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      element._selectedTabIndex = 1;
      setTimeout(() => {
        element.tabsData = [
          {
            headerData: [],
            list: [],
            name: 'Sotto Sezioni',
            propertyId: 'subSectionId',
            selectedRow: undefined,
          },
        ];
      });
      await aTimeout(200);
      await elementUpdated();
      const scratchElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      expect(scratchElement).to.exist;
      Sinon.restore();
    });

    it('Add Section action should work', async () => {
      element._selectedTabIndex = 1;
      element.tabsData = [
        {
          headerData: [],
          list: [],
          name: 'Sezioni',
          propertyId: 'sectionId',
          selectedRow: undefined,
        },
      ];
      await elementUpdated();
      const scratchElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      expect(scratchElement).to.exist;
    });

    it('It should change current step index and binding subsections List', async () => {
      // element._getExistingData = Sinon.stub();
      // element._getExistingData.resolves(element.subsectionBackendStructure);
      element.ajaxInstance.get.resolves({ data: element.subsectionBackendStructure[0] });
      element._selectedTabIndex = 1;
      element.existingElementSubsection = [40, 41];
      await elementUpdated();
      const stepperElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('stepper-custom'),
      );
      setTimeout(() => {
        stepperElement.dispatchEvent(
          new CustomEvent('changed-step-index', { detail: { data: 2 } }),
        );
      });
      aTimeout(200);
      await oneEvent(stepperElement, 'changed-step-index');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element._stepIndex).to.be.eq(2);
      await expect(element.subSectionsList.length).to.be.greaterThanOrEqual(1);
      await expect(element.existingElementRows.length).to.be.eq(2);
    });

    it('It should change current step index and binding rows List', async () => {
      // element._getExistingData = Sinon.stub();
      // element._getExistingData.resolves(element.rowsBackEndStructure);
      element.ajaxInstance.get.resolves({ data: element.rowsBackEndStructure[0] });
      element.makeElementsAjaxCall = Sinon.stub();
      element.makeElementsAjaxCall.resolves({
        list: [
          {
            noteId: '7658',
            name: 'Nota sulla riga',
            description: 'Descrizione nota sulla riga',
            version: '500',
            validity: '2022-08-08',
            id: '7658',
          },
        ],
      });
      element._selectedTabIndex = 1;
      element.existingElementRows = [198];
      element.rowData = [];
      await elementUpdated(element);
      const stepperElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('stepper-custom'),
      );
      setTimeout(() => {
        stepperElement.dispatchEvent(
          new CustomEvent('changed-step-index', { detail: { data: 1 } }),
        );
      });
      aTimeout(200);
      await oneEvent(stepperElement, 'changed-step-index');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element._stepIndex).to.be.eq(1);
      await expect(element.rowData.length).to.be.eq(1);
    });

    it('It should change current step index and binding notes List', async () => {
      // element._getExistingData = Sinon.stub();
      // element._getExistingData.resolves(element.notesBackEndStructure);
      element.ajaxInstance.get.resolves({ data: element.notesBackEndStructure[0] });
      element._selectedTabIndex = 1;
      element.existingElementNotes = [765, 798];
      await elementUpdated();
      const stepperElement = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('stepper-custom'),
      );
      setTimeout(() => {
        stepperElement.dispatchEvent(
          new CustomEvent('changed-step-index', { detail: { data: 0 } }),
        );
      });
      await oneEvent(stepperElement, 'changed-step-index');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element._stepIndex).to.be.eq(0);
      await expect(element.notesData.length).to.be.eq(1);
    });
    it('It should add the notes', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('new-document-creation'),
      );

      const data2 = {
        noteId: '7658',
        name: 'Nota sulla riga',
        description: 'Descrizione nota sulla riga',
        version: '500',
        validity: '2022-08-08',
        id: '7658',
      };
      setTimeout(async () => {
        ele.dispatchEvent(
          new CustomEvent('notes-changed', {
            detail: {
              data: [data2],
              data2,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'notes-changed');
      await elementUpdated();
      await expect(element.notesData.length).to.be.eq(1);
      await expect(element.savedNote.length).to.be.eq(1);
    });

    it('It should add the rows', async () => {
      element._selectedTabIndex = 1;
      element.savedRow = [];
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-creation'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('rows-changed', {
            detail: { data: element.rows, data2: element.rows[0] },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'rows-changed');
      await expect(element.rowData.length).to.be.eq(1);
      await expect(element.savedRow.length).to.be.eq(1);
    });

    it('It should remove the rows', async () => {
      element._selectedTabIndex = 1;
      element.rowData = [];
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-creation'),
      );
      setTimeout(() => {
        ele.dispatchEvent(new CustomEvent('rows-changed', { detail: { data: [], id: '1981' } }));
      });
      aTimeout(200);
      await oneEvent(ele, 'rows-changed');
      await expect(element.rowData.length).to.be.eq(0);
    });

    it('It should add the subsections', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="subsection"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-added', {
            detail: {
              list: element.subSections,
              data1: element.subSections[0],
              savedChildList: [],
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-added');
      await expect(element.subSectionsList.length).to.be.eq(1);
      await expect(element.savedSubSection.length).to.be.eq(1);
    });

    it('It should remove the subsections', async () => {
      element._selectedTabIndex = 1;
      element.subSectionsList = element.subSections;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="subsection"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-removed', { detail: { data: [], id: '411' } }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-removed');
      await expect(element.subSectionsList.length).to.be.eq(0);
    });

    it('It should add the sections', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="section"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-added', {
            detail: { list: element.sections, data1: element.sections[0], savedChildList: [] },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-added');
      await expect(element.sectionsList.length).to.be.eq(1);
      await expect(element.savedSection.length).to.be.eq(1);
    });

    it('It should remove the sections', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="section"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-removed', { detail: { data: [], id: '411' } }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-removed');
      await expect(element.sectionsList.length).to.be.eq(0);
    });

    it('It should add existing notes', async () => {
      // element._getVersionItemDetail = Sinon.stub();
      // element._getVersionItemDetail.resolves({ data: element.notesBackEndStructure[0] });
      element.ajaxInstance.get.resolves({ data: element.notesBackEndStructure[0] });
      element._selectedTabIndex = 1;
      element.notesData = [];
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      await elementUpdated();
      const ele = element.shadowRoot.querySelector('.add-note');

      setTimeout(() => ele.dispatchEvent(new Event('click')));
      await aTimeout(300);
      await elementUpdated(element);
      const ele1 = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      setTimeout(() =>
        ele1.dispatchEvent(
          new CustomEvent('add-row-elements', {
            detail: {
              data: {
                noteId: '122',
                name: 'Nota sulla riga',
                description: 'Descrizione nota sulla riga',
                version: '500',
                validity: '2027-08-30',
                id: '122',
              },
              type: 'Nota',
            },
          }),
        ),
      );
      await oneEvent(ele1, 'add-row-elements');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element.notesData.length).to.be.greaterThan(0);
      Sinon.restore();
    });

    it('It should add existing rows', async () => {
      // element._getVersionItemDetail = Sinon.stub();
      // element._getVersionItemDetail.resolves({ data: element.rowsBackEndStructure[0] });
      element.ajaxInstance.get.resolves({ data: element.rowsBackEndStructure[0] });
      element.rowData = [];
      element._selectedTabIndex = 1;
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      element.rowData = [];
      element.existingElementNotes = [];
      await elementUpdated(element);
      const ele = element.shadowRoot.querySelector('.add-row');
      setTimeout(() => ele.dispatchEvent(new Event('click')));
      await aTimeout(300);
      await elementUpdated(element);
      const ele1 = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      setTimeout(() => {
        ele1.dispatchEvent(
          new CustomEvent('add-row-elements', {
            detail: {
              data: element.rows1,
              type: 'Righe',
            },
          }),
        );
      });
      await oneEvent(ele1, 'add-row-elements');
      await element.updateComplete;
      await aTimeout(200);
      // await expect(element.rowData.length).to.be.eq(1);
      await expect(element.existingElementNotes.length).to.be.eq(1);
      Sinon.restore();
    });

    it('It should add existing subsections', async () => {
      // element._getVersionItemDetail = Sinon.stub();
      // element._getVersionItemDetail.resolves({ data: element.subsectionBackendStructure[0] });
      element.ajaxInstance.get.resolves({ data: element.subsectionBackendStructure[0] });
      element._selectedTabIndex = 1;
      element.tabsData = [
        {
          headerData: [],
          list: [],
          name: 'Sotto Sezioni',
          propertyId: 'subSectionId',
          selectedRow: undefined,
        },
      ];
      await elementUpdated();
      const ele1 = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      setTimeout(() => {
        ele1.dispatchEvent(
          new CustomEvent('add-row-elements', {
            detail: {
              data: element.subSections1,
              type: 'Sotto Sezioni',
            },
          }),
        );
      });
      await oneEvent(ele1, 'add-row-elements');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element.subSectionsList.length).to.be.greaterThanOrEqual(1);
      await expect(element.existingElementRows.length).to.be.eq(2);
    });

    it('It should add existing sections', async () => {
      // element._getVersionItemDetail = Sinon.stub();
      // element._getVersionItemDetail.resolves({ data: element.sectionBackendStructure });
      element.ajaxInstance.get.resolves({ data: element.sectionBackendStructure });

      element._selectedTabIndex = 1;
      element.tabsData = [
        {
          headerData: [],
          list: [],
          name: 'Sezioni',
          propertyId: 'sectionId',
          selectedRow: undefined,
        },
      ];
      await elementUpdated();
      const ele1 = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      setTimeout(() => {
        ele1.dispatchEvent(
          new CustomEvent('add-row-elements', {
            detail: {
              data: element.section1,
              type: 'Sezioni',
            },
          }),
        );
      });
      await oneEvent(ele1, 'add-row-elements');
      await element.updateComplete;
      await aTimeout(200);
      await expect(element.sectionsList.length).to.be.eq(1);
      await expect(element.existingElementSubsection.length).to.be.eq(2);
    });

    it('It should bind selected notes', async () => {
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves({ list: [], headerData: [], propertyId: '' });
      // element.requestUpdate();
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = element.shadowRoot.querySelector('.add-note');
      setTimeout(() => ele.dispatchEvent(new Event('click')));
      await elementUpdated(element);
      await aTimeout(200);
      const ele1 = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      const note = {
        noteId: '122',
        name: 'Nota sulla riga',
        description: 'Descrizione nota sulla riga',
        version: '500',
        from: '30/08/2027',
        id: '122',
      };
      setTimeout(() => {
        ele1.dispatchEvent(
          new CustomEvent('selected-table-row', {
            detail: {
              data: note,
              type: 'Nota',
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele1, 'selected-table-row');
      await expect(element.tabsData[0].selectedRow).equal(note);
      Sinon.restore();
    });
    it('It should replace unsaved sections', async () => {
      element._selectedTabIndex = 1;
      element._lastStepIndex = 3;
      element.valueChangedSection = ['411'];
      element.savedSection = JSON.parse(JSON.stringify([...element.sections]));
      const { name } = element.savedSection[0];
      element.sectionsList = JSON.parse(JSON.stringify([...element.sections]));
      element.sectionsList[0].name = 'test';
      await elementUpdated(element);
      element.replaceUnSavedItemsForSection(true);
      aTimeout(200);

      expect(name).to.equal(element.sectionsList[0].name);
    });

    it('It should replace unsaved sub-sections', async () => {
      element._selectedTabIndex = 1;
      element._lastStepIndex = 2;
      element.valueChangedSubSection = ['40'];
      element.savedSubSection = JSON.parse(JSON.stringify([element.subSections1]));
      const { name } = element.savedSubSection[0];
      element.subSectionsList = JSON.parse(JSON.stringify([element.subSections1]));
      element.subSectionsList[0].name = 'test';
      await elementUpdated(element);
      element.replaceUnSavedItemsForSubSection(true);
      aTimeout(200);

      expect(name).to.equal(element.subSectionsList[0].name);
    });

    it('It should replace unsaved notes', async () => {
      element._selectedTabIndex = 1;
      element._lastStepIndex = 0;
      element.valueChangedNote = ['123'];
      element.savedNote = [
        {
          noteId: '123',
          name: 'Nota sulla riga',
          description: 'Descrizione nota sulla riga',
          version: '501',
          validity: '2021-08-01',
          id: '123',
        },
      ];
      element.notesData = [
        {
          noteId: '123',
          name: 'Nota sulla riga',
          description: 'Descrizione nota sulla riga',
          version: '501',
          validity: '2021-08-01',
          id: '123',
        },
      ];
      element.notesData[0].name = 'test';
      await elementUpdated(element);
      element.replaceUnSavedItemsForNote(true);
      aTimeout(200);

      expect(element.notesData.length).to.equal(0);
    });

    it('It should trigger when section value changed', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="section"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('field-values-changed', {
            detail: { id: 1 },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'field-values-changed');

      expect(element.valueChangedSection.length).to.equal(1);
    });

    it('It should trigger when sub-section value changed', async () => {
      element._selectedTabIndex = 1;
      element.valueChangedSubSection = [2];
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="subsection"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('field-values-changed', {
            detail: { id: 1 },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'field-values-changed');

      expect(element.valueChangedSubSection.length).to.equal(2);
    });

    it('It should trigger when row value changed', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-creation'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('field-values-changed', {
            detail: { id: 1 },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'field-values-changed');

      expect(element.valueChangedRow.length).to.equal(1);
    });

    it('It should trigger when note value changed', async () => {
      element._selectedTabIndex = 1;
      element.valueChangedNote = [1];
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('new-document-creation'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('field-values-changed', {
            detail: { id: 1 },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'field-values-changed');

      expect(element.valueChangedNote.length).to.equal(1);
    });

    it('It should return true when trigger checkSubSectionExistsIntoSection', async () => {
      element._selectedTabIndex = 1;
      element.sectionsList = [
        {
          sectionId: '411',
          name: 'Section estratto conto',
          description: 'Sezione estratto',
          version: '15',
          validity: '2021-08-01',
          id: '411',
          subSections: [
            {
              name: 'Section estratto conto',
              description: 'Sezione estratto',
              version: '15',
              validity: '2021-08-01',
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated();
      const status = element.checkSubSectionExistsIntoSection('1');

      expect(status).to.equal(true);
    });

    it('It should return true when trigger checkRowsExistsIntoSubSection', async () => {
      element._selectedTabIndex = 1;
      element.subSectionsList = [
        {
          name: 'Section estratto conto',
          description: 'Sezione estratto',
          version: '15',
          validity: '2021-08-01',
          id: '411',
          rows: [
            {
              name: 'row estratto conto',
              description: 'row estratto',
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated();
      const status = element.checkRowsExistsIntoSubSection('1');

      expect(status).to.equal(true);
    });

    it('It should return true when trigger checkNotesExistsIntoRows', async () => {
      element._selectedTabIndex = 1;
      element.rowData = [
        {
          name: 'Section estratto conto',
          description: 'Sezione estratto',
          version: '15',
          validity: '2021-08-01',
          id: '411',
          columnNotes: [
            {
              name: 'row estratto conto',
              description: 'row estratto',
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated();
      const status = element.checkNotesExistsIntoRows('1');

      expect(status).to.equal(true);
    });

    it('It should bind selected value when document view is triggered', async () => {
      element._getVersionItemDetail = Sinon.stub();
      element._getVersionItemDetail.resolves({ data: element.documentData });
      element.showSuccessStep = true;
      element._selectedTabIndex = 1;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-created-successfully'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('document-view', {
            detail: 1,
          }),
        );
      });
      aTimeout(200);
      await oneEvent(element, 'homepage-modify');
      await expect(element._selectedValue.id).to.be.eq('100');
      await expect(element._selectedTabIndex).to.be.eq(2);
    });
    it('It clears all persisting data', async () => {
      element._getVersionItemDetail = Sinon.stub();
      element._getVersionItemDetail.resolves({ data: element.documentData });
      element.showSuccessStep = true;
      element._selectedTabIndex = 1;
      await elementUpdated(element);
      localStorage.setItem('test', 'test value');
      addElementToLocalStorage(
        element._selectedValue,
        localStorageKeysMap.APPLICATION_DOCUMENTS,
        true,
      );
      addElementToLocalStorage(
        {
          id: '2303-53330-90601',
          name: 'test',
          validity: '2022-11-02T06:02:52.077Z',
          style: '31',
          columns: [
            {
              id: '39662-80563-11101',
              name: '1',
              description: '',
              isBold: true,
              isItalic: false,
              column: '',
              note: '',
            },
          ],
          columnNotes: [],
          isNotSaved: true,
        },
        localStorageKeysMap.APPLICATION_ROWS,
      );
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-created-successfully'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('document-view', {
            detail: 1,
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'document-view');
      await expect(localStorage.getItem('test')).to.be.eq('test value');
      await expect(localStorage.getItem(localStorageKeysMap.APPLICATION_ROWS)).to.be.eq(null);
      await expect(localStorage.getItem(localStorageKeysMap.APPLICATION_DOCUMENTS)).to.be.eq(null);
    });
    it('It adds and populates then clears single Item from persistent data', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated(element);
      localStorage.setItem('test', 'test value');
      addElementToLocalStorage(
        {
          id: '2303-53330-90601',
          name: 'test',
          validity: '2022-11-02T06:02:52.077Z',
          style: '31',
          columns: [
            {
              id: '39662-80563-11101',
              name: '1',
              description: '',
              isBold: true,
              isItalic: false,
              column: '',
              note: '',
            },
          ],
          columnNotes: [],
          isNotSaved: true,
        },
        localStorageKeysMap.APPLICATION_ROWS,
      );
      addElementToLocalStorage(
        {
          name: 'Doc 1',
          status: '24',
          statusVal: 'IN SVILUPPO',
          product: '21',
          productVal: 'CA',
          type: '30',
          typeVal: 'SOF',
          start_date: '2022-11-04T05:02:01.486Z',
          code: 'abc',
          templateFile: 'dds_cca_2021.jrxml',
          selectedListSection: [
            {
              id: '1',
            },
          ],
          selectedListRule: [
            {
              id: '1',
            },
          ],
        },
        localStorageKeysMap.APPLICATION_DOCUMENTS,
        true,
      );
      await elementUpdated(element);
      element._populateDataFromLocalStorage();
      await expect(element.documentData?.type).to.be.eq('30');
      await expect(element.rowData?.[0]?.id).to.be.eq('2303-53330-90601');
      await expect(localStorage.getItem(localStorageKeysMap.APPLICATION_ROWS)).to.be.not.eq(null);

      removeElementFromLocalStorage('2303-53330-90601', localStorageKeysMap.APPLICATION_ROWS);
      await expect(localStorage.getItem(localStorageKeysMap.APPLICATION_ROWS)).to.be.eq(null);
      await expect(localStorage.getItem('test')).to.be.eq('test value');
    });
    it('Test singleton object works', async () => {
      const obj = new Singleton();
      obj.createdLookupValues([
        {
          lookupDataID: 21,
          ldKey: 'PRODUCT',
          ldValue: 'CA',
        },
        {
          lookupDataID: 22,
          ldKey: 'PRODUCT',
          ldValue: 'CCA',
        },
        {
          lookupDataID: 23,
          ldKey: 'PRODUCT',
          ldValue: 'CDC',
        },
        {
          lookupDataID: 24,
          ldKey: 'STATUS',
          ldValue: 'IN SVILUPPO',
        },
        {
          lookupDataID: 25,
          ldKey: 'STATUS',
          ldValue: 'APPROVATO',
        },
        {
          lookupDataID: 26,
          ldKey: 'STATUS',
          ldValue: 'IN REVISIONE',
        },
        {
          lookupDataID: 27,
          ldKey: 'STATUS',
          ldValue: 'DISMESSO',
        },
        {
          lookupDataID: 28,
          ldKey: 'TYPE',
          ldValue: 'DDS',
        },
        {
          lookupDataID: 29,
          ldKey: 'TYPE',
          ldValue: 'EC',
        },
        {
          lookupDataID: 30,
          ldKey: 'TYPE',
          ldValue: 'SOF',
        },
      ]);
      await aTimeout(200);
      expect(obj.getLookupValuesByKey(22)).to.eq('CCA');
      expect(obj.getLookupValuesByKey(26)).to.eq('IN REVISIONE');
      expect(obj.getLookupValuesByKey(30)).to.eq('SOF');
    });
  });

  describe('Structure with tab opened', () => {
    afterEach(() => {
      fixtureCleanup();
    });

    it('document details page is accessible', async () => {
      const el = await fixture(html`<${tag}></${tag}>`);
      await expect(el).to.exist;
    });
  });

  describe('Structure with row selected', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tagRowSelected}></${tagRowSelected}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('document details page is accessible', async () => {
      const el = element;
      await expect(el).to.exist;
      element._displayData = [
        {
          id: 1,
          docId: 1,
          name: 'test',
        },
      ];
      await elementUpdated(element);
      const viewBtn = element.shadowRoot.querySelector('[data-tag-id="viewRowBtn"]');
      expect(viewBtn).to.exist;
      expect(viewBtn.textContent.trim()).to.be.equal('Vedi dettaglio');
      expect(viewBtn).to.not.have.attribute('disabled');
    });
    it('It should Open Dialog to show saved status message', async () => {
      element._selectedTabIndex = 1;
      await elementUpdated();
      const ele = await element?.shadowRoot?.querySelector('[currentStep="section"]');
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('show-status-dialog', {
            detail: {
              data: {
                status: 200,
              },
            },
          }),
        );
      });
      await elementUpdated(element);
      await aTimeout(200);
      const dialog = element.shadowRoot.querySelector('#dialog3');
      expect(dialog.opened).to.be.eq(true);
    });
    it('It should sort array based on alphabetical order', async () => {
      const list = [
        { id: '0', name: 'select' },
        { id: '1', name: 'z test' },
        { id: '2', name: 'a test' },
      ];
      const list2 = [
        { id: '2', name: 'c test' },
        { id: '1', name: 'z test' },
        { id: '4', name: 'a test' },
      ];
      const sortedList = getSortedList(list);
      expect(sortedList[1]?.name).to.be.eq('a test');
      const sortedList2 = getSortedList(list2);
      expect(sortedList2[0]?.name).to.be.eq('a test');
      expect(sortedList2[2]?.name).to.be.eq('z test');
    });
  });

  describe('Events', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('button view is clicked', async () => {
      const el = element;
      await expect(el).to.exist;
      element._displayData = [
        {
          id: 1,
          docId: 1,
          name: 'test',
        },
      ];
      await elementUpdated(element);
      const viewBtn = element.shadowRoot.querySelector('[data-tag-id="viewRowBtn"]');
      viewBtn.click();

      expect(element.tabCount).to.equal(3);
      expect(element._selectedTabIndex).to.equal(2);
    });

    it('close tab clicked', async () => {
      const el = element;
      await expect(el).to.exist;

      element._closeTab;

      expect(element.tabCount).to.equal(2);
      expect(element._selectedTabIndex).to.equal(0);
    });
  });
});
