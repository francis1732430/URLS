import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
  aTimeout,
} from '@open-wc/testing';
import Sinon from 'sinon';

import { DocumentListReviewInfoCE } from './test-class.js';

describe('DocumentListReviewPage Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentListReviewInfoCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It has same ID', async () => {
      const idField = await element?.shadowRoot?.querySelector(
        '.dcouemnt-review-tr:first-child td strong',
      );
      console.log(idField);
      expect(idField.textContent).to.equal('1');
    });

    it('It should bind last request date', async () => {
      element.lastRequestDate = '2022-01-02';
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('.last-request-date');
      expect(el.textContent).to.equal('02/01/2022');
    });

    it('It should change the version list', async () => {
      element.currentTab = 'storicaReview';
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('[name="version"]');
      el.modelValue = '2';
      el.dispatchEvent(new Event('change'));
      aTimeout(300);
      element.version = '2';
      expect(element.version).to.equal(el.modelValue);
    });

    it('It should bind correct fields', async () => {
      element.reviewData.status = 'IN SVILUPPO';
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('.status_draft');
      const el1 = await element?.shadowRoot?.querySelector('.status_prod');
      const el2 = await element?.shadowRoot?.querySelector('.status_review');

      await expect(el).to.exist;
      await expect(el1).to.not.exist;
      await expect(el2).to.not.exist;
    });

    it('If version-detail-list event is fired it should get all detail of versions list for rules', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      await elementUpdated(element);
      element.getVersionDetails();
      aTimeout(200);
      await elementUpdated(element);
      await expect(element.versionList.length).to.be.eq(2);
    });
  });
});
