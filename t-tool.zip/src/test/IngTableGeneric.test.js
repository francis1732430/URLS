import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
} from '@open-wc/testing';

import { IngTableCE } from './test-class.js';

describe('IngTable generic Tests', () => {
  const tag = unsafeStatic(defineCE(IngTableCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It renders correct table rows', async () => {
      const trs = await element?.shadowRoot?.querySelectorAll('tbody tr');
      expect(trs.length).to.equal(element.tableData.length);
    });
    it('It renders correct table table row data', async () => {
      const tds = await element?.shadowRoot?.querySelectorAll('tbody tr:first-child td');
      expect(tds.length).to.equal(element.contentProperties.length);
    });
    it('It sends correct data when table row is clicked', async () => {
      const tr = await element?.shadowRoot?.querySelector('tbody tr');
      setTimeout(() => element._fireMockEvent(tr, 'click'));

      aTimeout(200);

      const { detail } = await oneEvent(element, 'selected-table-row');
      aTimeout(200);
      expect(detail.data).to.deep.equal(tr.data);
    });
    it('It renders dynamic html tags', async () => {
      const el = await element?.shadowRoot?.querySelector('tbody tr .review-cls');
      expect(el).to.exist;
    });
    it('It renders dynamic nested html tags', async () => {
      const el = await element?.shadowRoot?.querySelector('tbody tr .review-cls .review-cls-span');
      expect(el).to.exist;
    });
    it('It renders dynamic nested html tags List', async () => {
      const el1 = await element?.shadowRoot?.querySelector('tbody .review-cls-2');
      const el2 = await element?.shadowRoot?.querySelector('tbody .review-cls-nested');
      const el3 = await element?.shadowRoot?.querySelector('tbody .review-cls-span-new');
      const el4 = await element?.shadowRoot?.querySelector('tbody .review-cls-span-new-2');
      expect(el1).to.exist;
      expect(el2).to.exist;
      expect(el3).to.exist;
      expect(el4).to.exist;
    });
    it('It fires allowed events on dynamic html', async () => {
      const el = await element?.shadowRoot?.querySelector('tbody tr .review-cls .review-cls-span');
      setTimeout(() => el.click());

      aTimeout(300);

      const { detail } = await oneEvent(element, 'child-data-event');
      aTimeout(200);
      expect(detail.name).to.equal(el.name);
    });

    it('It renders dynamic class name green', async () => {
      const el = await element?.shadowRoot?.querySelectorAll('.review-cls-green');
      expect(el.length).to.be.eq(2);
    });

    it('It renders dynamic class name orange', async () => {
      const el = await element?.shadowRoot?.querySelectorAll('.review-cls-orange');
      expect(el.length).to.be.eq(3);
    });
  });
});
