import { expect, fixture, html, unsafeStatic, defineCE, fixtureCleanup } from '@open-wc/testing';
import { ApplicationAccessPageCE } from './test-class.js';

describe('ApplicationAccessPage Tests', () => {
  const tag = unsafeStatic(defineCE(ApplicationAccessPageCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
  });
});
