import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
} from '@open-wc/testing';

import { FileUploadCE } from './test-class.js';

describe('DocumentListReviewAttachmentsPage Tests', () => {
  const tag = unsafeStatic(defineCE(FileUploadCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It sends correct files when files-added event is fired', async () => {
      const input = await element?.shadowRoot?.querySelector('#file-upload-input');
      setTimeout(() => element._fireMockEvent(input, 'change'));

      aTimeout(200);
      await oneEvent(element, 'files-added');
      aTimeout(200);
      expect(element._files).to.deep.equal(element._mockFiles);
    });
    it('It receives files when files ares dropped on drop area', async () => {
      const dropArea = await element?.shadowRoot?.querySelector('.file-upload-drag-drop');
      setTimeout(() => element._fireMockEvent(dropArea, 'drop'));

      aTimeout(200);
      await oneEvent(element, 'files-added');
      aTimeout(200);
      expect(element._files).to.deep.equal(element._mockFiles);
    });
    it('It highlights drop area border when files are being dragged over', async () => {
      const dropArea = await element?.shadowRoot?.querySelector('.file-upload-drag-drop');

      setTimeout(() => element._fireMockEvent(dropArea, 'dragover'));
      await aTimeout(300);
      await expect(element.dragOverClass).to.equal('dragged-over');

      setTimeout(() => element._fireMockEvent(dropArea, 'dragleave'));
      await aTimeout(300);
      await expect(element.dragOverClass).to.not.equal('dragged-over');
    });
  });
});
