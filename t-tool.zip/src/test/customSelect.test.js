import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
  aTimeout,
} from '@open-wc/testing';
import { CustomSelectCE } from './test-class.js';

describe('CustomSelect Tests', () => {
  const tag = unsafeStatic(defineCE(CustomSelectCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('Checkbox options should not open', async () => {
      const checkboxes = element.shadowRoot.getElementById('mySelectOptions');
      checkboxes.style.display = 'block';
      await elementUpdated(element);

      const mySelectLabel = element.shadowRoot.getElementById('mySelectLabel');
      mySelectLabel.click();
      await aTimeout(200);
      const checkboxes1 = element.shadowRoot.getElementById('mySelectOptions');
      expect(checkboxes1?.style?.display).to.be.eq('none');
    });

    it('Selected text should not be empty', async () => {
      element.selectedOptions = [
        {
          id: '1',
          name: 'test',
          columnNoteId: '1_1',
        },
        {
          id: '2',
          name: 'test2',
          columnNoteId: '1_2',
        },
      ];
      await elementUpdated(element);
      element.initMultiselect();
      await aTimeout(200);
      expect(element.selectedTexts).to.be.eq('test,test2');
    });

    it('It should changes the checkbox status', async () => {
      // await elementUpdated(element);
      const checkboxes = element.shadowRoot.querySelector(`#mySelectOptions #id_1_1`);
      checkboxes.click();
      await aTimeout(200);
      expect(element.selectedOptions[0].columnNoteId).to.be.eq('1_1');
      checkboxes.click();
      await aTimeout(200);
      expect(element.selectedOptions.length).to.be.eq(0);
    });
  });
});
