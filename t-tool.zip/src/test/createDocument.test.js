import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  elementUpdated,
} from '@open-wc/testing';

import { CreateDocumentCE } from './test-class.js';

describe('CreateDocument Tests', () => {
  const tag = unsafeStatic(defineCE(CreateDocumentCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (selector, eventName, value = 'test') => {
      const input = await element?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.value = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It binds the name field', async () => {
      const input = await populateInput('name', 'keyup');
      expect(element.name).to.equal(input.value);
    });

    it('It binds the status field', async () => {
      const select = await element?.shadowRoot?.querySelector(`[name="status"]`);
      await aTimeout(300);
      await elementUpdated(element);
      expect('IN SVILUPPO').to.equal(select.value);
    });

    it('It binds the product field', async () => {
      const select = await element?.shadowRoot?.querySelector(`[name="product"]`);
      element.productList = [
        {
          id: '2',
          name: 'test',
        },
      ];
      await elementUpdated(element);
      select.modelValue = '2';
      select.dispatchEvent(new Event('change'));
      await aTimeout(300);
      await elementUpdated(element);
      expect(element.product).to.equal(select.modelValue);
    });

    it('It binds the code field', async () => {
      const input = await populateInput('code', 'keyup');
      expect(element.code).to.equal(input.value);
    });

    it('It binds the type field', async () => {
      const select = await element?.shadowRoot?.querySelector(`[name="type"]`);
      element.typeList = [
        {
          id: '2',
          name: 'test',
        },
      ];
      await elementUpdated(element);
      select.modelValue = '2';
      select.dispatchEvent(new Event('change'));
      await aTimeout(300);
      await elementUpdated(element);
      expect(element.type).to.equal(select.modelValue);
    });

    it('It binds the correct value when date value changed', async () => {
      const datepicker = await element?.shadowRoot?.querySelector(`[name="start_date"]`);

      datepicker.modelValue = new Date('10-10-2022');
      datepicker.dispatchEvent(new Event('change'));
      aTimeout(300);
      expect(new Date(element.start_date).getTime()).to.equal(new Date('2022-10-10').getTime());
    });
  });
});
