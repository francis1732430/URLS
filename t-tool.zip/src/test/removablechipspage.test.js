import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
} from '@open-wc/testing';
import { RemovableChipPageCE } from './test-class.js';

describe('DocumentListReviewAttachmentsPage Tests', () => {
  const tag = unsafeStatic(defineCE(RemovableChipPageCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It has same Label', async () => {
      const label = await element?.shadowRoot?.querySelector('.badge');
      console.log(label);
      expect(label.textContent).to.match(new RegExp(element.labelText, 'gi'));
    });
    it('It sends correct data when chip-deleted event is fired', async () => {
      const btn = await element?.shadowRoot?.querySelector('.cross');
      console.log(btn);
      setTimeout(() => btn.click());

      aTimeout(200);
      const event = await oneEvent(element, 'chip-deleted');

      aTimeout(200);
      expect(event?.detail?.id).to.equal(element.id);
    });
  });
});
