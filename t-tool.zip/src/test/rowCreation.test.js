import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import sinon from 'sinon';

import { RowCreationCE } from './test-class.js';

describe('CreateRowCE Tests', () => {
  const tag = unsafeStatic(defineCE(RowCreationCE));

  describe('Structure', () => {
    let element;

    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It binds data to save-row event', async () => {
      const btn = await element?.shadowRoot?.querySelector('#createNew');
      setTimeout(() => btn.click());
      await elementUpdated(element);
      await aTimeout(200);
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-row'),
      );

      expect(elements.length).to.equal(3);
    });
    it('It receives id in remove-row event', async () => {
      // element._deleteRow = sinon.stub();
      // element._deleteRow.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.delete = sinon.stub();
      element.ajaxInstance.delete.resolves({ text: 'Removed succesfully' });
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-row'),
      );
      element._fireMockEvent(el, 'remove-row', { id: el.id });
      await elementUpdated(element);
      await aTimeout(200);
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-row'),
      );

      expect(elements.length).to.equal(2);
      sinon.restore();
    });
    it('It receives data through save-row event', async () => {
      // element._putRow = sinon.stub();
      // element._putRow.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.patch = sinon.stub();
      element.ajaxInstance.patch.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.rowBackend });
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-row'),
      );
      setTimeout(() =>
        element._fireMockEvent(el, 'save-row', {
          ...element.rowData[0],
          name: 'test row',
          id: el.id,
        }),
      );
      aTimeout(200);
      const { detail } = await oneEvent(element, 'rows-changed');
      expect(detail?.data?.[0]?.name).to.equal('test row');
      sinon.restore();
    });
    it('It receives creation data through save-row event', async () => {
      // element._putRow = sinon.stub();
      // element._putRow.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.post = sinon.stub();
      element.ajaxInstance.post.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.rowBackend });
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-row'),
      );
      setTimeout(() =>
        element._fireMockEvent(el, 'save-row', {
          ...element.rowData[0],
          name: 'test row',
          id: '2334345',
          isNotSaved: true,
        }),
      );
      aTimeout(200);
      const { detail } = await oneEvent(element, 'rows-changed');
      expect(detail?.data?.[0]?.name).to.equal('Row 1');
      sinon.restore();
    });
    it('It should hide the create new button', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('#createNew');
      await expect(btn).to.not.exist;
    });

    it('It receives Column data through save-row event', async () => {
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.rowBackend });
      element.rowData[0].columns = [];
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-row'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('row-changed', {
            detail: {
              id: 1,
            },
          }),
        ),
      );
      aTimeout(200);
      const { detail } = await oneEvent(element, 'row_column_changed');
      expect(detail?.data?.[0]?.columns?.length).to.equal(element?.rowData[0]?.columns?.length);
      sinon.restore();
    });
    it('It receives update data through save-row event', async () => {
      element.rowData = [element.rowData1];
      element.ajaxInstance.post = sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'DETTAGLIO_RIGA',
              data: 5,
            },
          ],
        },
      });
      element.ajaxInstance.patch = sinon.stub();
      element.ajaxInstance.patch.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.rowBackend });
      element.requestUpdate();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-row'),
      );
      setTimeout(() =>
        element._fireMockEvent(el, 'save-row', {
          ...element.rowData[0],
          versionID: 2,
        }),
      );
      aTimeout(200);
      const { detail } = await oneEvent(el, 'save-row');
      expect(detail?.name).to.equal('Condizioni economiche');
      sinon.restore();
    });
  });
});
