import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
  aTimeout,
  oneEvent,
} from '@open-wc/testing';
import Sinon from 'sinon';
import { documents } from '../data/documents.js';
import { DialogModifySectionCE } from './test-class.js';

describe('DialogModifySection Tests', () => {
  const tag = unsafeStatic(defineCE(DialogModifySectionCE));
  describe('Structure', () => {
    let element;
    const getVersionList = async name => {
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList1 } });
      element.selectedRow = {
        id: '1',
        version: '1',
        style: '1',
      };
      element.name = name;
      await elementUpdated(element);
      element.getVersionDetails();
      await elementUpdated(element);
      await aTimeout(200);
    };

    const getVersionDetail = async (data, name) => {
      element.ajaxInstance.get.resolves({ data });
      element.selectedRow = {
        id: '1',
        version: '1',
        style: '1',
      };
      element.name = name;
      await elementUpdated(element);
      element.changeVersionDetail({ target: { value: 1 } });
      await element.updateComplete;
      await aTimeout(200);
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('If version-detail-list event is fired it should get all detail of versions list for sections', async () => {
      await getVersionList('Sezioni');
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If version-detail-list event is fired it should get all detail of versions list for sub-sections', async () => {
      await getVersionList('Sotto Sezioni');
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If version-detail-list event is fired it should get all detail of versions list for row', async () => {
      await getVersionList('Righe');
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If version-detail-list event is fired it should get all detail of versions list for note', async () => {
      await getVersionList('Nota');
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If version-detail-list event is fired it should get all detail of versions list for rule', async () => {
      await getVersionList('Regola');
      await expect(element.versionList.length).to.be.eq(3);
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for sections', async () => {
      await getVersionDetail(element.section, 'Sezioni');
      await expect(element.selectedRow.id).to.be.eq('98');
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for sub-sections', async () => {
      await getVersionDetail(element.subSection, 'Sotto Sezioni');
      await expect(element.selectedRow.id).to.be.eq('98');
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for row', async () => {
      await getVersionDetail(element.row, 'Righe');
      await expect(element.selectedRow.id).to.be.eq('198');
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for note', async () => {
      await getVersionDetail(element.note, 'Nota');
      await expect(element.selectedRow.id).to.be.eq('98');
      Sinon.restore();
    });

    it('If changed-version-detail event is fired it should get all detail of version for rule', async () => {
      await getVersionDetail(element.note, 'Regola');
      await expect(element.selectedRow.id).to.be.eq('98');
      Sinon.restore();
    });

    it('Removed items for section should be exist', async () => {
      element.dupSelectedRow = JSON.parse(JSON.stringify(documents[0].sections[0]));
      const section = JSON.parse(JSON.stringify(documents[0].sections[0]));
      delete section.subSections[1];
      element.selectedRow = { ...section };
      element.name = 'Sezioni';
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-sub-section'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-removed', {
            detail: {
              data1: section,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-removed');
      await expect(element.removedIds.length).to.be.eq(1);
    });

    it('Removed items for subsection should be exist', async () => {
      element.dupSelectedRow = JSON.parse(JSON.stringify(documents[0].sections[0].subSections[0]));
      const subSection = JSON.parse(JSON.stringify(documents[0].sections[0].subSections[0]));
      delete subSection.rows[1];
      element.selectedRow = { ...subSection };
      element.name = 'Sotto Sezioni';
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-sub-section'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('event-section-removed', {
            detail: {
              data1: subSection,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'event-section-removed');
      await expect(element.removedIds.length).to.be.eq(1);
    });

    it('Removed items for rows should be exist', async () => {
      element.dupSelectedRow = JSON.parse(
        JSON.stringify(documents[0].sections[0].subSections[0].rows[0]),
      );
      const row = JSON.parse(JSON.stringify(documents[0].sections[0].subSections[0].rows[0]));
      delete row.notes[1];
      row.columnNotes = row.notes;
      element.selectedRow = { ...row };
      element.rows = [element.selectedRow];
      element.notesMappingList = [{}];
      element.lookupData = [{}];
      element.name = 'Righe';
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-creation'),
      );
      setTimeout(() => {
        ele.dispatchEvent(
          new CustomEvent('rows-changed', {
            detail: {
              data2: row,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(ele, 'rows-changed');
      await expect(element.removedIds.length).to.be.eq(1);
    });

    it('Should exists subsection mapping list', async () => {
      const section = JSON.parse(JSON.stringify(documents[0].sections[0]));
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsList: [
            { id: 1, name: 'text' },
            { id: 2, name: 'text1' },
          ],
        },
      });
      await elementUpdated(element);
      element.addLinkedElement('Sezioni', section);
      await elementUpdated(element);
      await aTimeout(200);
      await expect(element.subSectionMappingList.length).to.be.eq(2);
    });

    it('Should exists rows mapping list', async () => {
      const subSection = JSON.parse(JSON.stringify(documents[0].sections[0].subSections[0]));
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsList: [
            { id: 1, name: 'text' },
            { id: 2, name: 'text1' },
          ],
        },
      });
      await elementUpdated(element);
      element.addLinkedElement('Sotto Sezioni', subSection);
      await elementUpdated(element);
      await aTimeout(200);
      await expect(element.rowsMappingList.length).to.be.eq(2);
    });

    it('Should exists notes mapping list', async () => {
      const row = JSON.parse(JSON.stringify(documents[0].sections[0].subSections[0].rows[0]));
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsList: [
            { id: 1, name: 'text' },
            { id: 2, name: 'text1' },
          ],
        },
      });
      await elementUpdated(element);
      element.addLinkedElement('Righe', row);
      await elementUpdated(element);
      await aTimeout(200);
      await expect(element.notesMappingList.length).to.be.eq(2);
    });
  });
});
