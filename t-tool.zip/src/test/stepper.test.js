import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
} from '@open-wc/testing';

import { StepperCE } from './test-class.js';

describe('Stepper Tests', () => {
  const tag = unsafeStatic(defineCE(StepperCE));

  describe('Structure', () => {
    let element;

    beforeEach(async () => {
      element = await fixture(html`<${tag}>
            <div slot="step-1"> <span class="step-1">Step 1 Content</span></div>
            <div slot="step-2"><span class="step-2">Step 2 Content</span></div>
        </${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('Previous button stays disabled by default', async () => {
      const btn = await element?.shadowRoot?.querySelector('.stepper-button.pre');
      expect(btn).to.have.attribute('disabled');
    });
    it('Clicking next button enabled Previous button ', async () => {
      const btn = await element?.shadowRoot?.querySelector('.stepper-button.next');
      btn.click();
      aTimeout(250);
      expect(btn).to.not.have.attribute('disabled');
    });
    it('Clicking next button till last step disabled itself ', async () => {
      let btn = await element?.shadowRoot?.querySelector('.stepper-button.next');
      const steps = element.shadowRoot.querySelectorAll(
        element.constructor.getScopedTagName('ing-step'),
      );
      // eslint-disable-next-line no-plusplus
      for (let i = 0; i <= steps.length - 1; i++) {
        btn.click();
      }
      aTimeout(300);
      btn = await element?.shadowRoot?.querySelector('.stepper-button.next');
      await expect(btn).to.have.attribute('disabled');
    });
  });
});
