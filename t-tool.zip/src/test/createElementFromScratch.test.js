import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import Sinon from 'sinon';

import { ElementFromScratchCE } from './test-class.js';
import { transformRowsToFrontEnd } from '../data/tranformations/rowTransformation.js';
import { transformSectionsToFrontEnd } from '../data/tranformations/sectionTransformation.js';
import { transformSubSectionsToFrontEnd } from '../data/tranformations/subSectionsTransformation.js';
import { transformNoteToFrontEnd } from '../data/tranformations/noteTransformation.js';
import { transformRulesToFrontEnd } from '../data/tranformations/ruleTransformation.js';

describe('createElementFromScratch Tests', () => {
  const tag = unsafeStatic(defineCE(ElementFromScratchCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (selector, eventName, value = 'test') => {
      const input = await element?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.modelValue = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It binds the searchText field', async () => {
      const input = await populateInput('searchText', 'keyup');
      await elementUpdated(element);
      expect(element.searchText).to.equal(input.modelValue);
    });

    it('It should binds the section name', async () => {
      const el = await element?.shadowRoot?.querySelector('.add-title');
      await elementUpdated(element);
      expect(`Aggiungi sezione esistente`).to.equal(el.innerText);
    });

    it('It should filter the list', async () => {
      await populateInput('searchText', 'keyup');
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('#searchButton');
      el.click();
      await elementUpdated(element);
      expect(element._dataDup.length).to.equal(1);
    });

    it('If section name is row it should bind the row table', async () => {
      element.sectionName = 'Righe';
      await elementUpdated(element);
      const elRow = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-rows-details-table'),
      );
      const elCommon = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      expect(elCommon).not.exist;
      expect(elRow).exist;
    });

    it('It should fired selected row event', async () => {
      element.sectionName = 'Righe';
      await elementUpdated();
      const elRow = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-rows-details-table'),
      );
      const row = {
        id: 1,
        name: 'test',
        description: 'test',
      };
      setTimeout(() => {
        elRow.dispatchEvent(
          new CustomEvent('selected-table-row', {
            detail: {
              data: row,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(elRow, 'selected-table-row');
      await expect(element.selectedRow).equal(row);
    });

    it('It should bind the pagination links', async () => {
      element._dataDup = element.tableContentData;
      element._data = element._dataDup;
      element.pagePerItem = 1;
      element.total = 30;

      await elementUpdated(element);
      const elPagination = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('ing-pagination-links'),
      );
      expect(elPagination).exist;
    });

    it('If toggleform event is fired it should change the current view', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: [] });
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('#createNew');
      el.click();
      await elementUpdated(element);
      expect(element._showCreateForm).true;
    });

    it('If version-detail-list event is fired it should get all detail of versions list for section', async () => {
      // element.getVersionsList = Sinon.stub();
      // element.getVersionsList.resolves(element.versionList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element._data = element.sectionList;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      element.sectionList[0].itemsVersionsID = '2';
      element.sectionList[0].versionNumber = 20;
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.sectionList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'version-detail-list');
      await expect(element._data[0].itemsVersionsID).to.be.eq('2');
      await expect(element._data[0].versionNumber).to.be.eq(20);
    });
    it('If version-detail-list event is fired it should get all detail of versions list for sub-section', async () => {
      // element.getVersionsList = Sinon.stub();
      // element.getVersionsList.resolves(element.versionList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element.sectionName = 'Sotto Sezioni';
      element._data = element.subSectionList;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      element.subSectionList[0].itemsVersionsID = '2';
      element.subSectionList[0].versionNumber = 20;
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.subSectionList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'version-detail-list');
      await expect(element._data[0].itemsVersionsID).to.be.eq('2');
      await expect(element._data[0].versionNumber).to.be.eq(20);
    });
    it('If version-detail-list event is fired it should get all detail of versions list for rows', async () => {
      // element.getVersionsList = Sinon.stub();
      // element.getVersionsList.resolves(element.versionList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element.sectionName = 'Righe';
      element._data = element.rowList;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-rows-details-table'),
      );
      element.rowList[0].itemsVersionsID = '2';
      element.rowList[0].versionNumber = 20;
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.rowList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'version-detail-list');
      await expect(element._data[0].itemsVersionsID).to.be.eq('2');
      await expect(element._data[0].versionNumber).to.be.eq(20);
    });
    it('If version-detail-list event is fired it should get all detail of versions list for notes', async () => {
      // element.getVersionsList = Sinon.stub();
      // element.getVersionsList.resolves(element.versionList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element.sectionName = 'Nota';
      element._data = element.noteList;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      element.noteList[0].itemsVersionsID = '2';
      element.noteList[0].versionNumber = 20;
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.noteList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'version-detail-list');
      await expect(element._data[0].itemsVersionsID).to.be.eq('2');
      await expect(element._data[0].versionNumber).to.be.eq(20);
    });
    it('If version-detail-list event is fired it should get all detail of versions list for rules', async () => {
      // element.getVersionsList = Sinon.stub();
      // element.getVersionsList.resolves(element.versionList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsVersionsList: element.versionList } });
      element.sectionName = 'Nota';
      element._data = element.ruleList;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      element.ruleList[0].itemsVersionsID = '2';
      element.ruleList[0].versionNumber = 20;
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.ruleList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'version-detail-list');
      await expect(element._data[0].itemsVersionsID).to.be.eq('2');
      await expect(element._data[0].versionNumber).to.be.eq(20);
    });

    it('If changed-version-detail event is fired it should get all detail of version for sections', async () => {
      const detail = { ...element.sectionList[0] };
      // element.getVersionItemDetail = Sinon.stub();
      // element.getVersionItemDetail.resolves({ data: detail });
      detail.itemsVersionsID = '2';
      detail.versionNumber = 20;
      detail.isVersionChanged = true;
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: detail });
      element.sectionName = 'Sezioni';
      element._data = [transformSectionsToFrontEnd(detail)];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: element.sectionList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'changed-version-detail');
      await expect(element._data[0].id).to.be.eq('2');
      await expect(element._data[0].version).to.be.eq(20);
    });

    it('If changed-version-detail event is fired it should get all detail of version for sub-sections', async () => {
      const detail = { ...element.subSectionList[0] };
      // element.getVersionItemDetail = Sinon.stub();
      // element.getVersionItemDetail.resolves({ data: detail });

      detail.itemsVersionsID = '2';
      detail.versionNumber = 20;
      detail.isVersionChanged = true;
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: detail });

      element.sectionName = 'Sotto Sezioni';
      element._data = [transformSubSectionsToFrontEnd(detail)];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: element.subSectionList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'changed-version-detail');
      await expect(element._data[0].id).to.be.eq('2');
      await expect(element._data[0].version).to.be.eq('20');
      await expect(element._data[0].isVersionChanged).to.be.eq(true);
    });

    it('If changed-version-detail event is fired it should get all detail of version for rows', async () => {
      const detail = { ...element.rowList[0] };
      detail.itemsVersionsID = '2';
      detail.versionNumber = 20;
      detail.isVersionChanged = true;
      // element.getVersionItemDetail = Sinon.stub();
      // element.getVersionItemDetail.resolves({ data: detail });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: detail });
      element.sectionName = 'Righe';
      element._data = [transformRowsToFrontEnd(detail)];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-rows-details-table'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: element.rowList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'changed-version-detail');
      await expect(element._data[0].id).to.be.eq('2');
      await expect(element._data[0].version).to.be.eq(20);
      await expect(element._data[0].isVersionChanged).to.be.eq(true);
    });

    it('If changed-version-detail event is fired it should get all detail of version for notes', async () => {
      const detail = { ...element.noteList[0] };
      detail.itemsVersionsID = '2';
      detail.versionNumber = 20;
      detail.isVersionChanged = true;
      // element.getVersionItemDetail = Sinon.stub();
      // element.getVersionItemDetail.resolves({ data: detail });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: detail });
      element.sectionName = 'Nota';
      element._data = [transformNoteToFrontEnd(detail)];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: element.noteList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'changed-version-detail');
      await expect(element._data[0].id).to.be.eq('2');
      await expect(element._data[0].version).to.be.eq(20);
      await expect(element._data[0].isVersionChanged).to.be.eq(true);
    });

    it('If changed-version-detail event is fired it should get all detail of version for Rules', async () => {
      const detail = { ...element.ruleList[0] };
      detail.itemsVersionsID = '2';
      detail.versionNumber = 20;
      detail.isVersionChanged = true;
      // element.getVersionItemDetail = Sinon.stub();
      // element.getVersionItemDetail.resolves({ data: detail });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: detail });
      element.sectionName = 'Regole';
      element._data = [transformRulesToFrontEnd(detail)];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-common-details-table'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: element.ruleList[0],
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'changed-version-detail');
      await expect(element._data[0].id).to.be.eq('2');
      await expect(element._data[0].version).to.be.eq(20);
      await expect(element._data[0].isVersionChanged).to.be.eq(true);
    });

    it('It should bind document list when open dialog triggered', async () => {
      // element.getDocumentList = Sinon.stub();
      // element.getDocumentList.resolves(element.documentList);
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: { itemsVersionsParentDocumentsList: element.documentList },
      });
      element.sectionName = 'Sezioni';
      element.openDialog(null, transformSectionsToFrontEnd(element.sectionList[0]));
      aTimeout(200);
      await elementUpdated(element);
      aTimeout(200);
      await expect(element._displayData.length).to.be.eq(1);
    });

    it('It should bind document name', async () => {
      element.sectionName = 'Sezioni';
      element.docName = 'Document 1';
      await elementUpdated(element);
      await aTimeout(200);
      const el = await element?.shadowRoot?.querySelector('.add-title-margin');
      await expect(el.innerText).to.be.eq(element.docName);
    });

    it('It should bind subsection list when getChildElementsList triggered', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsList: element.sectionList } });
      element.sectionName = 'Sezioni';
      await elementUpdated(element);
      element.getChildElementsList('Sezioni');
      aTimeout(200);
      await elementUpdated(element);
      aTimeout(200);
      await expect(element.subSectionList.length).to.be.eq(1);
    });

    it('It should bind rows list when getChildElementsList triggered', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsList: element.sectionList } });
      element.sectionName = 'Sotto Sezioni';
      await elementUpdated(element);
      element.getChildElementsList('Sotto Sezioni');
      aTimeout(200);
      await elementUpdated(element);
      aTimeout(200);
      await expect(element.rows.length).to.be.eq(1);
    });

    it('It should bind notes list when getChildElementsList triggered', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemsList: element.sectionList } });
      element.sectionName = 'Righe';
      await elementUpdated(element);
      element.getChildElementsList('Righe');
      aTimeout(200);
      await elementUpdated(element);
      aTimeout(200);
      await expect(element.notes.length).to.be.eq(1);
    });
  });
});
