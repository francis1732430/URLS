import Sinon from 'sinon';
import { DocumentListHomePage } from '../DocumentListHomePage.js';
import { IngFeatTransparencyTool } from '../IngFeatTransparencyTool.js';
import { DocumentListReviewPage } from '../DocumentListReviewPage.js';
import { DocumentReviewAttachments } from '../DocumentReviewAttachments.js';
import { DocumentListReviewInfo } from '../DocumentReviewInfo.js';
import { RemovableChip } from '../components/removableChip/removableChip.js';
import { FileUpload } from '../components/fileUpload/fileUpload.js';
import { IngTable } from '../components/tables/IngTable.js';
import { NewDocumentCreation } from '../components/document/creation/NewDocumentCreation.js';
import { CreateNewNote } from '../components/document/creation/CreateNewNote.js';
import { Stepper } from '../components/stepper/stepper.js';
import { headerData } from '../data/reviewData.js';
import { generateId } from '../utils/IngFeatTransparencyToolUtils.js';
import { RowElements } from '../components/document/creation/RowElements.js';
import { RowDefination } from '../components/document/creation/RowDefination.js';
import { CreateRow } from '../components/document/creation/CreateNewRow.js';
import { RowCreation } from '../components/document/creation/rowCreation.js';
import { notes, rowStyles, radioData, rowData, rowData1 } from '../data/rowCreationData.js';
import {
  appliesToColumns,
  appliesToElements,
  appliesToRules,
  rulesData,
  rulesData1,
} from '../data/rulesCreationData.js';
import { contentData } from '../data/documentPreview.js';

import { CreateSubSection } from '../components/document/creation/CreateSubSection.js';
import { SubSection } from '../components/document/creation/SubSection.js';
import { ComponentAssociation } from '../components/document/creation/ComponentAssociation.js';
import { RuleElements } from '../components/document/creation/Rules/RuleElements.js';
import { RuleDefination } from '../components/document/creation/Rules/RuleDefination.js';
import { CreateRule } from '../components/document/creation/Rules/NewRule.js';
import { RuleCreation } from '../components/document/creation/Rules/RuleCreation.js';

import { CreateDocument } from '../components/document/creation/CreateDocument.js';
import { DocumentCreatedSuccessfully } from '../components/document/creation/DocumentCreatedSuccessfully.js';
import { DocumentPreview } from '../DocumentPreview.js';
import { ConfirmationDialog } from '../components/dialog/ConfirmationDialog.js';
import { DocumentModification } from '../DocumentModification.js';
import { DocumentDetailsPage } from '../DocumentDetailsPage.js';
import { ElementFromScratch } from '../createElementFromScratch.js';
import { versionList } from '../data/documentCreationData.js';
import { CollapsibleDocumentCommonDetails } from '../CollapsibleDocumentCommonDetails.js';
import { DocumentCommonDetailsTable } from '../components/tables/DocumentCommonDetailsTable.js';
import { DocumentRowsDetailsTable } from '../components/tables/DocumentRowsDetailsTable.js';
import { sectionsHeader } from '../data/documentDetailsHeaders.js';
import { transformSectionsToFrontEnd } from '../data/tranformations/sectionTransformation.js';
import { ApplicationAccessPage } from '../ApplicationAccessPage.js';
import { DialogModifySection } from '../components/dialog/DialogModifySection.js';
import { CollapsibleDocumentDetails } from '../CollapsibleDocumentDetails.js';
import { CollapsibleDocumentRowsDetails } from '../CollapsibleDocumentRowsDetails.js';
import { ajaxInstance } from '../utils/endpoints.js';
import { CustomSelect } from '../components/customSelect/CustomSelect.js';

/* eslint max-classes-per-file: ["error", 40] */
export class IngFeatTransparencyToolComponentCE extends IngFeatTransparencyTool {
  constructor() {
    super();
    ajaxInstance.get = Sinon.stub();
    ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
  }
}

export class DocumentListHomePageComponentCE extends DocumentListHomePage {
  constructor() {
    super();
    this.notesData = [];
    this.rowData = rowData;
    this.ruleData = rulesData;
    this.sectionBackendStructure = {
      itemID: '1',
      itemsVersionsID: '1',
      name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
      validity: '2021-08-08',
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Condizioni economiche',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: '1',
        },
      ],
      itemChildren: [
        {
          itemID: '40',
          itemOrder: 1,
          itemsVersionsID: '40',
          name: 'Subsection condizioni economiche Q4',
        },
        {
          itemID: '41',
          itemOrder: 2,
          itemsVersionsID: '41',
          name: 'Subsection estratto conto',
        },
      ],
    };
    this.subsectionBackendStructure = [
      {
        itemID: '40',
        itemsVersionsID: '40',
        name: 'Subsection condizioni economiche Q4',
        id: '40',
        validity: '2021-08-08',
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Sotto sezione condizioni',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
          },
        ],
        itemChildren: [
          {
            itemID: '198',
            itemOrder: 1,
            itemsVersionsID: '198',
            name: 'Condizioni economiche1',
          },
          {
            itemID: '199',
            itemOrder: 2,
            itemsVersionsID: '199',
            name: 'Condizioni economiche2',
          },
        ],
      },
      {
        itemID: '41',
        itemsVersionsID: '41',
        name: 'Subsection condizioni economiche Q4',
        id: '41',
        validity: '2021-08-08',
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Sotto sezione condizioni',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
          },
        ],
        itemChildren: [
          {
            itemID: '198',
            itemOrder: 1,
            itemsVersionsID: '198',
            name: 'Condizioni economiche1',
          },
          {
            itemID: '199',
            itemOrder: 2,
            itemsVersionsID: '199',
            name: 'Condizioni economiche2',
          },
        ],
      },
    ];
    this.rowsBackEndStructure = [
      {
        itemID: '198',
        itemsVersionsID: '198',
        name: 'Condizioni economiche',
        id: '198',
        validity: '2023-01-02',
        versionNumber: 2,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
            data: 'style 1',
            versionDetailLevel0ID: 1,
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'DETTAGLIO_RIGA',
            data: 'Col1',
            versionDetailLevel1ID: '1',
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: 'desc1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: true,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: false,
              },
              {
                itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
                itemTypeValue: 'DETTAGLIO_NOTA',
                data: 1,
                versionDetailL2: [
                  {
                    itemTypeKey: 'FIELD',
                    itemTypeValue: 'ID_NOTA',
                    data: 'Nota sulla riga',
                    versionDetailLevel2ID: '765',
                  },
                ],
              },
            ],
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'DETTAGLIO_RIGA',
            data: 'Col2',
            versionDetailLevel1ID: '1',
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: 'desc2',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: false,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: true,
              },
              {
                itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
                itemTypeValue: 'DETTAGLIO_NOTA',
                data: 2,
                versionDetailL2: [
                  {
                    itemTypeKey: 'FIELD',
                    itemTypeValue: 'ID_NOTA',
                    data: 'Nota sulla riga',
                    versionDetailLevel2ID: '798',
                  },
                ],
              },
            ],
          },
        ],
      },
    ];

    this.notesBackEndStructure = [
      {
        itemID: '765',
        itemsVersionsID: '765',
        name: 'Nota sulla riga',
        id: '765',
        validity: '2021-08-08',
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Descrizione nota sulla riga',
          },
        ],
      },
    ];

    this.rows = [
      {
        rowId: '1981',
        name: 'Condizioni economiche',
        description: 'Condizioni economiche',
        type: '1',
        version: '1',
        validity: '2021-08-08',
        id: '1981',
        columns: [
          {
            name: 'Col1',
            description: 'desc1',
            style: '1',
            id: 1,
          },
          {
            name: 'Col2',
            description: 'desc2',
            style: '2',
            id: 2,
          },
        ],
        columnNotes: [
          {
            name: 'Nota sulla riga',
            description: '',
            columnId: 1,
            id: '7651',
          },
          {
            name: 'Nota sulla riga',
            description: '',
            columnId: 2,
            id: '7981',
          },
        ],
        notes: [
          {
            noteId: '7651',
            name: 'Nota sulla riga',
            description: 'Descrizione nota sulla riga',
            version: '500',
            validity: '2021-08-08',
            id: '7651',
          },
          {
            noteId: '7981',
            name: 'Nota sulla riga',
            description: 'Descrizione nota sulla riga',
            version: '501',
            validity: '2021-08-08',
            id: '7981',
          },
        ],
      },
    ];
    this.subSections = [
      {
        subSectionId: '411',
        name: 'Subsection estratto conto',
        description: 'Sotto sezione estratto',
        version: '15',
        validity: '2021-08-01',
        id: '411',
        rows: [
          {
            rowId: '2301',
            name: 'Condizioni economiche',
            description: 'Condizioni economiche',
            type: '1',
            version: '1',
            validity: '2021-08-01',
            notes: [],
            id: '2301',
            columnNotes: [],
            columns: [],
          },
        ],
      },
    ];
    this.sections = [
      {
        sectionId: '411',
        name: 'Section estratto conto',
        description: 'Sezione estratto',
        version: '15',
        validity: '2021-08-01',
        id: '411',
      },
    ];

    this.rows1 = {
      rowId: '199',
      name: 'Condizioni economiche',
      description: 'Condizioni economiche',
      type: '2',
      version: '2',
      validity: '2021-08-01',
      id: '199',
      columns: [
        {
          name: 'Col1',
          description: 'desc1',
          style: '1',
          id: 1,
        },
        {
          name: 'Col2',
          description: 'desc2',
          style: '2',
          id: 2,
        },
      ],
      columnNotes: [
        {
          name: 'note1',
          description: '',
          columnId: 1,
          id: '122',
        },
        {
          name: 'note2',
          description: '',
          columnId: 2,
          id: '123',
        },
      ],
      notes: [
        {
          noteId: '122',
          name: 'Nota sulla riga',
          description: 'Descrizione nota sulla riga',
          version: '500',
          validity: '2021-08-08',
          id: '122',
        },
        {
          noteId: '123',
          name: 'Nota sulla riga',
          description: 'Descrizione nota sulla riga',
          version: '501',
          validity: '2021-08-08',
          id: '123',
        },
      ],
    };
    this.subSections1 = {
      subSectionId: '40',
      name: 'Subsection condizioni economiche Q4',
      description: 'Sotto sezione condizioni',
      version: '10',
      validity: '2021-08-08',
      id: '40',
      rows: [
        {
          rowId: '198',
          name: 'Condizioni economiche',
          description: 'Condizioni economiche',
          type: '1',
          version: '1',
          validity: '2021-08-08',
          id: '198',
          columns: [
            {
              name: 'Col1',
              description: 'desc1',
              style: '1',
              id: 1,
            },
            {
              name: 'Col2',
              description: 'desc2',
              style: '2',
              id: 2,
            },
          ],
          columnNotes: [
            {
              name: 'Nota sulla riga',
              description: '',
              columnId: 1,
              id: '765',
            },
            {
              name: 'Nota sulla riga',
              description: '',
              columnId: 2,
              id: '798',
            },
          ],
          notes: [
            {
              noteId: '765',
              name: 'Nota sulla riga',
              description: 'Descrizione nota sulla riga',
              version: '500',
              validity: '2021-08-08',
              id: '765',
            },
            {
              noteId: '798',
              name: 'Nota sulla riga',
              description: 'Descrizione nota sulla riga',
              version: '501',
              validity: '2021-08-08',
              id: '798',
            },
          ],
        },
        {
          rowId: '199',
          name: 'Condizioni economiche',
          description: 'Condizioni economiche',
          type: '2',
          version: '2',
          validity: '2021-08-08',
          id: '199',
          columns: [
            {
              name: 'Col1',
              description: 'desc1',
              style: '1',
              id: 1,
            },
            {
              name: 'Col2',
              description: 'desc2',
              style: '2',
              id: 2,
            },
          ],
          columnNotes: [
            {
              name: 'note1',
              description: '',
              columnId: 1,
              id: '122',
            },
            {
              name: 'note2',
              description: '',
              columnId: 2,
              id: '123',
            },
          ],
          notes: [
            {
              noteId: '122',
              name: 'Nota sulla riga',
              description: 'Descrizione nota sulla riga',
              version: '500',
              validity: '2021-08-08',
              id: '122',
            },
            {
              noteId: '123',
              name: 'Nota sulla riga',
              description: 'Descrizione nota sulla riga',
              version: '501',
              validity: '2021-08-08',
              id: '123',
            },
          ],
        },
      ],
    };
    this.section1 = {
      sectionId: '1',
      name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
      description: 'Condizioni economiche',
      version: '1',
      validity: '2021-08-08',
      id: '1',
      subSections: [
        {
          subSectionId: '40',
          name: 'Subsection condizioni economiche Q4',
          description: 'Sotto sezione condizioni',
          version: '10',
          validity: '2021-08-08',
          id: '40',
          rows: [
            {
              rowId: '198',
              name: 'Condizioni economiche',
              description: 'Condizioni economiche',
              type: '1',
              version: '1',
              validity: '2021-08-08',
              id: '198',
              columns: [
                {
                  name: 'Col1',
                  description: 'desc1',
                  style: '1',
                  id: 1,
                },
                {
                  name: 'Col2',
                  description: 'desc2',
                  style: '2',
                  id: 2,
                },
              ],
              columnNotes: [
                {
                  name: 'Nota sulla riga',
                  description: '',
                  columnId: 1,
                  id: '765',
                },
                {
                  name: 'Nota sulla riga',
                  description: '',
                  columnId: 2,
                  id: '798',
                },
              ],
              notes: [
                {
                  noteId: '765',
                  name: 'Nota sulla riga',
                  description: 'Descrizione nota sulla riga',
                  version: '500',
                  validity: '2021-08-08',
                  id: '765',
                },
                {
                  noteId: '798',
                  name: 'Nota sulla riga',
                  description: 'Descrizione nota sulla riga',
                  version: '501',
                  validity: '2021-08-08',
                  id: '798',
                },
              ],
            },
            {
              rowId: '199',
              name: 'Condizioni economiche',
              description: 'Condizioni economiche',
              type: '2',
              version: '2',
              validity: '2021-08-08',
              id: '199',
              columns: [
                {
                  name: 'Col1',
                  description: 'desc1',
                  style: '1',
                  id: 1,
                },
                {
                  name: 'Col2',
                  description: 'desc2',
                  style: '2',
                  id: 2,
                },
              ],
              columnNotes: [
                {
                  name: 'note1',
                  description: '',
                  columnId: 1,
                  id: '122',
                },
                {
                  name: 'note2',
                  description: '',
                  columnId: 2,
                  id: '123',
                },
              ],
              notes: [
                {
                  noteId: '122',
                  name: 'Nota sulla riga',
                  description: 'Descrizione nota sulla riga',
                  version: '500',
                  validity: '2021-08-08',
                  id: '122',
                },
                {
                  noteId: '123',
                  name: 'Nota sulla riga',
                  description: 'Descrizione nota sulla riga',
                  version: '501',
                  validity: '2021-08-08',
                  id: '123',
                },
              ],
            },
          ],
        },
        {
          subSectionId: '41',
          name: 'Subsection estratto conto',
          description: 'Sotto sezione estratto',
          version: '15',
          validity: '2021-08-08',
          id: '41',
          rows: [
            {
              rowId: '230',
              name: 'Condizioni economiche',
              description: 'Condizioni economiche',
              type: '1',
              version: '1',
              validity: '2021-08-08',
              notes: [],
              id: '230',
              columnNotes: [],
              columns: [],
            },
            {
              rowId: '231',
              name: 'Condizioni economiche',
              description: 'Condizioni economiche',
              type: '2',
              version: '2',
              validity: '2021-08-08',
              notes: [],
              id: '231',
              columnNotes: [],
              columns: [],
            },
          ],
        },
      ],
    };

    this.documentData = {
      itemTypeKey: 'DOCUMENT_TYPE',
      itemTypeValue: 'DOCUMENTO',
      name: 'DOCUMENTO DI SINTESI ANNUALE',
      validity: '2023-01-02',
      id: '100',
      itemsVersionsID: '100',
      itemID: '1',
      versionNumber: 4,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
          data: 'IN SVILUPPO',
          versionDetailLevel0ID: 1,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
          data: 'CCA',
          versionDetailLevel0ID: 2,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'CODICE',
          data: 'WDS',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
          data: 'DDS',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [],
    };

    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.patch = Sinon.stub();
    this.ajaxInstance.delete = Sinon.stub();
    this.ajaxInstance.post = Sinon.stub();

    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
    this.ajaxInstance.patch.resolves({ data: [] });
    this.ajaxInstance.delete.resolves({ data: [] });
    this.ajaxInstance.post.resolves({ data: [] });
  }
  // makeDocumentsAjaxCall(transformFn) {
  //   // eslint-disable-next-line no-console
  //   console.log('makeDocumentsAjaxCall,', transformFn);
  // }
}

export class DocumentListHomePageTabOpenComponentCE extends DocumentListHomePage {
  constructor() {
    super();
    this.tabCount = 3;
    this._selectedValue =
      '{code: "WDS",docId: "1",name: "DOCUMENTO DI SINTESI ANNUALE",product: "CCA",sections: [],start_date: "31/12/20",status: "IN SVILUPPO",type: "DDS",version: "1"}';
    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.patch = Sinon.stub();
    this.ajaxInstance.delete = Sinon.stub();
    this.ajaxInstance.post = Sinon.stub();

    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
    this.ajaxInstance.patch.resolves({ data: [] });
    this.ajaxInstance.delete.resolves({ data: [] });
    this.ajaxInstance.post.resolves({ data: [] });
  }

  // makeDocumentsAjaxCall(transformFn) {
  //   // eslint-disable-next-line no-console
  //   console.log('makeDocumentsAjaxCall,', transformFn);
  // }
}

export class DocumentListHomePageSelectedRowValueComponentCE extends DocumentListHomePage {
  constructor() {
    super();
    this._selectedValue =
      '{code: "WDS",docId: "1",name: "DOCUMENTO DI SINTESI ANNUALE",product: "CCA",sections: [],start_date: "31/12/20",status: "IN SVILUPPO",type: "DDS",version: "1"}';
    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.patch = Sinon.stub();
    this.ajaxInstance.delete = Sinon.stub();
    this.ajaxInstance.post = Sinon.stub();

    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
    this.ajaxInstance.patch.resolves({ data: [] });
    this.ajaxInstance.delete.resolves({ data: [] });
    this.ajaxInstance.post.resolves({ data: [] });
  }

  // makeDocumentsAjaxCall(transformFn) {
  //   // eslint-disable-next-line no-console
  //   console.log('makeDocumentsAjaxCall,', transformFn);
  // }
}
export class DocumentListReviewPageCE extends DocumentListReviewPage {
  constructor() {
    super();
    this.reviewData = {
      code: 'WDS',
      docId: '1',
      name: 'DOCUMENTO DI SINTESI ANNUALE',
      product: 'CCA',
      sections: [],
      start_date: '31/12/20',
      status: 'IN SVILUPPO',
      type: 'DDS',
      version: '1',
    };
    this.requestReview1 = [
      {
        itemTypeKey: 'DOCUMENT_TYPE',
        itemTypeValue: 'RICHIESTA REVIEW',
        itemID: '1',
        itemUser: 'nome.cognome@ing.com',
        dateAndTime: '31/01/21 09:43',
        itemsVersionsID: '1',
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'MODIFICHE EFFETTUATE',
            data: 'MODULO STANDARD PER LE INFORMAZIONI DA FORNIRE AI DEPOSITANTI',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'CARICA ALLEGATI DA ASSOCIARE',
            data: 'http://test.pdf',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'AGGIUNGI REVISORI',
            data: 'Compliance',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'AGGIUNGI REVISORI',
            data: 'Brand',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'AGGIUNGI REVISORI',
            data: 'MARIO ROSSI',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'AGGIUNGI REVISORI',
            data: 'BIANCA NERI',
          },
        ],
      },
    ];
    this.reviews = [
      {
        itemID: 863,
        itemsVersionsID: 879,
        name: 'REVISIONE DEL 06/12/2022, 22:57:00',
        validity: '2022-12-06',
        versionDetailL0: [
          {
            versionDetailLevel0ID: 2453,
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_REVISIONE',
            data: 'DOC DVS05 DA MODIFICARE PER CANONE CDC. DA CANONE CDC A CANONE CDC MASTERCARD',
          },
          {
            versionDetailLevel0ID: 2456,
            itemTypeKey: 'FIELD',
            itemTypeValue: 'REVISORE',
            data: 'ROGER',
          },
          {
            versionDetailLevel0ID: 2459,
            itemTypeKey: 'FIELD',
            itemTypeValue: 'REVIEW_ESITO',
            data: '0',
          },
          {
            versionDetailLevel0ID: 2462,
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'REVIEW_ALLEGATO',
            data: '897345-34534-675845E6562342',
            versionDetailL1: [
              {
                versionDetailLevel1ID: 2468,
                itemTypeKey: 'DETTAGLIO_ALLEGATO',
                itemTypeValue: 'FILESIZE',
                data: '15654',
              },
              {
                versionDetailLevel1ID: 2465,
                itemTypeKey: 'DETTAGLIO_ALLEGATO',
                itemTypeValue: 'FILENAME',
                data: 'ALLEGATO1.DOC',
              },
            ],
          },
        ],
        itemChildren: [],
      },
    ];

    this.documentData = {
      itemTypeKey: 'DOCUMENT_TYPE',
      itemTypeValue: 'DOCUMENTO',
      name: 'DOCUMENTO DI SINTESI ANNUALE',
      validity: '2023-01-02',
      id: '100',
      itemsVersionsID: '100',
      itemID: '1',
      versionNumber: 4,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
          data: 'IN SVILUPPO',
          versionDetailLevel0ID: 1,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
          data: 'CCA',
          versionDetailLevel0ID: 2,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'CODICE',
          data: 'WDS',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
          data: 'DDS',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [],
    };
  }

  __emailsChanged() {
    console.log('Mocked .......................');
  }

  _mockGenerateDataReceivedEvent() {
    const data = [
      { labelText: 'one', id: 1 },
      { labelText: 'two', id: 2 },
    ];
    return new CustomEvent('data-received', {
      detail: data,
    });
  }

  firstUpdated() {
    ajaxInstance.get = Sinon.stub();
    ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
  }
}
export class DocumentListReviewAttachmentsPageCE extends DocumentReviewAttachments {
  constructor() {
    super();
    this.labelText = 'Attachments';
    this.addButtonText = 'add';
    this.saveButtonText = 'save';
    this._value = 'chip3';

    this._data = [
      { labelText: 'one', id: 1 },
      { labelText: 'two', id: 2 },
    ];
    this._deleteChipEventFired = () => {
      const id = 1;
      this.dispatchEvent(new CustomEvent('chip-deleted', { detail: { id } }));
    };
    this._filesAddedEventFired = fileUpload => {
      fileUpload.dispatchEvent(
        new CustomEvent('files-added', {
          detail: [
            { name: 'three', id: 3 },
            { name: 'four', id: 4 },
          ],
        }),
      );
    };
  }
}
export class RemovableChipPageCE extends RemovableChip {
  constructor() {
    super();
    this.labelText = 'chip1';
    this.id = 1;
  }
}
export class DocumentListReviewInfoCE extends DocumentListReviewInfo {
  constructor() {
    super();
    this.reviewData = {
      code: 'WDS',
      docId: '1',
      id: '1',
      name: 'DOCUMENTO DI SINTESI ANNUALE',
      product: 'CCA',
      sections: [],
      start_date: '31/12/20',
      status: 'IN SVILUPPO',
      type: 'DDS',
      version: '1',
    };
    this.versionList = versionList;
  }
}
export class FileUploadCE extends FileUpload {
  constructor() {
    super();
    this._fireMockEvent = (element, event, options = {}) => {
      element.dispatchEvent(new CustomEvent(event), options);
    };
    this._mockFiles = [
      { name: 'three', id: 3 },
      { name: 'four', id: 4 },
    ];
  }

  _onDrop(event) {
    event.preventDefault();
    this.dragOverClass = '';
    this._onUpload(this._mockFiles);
  }

  _change() {
    this._onUpload(this._mockFiles);
  }
}
export class IngTableCE extends IngTable {
  constructor() {
    super();
    this._fireMockEvent = (element, event, options = {}) => {
      element.dispatchEvent(new CustomEvent(event), options);
    };
    this.tableData = [
      {
        code: 'WDS',
        docId: '1',
        name: 'DOCUMENTO DI SINTESI ANNUALE',
        product: 'CCA',
        sections: [],
        start_date: '31/12/20',
        status: 'IN SVILUPPO',
        type: 'DDS',
        version: '1',
      },
      {
        code: 'HDC',
        docId: '3',
        name: 'DOCUMENTO DI SINTESI ANNUALE',
        product: 'CCAF',
        sections: [],
        start_date: '31/12/30',
        status: 'IN SVILUPPO',
        type: 'DDS',
        version: '3',
      },
    ];
    this.propertyId = 'docId';
    this.contentProperties = [
      {
        propertyName: 'product',
        propertyClass: 'left_text_align',
        contentHtml: {
          tag: 'div',
          isSelfClosingTag: false,
          innerText: 'Hello1', // false
          attributes: {
            class: 'review-cls',
            disabled: 'code',
          },
          contentHtml: {
            tag: 'span',
            isSelfClosingTag: false,
            innerText: 'Hello', // false
            attributes: {
              class: 'review-cls-span',
              name: 'reviewSpan',
            },
          },
          classCondition: [
            {
              operator: '===',
              text: 'CCA1',
              className: 'review-cls-green',
            },
            {
              operator: '!==',
              text: 'CCAF',
              className: 'review-cls-orange',
            },
          ],
        },
        contentHtmlEvents: ['click', 'keyup'],
      },
      {
        propertyName: 'code',
        propertyClass: 'left_text_align',
        contentHtml: [
          {
            tag: 'div',
            isSelfClosingTag: false,
            innerText: 'Hello', // false
            attributes: {},
            classCondition: [
              {
                operator: '===',
                text: 'NDS',
                className: 'review-cls-green',
              },
              {
                operator: '!==',
                text: 'VDS',
                className: 'review-cls-orange',
              },
            ],
          },
        ],
      },
      {
        propertyName: 'type',
        propertyClass: 'left_text_align',
        contentHtml: [
          {
            tag: 'div',
            isSelfClosingTag: false,
            innerText: 'Hello', // false
            attributes: {
              class: 'review-cls-2',
            },
            contentHtml: {
              tag: 'div',
              isSelfClosingTag: false,
              innerText: 'Hello', // false
              attributes: {
                class: 'review-cls-nested',
                disabled: 'code',
              },
              contentHtml: [
                {
                  tag: 'span',
                  attributes: {
                    class: 'review-cls-span-new',
                  },
                },
                {
                  tag: 'span',
                  attributes: {
                    class: 'review-cls-span-new-2',
                  },
                },
              ],
            },
          },
          {
            tag: 'span',
            isSelfClosingTag: false,
            innerText: 'Hello', // false
            attributes: {
              name: 'reviewSpan',
            },
            classCondition: [
              {
                operator: '===',
                text: 'DDS',
                className: 'review-cls-green',
              },
              {
                operator: '!==',
                text: 'DDS',
                className: 'review-cls-orange',
              },
            ],
          },
        ],
      },
    ];
    this.headerData = headerData;
  }
}
export class NewDocumentCreationCE extends NewDocumentCreation {
  constructor() {
    super();
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
    this._addedData = {
      id: 4,
      name: 'efg',
      description: 'efg',
      validity: new Date(),
    };
    this.notesData = [
      {
        id: 1,
        name: 'abc',
        description: 'abc',
        validity: new Date(),
      },
      {
        id: 2,
        name: 'xyz',
        description: 'xyz',
        validity: new Date(),
      },
    ];
    this.noteBackendStructure = {
      itemID: '765',
      itemsVersionsID: '98',
      name: 'Nota sulla riga',
      id: '765',
      validity: '2023-01-02',
      versionNumber: 1,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Descrizione nota sulla riga version changed',
          versionDetailLevel0ID: 1,
        },
      ],
    };
  }
}
export class CreateNewNoteCE extends CreateNewNote {
  constructor() {
    super();
    this.id = generateId();
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}
export class StepperCE extends Stepper {}

export class RowElementsCE extends RowElements {
  constructor() {
    super();
    this.id = generateId();
    this.selectLabel = true;
    this.select2Data = notes;
    this.checkedData = [];
    this.selectData = rowData[0].columns;
    this.radioData = radioData;
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}
export class RowDefinationCE extends RowDefination {
  constructor() {
    super();
    this.id = generateId();
    this.select2Data = notes;
    this.checkedData = [];
    this.selectData = rowData[0].columns;
    // this.elementsData = rowData[0].columns;
    this.radioData = radioData;
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}

export class CreateRowCE extends CreateRow {
  constructor() {
    super();
    this.id = generateId();
    this.rowStyles = rowStyles;

    this.notes = notes;
    this.radioData = radioData;
    // this.elementsData = rowData[0].columns;
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}
export class RowCreationCE extends RowCreation {
  constructor() {
    super();
    this.rowData = rowData;
    this.rowData1 = rowData1;

    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };

    this.rowBackend = {
      itemID: '198',
      itemsVersionsID: '98',
      name: 'Condizioni economiche',
      id: '1981',
      validity: '2023-01-02',
      versionNumber: 2,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: '32',
          versionDetailLevel0ID: '321',
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'DETTAGLIO_RIGA',
          data: '1',
          versionDetailLevel0ID: '1',
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: 'desc1',
              versionDetailLevel1ID: '2',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: 'true',
              versionDetailLevel1ID: '3',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: 'false',
              versionDetailLevel1ID: '4',
            },
            {
              itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
              itemTypeValue: 'DETTAGLIO_NOTA',
              data: 1,
              versionDetailLevel1ID: '5',
              versionDetailL2: [
                {
                  itemTypeKey: 'FIELD',
                  itemTypeValue: 'ID_NOTA',
                  data: '765',
                  versionDetailLevel2ID: '765',
                },
              ],
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'DETTAGLIO_RIGA',
          data: '2',
          versionDetailLevel0ID: '6',
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: 'desc2',
              versionDetailLevel1ID: '7',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: false,
              versionDetailLevel1ID: '8',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: true,
              versionDetailLevel1ID: '9',
            },
            {
              itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
              itemTypeValue: 'DETTAGLIO_NOTA',
              data: 2,
              versionDetailLevel1ID: '10',
              versionDetailL2: [
                {
                  itemTypeKey: 'FIELD',
                  itemTypeValue: 'ID_NOTA',
                  data: '798',
                  versionDetailLevel2ID: '798',
                },
              ],
            },
          ],
        },
      ],
    };
  }
}
export class CreateSubSectionCE extends CreateSubSection {
  constructor() {
    super();
    this.subSectionsData = [
      {
        id: 1,
        name: 'test1',
        description: 'test',
        validity: new Date(),
        sectionStyle: '',
      },
      {
        id: 2,
        name: 'test2',
        description: 'test',
        validity: new Date(),
        sectionStyle: '',
      },
    ];
    this.detail = {
      data: {
        id: 1,
        name: 'test',
        description: 'test',
        validity: new Date(),
        sectionStyle: '',
      },
    };
    this.sectionBackend = {
      itemID: '1',
      itemsVersionsID: '98',
      name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
      validity: '2024-01-01',
      versionNumber: 1,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Condizioni economiche version changed',
          versionDetailLevel0ID: 2,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: '32',
          versionDetailLevel0ID: 32,
        },
      ],
      itemChildren: [
        {
          itemID: '40',
          itemOrder: 1,
          itemsVersionsID: '40',
          name: 'Subsection condizioni economiche Q4',
          description: 'Subsection condizioni economiche Q4d',
          validity: '2024-01-01',
        },
        {
          itemID: '41',
          itemOrder: 2,
          itemsVersionsID: '41',
          name: 'Subsection estratto conto',
          description: 'Subsection estratto contod',
          validity: '2024-01-01',
        },
      ],
    };
  }
}
export class SubSectionCE extends SubSection {
  constructor() {
    super();
    this._id = generateId();
  }
}

export class ComponentAssociationCE extends ComponentAssociation {
  constructor() {
    super();
    this._arrList1 = [
      {
        id: '1',
        name: 'SubSection1',
        rows: [],
      },
    ];
    this._arrList2 = [
      {
        id: '1',
        name: 'Rows1',
      },
      {
        id: '2',
        name: 'Rows2',
      },
    ];

    this.str1 = '1';
    this.str2 = '2';
  }
}
export class RuleElementsCE extends RuleElements {
  constructor() {
    super();
    this.id = generateId();
    this.selectFieldsData = {
      version1: {
        selectData: {},
        select2Data: {},
      },
      version2: {
        selectData: {},
        select2Data: {},
        select3Data: {},
      },
    };
    this.selectLabel = true;
    this.selectData = appliesToElements;
    this.select2Data = appliesToRules;
    this.select3Data = appliesToColumns;
    this.elementsData = appliesToColumns;
    this.checkedData = [];
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
    // this.makeAjaxCall = () => {
    //   console.log('AJAX call Test');
    //   return { list: [] };
    // };
    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
  }
}
export class RuleDefinationCE extends RuleDefination {
  constructor() {
    super();
    this.id = generateId();
    this.selectFieldsData = {
      version1: {
        selectData: {},
        select2Data: {},
      },
      version2: {
        selectData: {},
        select2Data: {},
        select3Data: {},
      },
    };
    this.selectData = appliesToElements;
    this.select2Data = appliesToRules;
    this.select3Data = appliesToColumns;
    this.checkedData = [];
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}
export class CreateNewRuleCE extends CreateRule {
  constructor() {
    super();
    this.id = generateId();
    this.selectFieldsData = {
      version1: {
        selectData: {},
        select2Data: {},
      },
      version2: {
        selectData: {},
        select2Data: {},
        select3Data: {},
      },
    };
    this.selectData = appliesToElements;
    this.select2Data = appliesToRules;
    this.select3Data = appliesToColumns;
    this.checkedData = [];
    this.elementsDataMock = appliesToColumns;
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
  }
}
export class RuleCreationCE extends RuleCreation {
  constructor() {
    super();
    this.id = generateId();
    this.selectFieldsData = {
      version1: {
        selectData: {},
        select2Data: {},
      },
      version2: {
        selectData: {},
        select2Data: {},
        select3Data: {},
      },
    };
    this.selectData = appliesToElements;
    this.select2Data = appliesToRules;
    this.select3Data = appliesToColumns;
    this.checkedData = [];
    this.elementsDataMock = appliesToColumns;
    this.ruleData1 = rulesData1;
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
    this.ruleBackend = {
      itemID: '1',
      itemsVersionsID: '98',
      name: 'Rule 1',
      id: '1',
      validity: '2023-01-02',
      versionNumber: 8,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_ITEM',
          data: 'Rule 1 Desc',
          versionDetailLevel0ID: 1,
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_CONDIZIONE',
          data: 1,
          versionDetailLevel0ID: 2,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
              data: 'Col1',
              versionDetailLevel1ID: 40,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'RULE_CONDITION_OPERATOR',
              data: '43',
              versionDetailLevel1ID: 43,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VALORE',
              data: 'desc1',
              versionDetailLevel1ID: 3,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ASSOCIATO_A_RIGA',
              data: '2',
              versionDetailLevel1ID: 46,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_CONDIZIONE',
          data: 2,
          versionDetailLevel0ID: 4,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
              data: 'Col2',
              versionDetailLevel1ID: 39,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'RULE_CONDITION_OPERATOR',
              data: '42',
              versionDetailLevel1ID: 42,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VALORE',
              data: 'desc1',
              versionDetailLevel1ID: 5,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ASSOCIATO_A_RIGA',
              data: '1',
              versionDetailLevel1ID: 45,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_AZIONE',
          data: 199,
          versionDetailLevel0ID: 6,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'COLONNA_ID',
              data: '6',
              versionDetailLevel1ID: 7,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: '123',
              versionDetailLevel1ID: 8,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'SI_APPLICA_A',
              data: '33',
              versionDetailLevel1ID: 33,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VISIBLE',
              data: false,
              versionDetailLevel1ID: 9,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: true,
              versionDetailLevel1ID: 10,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: false,
              versionDetailLevel1ID: 11,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_AZIONE',
          data: 98,
          versionDetailLevel0ID: 6,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'SI_APPLICA_A',
              data: 34,
              versionDetailLevel1ID: 34,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: '',
              versionDetailLevel1ID: 12,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VISIBLE',
              data: true,
              versionDetailLevel1ID: 13,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: false,
              versionDetailLevel1ID: 14,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: true,
              versionDetailLevel1ID: 15,
            },
          ],
        },
      ],
    };
  }
}
export class CreateDocumentCE extends CreateDocument {}

export class DocumentCreatedSuccessfullyCE extends DocumentCreatedSuccessfully {
  constructor() {
    super();
    this.documentData = {
      name: 'test',
      status: 'IN SVILUPPO',
      docId: '1',
      product: 'product1',
      code: 'code1',
      type: 'type1',
      start_date: '02/02/2021',
      data: [
        {
          id: '1',
          name: 'test',
        },
      ],
      version: '01',
      templateFile: 'test.xlsx',
    };
  }
}

export class DocumentPreviewCE extends DocumentPreview {
  constructor() {
    super();
    this.contentData = contentData;
  }
}

export class ConfirmationDialogCE extends ConfirmationDialog {
  constructor() {
    super();
    this.confirmationMessageDetail = {
      messages: [
        'Sei sicuro di voler creare una nuova versione del sezioni?',
        `Troverai tutte le versioni del documento nell'elenco delle sezioni dei documenti`,
      ],
      type: 'newVersion',
    };
  }
}
export class DocumentModificationCE extends DocumentModification {
  constructor() {
    super();

    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };
    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.put = Sinon.stub();
    this.ajaxInstance.delete = Sinon.stub();
    this.ajaxInstance.post = Sinon.stub();
    this.ajaxInstance.patch = Sinon.stub();

    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
    this.ajaxInstance.put.resolves({ data: [] });
    this.ajaxInstance.delete.resolves({ data: [] });
    this.ajaxInstance.post.resolves({ data: [] });
    this.ajaxInstance.patch.resolves({ data: [] });
  }

  firstUpdated() {
    this.selectedValue = JSON.parse(JSON.stringify(this.documentData));
    console.log('setting Test data >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>');
  }
}
export class DocumentDetailsPageCE extends DocumentDetailsPage {
  constructor() {
    super();
    this._fireMockEvent = (element, event, detail = {}, options = {}) => {
      element.dispatchEvent(new CustomEvent(event, { detail }), options);
    };

    this.versionList = [
      {
        itemsVersionsID: 101,
        versionID: 101,
        versionNumber: 15,
        validity: '01-04-21',
        status: 'APPROVATO',
      },
      {
        itemsVersionsID: 98,
        versionID: 98,
        versionNumber: 16,
      },
      {
        itemsVersionsID: 40,
        versionID: 40,
        versionNumber: 4,
      },
    ];

    this.documentData = {
      itemTypeKey: 'DOCUMENT_TYPE',
      itemTypeValue: 'DOCUMENTO',
      name: 'DOCUMENTO DI SINTESI ANNUALE',
      validity: '2023-01-02',
      id: '100',
      itemsVersionsID: '100',
      itemID: '1',
      versionNumber: 4,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
          data: 'IN SVILUPPO',
          versionDetailLevel0ID: 1,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
          data: 'CCA',
          versionDetailLevel0ID: 2,
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'CODICE',
          data: 'WDS',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
          data: 'DDS',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [],
    };

    this.section = {
      itemID: '1',
      itemsVersionsID: '98',
      name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
      validity: '2024-01-01',
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Condizioni economiche version changed',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: 'style 2',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [
        {
          itemID: '40',
          itemOrder: 1,
          itemsVersionsID: '40',
          name: 'Subsection condizioni economiche Q4',
        },
        {
          itemID: '41',
          itemOrder: 2,
          itemsVersionsID: '41',
          name: 'Subsection estratto conto',
        },
      ],
    };
  }

  firstUpdated() {
    this.ajaxInstance.get = Sinon.stub();
    this.ajaxInstance.get.resolves({
      data: {
        itemsVersionsList: [],
        itemsVersionsParentDocumentsList: [],
        itemsList: [],
        lookupList: [],
        lookupRulesList: [],
      },
    });
  }
}
export class ElementFromScratchCE extends ElementFromScratch {
  constructor() {
    super();
    this.tableContentData = [
      {
        id: 1,
        name: 'test',
        description: 'test',
      },
      {
        id: 2,
        name: 'tjest2',
        description: 'tkest2',
      },
    ];
    this.sectionName = 'Sezioni';
    this.sectionList = [
      {
        itemID: '1',
        itemsVersionsID: '1',
        name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
        validity: '2021-08-08',
        versionNumber: 15,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Condizioni economiche',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
            data: '1',
          },
        ],
        itemChildren: [
          {
            itemID: '40',
            itemOrder: 1,
            itemsVersionsID: '40',
            name: 'Subsection condizioni economiche Q4',
          },
          {
            itemID: '41',
            itemOrder: 2,
            itemsVersionsID: '41',
            name: 'Subsection estratto conto',
          },
        ],
      },
    ];
    this.subSectionList = [
      {
        itemID: '40',
        itemsVersionsID: '40',
        name: 'Subsection condizioni economiche Q4',
        validity: '2021-08-08',
        versionNumber: 4,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Sotto sezione condizioni',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
          },
        ],
        itemChildren: [
          {
            itemID: '198',
            itemOrder: 1,
            itemsVersionsID: '198',
            name: 'Condizioni economiche1',
          },
          {
            itemID: '199',
            itemOrder: 2,
            itemsVersionsID: '199',
            name: 'Condizioni economiche2',
          },
        ],
      },
    ];

    this.rowList = [
      {
        itemID: '198',
        itemsVersionsID: '198',
        name: 'Condizioni economiche',
        id: '198',
        validity: '2021-08-08',
        versionNumber: 1,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'DETTAGLIO_RIGA',
            data: 'Col1',
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: 'desc1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: true,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: false,
              },
              {
                itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
                itemTypeValue: 'DETTAGLIO_NOTA',
                data: 1,
                versionDetailL2: [
                  {
                    itemTypeKey: 'FIELD',
                    itemTypeValue: 'ID_NOTA',
                    data: 'Nota sulla riga',
                    VersionDetailLevel2ID: '765',
                  },
                ],
              },
            ],
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'DETTAGLIO_RIGA',
            data: 'Col2',
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: 'desc2',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: false,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: true,
              },
              {
                itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
                itemTypeValue: 'DETTAGLIO_NOTA',
                data: 2,
                versionDetailL2: [
                  {
                    itemTypeKey: 'FIELD',
                    itemTypeValue: 'ID_NOTA',
                    data: 'Nota sulla riga',
                    VersionDetailLevel2ID: '798',
                  },
                ],
              },
            ],
          },
        ],
      },
    ];

    this.noteList = [
      {
        itemID: '765',
        itemsVersionsID: '765',
        name: 'Nota sulla riga',
        id: '765',
        validity: '2021-08-08',
        versionNumber: 2,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Descrizione nota sulla riga',
          },
        ],
      },
    ];

    this.ruleList = [
      {
        itemID: '1',
        itemsVersionsID: '1',
        name: 'Rule 1',
        id: '1',
        validity: '2021-08-08',
        versionNumber: 8,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_ITEM',
            data: 'Rule 1 Desc',
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'REGOLA_CONDIZIONE',
            data: 1,
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
                data: 'Col1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'RULE_CONDITION_OPERATOR',
                data: '1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'VALORE',
                data: 'desc1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ASSOCIATO_A_RIGA',
                data: '2',
              },
            ],
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'REGOLA_CONDIZIONE',
            data: 2,
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
                data: 'Col2',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'RULE_CONDITION_OPERATOR',
                data: '2',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'VALORE',
                data: 'desc1',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ASSOCIATO_A_RIGA',
                data: '1',
              },
            ],
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'REGOLA_AZIONE',
            data: 3,
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'COLONNA_ID',
                data: 3,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: '123',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'VISIBLE',
                data: false,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: true,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: false,
              },
            ],
          },
          {
            itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
            itemTypeValue: 'REGOLA_AZIONE',
            data: 2,
            versionDetailL1: [
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'COLONNA_ID',
                data: 4,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
                data: '1456',
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'VISIBLE',
                data: true,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'BOLD',
                data: false,
              },
              {
                itemTypeKey: 'FIELD',
                itemTypeValue: 'ITALIC',
                data: true,
              },
            ],
          },
        ],
      },
    ];

    this.versionList = [
      {
        itemsVersionsID: 101,
        versionID: 101,
        versionNumber: 15,
      },
      {
        itemsVersionsID: 98,
        versionID: 98,
        versionNumber: 16,
      },
      {
        itemsVersionsID: 40,
        versionID: 40,
        versionNumber: 4,
      },
    ];

    this.documentList = [
      {
        itemTypeKey: 'DOCUMENT_TYPE',
        itemTypeValue: 'DOCUMENTO',
        name: 'DOCUMENTO DI SINTESI ANNUALE',
        validity: '2021-08-08',
        id: '1',
        itemsVersionsID: '1',
        itemID: '1',
        versionNumber: 2,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
            data: 'IN SVILUPPO',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
            data: 'CCA',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'CODICE',
            data: 'WDS',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
            data: 'DDS',
          },
        ],
        itemChildren: [],
      },
    ];
  }
}

export class CollapsibleDocumentCommonDetailsCE extends CollapsibleDocumentCommonDetails {
  constructor() {
    super();
    this.tableContentData = [
      {
        id: 1,
        name: 'test',
        description: 'test',
      },
      {
        id: 2,
        name: 'tjest2',
        description: 'tkest2',
      },
    ];
    this.sectionName = 'Review Inserite';
  }
}

export class CollapsibleDocumentDetailsCE extends CollapsibleDocumentDetails {
  constructor() {
    super();
    this.tableContentData = [
      {
        id: 1,
        name: 'test',
        description: 'test',
      },
      {
        id: 2,
        name: 'tjest2',
        description: 'tkest2',
      },
    ];
    this.sectionName = 'Review Inserite';
  }
}

export class CollapsibleDocumentRowsDetailsCE extends CollapsibleDocumentRowsDetails {
  constructor() {
    super();
    this.tableContentData = [
      {
        id: 1,
        name: 'test',
        description: 'test',
      },
      {
        id: 2,
        name: 'tjest2',
        description: 'tkest2',
      },
    ];
    this.sectionName = 'Review Inserite';
  }
}

export class DocumentCommonDetailsTableCE extends DocumentCommonDetailsTable {
  constructor() {
    super();
    this.headerData = sectionsHeader;
    this.tableData = [
      transformSectionsToFrontEnd({
        itemID: '1',
        itemsVersionsID: '1',
        name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
        validity: '2021-08-08',
        versionNumber: 15,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Condizioni economiche',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
            data: '1',
          },
        ],
        itemChildren: [
          {
            itemID: '40',
            itemOrder: 1,
            itemsVersionsID: '40',
            name: 'Subsection condizioni economiche Q4',
          },
          {
            itemID: '41',
            itemOrder: 2,
            itemsVersionsID: '41',
            name: 'Subsection estratto conto',
          },
        ],
      }),
    ];
  }
}

export class DocumentRowsDetailsTableCE extends DocumentRowsDetailsTable {
  constructor() {
    super();
    this.headerData = sectionsHeader;
    this.tableData = [
      transformSectionsToFrontEnd({
        itemID: '1',
        itemsVersionsID: '1',
        name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
        validity: '2021-08-08',
        versionNumber: 15,
        versionDetailL0: [
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
            data: 'Condizioni economiche',
          },
          {
            itemTypeKey: 'FIELD',
            itemTypeValue: 'STILE',
            data: '1',
          },
        ],
        itemChildren: [
          {
            itemID: '40',
            itemOrder: 1,
            itemsVersionsID: '40',
            name: 'Subsection condizioni economiche Q4',
          },
          {
            itemID: '41',
            itemOrder: 2,
            itemsVersionsID: '41',
            name: 'Subsection estratto conto',
          },
        ],
      }),
    ];
  }
}

export class ApplicationAccessPageCE extends ApplicationAccessPage {}
export class DialogModifySectionCE extends DialogModifySection {
  constructor() {
    super();
    this.versionList = [];
    this.ajaxInstance.get = Sinon.stub();
    this.versionList1 = [
      {
        itemsVersionsID: 101,
        versionID: 101,
        versionNumber: 15,
      },
      {
        itemsVersionsID: 98,
        versionID: 98,
        versionNumber: 16,
      },
      {
        itemsVersionsID: 40,
        versionID: 40,
        versionNumber: 4,
      },
    ];

    this.section = {
      itemID: '1',
      itemsVersionsID: '98',
      name: 'CONDIZIONI ECONOMICHE DDS CCA Q4',
      validity: '2024-01-01',
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Condizioni economiche version changed',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: 'style 2',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [
        {
          itemID: '40',
          itemOrder: 1,
          itemsVersionsID: '40',
          name: 'Subsection condizioni economiche Q4',
        },
        {
          itemID: '41',
          itemOrder: 2,
          itemsVersionsID: '41',
          name: 'Subsection estratto conto',
        },
      ],
    };

    this.subSection = {
      itemID: '40',
      itemsVersionsID: '98',
      name: 'Subsection condizioni economiche Q4',
      versionNumber: 16,
      validity: '2023-01-02',
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Sotto sezione condizioni version changed',
        },
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: 'style 2',
          versionDetailLevel0ID: 2,
        },
      ],
      itemChildren: [
        {
          itemID: '198',
          itemOrder: 1,
          itemsVersionsID: '198',
          name: 'Condizioni economiche1',
        },
        {
          itemID: '199',
          itemOrder: 2,
          itemsVersionsID: '199',
          name: 'Condizioni economiche2',
        },
      ],
    };
    this.rule = {
      itemID: '1',
      itemsVersionsID: '1',
      name: 'Rule 1',
      id: '1',
      validity: '2023-01-02',
      versionNumber: 8,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_ITEM',
          data: 'Rule 1 Desc',
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_CONDIZIONE',
          data: 1,
          versionDetailLevel0ID: 1,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
              data: 'Col1',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'RULE_CONDITION_OPERATOR',
              data: '1',
              versionDetailLevel1ID: 1,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VALORE',
              data: 'desc1',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ASSOCIATO_A_RIGA',
              data: '2',
              versionDetailLevel1ID: 1,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_CONDIZIONE',
          data: 2,
          versionDetailLevel0ID: 1,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'NUMERO_CAMPO_FILE_INDICE',
              data: 'Col2',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'RULE_CONDITION_OPERATOR',
              data: '2',
              versionDetailLevel1ID: 1,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VALORE',
              data: 'desc1',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ASSOCIATO_A_RIGA',
              data: '1',
              versionDetailLevel1ID: 1,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_AZIONE',
          data: 3,
          versionDetailLevel0ID: 1,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'COLONNA_ID',
              data: 3,
              versionDetailLevel1ID: 1,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: '123',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VISIBLE',
              data: false,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: true,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: false,
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'REGOLA_AZIONE',
          data: 2,
          versionDetailLevel0ID: 1,
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'COLONNA_ID',
              data: 4,
              versionDetailLevel1ID: 1,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: '1456',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'VISIBLE',
              data: true,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: false,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: true,
            },
          ],
        },
      ],
    };
    this.note = {
      itemID: '765',
      itemsVersionsID: '98',
      name: 'Nota sulla riga',
      id: '765',
      validity: '2023-01-02',
      versionNumber: 1,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
          data: 'Descrizione nota sulla riga version changed',
          versionDetailLevel0ID: 1,
        },
      ],
    };
    this.row = {
      itemID: '198',
      itemsVersionsID: '198',
      name: 'Condizioni economiche',
      id: '198',
      validity: '2023-01-02',
      versionNumber: 2,
      versionDetailL0: [
        {
          itemTypeKey: 'FIELD',
          itemTypeValue: 'STILE',
          data: 'style 1',
          versionDetailLevel0ID: 1,
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'DETTAGLIO_RIGA',
          data: 'Col1',
          versionDetailLevel1ID: '1',
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: 'desc1',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: true,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: false,
            },
            {
              itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
              itemTypeValue: 'DETTAGLIO_NOTA',
              data: 1,
              versionDetailL2: [
                {
                  itemTypeKey: 'FIELD',
                  itemTypeValue: 'ID_NOTA',
                  data: 'Nota sulla riga',
                  versionDetailLevel2ID: '765',
                },
              ],
            },
          ],
        },
        {
          itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
          itemTypeValue: 'DETTAGLIO_RIGA',
          data: 'Col2',
          versionDetailLevel1ID: '1',
          versionDetailL1: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'DESCRIZIONE_IN_STAMPA',
              data: 'desc2',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'BOLD',
              data: false,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'ITALIC',
              data: true,
            },
            {
              itemTypeKey: 'VERSION_DETAIL_LEVEL_2',
              itemTypeValue: 'DETTAGLIO_NOTA',
              data: 2,
              versionDetailL2: [
                {
                  itemTypeKey: 'FIELD',
                  itemTypeValue: 'ID_NOTA',
                  data: 'Nota sulla riga',
                  versionDetailLevel2ID: '798',
                },
              ],
            },
          ],
        },
      ],
    };
  }
}

export class CustomSelectCE extends CustomSelect {
  constructor() {
    super();
    this.displayData = [
      {
        id: 1,
        name: 'test',
      },
      {
        id: 2,
        name: 'test2',
      },
    ];
    this.propKey = 'name';
    this.columnId = '1';
  }
}
