import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
} from '@open-wc/testing';
import { CollapsibleDocumentDetailsCE } from './test-class.js';

describe('CollapsibleDocumentDetails Tests', () => {
  const tag = unsafeStatic(defineCE(CollapsibleDocumentDetailsCE));
  describe('Structure', () => {
    let element;
    const isCheckDisabled = async tagItem => {
      const el = await element?.shadowRoot?.querySelector(tagItem);
      await expect(el.disabled).to.equal(true);
    };

    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It should bind section name', async () => {
      const el = await element?.shadowRoot?.querySelector('span');
      expect(el.textContent).to.equal(element.sectionName);
    });

    it('It should disabled upArrow btn', async () => {
      element.isEnableUpArrow = true;
      await elementUpdated();
      const el = await element?.shadowRoot?.querySelector('.pointer-events');
      await expect(el).to.exist;
    });

    it('It should disabled downArrow btn', async () => {
      element.isEnableDownArrow = true;
      await elementUpdated();
      const el = await element?.shadowRoot?.querySelector('.pointer-events');
      await expect(el).to.exist;
    });

    it('It should disabled Add btn', async () => {
      element.isEnableAddElement = true;
      await elementUpdated();
      await isCheckDisabled('.add_button');
    });

    it('It should disabled remove btn', async () => {
      element.isEnableRemoveElement = true;
      await elementUpdated();
      await isCheckDisabled('.remove_button');
    });

    it('It should disabled new version btn', async () => {
      element.isEnableNewVersion = true;
      await elementUpdated();
      await isCheckDisabled('.new_version_button');
    });

    it('It should disabled duplicate version btn', async () => {
      element.isEnableDuplicateVersion = true;
      await elementUpdated();
      await isCheckDisabled('.new_duplication_button');
    });

    it('It should disabled modify btn', async () => {
      element.isEnableViewDetails = true;
      await elementUpdated();
      await isCheckDisabled('.modify_button');
    });
  });
});
