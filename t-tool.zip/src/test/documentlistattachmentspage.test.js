import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import { DocumentListReviewAttachmentsPageCE } from './test-class.js';

describe('DocumentListReviewAttachmentsPage Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentListReviewAttachmentsPageCE));
  describe('Structure', () => {
    let element;
    const isCheckDisabled = async tagItem => {
      const el = await element?.shadowRoot?.querySelector(tagItem);
      await expect(el.disabled).to.equal(true);
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It has same Label', async () => {
      const addBtn = await element?.shadowRoot?.querySelector('[add-button]');
      console.log(addBtn);
      expect(addBtn.textContent).to.equal('add');
    });
    // ing-input-test
    it('It binds correct value to value property', async () => {
      const input = await element?.shadowRoot?.querySelector('[ing-input-test]');
      const value = 'testvalue@domain.com';
      input.value = value;
      await input.dispatchEvent(new Event('keyup'));
      aTimeout(200);
      expect(element._value).to.equal(value);
    });
    it('It has exact number of chips rendered', async () => {
      const chips = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      console.log(chips);
      expect(chips.length).to.equal(2);
    });
    it('It adds a new chip on add button click', async () => {
      const btn = await element?.shadowRoot?.querySelector('[add-button]');
      console.log(btn);
      await btn.click();
      aTimeout(200);
      const chips = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      expect(chips.length).to.equal(3);
    });
    it('It removes a chip when when chip-deleted event is fired', async () => {
      setTimeout(() => element._deleteChipEventFired());
      const event = await oneEvent(element, 'chip-deleted');
      await element._onChipDeleted(event);
      aTimeout(200);
      const chips = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      expect(chips.length).to.equal(2);
    });
    it('It sends correct data when data-received event is fired', async () => {
      const btn = await element?.shadowRoot?.querySelector('.save-button [indigo]');
      console.log(btn);
      setTimeout(() => btn.click());

      aTimeout(200);
      const event = await oneEvent(element, 'data-received');

      aTimeout(200);
      expect(event.detail).to.equal(element._data);
    });
    it('It displays file-upload component when type is file', async () => {
      element = await fixture(html`<${tag} type="file"></${tag}>`);

      const fileUpload = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('file-upload'),
      );
      expect(fileUpload).to.exist;
    });
    it('It does not display file-upload component when type is other than file', async () => {
      element = await fixture(html`<${tag} type="email"></${tag}>`);

      const fileUpload = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('file-upload'),
      );
      expect(fileUpload).to.not.exist;
      const input = await element?.shadowRoot?.querySelector('[ing-input-test]');
      expect(input.type).to.equal('email');
    });
    it('It receives correct data when files-added event is fired', async () => {
      element = await fixture(html`<${tag} type="file"></${tag}>`);
      const fileUpload = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('file-upload'),
      );
      setTimeout(() => element._filesAddedEventFired(fileUpload));
      aTimeout(200);
      await oneEvent(fileUpload, 'files-added');
      aTimeout(200);
      expect(element._data.length).to.equal(4);

      const chips = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      expect(chips.length).to.equal(4);
    });

    it('It should disabled attachment fields', async () => {
      element.disableRequestReviewFields = true;
      await elementUpdated(element);
      await isCheckDisabled('[ing-input-test]');
      await isCheckDisabled('.save-button [data-tag-name="ing-button"]');
    });
  });
});
