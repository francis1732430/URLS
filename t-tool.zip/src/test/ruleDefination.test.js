import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  elementUpdated,
} from '@open-wc/testing';
import Sinon from 'sinon';
import { ajaxInstance } from '../utils/endpoints.js';

import { RuleDefinationCE } from './test-class.js';

describe('RowElements Tests', () => {
  const tag = unsafeStatic(defineCE(RuleDefinationCE));

  describe('Structure', () => {
    let element;

    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('Remove button stays disabled by default', async () => {
      const btn = await element?.shadowRoot?.querySelector('#remove');
      // debugger;
      expect(btn).to.have.attribute('disabled');
    });
    it('Remove button gets Enabled after checkedData is populated', async () => {
      element.checkedData = [1, 2];
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('#remove');
      // debugger;
      expect(btn).to.not.have.attribute('disabled');
    });
    it('Remove button removes checked Elements', async () => {
      element.checkedData = [element.elementsData?.[0]?.id];
      const btn = await element?.shadowRoot?.querySelector('#remove');
      btn.click();
      await elementUpdated(element);
      aTimeout(200);
      // debugger;
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('rule-elements'),
      );
      expect(elements.length).to.equal(0);
    });
    it('Add button adds new elements', async () => {
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await elementUpdated(element);
      await aTimeout(200);
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('rule-elements'),
      );
      expect(elements.length).to.equal(2);
    });

    it('Add button stays enabled if both rows and Notes are present', async () => {
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      expect(btn).to.not.have.attribute('disabled');
    });

    it('Condition should be removed from Rule', async () => {
      const stubFn = Sinon.stub(element, 'deleteLevels');
      element.selectLabel = '';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      element.checkedData = ['95728-41811-17742'];
      ajaxInstance.delete = Sinon.stub();
      ajaxInstance.delete.resolves({ text: 'saved succesfully' });
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#remove');
      btn.click();
      await aTimeout(200);
      expect(stubFn).to.have.callCount(1);
    });

    it('It should add new conditions If versionID exists', async () => {
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'REGOLA_CONDIZIONE',
              data: 5,
            },
          ],
        },
      });
      element.versionID = '1';
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });

    it('It should add new actions If versionID exists', async () => {
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'REGOLA_AZIONE',
              data: 5,
            },
          ],
        },
      });
      element.versionID = '1';
      element.selectLabel = 'Select';
      element.sectionsList = [
        {
          id: '95728-41811-17742',
          name: 'Sect 1',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          value: 'Sect 1',
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      element.checkedData = ['95728-41811-17742'];
      // eslint-disable-next-line
      element.checkedDataInfo = element.sectionsList[0];
      await elementUpdated(element);
      aTimeout(200);
      const formComponent = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('rule-form'),
      );
      element._fireMockEvent(formComponent, 'form-data-received', {
        ...element.sectionsList[0],
        id: '95728-41811-17742',
      });

      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });

    it('It should add new condition If versionID not exists', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsVersionsList: [
            {
              itemsVersionsID: 1,
              versionID: 98,
              versionNumber: 15,
              hasParentDocuments: true,
              status: 'APPROVATO',
              validity: '2023-01-01',
            },
          ],
        },
      });
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'REGOLA_CONDIZIONE',
              data: 5,
            },
          ],
        },
      });
      element.id = 1;
      element.rowId = 2;
      // element.selectLabel = 'Select';
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });

    it('It should add new action If versionID not exists', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsVersionsList: [
            {
              itemsVersionsID: 1,
              versionID: 98,
              versionNumber: 15,
              hasParentDocuments: true,
              status: 'APPROVATO',
              validity: '2023-01-01',
            },
          ],
        },
      });
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'REGOLA_AZIONE',
              data: 5,
            },
          ],
        },
      });
      element.id = 1;
      element.rowId = 2;
      element.selectLabel = 'Select';
      element.sectionsList = [
        {
          id: '95728-41811-17742',
          name: 'Sect 1',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          value: 'Sect 1',
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      element.checkedData = ['95728-41811-17742'];
      // eslint-disable-next-line
      element.checkedDataInfo = element.sectionsList[0];
      await elementUpdated(element);
      aTimeout(200);
      const formComponent = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('rule-form'),
      );
      element._fireMockEvent(formComponent, 'form-data-received', {
        ...element.sectionsList[0],
        id: '95728-41811-17742',
      });
      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });
    const renderTree = async () => {
      element.id = 1;
      element.rowId = 2;
      element.selectLabel = 'Select';
      element.sectionsList = [
        {
          id: '95728-41811-17742',
          name: 'Sect 1',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          value: 'Sect 1',
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      element.checkedData = ['95728-41811-17742'];
      // eslint-disable-next-line
      element.checkedDataInfo = element.sectionsList[0];
      await elementUpdated(element);
      aTimeout(200);
      const components = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('custom-tree'),
      );
      return components;
    };
    it('It should render tree view when sections list has data', async () => {
      const components = await renderTree();
      await aTimeout(200);
      const tree = components[0]?.shadowRoot?.querySelector(
        components[0]?.constructor?.getScopedTagName('ing-collapsible'),
      );
      const list = components[1]?.shadowRoot?.querySelector('.d-inline-block');
      expect(tree).to.exist;
      expect(list).to.exist;
    });
    it('It should render expanded children of parents data', async () => {
      element.subSectionsList = [
        {
          id: '95728-41811-46576222',
          name: 'Sub 1',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          value: 'Sect 1',
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      const components = await renderTree();
      element.sectionsList[0].sectionId = '95728-41811-17742';
      await aTimeout(200);
      element._fireMockEvent(components[0], 'expanded-parent', {
        data: element.sectionsList[0],
        target: components[0]?.shadowRoot?.querySelector(
          components[0].constructor.getScopedTagName('ing-collapsible-invoker'),
        ),
      });
      await aTimeout(300);
      expect(element.sectionsList[0]?.children?.length).eq(1);
    });
    it('It should push checked data in checkedData list', async () => {
      const components = await renderTree();
      element.checkedData = [];
      await aTimeout(200);
      element._fireMockEvent(components[0], 'nodes-checked', {
        id: element.sectionsList[0]?.id,
      });
      await aTimeout(200);
      expect(element.checkedData.indexOf(element.sectionsList[0]?.id)).eq(0);
    });
    it('It should render and map expanded data with actions data', async () => {
      element.subSectionsList = [
        {
          id: '95728-41811-46576222',
          name: 'Sub 1',
          description: '',
          note: '',
          column: '',
          isNew: true,
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDColumn: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      const components = await renderTree();
      element.elementsData = [
        ...element.elementsData,
        {
          ...element.subSectionsList[0],
          value: 'test data',
          isBold: true,
          isItalic: false,
          isVisible: true,
          appliedToRule: element.subSectionsList[0].id,
        },
      ];
      element.sectionsList[0].sectionId = '95728-41811-17742';
      await aTimeout(200);
      element._fireMockEvent(components[0], 'expanded-parent', {
        data: element.sectionsList[0],
        target: components[0]?.shadowRoot?.querySelector(
          components[0].constructor.getScopedTagName('ing-collapsible-invoker'),
        ),
      });
      await aTimeout(300);
      expect(element.sectionsList[0]?.children[0]?.value).eq('test data');
    });
    it('It should return action data in Rule form when checked ', async () => {
      const components = await renderTree();
      element.checkedData = [];
      await aTimeout(200);
      element._fireMockEvent(components[0], 'nodes-checked', {
        id: element.sectionsList[0].id,
      });
      await aTimeout(300);
      expect(element.ruleFormData?.id).to.exist;
    });
    it('It should load proper view of tabs', async () => {
      const components = await renderTree();
      element.checkedData = [];
      element.elementsData = [...element.sectionsList];
      await aTimeout(200);
      expect(element.activeTabButtonId).to.eq(2);
      expect(components[0].hidden).to.eq(false);
      expect(components[1].hidden).to.eq(true);
      const tab = element?.shadowRoot?.querySelector('.tab-btn');
      tab?.click();
      await aTimeout(200);
      expect(element.activeTabButtonId).to.eq(1);
      expect(components[1].hidden).to.eq(false);
      expect(components[0].hidden).to.eq(true);
    });
  });
});
