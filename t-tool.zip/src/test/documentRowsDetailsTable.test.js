import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  elementUpdated,
  oneEvent,
  aTimeout,
} from '@open-wc/testing';
import { DocumentRowsDetailsTableCE } from './test-class.js';

describe('DocumentCommonDetailsTableCE Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentRowsDetailsTableCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It should not bind pointer-event-curser class', async () => {
      element.showVersionlist = false;
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector('.pointer-event-curser');
      await expect(el).to.not.exist;
    });

    it('It should bind version list dropdown', async () => {
      element.showVersionlist = true;
      element.tableData[0].versionList = [
        {
          itemsVersionsID: 101,
          versionID: 101,
          versionNumber: 15,
        },
        {
          itemsVersionsID: 98,
          versionID: 98,
          versionNumber: 16,
        },
        {
          itemsVersionsID: 40,
          versionID: 40,
          versionNumber: 4,
        },
      ];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(`[data-tag-name='ing-select']`);
      await expect(el).to.exist;
    });

    it('It should trigger version detail list event', async () => {
      element.showVersionlist = true;
      await elementUpdated(element);
      element.getVersionDetails(null, element.tableData[0]);
      setTimeout(() => {
        element.dispatchEvent(
          new CustomEvent('version-detail-list', {
            detail: element.tableData[0],
          }),
        );
      });
      aTimeout(200);
      const { detail } = await oneEvent(element, 'version-detail-list');
      await expect(detail.id).to.eq(element.tableData[0].id);
    });

    it('It should trigger changed-version-detail event', async () => {
      element.showVersionlist = true;
      element.tableData[0].versionList = [
        {
          itemsVersionsID: 101,
          versionID: 101,
          versionNumber: 15,
        },
        {
          itemsVersionsID: 98,
          versionID: 98,
          versionNumber: 16,
        },
        {
          itemsVersionsID: 40,
          versionID: 40,
          versionNumber: 4,
        },
      ];
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(`[data-tag-name='ing-select']`);
      el.dispatchEvent(new Event('change'));
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('changed-version-detail', {
            detail: {
              id: 1,
            },
          }),
        );
      });
      aTimeout(200);
      const { detail } = await oneEvent(el, 'changed-version-detail');
      await expect(detail.id).to.eq(1);
    });
  });
});
