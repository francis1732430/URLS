import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  elementUpdated,
  oneEvent,
} from '@open-wc/testing';
import Sinon from 'sinon';
import { ajaxInstance } from '../utils/endpoints.js';

import { RowDefinationCE } from './test-class.js';

describe('RowElements Tests', () => {
  const tag = unsafeStatic(defineCE(RowDefinationCE));

  describe('Structure', () => {
    let element;

    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('Remove button stays disabled by default', async () => {
      const btn = await element?.shadowRoot?.querySelector('#remove');
      // debugger;
      expect(btn).to.have.attribute('disabled');
    });
    it('Remove button gets Enabled after checkedData is populated', async () => {
      element.checkedData = [1, 2];
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('#remove');
      // debugger;
      expect(btn).to.not.have.attribute('disabled');
    });
    it('Remove button removes checked Elements', async () => {
      element.checkedData = [element.elementsData?.[0]?.id];
      const btn = await element?.shadowRoot?.querySelector('#remove');
      btn.click();
      await elementUpdated(element);
      aTimeout(200);
      // debugger;
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('row-elements'),
      );
      expect(elements.length).to.equal(0);
    });
    it('Add button adds new elements', async () => {
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await elementUpdated(element);
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('row-elements'),
      );
      expect(elements.length).to.equal(2);
    });
    it('Add button adds new attached note', async () => {
      element.selectLabel = 'select';
      element.selectLabel = 'select';
      element.selectedColumn = '1';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '1',
          isNew: true,
          notesList: [
            {
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await elementUpdated(element);
      const elements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      expect(elements.length).to.equal(1);
    });
    it('Chip Remove event is listened', async () => {
      element.selectLabel = 'select';
      element.selectedColumn = '1';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          isNew: true,
          column: '1',
          notesList: [
            {
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await elementUpdated(element);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('removable-chip'),
      );
      setTimeout(() =>
        element._fireMockEvent(el, 'chip-deleted', {
          id: el.id,
          columnId: element.selectedColumn,
        }),
      );
      await elementUpdated(element);
      await aTimeout(300);
      const els = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('removable-chip'),
      );
      expect(els.length).to.equal(0);
    });
    it('Add button stays enabled if both rows and Notes are present', async () => {
      element.selectLabel = 'select';
      element.selectedColumn = '1';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          isNew: true,
          column: '1',
          notesList: [
            {
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      expect(btn).to.not.have.attribute('disabled');
    });
    it('Add button stays disabled if No Notes are present', async () => {
      element.selectLabel = 'select';
      element.select2Data = [];
      element.selectLabel = 'select';
      element.selectedColumn = '1';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          isNew: true,
          column: '1',
          notesList: [
            {
              id: '1',
            },
          ],
        },
      ];
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      expect(btn).to.have.attribute('disabled');
    });
    it('Add button stays disabled if No Rows are present', async () => {
      element.selectLabel = 'select';
      element.selectData = [];
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      expect(btn).to.have.attribute('disabled');
    });

    it('Column should be removed from Row', async () => {
      const stubFn = Sinon.stub(element, 'deleteLevels');
      element.selectLabel = '';
      element.elementsData = [
        {
          id: '95728-41811-17742',
          name: '',
          description: '',
          isBold: 'false',
          isItalic: 'false',
          note: '',
          column: '',
          isNew: true,
          versionDetailLevel0ID: 2,
          versionDetailLevel1IDDescription: 3,
          versionDetailLevel1IDBold: 4,
          versionDetailLevel1IDItalic: 5,
        },
      ];
      element.checkedData = ['95728-41811-17742'];
      ajaxInstance.delete = Sinon.stub();
      ajaxInstance.delete.resolves({ text: 'saved succesfully' });
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#remove');
      btn.click();
      await aTimeout(200);
      expect(stubFn).to.have.callCount(1);
    });

    it('Note should be removed from Column', async () => {
      const stubFn = Sinon.stub(element, 'deleteLevels');
      element.selectLabel = 'Select';
      element.columnNotes = [
        {
          name: 'Nota sulla riga',
          description: '',
          columnId: 1,
          id: '765',
          versionDetailLevel2ID: 2,
        },
      ];
      element.selectedColumn = 1;
      ajaxInstance.delete = Sinon.stub();
      ajaxInstance.delete.resolves({ text: 'saved succesfully' });
      await elementUpdated(element);
      aTimeout(200);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('removable-chip'),
      );
      setTimeout(() =>
        element._fireMockEvent(el, 'chip-deleted', {
          id: 765,
          columnId: element.selectedColumn,
        }),
      );
      await elementUpdated(element);
      await aTimeout(300);
      await aTimeout(200);
      expect(stubFn).to.have.callCount(1);
    });

    it('It should add new column If versionID exists', async () => {
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'DETTAGLIO_RIGA',
              data: 5,
            },
          ],
        },
      });
      element.versionID = '1';
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });

    it('It should add new column If versionID not exists', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({
        data: {
          itemsVersionsList: [
            {
              itemsVersionsID: 1,
              versionID: 98,
              versionNumber: 15,
              hasParentDocuments: true,
              status: 'APPROVATO',
              validity: '2023-01-01',
            },
          ],
        },
      });
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({
        data: {
          versionDetailsDTO: [
            {
              versionDetailLevel: 0,
              versionDetailParentID: 1,
              itemTypeKey: 'VERSION_DETAIL_LEVEL_1',
              itemTypeValue: 'DETTAGLIO_RIGA',
              data: 5,
            },
          ],
        },
      });
      element.id = 1;
      element.rowId = 2;
      await elementUpdated(element);
      aTimeout(200);
      const btn = await element?.shadowRoot?.querySelector('#add');
      btn.click();
      await aTimeout(200);
      expect(element.elementsData.length).to.eq(2);
    });

    it('It should change selected note', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-elements'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('note-select-changed', {
            detail: {
              ids: [
                {
                  id: '1',
                  name: 'test',
                  columnNoteId: '1_1',
                },
                {
                  id: '2',
                  name: 'test2',
                  columnNoteId: '1_2',
                },
              ],
              columnId1: '1',
            },
          }),
        ),
      );
      aTimeout(200);
      await oneEvent(el, 'note-select-changed');
      expect(element.selectedNote.length).to.equal(2);
    });

    it('It should remove selected note', async () => {
      element.selectedNote = [
        {
          id: '1',
          name: 'test',
          columnNoteId: '1_1',
        },
        {
          id: '2',
          name: 'test2',
          columnNoteId: '1_2',
        },
      ];
      await elementUpdated();
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-elements'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('note-select-changed', {
            detail: {
              ids: [
                {
                  id: '1',
                  name: 'test',
                  columnNoteId: '1_1',
                },
                {
                  id: '2',
                  name: 'test2',
                  columnNoteId: '1_2',
                },
              ],
              columnId1: '1',
              unCheckedId: '1',
            },
          }),
        ),
      );
      aTimeout(200);
      await oneEvent(el, 'note-select-changed');
      expect(element.selectedNote.length).to.equal(1);
    });
  });
});
