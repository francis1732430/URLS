import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import sinon from 'sinon';

import { NewDocumentCreationCE } from './test-class.js';

describe('NewDocumentCreation Tests', () => {
  const tag = unsafeStatic(defineCE(NewDocumentCreationCE));
  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It renders correct notes creation ', async () => {
      const createNoteElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-note'),
      );
      expect(createNoteElements.length).to.equal(element.notesData.length);
    });
    it('It receives correct modification data when add-note-section event is fired', async () => {
      // element._putNote = sinon.stub();
      // element._putNote.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.patch = sinon.stub();
      element.ajaxInstance.patch.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.noteBackendStructure });
      element.requestUpdate();
      const modifiedData = { ...element.notesData[0], name: 'modified name' };
      await element.updateComplete;
      const createNote = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-note'),
      );

      setTimeout(() =>
        element._fireMockEvent(createNote, 'add-note-section', { data: modifiedData }),
      );

      aTimeout(200);

      const { detail } = await oneEvent(createNote, 'add-note-section');
      aTimeout(200);
      await element.updateComplete;
      expect(detail.data).to.deep.equal(modifiedData);

      const createNoteElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-note'),
      );

      expect(createNoteElements.length).to.equal(2);
      sinon.restore();
    });
    it('It receives correct Creation data when add-note-section event is fired', async () => {
      // element._putNote = sinon.stub();
      // element._putNote.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.post = sinon.stub();
      element.ajaxInstance.post.resolves({ text: 'saved succesfully' });
      element.ajaxInstance.get = sinon.stub();
      element.ajaxInstance.get.resolves({ data: element.noteBackendStructure });
      element.requestUpdate();
      const modifiedData = {
        ...element.notesData[0],
        name: 'modified name',
        id: '343434',
        isNotSaved: true,
      };
      await element.updateComplete;
      const createNote = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-note'),
      );

      setTimeout(() =>
        element._fireMockEvent(createNote, 'add-note-section', { data: modifiedData }),
      );

      aTimeout(200);

      const { detail } = await oneEvent(createNote, 'add-note-section');
      aTimeout(200);
      await element.updateComplete;
      expect(detail.data).to.deep.equal(modifiedData);

      const createNoteElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-note'),
      );

      expect(createNoteElements.length).to.equal(2);
      sinon.restore();
    });
    it('It receives correct data when remove-note-section event is fired', async () => {
      // element._deleteNote = sinon.stub();
      // element._deleteNote.resolves({ text: 'Removed succesfully' });
      element.ajaxInstance.delete = sinon.stub();
      element.ajaxInstance.delete.resolves({ text: 'Removed succesfully' });
      element.requestUpdate();
      await element.updateComplete;
      const createNote = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('create-new-note'),
      );
      setTimeout(() => element._fireMockEvent(createNote, 'remove-note-section', { data: 2 }));

      aTimeout(200);

      const { detail } = await oneEvent(createNote, 'remove-note-section');
      await element.updateComplete;
      aTimeout(200);
      expect(detail.data).to.equal(2);

      const createNoteElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-note'),
      );
      expect(createNoteElements.length).to.equal(2);
    });
    it('It adds a new note creation section on add new button click', async () => {
      const createNewBtn = await element?.shadowRoot?.querySelector('#createNew');
      createNewBtn.click();
      await element.updateComplete;
      aTimeout(300);

      const createNoteElements = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('create-new-note'),
      );
      expect(createNoteElements.length).to.equal(3);
    });

    it('It should hide the create new button', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('#createNew');
      await expect(btn).to.not.exist;
    });
  });
});
