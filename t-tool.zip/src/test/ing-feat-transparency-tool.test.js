import { expect, fixture, html, unsafeStatic, defineCE, fixtureCleanup } from '@open-wc/testing';
import { IngFeatTransparencyToolComponentCE } from './test-class.js';

describe('IngFeatTransparencyTool', () => {
  const tag = unsafeStatic(defineCE(IngFeatTransparencyToolComponentCE));

  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('is accessible', async () => {
      const el = await fixture(
        html`<ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration>`,
      );
      await expect(el).to.exist;

      const stepsEl = element.shadowRoot.querySelector(
        element.constructor.getScopedTagName('transparency-tool-access'),
      );
      expect(stepsEl).to.exist;
    });
  });
});
