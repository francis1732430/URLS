import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import { SubSectionCE } from './test-class.js';

describe('SubSection Tests', () => {
  const tag = unsafeStatic(defineCE(SubSectionCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (selector, eventName, value = 'test') => {
      const input = await element?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.value = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It binds the name field', async () => {
      const input = await populateInput('name', 'keyup');
      expect(element.name).to.equal(input.value);
    });

    it('It binds the description field', async () => {
      const input = await populateInput('description', 'keyup');
      expect(element.description).to.equal(input.value);
    });

    it('Save button stays disabled by default', async () => {
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      expect(btn).to.have.attribute('disabled');
    });

    it('Save button enables when required data is entered', async () => {
      await populateInput('name', 'keyup');

      await populateInput('description', 'keyup');

      aTimeout(300);
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      expect(btn).to.not.have.attribute('disabled');
    });
    it('It sends correct data when add-note-section event is fired', async () => {
      await populateInput('name', 'keyup');

      await populateInput('description', 'keyup');

      aTimeout(300);
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      setTimeout(() => btn.click());
      aTimeout(200);

      const { detail } = await oneEvent(element, 'new-sub-section-added');
      aTimeout(200);
      expect(detail?.data?.id).to.equal(element._id);
    });
    it('It sends correct data when remove-note-section event is fired', async () => {
      const btn = await element?.shadowRoot?.querySelector('.cancel_button');
      setTimeout(() => btn.click());
      aTimeout(200);

      const { detail } = await oneEvent(element, 'remove-sub-section');
      aTimeout(200);
      expect(detail?.id).to.equal(element._id);
    });
    it('It binds the correct value when style value changed', async () => {
      const select = await element?.shadowRoot?.querySelector(`[name="sectionStyle"]`);
      element.styleList = [
        {
          id: '2',
          name: 'test',
        },
      ];
      await elementUpdated(element);
      select.modelValue = '2';
      select.dispatchEvent(new Event('change'));
      await aTimeout(300);
      await elementUpdated(element);
      expect(element.sectionStyle).to.equal(select.modelValue);
    });
    it('It binds the correct value when date value changed', async () => {
      const datepicker = await element?.shadowRoot?.querySelector(`[name="validity"]`);

      datepicker.modelValue = new Date('10-10-2022');
      datepicker.dispatchEvent(new Event('change'));
      aTimeout(300);
      expect(new Date(element.validity).getTime()).to.equal(new Date('2022-10-10').getTime());
    });

    it('It binds the correct value when currentstep is a subsection', async () => {
      element._currentStep = 'subsection';
      await elementUpdated(element);
      const ele = element.shadowRoot.querySelector('[name="name"]');
      aTimeout(200);
      await expect(ele.label).to.equal('NOME SOTTO SEZIONE');
    });

    it('It binds the correct value when currentstep is a section', async () => {
      element._currentStep = 'section';
      await elementUpdated(element);
      const ele = element.shadowRoot.querySelector('[name="name"]');
      aTimeout(200);
      await expect(ele.label).to.equal('NOME SEZIONE');
    });

    it('It should bind the annulla text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.cancel_button');
      await expect(ele.innerText).to.equal('Annulla');
    });

    it('It should bind the Aggiungi e Chiudi text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.save_button');
      await expect(ele.innerText).to.equal('Aggiungi e Chiudi');
    });
  });
});
