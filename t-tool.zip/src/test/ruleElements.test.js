import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import Sinon from 'sinon';
import { RuleElementsCE } from './test-class.js';

import { appliesToColumns, appliesToRules } from '../data/rulesCreationData.js';

describe('RuleElements Tests', () => {
  const tag = unsafeStatic(defineCE(RuleElementsCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (el, selector, eventName, value = 'test') => {
      const parent = el || element;
      const input = await parent?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.value = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    const changeSelect = async (target, value = '2') => {
      const select = await element?.shadowRoot?.querySelector(
        `${element.constructor.getScopedTagName('ing-select')}[name="${target}"]`,
      );
      select.modelValue = value;
      setTimeout(() => select.dispatchEvent(new Event('change')));
      await aTimeout(500);
      expect(element[target]).to.equal(select.modelValue);
    };
    const changeCheckBox = async (target, eventName) => {
      const checkbox = await element?.shadowRoot?.querySelector(`[name="${target}"]`);
      checkbox.checked = !checkbox.checked;
      setTimeout(() => checkbox.dispatchEvent(new Event(eventName)));
      await aTimeout(500);
      expect(element[target]).to.equal(checkbox.checked);
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It binds the selectVal field', async () => {
      await changeSelect('selectVal');
    });
    it('It binds the isVisible field', async () => {
      await changeCheckBox('isVisible', 'click');
    });
    it('It binds the isBold field', async () => {
      await changeCheckBox('isBold', 'change');
    });
    it('It binds the isItalic field', async () => {
      await changeCheckBox('isItalic', 'change');
    });
    it('It binds the select2Val field', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { lookupRulesList: appliesToRules } });
      element.docId = '1';
      // element.makeAjaxCall = Sinon.stub();
      // element.makeAjaxCall.resolves({ list: appliesToRules });
      element.requestUpdate();
      await elementUpdated(element);
      // debugger;
      await changeSelect('selectVal');
      // debugger;
      // await changeSelect('select2Val');
      Sinon.restore();
    });
    it('It binds the select3Val field', async () => {
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { lookupRulesList: appliesToColumns } });
      // element.makeAjaxCall = Sinon.stub();
      // element.makeAjaxCall.resolves({ list: appliesToColumns });
      element.requestUpdate();
      await elementUpdated(element);
      await changeSelect('selectVal');
      // await changeSelect('select2Val');
      // await changeSelect('select3Val', '2');
      Sinon.restore();
    });
    it('It binds the value field', async () => {
      const input = await populateInput(element, 'input1Val', 'keyup');
      await aTimeout(500);
      expect(element.input1Val).to.equal(input.value);
    });

    it('It binds id to checked-fields event', async () => {
      // element = await fixture(html`<${tag} selectLabel=${undefined}></${tag}>`);
      element.selectLabel = undefined;
      await elementUpdated(element);
      const checkbox = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('ing-checkbox'),
      );
      checkbox.checked = true;
      setTimeout(() => checkbox.dispatchEvent(new Event('change')));
      const { detail } = await oneEvent(element, 'checked-fields');
      expect(detail.id).to.equal(element.id);
    });
  });
});
