import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  elementUpdated,
  oneEvent,
} from '@open-wc/testing';

import Sinon from 'sinon';
import { DocumentModificationCE } from './test-class.js';
import { documents } from '../data/documents.js';

describe('CreateRowCE Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentModificationCE));

  describe('Structure', () => {
    let element;
    const receiveEventWithData = async (
      customTagName,
      customEventName,
      dataName,
      dataId,
      actualData,
      restData = {},
    ) => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName(customTagName),
      );
      element._fireMockEvent(el, customEventName, {
        data: {
          name: dataName,
          id: dataId,
          data: { ...actualData, headerData: [], tableContentData: [] },
          ...restData,
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag} .documentData="${documents[0]}"></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    it('It receives id in modify-selected-section', async () => {
      await receiveEventWithData(
        'document-details-page',
        'modify-selected-section',
        'Sezioni',
        1,
        documents[0].sections[0],
      );
      const tabs = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('ing-tab'),
      );

      expect(tabs.length).to.equal(3);
    });

    it('It receives id in add-new-element', async () => {
      await receiveEventWithData(
        'document-details-page',
        'add-new-element',
        'Sezioni',
        1,
        documents[0].sections[0],
      );

      const tabs = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('ing-tab'),
      );
      expect(tabs.length).to.equal(3);
    });
    it('It receives selected-data-changed', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-details-page'),
      );
      element._fireMockEvent(el, 'selected-data-changed', {
        name: 'Sezioni',
        id: 1,
        data: documents[0].sections[0],
        type: 'selectedSection',
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedSection).to.equal(documents[0].sections[0]);
    });
    it('It creates new version of selected element', async () => {
      element.confirmationMessageTitle = 'Nuova Versione';
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });
      element.ajaxInstance.put = Sinon.stub();
      element.ajaxInstance.put.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      element.ajaxInstance.delete = Sinon.stub();
      element.ajaxInstance.delete.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      const [selectedValue] = documents;
      element.selectedValue = selectedValue;
      await elementUpdated(element);
      element._closeDialog({
        detail: {
          confirmationMessageDetail: {
            type: 'newVersion',
            detail: {
              name: 'Sezioni',
              id: 1,
              data: documents[0].sections[0],
              type: 'Sezioni',
            },
          },
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedValue.sections.length).to.equal(4);
    });
    it('It creates duplicate version of selected element', async () => {
      element.confirmationMessageTitle = 'Nuova Con Duplicazione';
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      element.ajaxInstance.get = Sinon.stub();
      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });
      element.ajaxInstance.put = Sinon.stub();
      element.ajaxInstance.put.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      const [selectedValue] = documents;
      element.selectedValue = selectedValue;
      await elementUpdated(element);
      element._closeDialog({
        detail: {
          confirmationMessageDetail: {
            type: 'newDuplication',
            detail: {
              name: 'Sezioni',
              id: 8,
              data: documents[0].sections[0],
              type: 'Sezioni',
            },
          },
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedValue.sections.length).to.equal(4);
    });
    it('It deletes selected element', async () => {
      element.confirmationMessageTitle = 'Elimina';
      element.ajaxInstance.post = Sinon.stub();
      element.ajaxInstance.post.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      element.ajaxInstance.delete = Sinon.stub();
      element.ajaxInstance.delete.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      element.ajaxInstance.get = Sinon.stub();

      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });

      const [selectedValue] = documents;
      element.selectedValue = selectedValue;
      await elementUpdated(element);
      element._closeDialog({
        detail: {
          confirmationMessageDetail: {
            type: 'removeRow',
            detail: {
              name: 'Sezioni',
              id: 1,
              data: documents[0].sections[0],
              type: 'Sezioni',
              newSectionId: 1,
            },
          },
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedValue.sections.length).to.equal(4);
    });
    it('It creates new element', async () => {
      element.ajaxInstance.patch = Sinon.stub();
      element.ajaxInstance.patch.resolves({ data: { text: 'Saved Successfully' } });
      element.ajaxInstance.put = Sinon.stub();
      element.ajaxInstance.put.resolves({ data: { text: 'Updated Successfully' } });
      element.ajaxInstance.get = Sinon.stub();

      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });

      await receiveEventWithData(
        'document-details-page',
        'add-new-element',
        'Sezioni',
        1,
        documents[0].sections[0],
      );

      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      element._fireMockEvent(el, 'data-received', {
        name: 'Sezioni',
        id: 1,
        data: [{ ...documents[0].sections[0] }],
        type: 'Sezioni',
        newSectionId: '45643',
        res: {
          itemID: 123,
          versionID: 123,
          itemsVersionsID: 123,
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.openedTabsDataMapper.Sezioni).to.eq(undefined);
      expect(element.selectedValue.sections.length).to.equal(4);
    });
    it('It modifies existing element', async () => {
      await receiveEventWithData(
        'document-details-page',
        'modify-selected-section',
        'Sezioni',
        1,
        documents[0].sections[0],
      );
      element.ajaxInstance.delete = Sinon.stub();
      element.ajaxInstance.delete.resolves({ data: { itemsVersionsID: 122, itemID: 123 } });
      element.ajaxInstance.get = Sinon.stub();

      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });

      const [selectedValue] = documents;
      element.selectedValue = selectedValue;
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('dialog-modify-section'),
      );
      element._fireMockEvent(el, 'data-received', {
        name: 'Sezioni',
        id: 1,
        data: { ...documents[0].sections[0], name: 'test' },
        type: 'Sezioni',
        newSectionId: documents[0].sections[0].id,
        removedIds: [41],
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedValue.sections[0].name).to.equal('CONDIZIONI ECONOMICHE DDS CCA Q4');
      Sinon.restore();
    });

    it('It auto closes the tab', async () => {
      await receiveEventWithData(
        'document-details-page',
        'modify-selected-section',
        'Sezioni',
        1,
        documents[0].sections[0],
      );
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('dialog-modify-section'),
      );
      element._fireMockEvent(el, 'cancel-action', {
        name: 'Sezioni',
        id: 1,
        data: documents[0].sections[0],
        type: 'Sezioni',
        sectionId: documents[0].sections[0].id,
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.tabsData.length).to.equal(1);
    });
    it('It redirects back to Homepage', async () => {
      const el = await element?.shadowRoot?.querySelector('.back-to-home-icon');
      setTimeout(() => el.click());
      const { detail } = await oneEvent(element, 'navigate-to');
      expect(detail.route).to.equal('list_documents');
    });

    it('It should update the selected value when document-version-changed event is fired', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-details-page'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('document-version-changed', {
            detail: {
              data: {
                docId: 1,
              },
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(el, 'document-version-changed');
      await expect(element.selectedValue.docId).to.be.eq(1);
    });
    it('It creates existing element', async () => {
      element.ajaxInstance.patch = Sinon.stub();
      element.ajaxInstance.patch.resolves({ data: { text: 'Saved Successfully' } });
      element.ajaxInstance.put = Sinon.stub();
      element.ajaxInstance.put.resolves({ data: { text: 'Updated Successfully' } });
      element.ajaxInstance.get = Sinon.stub();

      element.ajaxInstance.get.resolves({ data: { itemChildren: documents[0].sections } });

      await receiveEventWithData(
        'document-details-page',
        'add-new-element',
        'Sezioni',
        1,
        documents[0].sections[0],
      );

      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('element-from-scratch'),
      );
      element._fireMockEvent(el, 'existing-data-received', {
        name: 'Sezioni',
        id: 45643,
        data: [{ ...documents[0].sections[0] }],
        type: 'Sezioni',
        newSectionId: '45643',
        res: {
          itemID: 123,
          versionID: 123,
          itemsVersionsID: 123,
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.selectedValue.sections.length).to.equal(4);
    });

    it('It should send correct data value when data-order-changed event is fired', async () => {
      element.ajaxInstance.put = Sinon.stub();
      element.ajaxInstance.put.resolves({ data: 'Sorted Successfully' });
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-details-page'),
      );
      setTimeout(() => {
        el.dispatchEvent(
          new CustomEvent('data-order-changed', {
            detail: {
              type: 'Sezioni',
              swappedData: {
                id: 1,
                order: 2,
              },
              swappedWithData: {
                id: 2,
                order: 1,
              },
            },
          }),
        );
      });
      const { detail } = await oneEvent(el, 'data-order-changed');
      await expect(detail.swappedData.order).to.be.eq(2);
    });
    it('It should retain last scrolled position', async () => {
      setTimeout(() => {
        window.scrollTo(0, 1);
      });
      await aTimeout(1000);
      await expect(element.selectedValue.scrollPosition).to.be.eq(1);
    });
    it('It should Open Dialog to show saved status message', async () => {
      await receiveEventWithData(
        'document-details-page',
        'modify-selected-section',
        'Sezioni',
        1,
        documents[0].sections[0],
      );
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('dialog-modify-section'),
      );
      element._fireMockEvent(el, 'show-status-dialog', {
        data: {
          status: 400,
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      const dialog = element.shadowRoot.querySelector('#dialog3');
      expect(dialog.opened).to.be.eq(true);
    });
    it('It shows up Dialog when there are unsaved changes in tab', async () => {
      await receiveEventWithData(
        'document-details-page',
        'modify-selected-section',
        'Sezioni',
        1,
        documents[0].sections[0],
      );
      const tabs = await element?.shadowRoot?.querySelectorAll(
        element.constructor.getScopedTagName('ing-tab'),
      );
      element.openedTabsDataMapper[1].dataChanged = true;
      const tab = tabs[2];
      tab?.querySelector('button')?.click();
      await aTimeout(200);
      const dialog = element.shadowRoot.querySelector('#dialog-change-tab');
      expect(dialog.opened).to.be.eq(true);
    });
    it('It shows up dialog while redirecting to homepage', async () => {
      element.openedTabsDataMapper = {
        1: {
          dataChanged: true,
          id: 1,
        },
      };
      const el = await element?.shadowRoot?.querySelector('.back-to-home-icon');
      setTimeout(() => el.click());
      await aTimeout(200);
      const dialog = element.shadowRoot.querySelector('#dialog-change-tab');
      expect(dialog.opened).to.be.eq(true);
    });
    it('It fires data changed event from changes in tab', async () => {
      await receiveEventWithData('document-details-page', 'modify-selected-section', 'Sezioni', 1, {
        ...documents[0].sections[0],
        id: 1,
      });
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('dialog-modify-section'),
      );
      element._fireMockEvent(el, 'fields-changed', {
        id: 1,
        data: documents[0].sections[0],
      });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.openedTabsDataMapper[1]?.dataChanged).to.be.eq(true);
    });
    it('It fires data changed event from documents details', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-details-page'),
      );
      element._fireMockEvent(el, 'document-data-changed', { ...documents[0], id: 123 });
      await elementUpdated(element);
      await aTimeout(200);
      expect(element.openedTabsDataMapper[123]?.dataChanged).to.be.eq(true);
    });
    describe('PDF viewer Tests', () => {
      const getChildEventData = async () => {
        element.ajaxInstance.get = Sinon.stub();
        element.ajaxInstance.get.resolves({ data: { base64: '' } });
        const el = await element?.shadowRoot?.querySelector(
          element.constructor.getScopedTagName('document-details-page'),
        );
        const target = document.createElement('a');
        target.classList.add('download-btn');
        setTimeout(() => {
          el.dispatchEvent(
            new CustomEvent('child-data-event', {
              detail: {
                target,
                name: 'test',
                data: '123456',
              },
            }),
          );
        });
        const { detail } = await oneEvent(el, 'child-data-event');
        return detail;
      };
      it('It should receive correct data from child-data-event', async () => {
        await getChildEventData();
        await aTimeout(200);
        await expect(element.pdfDetails.name).to.be.eq('test');
      });
      it('It should open dialog when child-data-event is fired', async () => {
        await getChildEventData();
        await aTimeout(200);
        await expect(element?.shadowRoot?.querySelector('.fixed-dialog')).to.exist;
      });
      it('It should close dialog when child-data-event is fired', async () => {
        await getChildEventData();
        await aTimeout(200);
        const closeButton = element?.shadowRoot?.querySelector('.fixed-dialog .close-tab');
        closeButton?.click();
        await aTimeout(200);
        await expect(element?.shadowRoot?.querySelector('.fixed-dialog')).to.not.exist;
      });
    });
  });
});
