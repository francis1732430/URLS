import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import { CreateNewNoteCE } from './test-class.js';

describe('CreateNewNote Tests', () => {
  const tag = unsafeStatic(defineCE(CreateNewNoteCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (selector, eventName, value = 'test') => {
      const input = await element?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.value = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It binds the name field', async () => {
      const input = await populateInput('name', 'keyup');
      expect(element.name).to.equal(input.value);
    });
    it('It binds the description field', async () => {
      const input = await populateInput('description', 'keyup');
      expect(element.description).to.equal(input.value);
    });
    it('Save button stays disabled by default', async () => {
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      expect(btn).to.have.attribute('disabled');
    });
    it('Save button enables when required data is entered', async () => {
      await populateInput('name', 'keyup');

      await populateInput('description', 'keyup');

      aTimeout(300);
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      expect(btn).to.not.have.attribute('disabled');
    });
    it('It sends correct data when add-note-section event is fired', async () => {
      await populateInput('name', 'keyup');

      await populateInput('description', 'keyup');

      aTimeout(300);
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      setTimeout(() => btn.click());
      aTimeout(200);

      const { detail } = await oneEvent(element, 'add-note-section');
      aTimeout(200);
      expect(detail?.data?.id).to.equal(element.id);
    });
    it('It sends correct data when remove-note-section event is fired', async () => {
      const btn = await element?.shadowRoot?.querySelector('.cancel_button');
      setTimeout(() => btn.click());
      aTimeout(200);

      const { detail } = await oneEvent(element, 'remove-note-section');
      aTimeout(200);
      expect(detail?.data).to.equal(element.id);
    });

    it('It should bind the annulla text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.cancel_button');
      await expect(ele.innerText).to.equal('Annulla');
    });

    it('It should bind the Aggiungi e Chiudi text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.save_button');
      await expect(ele.innerText).to.equal('Aggiungi e Chiudi');
    });
  });
});
