import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';
import Sinon, { stub } from 'sinon';
import { ajaxInstance } from '../utils/endpoints.js';
import { DocumentListReviewPageCE } from './test-class.js';

describe('DocumentListReviewPage Tests', () => {
  const tag = unsafeStatic(defineCE(DocumentListReviewPageCE));
  describe('Structure', () => {
    let element;
    const isCheckDisabled = async tagItem => {
      const el = await element?.shadowRoot?.querySelector(tagItem);
      await expect(el.disabled).to.equal(true);
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
      element.getReviewRequests = stub();
      element.getReviewRequests.resolves(element.requestReview1);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;

      const reviewAttachment = element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('document-review-attachments'),
      );
      expect(reviewAttachment).to.exist;
    });
    it('It binds correct value to message property', async () => {
      const input = await element?.shadowRoot?.querySelector('[reviewtextarea]');
      const value = 'test value';
      input.value = value;
      await input.dispatchEvent(new Event('change'));
      aTimeout(200);
      expect(element?.requestMessage).to.equal(value);
    });
    it('It binds correct value to message property of reviewer', async () => {
      const input = await element?.shadowRoot?.querySelector('[reviewertextarea]');
      const value = 'test value';
      input.value = value;
      await input.dispatchEvent(new Event('change'));
      aTimeout(200);
      expect(element?.reviewerMessage).to.equal(value);
    });
    it('It binds correct value to reviewer property of reviewer', async () => {
      const input = await element?.shadowRoot?.querySelector('[name="reviewer"]');
      const value = 'test value';
      input.value = value;
      await input.dispatchEvent(new Event('change'));
      aTimeout(200);
      expect(element?.reviewer).to.equal(value);
    });
    it('It binds correct value to reviewStatus property of reviewer', async () => {
      const checkbox = await element?.shadowRoot?.querySelector('[name="reviewStatus"]');
      checkbox.checked = true;
      checkbox.click();
      aTimeout(200);
      expect(element?.reviewStatus).to.equal(true);
    });
    it('It fires data-received event and calls _emailsChanged function', async () => {
      const stubFn = stub(element, '_emailsChanged');
      element.requestUpdate();
      await element.updateComplete;
      const reviewAttachment = element?.shadowRoot?.querySelector(
        `${element.constructor.getScopedTagName(
          'document-review-attachments',
        )}[addButtonText="Aggiungi"]`,
      );
      reviewAttachment.dispatchEvent(element._mockGenerateDataReceivedEvent());
      aTimeout(200);

      await expect(stubFn).to.have.callCount(1);
    });

    it('It should update the review list when version-changed event is fired', async () => {
      element.reviewsList = [
        {
          id: '1',
          review: 'OK',
          reviewer: 'Compliance',
          note: 'ESTRATTO CONTO DI CONTO CORRENTE ANNUALE',
          user: 'nome.cognome@ing.com',
          attachment: 'http://test.pdf',
          dateAndTime: '31/01/21 09:43',
        },
      ];
      element.getReviewRequestsByVersion = stub();
      element.getReviewRequestsByVersion.resolves(element.requestReview1);
      ajaxInstance.get = Sinon.stub();
      ajaxInstance.get.resolves({
        data: {
          itemTypeKey: 'DOCUMENT_TYPE',
          itemTypeValue: 'DOCUMENTO',
          name: 'DOCUMENTO DI SINTESI ANNUALE',
          validity: '2023-01-02',
          id: '100',
          itemsVersionsID: '100',
          itemID: '1',
          versionNumber: 4,
          versionDetailL0: [
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'LOOKUP_DATA_ID_STATUS',
              data: 'IN SVILUPPO',
              versionDetailLevel0ID: 27,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT',
              data: 'CCA',
              versionDetailLevel0ID: 22,
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'CODICE',
              data: 'WDS',
            },
            {
              itemTypeKey: 'FIELD',
              itemTypeValue: 'LOOKUP_DATA_ID_PRODUCT_TYPE',
              data: 'DDS',
              versionDetailLevel0ID: 29,
            },
          ],
          itemChildren: [],
        },
      });
      await elementUpdated(element);
      const historyReview = await element?.shadowRoot?.querySelector(
        `[currentTab="storicaReview"]`,
      );
      setTimeout(() => {
        historyReview.dispatchEvent(
          new CustomEvent('version-changed', {
            detail: {
              data: '2',
            },
          }),
        );
      });
      await aTimeout(200);
      await elementUpdated(element);
      oneEvent(historyReview, 'version-changed');
      await expect(element.reviewsList.length).to.be.eq(0);
    });

    it('It should update the review list when selected-table-row  event is fired', async () => {
      element.reviewRequests = [
        {
          id: '1',
          requestId: '1',
          reviewer: ['Compliance', 'Brand', 'MARIO ROSSI', 'BIANCA NERI'],
          note: 'MODULO STANDARD PER LE INFORMAZIONI DA FORNIRE AI DEPOSITANTI',
          user: 'nome.cognome@ing.com',
          attachment: 'http://test.pdf',
          dateAndTime: '31/01/21 09:43',
          reviewsList: [
            {
              id: '1',
              review: 'OK',
              reviewer: 'Compliance',
              note: 'ESTRATTO CONTO DI CONTO CORRENTE ANNUALE',
              user: 'nome.cognome@ing.com',
              attachment: 'http://test.pdf',
              dateAndTime: '31/01/21 09:43',
            },
          ],
        },
      ];
      element.getReviewsByRequestId = stub();
      element.refetch = stub();
      element.refetch.resolves({ itemChildren: element.reviews });
      element.getReviewsByRequestId.resolves({ itemChildren: element.reviews });
      await elementUpdated(element);
      const historyReview = await element?.shadowRoot?.querySelector(`[ing-generic-table]`);
      setTimeout(() => {
        historyReview.dispatchEvent(
          new CustomEvent('selected-table-row', {
            detail: {
              data: {
                id: '1',
                requestId: '1',
                reviewer: 'Compliance',
                note: 'MODULO STANDARD PER LE INFORMAZIONI DA FORNIRE AI DEPOSITANTI',
                user: 'nome.cognome@ing.com',
                attachment: 'http://test.pdf',
                dateAndTime: '31/01/21 09:43',
                reviewsList: [
                  {
                    id: '1',
                    review: 'OK',
                    reviewer: 'Compliance',
                    note: 'ESTRATTO CONTO DI CONTO CORRENTE ANNUALE',
                    user: 'nome.cognome@ing.com',
                    attachment: 'http://test.pdf',
                    dateAndTime: '31/01/21 09:43',
                  },
                  {
                    id: '2',
                    review: 'KO',
                    reviewer: 'Brand',
                    note: 'ESTRATTO CONTO DI CONTO CORRENTE ANNUALE',
                    user: 'nome.cognome@ing.com',
                    attachment: 'http://test.pdf',
                    dateAndTime: '31/01/21 09:43',
                  },
                  {
                    id: '3',
                    review: 'OK',
                    reviewer: 'Compliance',
                    note: 'MODULO STANDARD PER LE INFORMAZIONI',
                    user: 'nome.cognome@ing.com',
                    attachment: 'http://test.pdf',
                    dateAndTime: '31/01/21 09:43',
                  },
                ],
              },
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(historyReview, 'selected-table-row');
      await elementUpdated(element);
      await expect(element.reviewsList.length).to.be.eq(1);
    });

    it('It should update the files list when request review data-removed event is fired', async () => {
      element.deleteData = stub();
      element.deleteData.resolves({
        text: 'File deleted successfully',
      });
      element.fileData = [
        {
          id: 1,
        },
        {
          id: 2,
        },
      ];
      element.requestUpdate();
      const requestReview = await element?.shadowRoot?.getElementById('reviewRequest');
      setTimeout(() => {
        requestReview.dispatchEvent(
          new CustomEvent('data-removed', {
            detail: {
              id: 1,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(requestReview, 'data-removed');
      await expect(element.fileData.length).to.be.eq(1);
    });

    it('It should update the files list when request review files added event is fired', async () => {
      element.uploadFiles = stub();
      element.uploadFiles.resolves([
        {
          value: [
            {
              id: 1,
              ItemUrl: 'test.xlsx',
            },
          ],
          status: 'fulfilled',
        },
      ]);
      element.toBase64 = stub();
      element.toBase64.resolves('xyzabcdrtyuo');
      await elementUpdated(element);
      const requestReview = await element?.shadowRoot?.getElementById('reviewRequest');
      setTimeout(() => {
        requestReview.dispatchEvent(
          new CustomEvent('files-added', {
            detail: {
              data: [{ id: 3, isSaved: true }],
              files: [
                {
                  id: 3,
                  name: 'test',
                  size: 256,
                },
              ],
            },
          }),
        );
      });
      await aTimeout(200);
      await elementUpdated(element);
      oneEvent(requestReview, 'files-added');
      await expect(element.fileData.length).to.be.eq(1);
    });

    it('Save button should disabled when request review message, files and reviewers fields are empty', async () => {
      const saveBtn = await element?.shadowRoot?.querySelector(
        '.save-button [data-tag-name="ing-button"]',
      );
      await expect(saveBtn.disabled).to.be.eq(true);
    });

    it('Save button should enabled when request review message, files and reviewers fields have value', async () => {
      element.requestMessage = 'test';
      element.fileData = [
        { id: 1, isSaved: true },
        { id: 2, isSaved: true },
      ];
      element.emailList = [{ id: 1, name: 'test@gmail.com' }];
      await elementUpdated(element);
      const saveBtn = await element?.shadowRoot?.querySelector(
        '.save-button [data-tag-name="ing-button"]',
      );
      await expect(saveBtn.disabled).to.be.eq(false);
    });

    it('It should update the files list when insert review data-removed event is fired', async () => {
      element.deleteData = stub();
      element.deleteData.resolves({
        text: 'File deleted successfully',
      });
      element.reviewerFileData = [
        {
          id: 1,
        },
        {
          id: 2,
        },
      ];
      element.requestUpdate();
      const insertReview = await element?.shadowRoot?.getElementById('insertReview');
      setTimeout(() => {
        insertReview.dispatchEvent(
          new CustomEvent('data-removed', {
            detail: {
              id: 1,
            },
          }),
        );
      });
      aTimeout(200);
      await oneEvent(insertReview, 'data-removed');
      await expect(element.reviewerFileData.length).to.be.eq(1);
    });

    it('It should update the files list when insert review files added event is fired', async () => {
      element.uploadFiles = stub();
      element.uploadFiles.resolves([
        {
          value: [
            {
              id: 1,
              ItemUrl: 'test.xlsx',
            },
          ],
          status: 'fulfilled',
        },
      ]);
      element.toBase64 = stub();
      element.toBase64.resolves('xyzabcdrtyuo');
      await elementUpdated(element);

      const insertReview = await element?.shadowRoot?.getElementById('insertReview');
      setTimeout(() => {
        insertReview.dispatchEvent(
          new CustomEvent('files-added', {
            detail: {
              data: [{ id: 3, isSaved: true }],
              files: [
                {
                  id: 3,
                  name: 'test',
                  size: 256,
                },
              ],
            },
          }),
        );
      });
      await aTimeout(200);
      await elementUpdated(element);
      oneEvent(insertReview, 'files-added');
      await expect(element.reviewerFileData.length).to.be.eq(1);
    });

    it('Save button should disabled when insert review message, files and reviewers fields are empty', async () => {
      const saveBtn = await element?.shadowRoot?.getElementById('insert-review-btn');
      await expect(saveBtn.disabled).to.be.eq(true);
    });

    it('Save button should enabled when insert review message, files and reviewers fields have value', async () => {
      element.reviewerMessage = 'test';
      element.reviewerFileData = [
        { id: 1, isSaved: true },
        { id: 2, isSaved: true },
      ];
      element.reviewData.status = 'IN REVISIONE';
      element.reviewer = 'test@gmail.com';
      await elementUpdated(element);
      const saveBtn = await element?.shadowRoot?.getElementById('insert-review-btn');
      await expect(saveBtn.disabled).to.be.eq(false);
    });

    it('It should disabled requestReview fields', async () => {
      element.reviewData.status = 'APPROVATO';
      element.disableRequestReviewFields = true;
      await elementUpdated(element);
      await isCheckDisabled('[reviewtextarea]');
      await isCheckDisabled('.save-button [data-tag-name="ing-button"]');
    });

    it('It should open request review dialog when request review btn pressed', async () => {
      const el = await element?.shadowRoot?.querySelector(
        '.save-button [data-tag-name="ing-button"]',
      );
      el.click();
      await elementUpdated(element);
      const dialog = await element?.shadowRoot?.querySelector('#dialog2');
      await expect(dialog.opened).to.be.eq(true);
    });

    it('It should open inserimento review dialog when inserimento review btn pressed', async () => {
      const el = await element?.shadowRoot?.querySelector('#insert-review-btn');
      el.click();
      await elementUpdated(element);
      const dialog = await element?.shadowRoot?.querySelector('#dialog2');
      await expect(dialog.opened).to.be.eq(true);
    });

    it('It should disabled requestReview fields when request review btn pressed', async () => {
      ajaxInstance.get = Sinon.stub();
      ajaxInstance.get.resolves({ data: { itemsVersionsID: 1 } });
      ajaxInstance.post = Sinon.stub();
      ajaxInstance.post.resolves({ data: { itemsVersionsID: 1 } });
      ajaxInstance.put = Sinon.stub();
      ajaxInstance.put.resolves({ data: { itemsVersionsID: 1 } });
      element.getVersionItemDetail = Sinon.stub();
      element.getVersionItemDetail.resolves({ data: element.documentData });
      await elementUpdated(element);
      element._closeDialog({
        detail: {
          confirmationMessageDetail: {
            type: 'requestReview',
          },
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      // await isCheckDisabled('[reviewtextarea]');
      await isCheckDisabled('.save-button [data-tag-name="ing-button"]');
    });

    it('It should disabled insertReview fields when insert review btn pressed', async () => {
      ajaxInstance.get = Sinon.stub();
      ajaxInstance.get.resolves({ data: { itemsVersionsID: 1 } });
      ajaxInstance.post = Sinon.stub();
      ajaxInstance.post.resolves({ data: { itemsVersionsID: 1 } });
      ajaxInstance.put = Sinon.stub();
      ajaxInstance.put.resolves({ data: { itemsVersionsID: 1 } });
      ajaxInstance.patch = Sinon.stub();
      ajaxInstance.patch.resolves({ data: { itemsVersionsID: 1 } });
      element.getVersionItemDetail = Sinon.stub();
      element.getVersionItemDetail.resolves({ data: element.documentData });
      await elementUpdated(element);
      element._closeDialog({
        detail: {
          confirmationMessageDetail: {
            type: 'insertReview',
          },
        },
      });
      await elementUpdated(element);
      await aTimeout(200);
      await isCheckDisabled('[reviewertextarea]');
      await isCheckDisabled('#reviewer');
      await isCheckDisabled('[name="reviewStatus"]');
      await isCheckDisabled('#insert-review-btn');
    });

    it('It should disabled insertReview fields', async () => {
      element.reviewData.status = 'APPROVATO';
      element.disableReviewFields = true;
      await elementUpdated(element);
      await isCheckDisabled('[reviewertextarea]');
      await isCheckDisabled('#reviewer');
      await isCheckDisabled('[name="reviewStatus"]');
      await isCheckDisabled('#insert-review-btn');
    });
  });
});
