import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import { ComponentAssociationCE } from './test-class.js';

describe('SubSection Tests', () => {
  const tag = unsafeStatic(defineCE(ComponentAssociationCE));

  describe('Structure', () => {
    let element;
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });

    // it('It Should bind correct label text when currentstep changed as subsection', async () => {
    //   element._currentStep = 'subsection';
    //   await elementUpdated();
    //   const str2 = element.shadowRoot.querySelector('[name="str2"]');
    //   aTimeout(200);
    //   await expect(str2.label).equal('SELEZIONA LE RIGA DA INCLUDERE NELLA SOTTO - SEZIONE');
    // });

    // it('It Should bind correct label text when currentstep changed as section', async () => {
    //   element._currentStep = 'section';
    //   await elementUpdated();
    //   const str2 = element.shadowRoot.querySelector('[name="str2"]');
    //   aTimeout(200);
    //   await expect(str2.label).equal('SELEZIONA LE SOTTO-SEZIONI DA INCLUDERE NELLA SEZIONE');
    // });

    it('It Should add the items into filter array list', async () => {
      await element.filterSelectedRows(element.str1);
      aTimeout(200);
      await expect(element.filterArrList2.length).to.be.eq(2);
    });

    it('It Should be attached rows into sub sections', async () => {
      element.filterArrList2 = element._arrList2;
      await elementUpdated();
      const btn = element.shadowRoot.querySelector('.row-defination-btn');
      setTimeout(() => btn.click());
      await oneEvent(element, 'associated-list');
      aTimeout(200);
      // await expect(element.filterArrList2.length).to.be.eq(1);
      // await expect(element.filterChipsList.length).to.be.eq(1);
    });

    it('Chip should be removed when delete event is fired', async () => {
      element.filterArrList2 = [element._arrList2[1]];
      element.selectedList = [
        {
          id: '1',
          name: 'SubSection1',
          lists: [
            {
              id: '1',
              name: 'Rows1',
            },
          ],
        },
      ];
      element.filterChipsList = [element._arrList2[0]];
      await elementUpdated();

      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('removable-chip'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('chip-deleted', {
            detail: { id: '1' },
          }),
        ),
      );
      aTimeout(200);
      await oneEvent(el, 'chip-deleted');
      aTimeout(200);
      await expect(element.filterArrList2.length).to.be.eq(2);
      await expect(element.filterChipsList.length).to.be.eq(0);
    });
  });
});
