import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import { CreateRowCE } from './test-class.js';

describe('CreateRowCE Tests', () => {
  const tag = unsafeStatic(defineCE(CreateRowCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (el, selector, eventName, value = 'test') => {
      const parent = el || element;
      const input = await parent?.shadowRoot?.querySelector(`[name="${selector}"]`);
      if (selector === 'validity') {
        input.modelValue = value;
      } else {
        input.value = value;
      }
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It binds the name field', async () => {
      const input = await populateInput(null, 'name', 'keyup');
      await aTimeout(300);
      expect(element.name).to.equal(input.value);
    });
    it('It binds the validity field', async () => {
      const dateValue = new Date('10-10-2022');
      await populateInput(null, 'validity', 'change', dateValue);
      await aTimeout(300);
      expect(element.validity).to.equal('2022-10-10');
    });
    it('It binds the rowStyle field', async () => {
      const style = await populateInput(null, 'rowStyle', 'change', '2');
      await aTimeout(300);
      expect(element.rowStyle).to.equal(style.value);
    });

    it('It binds data to save-row event', async () => {
      const dateValue = new Date();
      await populateInput(null, 'name', 'keyup');
      await populateInput(null, 'validity', 'change', dateValue);
      await populateInput(null, 'rowStyle', 'change', '2');
      await elementUpdated(element);
      const btn = await element?.shadowRoot?.querySelector('.save_button');
      setTimeout(() => btn.click());
      const { detail } = await oneEvent(element, 'save-row');
      expect(detail.id).to.equal(element.id);
      expect(detail.name).to.equal(element.name);
      expect(detail.validty).to.equal(element.validty);
      expect(detail.style).to.equal(element.rowStyle);
    });
    it('It binds id to remove-row event', async () => {
      const btn = await element?.shadowRoot?.querySelector('.cancel_button');
      setTimeout(() => btn.click());
      const { detail } = await oneEvent(element, 'remove-row');
      expect(detail.id).to.equal(element.id);
    });

    it('It should bind the annulla text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.cancel_button');
      await expect(ele.innerText).to.equal('Annulla');
    });

    it('It should bind the Aggiungi e Chiudi text', async () => {
      element.isExistingDocument = true;
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.save_button');
      await expect(ele.innerText).to.equal('Aggiungi e Chiudi');
    });

    it('Row change should be triggered', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-defination'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('row-changed', {
            detail: {
              id: 1,
            },
          }),
        ),
      );
      aTimeout(200);
      const { detail } = await oneEvent(el, 'row-changed');
      expect(detail?.id).to.equal(1);
    });

    it('It should be triggered if new row is created', async () => {
      element.columns = [];
      element.columnNotes = [];
      await elementUpdated(element);
      await aTimeout(200);
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-defination'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('columns-changed', {
            detail: {
              data: [
                {
                  id: 2,
                  name: '',
                  description: '',
                  isBold: 'false',
                  isItalic: 'false',
                  note: '',
                  column: '',
                  isNew: true,
                },
                {
                  id: 3,
                  name: '',
                  description: '',
                  isBold: 'false',
                  isItalic: 'false',
                  note: '',
                  column: '',
                  isNew: true,
                },
              ],
              isDelete: true,
            },
          }),
        ),
      );
      aTimeout(200);
      await oneEvent(el, 'columns-changed');
      expect(element.columns.length).to.equal(1);
    });

    it('It should be triggered if versionID is changed', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('row-defination'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('versionID-changed', {
            detail: 1,
          }),
        ),
      );
      aTimeout(200);
      const { detail } = await oneEvent(el, 'versionID-changed');
      expect(detail).to.equal(1);
    });
    it('It should Enable the button', async () => {
      element.columns = [
        {
          id: '36644-35953-28875',
          name: 1,
          description: 'abc',
          isBold: false,
          isItalic: false,
          column: '',
          note: '',
        },
      ];
      await populateInput(null, 'name', 'keyup');
      await aTimeout(200);
      await elementUpdated(element);
      const ele = await element?.shadowRoot?.querySelector('.save_button');
      await expect(ele.disabled).to.be.eq(false);
    });
  });
});
