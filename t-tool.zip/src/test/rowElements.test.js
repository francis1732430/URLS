import {
  expect,
  fixture,
  html,
  unsafeStatic,
  defineCE,
  fixtureCleanup,
  aTimeout,
  oneEvent,
  elementUpdated,
} from '@open-wc/testing';

import { RowElementsCE } from './test-class.js';

describe('RowElements Tests', () => {
  const tag = unsafeStatic(defineCE(RowElementsCE));

  describe('Structure', () => {
    let element;
    const populateInput = async (el, selector, eventName, value = 'test') => {
      const parent = el || element;
      const input = await parent?.shadowRoot?.querySelector(`[name="${selector}"]`);
      input.value = value;
      input.dispatchEvent(new Event(eventName));
      return input;
    };
    beforeEach(async () => {
      element = await fixture(html`<${tag}></${tag}>`);
    });

    afterEach(() => {
      fixtureCleanup();
    });

    it('It Exists', async () => {
      await expect(element).to.exist;
    });
    it('It binds the selectVal field', async () => {
      const select = await element?.shadowRoot?.querySelector(
        `${element.constructor.getScopedTagName('ing-select')}[name="selectVal"]`,
      );
      select.value = '2';
      setTimeout(() => select.dispatchEvent(new Event('change')));
      await aTimeout(500);
      expect(element.selectVal).to.equal(select.value);
    });
    // it('It binds the select2Val field', async () => {
    //   const select2 = await element?.shadowRoot?.querySelector(
    //     `${element.constructor.getScopedTagName('ing-select')}[name="select2Val"]`,
    //   );
    //   select2.value = '2';
    //   setTimeout(() => select2.dispatchEvent(new Event('change')));
    //   await waitUntil(() => element.select2Val === '2', 'Element to be Updated', {
    //     interval: 50,
    //     timeout: 10000,
    //   });
    //   expect(element.select2Val).to.equal(select2.value);
    // });
    it('It binds the name field', async () => {
      element = await fixture(html`<${tag}></${tag}>`);
      element.selectLabel = undefined;
      await elementUpdated(element);
      const input = await populateInput(element, 'input1Val', 'keyup');
      await aTimeout(500);
      expect(element.input1Val).to.equal(input.value);
    });
    it('It binds the description field', async () => {
      // element = await fixture(html`<${tag} selectLabel=${undefined}></${tag}>`);
      element.selectLabel = undefined;
      await elementUpdated(element);
      const input = await populateInput(element, 'input2Val', 'keyup');
      await aTimeout(500);
      expect(element.input2Val).to.equal(input.value);
    });
    it('It binds the Bold field', async () => {
      // element = await fixture(html`<${tag} selectLabel=${undefined}></${tag}>`);
      element.selectLabel = undefined;
      element.radioLabel = 'radio';
      await elementUpdated(element);
      const checkbox = await element?.shadowRoot?.querySelector(
        `${element.constructor.getScopedTagName('ing-checkbox')}[name="isBold"]`,
      );
      checkbox.checked = 'true';
      setTimeout(() => checkbox.dispatchEvent(new Event('change')));
      await aTimeout(500);
      expect(element.isBold).to.equal(checkbox.checked);
    });
    it('It binds id to checked-fields event', async () => {
      // element = await fixture(html`<${tag} selectLabel=${undefined}></${tag}>`);
      element.selectLabel = undefined;
      element.radioLabel = 'radio';
      await elementUpdated(element);
      const checkbox = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('ing-checkbox'),
      );
      checkbox.checked = true;
      setTimeout(() => checkbox.dispatchEvent(new Event('change')));
      const { detail } = await oneEvent(element, 'checked-fields');
      expect(detail.id).to.equal(element.id);
    });

    it('It binds the Italic field', async () => {
      // element = await fixture(html`<${tag} selectLabel=${undefined}></${tag}>`);
      element.selectLabel = undefined;
      element.radioLabel = 'radio';
      await elementUpdated(element);
      const checkbox = await element?.shadowRoot?.querySelector(
        `${element.constructor.getScopedTagName('ing-checkbox')}[name="isItalic"]`,
      );
      checkbox.checked = 'true';
      setTimeout(() => checkbox.dispatchEvent(new Event('change')));
      await aTimeout(500);
      expect(element.isItalic).to.equal(checkbox.checked);
    });

    it('It should change selected note', async () => {
      const el = await element?.shadowRoot?.querySelector(
        element.constructor.getScopedTagName('custom-select'),
      );
      setTimeout(() =>
        el.dispatchEvent(
          new CustomEvent('value-change', {
            detail: {
              selectedOptions: [
                {
                  id: '1',
                  name: 'test',
                  columnNoteId: '1_1',
                },
                {
                  id: '2',
                  name: 'test2',
                  columnNoteId: '1_2',
                },
              ],
            },
          }),
        ),
      );
      aTimeout(200);
      const { detail } = await oneEvent(el, 'value-change');
      expect(detail.selectedOptions.length).to.equal(2);
    });
  });
});
