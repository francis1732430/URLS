import {
  ScopedElementsMixin,
  LitElement,
  html,
  IngButton,
  IngChipChoice,
  IngChipChoiceGroup,
  IngInput,
  IngForm,
  IngSelect,
  IngTab,
  IngTabs,
  IngTabPanel,
  IngLink,
  IngPaginationLinks,
  IngDialog,
  IngDialogFrame,
} from 'ing-web';

import { IngTable } from './ing-table.js';

import styles from './DocumentListHomePageStyles.js';
import { filters } from './data/filters.js';
import { DocumentDetailsPage } from './DocumentDetailsPage.js';
import { NewDocumentCreation } from './components/document/creation/NewDocumentCreation.js';
import { RowCreation } from './components/document/creation/rowCreation.js';
import { RuleCreation } from './components/document/creation/Rules/RuleCreation.js';
import { Stepper } from './components/stepper/stepper.js';
import { CreateSubSection } from './components/document/creation/CreateSubSection.js';
import { CreateDocument } from './components/document/creation/CreateDocument.js';
import { DocumentCreatedSuccessfully } from './components/document/creation/DocumentCreatedSuccessfully.js';
import {
  sectionsHeader,
  subSectionsHeader,
  rowsHeader,
  notesHeader,
  rulesHeader,
} from './data/documentDetailsHeaders.js';
import { ElementFromScratch } from './createElementFromScratch.js';
import {
  transformNoteToFrontEnd,
  transformNotesListToFrontEnd,
  transformNotesIdsToBackend,
} from './data/tranformations/noteTransformation.js';
import {
  transformRowsToFrontEnd,
  transformRowsListToFrontEnd,
  transformRowsIdsToBackend,
} from './data/tranformations/rowTransformation.js';
import { transformSectionsToFrontEnd } from './data/tranformations/sectionTransformation.js';
import {
  transformSubSectionsToFrontEnd,
  transformSubSectionsListToFrontEnd,
  transformSubSectionsIdsToBackend,
} from './data/tranformations/subSectionsTransformation.js';
import { transformRulesToFrontEnd } from './data/tranformations/ruleTransformation.js';
import { ajaxInstance } from './utils/endpoints.js';
import {
  baseURL,
  baseURL2,
  baseURL3,
  localEnvironment,
  localStorageKeysMap,
  localStorageValuesMap,
} from './utils/constants.js';
import {
  transformDocumentsToFrontEnd,
  transformLookUpDataToFrontEnd,
} from './data/tranformations/documentTranformation.js';
import { ConfirmationDialog } from './components/dialog/ConfirmationDialog.js';
import { fetchChildItems, chunks, fetchChildItemsByStyle } from './utils/chunks.js';
import { deriveData } from './utils/globalApiKeys.js';
import {
  addElementToLocalStorage,
  removeAllElementsFromLocalStorage,
  removeElementFromLocalStorage,
  getHostURL,
  removeElementFromLocalStorageByKey,
  mapPropertyToObjectFromList,
  sortArray,
} from './utils/IngFeatTransparencyToolUtils.js';
import { messages } from './data/messages.js';

// creates a case insensitive filter
const buildFilter =
  (property = '', searchText = '') =>
  item =>
    (item?.[property] || '').toUpperCase().trim().includes(searchText.toUpperCase().trim());

function closeDialog(event) {
  if (event && event.target) {
    event.target.dispatchEvent(
      new Event('close-overlay', {
        bubbles: true,
      }),
    );
  }
}

export class DocumentListHomePage extends ScopedElementsMixin(LitElement) {
  static get scopedElements() {
    return {
      'ing-tabs': IngTabs,
      'ing-tab': IngTab,
      'ing-tab-panel': IngTabPanel,
      'ing-select': IngSelect,
      'ing-chip-choice-group': IngChipChoiceGroup,
      'ing-chip-choice': IngChipChoice,
      'ing-button': IngButton,
      'ing-form': IngForm,
      'ing-input': IngInput,
      'ing-table': IngTable,
      'document-details-page': DocumentDetailsPage,
      'ing-link': IngLink,
      'stepper-custom': Stepper,
      'new-document-creation': NewDocumentCreation,
      'row-creation': RowCreation,
      'rule-creation': RuleCreation,
      'create-sub-section': CreateSubSection,
      'create-document': CreateDocument,
      'document-created-successfully': DocumentCreatedSuccessfully,
      'ing-pagination-links': IngPaginationLinks,
      'element-from-scratch': ElementFromScratch,
      'confirmation-dialog': ConfirmationDialog,
      'ing-dialog': IngDialog,
      'ing-dialog-frame': IngDialogFrame,
    };
  }

  static get styles() {
    return styles;
  }

  static get properties() {
    return {
      _displayData: { type: Array },
      _selectedValue: { type: Object },
      _searchText: { type: String },
      tabCount: { type: Number },
      _selectedTabIndex: { type: Number },
      subSectionsList: { type: Array },
      sectionsList: { type: Array },
      showSuccessStep: Boolean,
      documentData: Object,
      currentPage: Number,
      totalPage: Number,
      _filter: Object,
      documentDupList: Array,
      tabsData: Array,
      _stepIndex: Number,
      notesData: Array,
      rowData: Array,
      ruleData: Array,
      selectedSubSectionList: Array,
      selectedSectionList: Array,
      existingElementSubsection: Array,
      existingElementRows: Array,
      existingElementNotes: Array,
      rowsMappingList: Array,
      subSectionMappingList: Array,
      notesMappingList: Array,
      disableBackButtons: Boolean,
      confirmationMessageDetail: Object,
      _lastStepIndex: Number,
      appliedToElements: Array,
      lookupData: Array,
      savedChildList: Array,
      savedChildListSubSection: Array,
      isShowReviewTab: { type: Boolean, reflect: true },
      savedChildListRule: Array,
      savedChildListRow: Array,
    };
  }

  constructor() {
    super();
    this.filters = filters;
    // this.data = documents;
    this.data = [];

    this._displayData = [];
    this.tabCount = 2;
    this._selectedTabIndex = 0; // tab index to focus
    this.subSectionsList = [];
    this.sectionsList = [];
    this.showSuccessStep = false;
    this.pagePerItem = 25;
    this.currentPage = 1;
    this.tabsData = [];
    this._stepIndex = 0;
    this.notesData = [];
    this.rowData = [];
    this.ruleData = [];
    this.selectedSubSectionList = [];
    this.selectedSectionList = [];
    this.documentDupList = [];
    this.existingElementSubsection = [];
    this.existingElementRows = [];
    this.existingElementNotes = [];
    this.subSectionMappingList = [];
    this.rowsMappingList = [];
    this.notesMappingList = [];
    this.disableBackButtons = false;
    this.getAPIMapper = {
      Regole: 'REGOLA',
      Sezioni: 'SEZIONE',
      Righe: 'RIGA',
      Nota: 'NOTA',
      'Sotto Sezioni': 'SOTTOSEZIONE',
    };
    this.ajaxInstance = ajaxInstance;
    this.confirmationMessageDetail = {};
    this._lastStepIndex = 0;
    this.savedSection = [];
    this.savedSubSection = [];
    this.valueChangedSubSection = [];
    this.valueChangedSection = [];
    this.valueChangedRow = [];
    this.savedRow = [];
    this.valueChangedNote = [];
    this.savedNote = [];
    this.valueChangedRule = [];
    this.savedRule = [];
    this.appliedToElements = [];
    this.lookupData = [];
    this.savedChildList = [];
    this.savedChildListSubSection = [];
    this.savedChildListRule = [];
    this.savedChildListRow = [];
    this.urlHashed = getHostURL();
    this.isShowReviewTab = false;
  }

  async connectedCallback() {
    super.connectedCallback();
    await this.loadLookupData();
    await this.getDocumentListByDocumentId();
  }

  async updated(changed) {
    super.updated(changed);
    if (
      changed.has('_selectedTabIndex') &&
      this._selectedTabIndex === 1 &&
      this.lookupData?.length === 0
    ) {
      await this.loadLookupData();
    }
  }

  async loadLookupData() {
    const res = await this.getLookUpDataList();
    this.lookupData = deriveData(res?.data);
    const list = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE') || [];
    this.appliesToElements = [
      {
        id: '0',
        name: 'Select Element',
      },
      ...list,
    ];
  }

  async getDocumentListByDocumentId() {
    await this.makeDocumentsAjaxCall(transformDocumentsToFrontEnd);
    // this.data = [...this.documentDupList, ...this.data];
    this._displayData = [...this.data]; // TODO: remove after ajax invocation
    this.getTotalPage();
    if (this._selectedValue) {
      const index = this._displayData.findIndex(
        item => this._selectedValue?.id?.toString() === item?.id?.toString(),
      );
      if (index > -1) {
        this.currentPage = Math.round((index + 1) / this.pagePerItem);
        this.currentPage = this.currentPage ? this.currentPage : 1;
      }
    }
    this.sliceItems(this._selectedValue);
  }

  firstUpdated() {
    this.loadDefaultData();
    // this._populateDataFromLocalStorage();
    removeAllElementsFromLocalStorage();
  }

  loadDefaultData(isHideLoad) {
    const notesList = [];
    const rowsList = [];
    const subsectionList = [];
    if (this.existingElementNotes?.length > 0) {
      this.existingElementNotes.forEach(note1 => {
        const index = this.notesMappingList.findIndex(
          note2 => note1?.toString() === note2?.id?.toString(),
        );
        if (index > -1) {
          notesList.push(this.notesMappingList[index]);
        }
      });
    }
    if (this.existingElementRows?.length > 0) {
      this.existingElementRows.forEach(note1 => {
        const index = this.rowsMappingList.findIndex(
          note2 => note1?.toString() === note2?.id?.toString(),
        );
        if (index > -1) {
          rowsList.push(this.rowsMappingList[index]);
        }
      });
    }
    if (this.existingElementSubsection?.length > 0) {
      this.existingElementSubsection.forEach(note1 => {
        const index = this.subSectionMappingList.findIndex(
          note2 => note1?.toString() === note2?.id?.toString(),
        );
        if (index > -1) {
          subsectionList.push(this.subSectionMappingList[index]);
        }
      });
    }
    this.subSectionMappingList = this.subSectionsList.filter(item => !item.isNotSaved);
    this.rowsMappingList = this.rowData.filter(item => !item.isNotSaved);
    this.notesMappingList = this.notesData.filter(item => !item.isNotSaved);
    if (notesList.length) {
      this.notesMappingList = [...this.notesMappingList, ...notesList];
      this.notesMappingList = this.notesMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
    }
    if (rowsList.length) {
      this.rowsMappingList = [...this.rowsMappingList, ...rowsList];
      this.rowsMappingList = this.rowsMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
    }
    if (subsectionList.length) {
      this.subSectionMappingList = [...this.subSectionMappingList, ...subsectionList];
      this.subSectionMappingList = this.subSectionMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
    }
    if (!isHideLoad) {
      this.savedRow = this.rowsMappingList;
      this.savedChildListSubSection = this.subSectionMappingList;
      this.savedChildListRow = this.rowsMappingList;
      this.savedChildList = this.sectionsList.filter(item => !item.isNotSaved);
      this.savedChildListRule = this.ruleData.filter(item => !item.isNotSaved);
    }
  }

  _populateDataFromLocalStorage() {
    Object.keys(localStorageValuesMap).forEach(key => {
      const data = localStorage.getItem(localStorageKeysMap[localStorageValuesMap[key]]);
      const parsedData = data && JSON.parse(data);
      if (parsedData && Array.isArray(parsedData)) {
        this[key] = parsedData;
      } else if (parsedData && parsedData.product && parsedData.type) {
        this[key] = parsedData;
      }
    });
  }

  _applyFilter() {
    const shadow = this.shadowRoot;
    this._searchText = shadow.getElementById('searchText').modelValue;
    if (!this._filter || !this._searchText) {
      this._displayData = [...this.data];
      this.getTotalPage();
      this.sliceItems();
      return;
    }
    this.currentPage = 1;
    const text =
      this._filter.name === 'start_date'
        ? this._searchText.trim().split('/').reverse().join('-')
        : this._searchText;
    const filterFn = buildFilter(this._filter.name, text);
    this._displayData = this.data.filter(filterFn);
    // eslint-disable-next-line no-console
    console.log(this._displayData);
    this.getTotalPage();
    this.sliceItems();
  }

  async _openDocumentDetails() {
    // eslint-disable-next-line no-console
    console.log(this._selectedValue);

    // open document details tab
    this.tabCount += 1;
    this._selectedTabIndex = 2;
    if (!this._selectedValue?.status && this._selectedValue?.id) {
      const res = await this._getVersionItemDetail(this._selectedValue?.id);
      const data = transformDocumentsToFrontEnd(res?.data);
      this._cloneRecord(this._selectedValue, data);
      this._selectedValue = { ...this._selectedValue };
    }
    const modifyEvent = new CustomEvent('homepage-modify', {
      detail: {
        data: this._selectedValue,
      },
    });
    this.dispatchEvent(modifyEvent);
  }

  // eslint-disable-next-line
  _cloneRecord(orginalObj, newObj) {
    // eslint-disable-next-line no-restricted-syntax
    for (const i in newObj) {
      if (newObj[i]) {
        // eslint-disable-next-line guard-for-in
        // eslint-disable-next-line no-param-reassign
        orginalObj[i] = newObj[i];
      }
    }
  }

  _setFilter(filter) {
    this._filter = filter;
    // eslint-disable-next-line no-console
    console.log(this._filter);
  }

  _checkText() {
    const component = this.shadowRoot.getElementById('searchText');
    component.modelValue = '';
    this.searchText = '';
  }

  _setSelectedElement(event) {
    this._selectedValue = event.currentTarget.data;
    // eslint-disable-next-line no-console
    console.log(this._selectedValue);
  }

  _viewDocumentDetails(event) {
    this._selectedValue = event.detail.data;
    // eslint-disable-next-line no-console
    console.log(this._selectedValue);
    const ev1 = new CustomEvent('select-document', { detail: { data: this._selectedValue } });
    this.dispatchEvent(ev1);
  }

  _closeTab(event) {
    const tabTitle = event.detail.title;
    // eslint-disable-next-line no-console
    console.log(tabTitle);
    this.tabCount -= 1;
    this._selectedTabIndex = 0; // focus on main tab
  }

  async __handleAppendClick() {
    const selectedRowEvent = new CustomEvent('homepage-review', {
      detail: {
        data: this._selectedValue,
      },
    });
    this.dispatchEvent(selectedRowEvent);
  }

  // eslint-disable-next-line class-methods-use-this
  deepObjectIteration(data1) {
    return JSON.parse(JSON.stringify({ ...data1 }));
  }

  _addSubSection(ev) {
    const { list, data1, savedChildList: childList } = ev.detail;
    this.subSectionsList = [...list];
    this.subSectionMappingList = this.subSectionsList.filter(item => !item.isNotSaved);
    const index = this.savedSubSection.findIndex(
      subSection => subSection?.id?.toString() === data1?.id?.toString(),
    );
    if (index === -1 && data1) {
      this.savedSubSection.push(this.deepObjectIteration(data1));
    } else if (index > -1 && data1) {
      this.savedSubSection[index] = this.deepObjectIteration(data1);
    }
    this.rowsMappingList = this.rowData
      .filter(item => !item.isNotSaved)
      ?.map(item => {
        const item2 = { ...item };
        item2.parentId = data1.id;
        return item2;
      });
    let sList = [];
    const data5 = localStorage.getItem(localStorageKeysMap[localStorageValuesMap.rowsMappingList]);
    const parsedData = data5 && JSON.parse(data5);
    if (parsedData && Array.isArray(parsedData)) {
      sList = parsedData;
    } else if (parsedData && parsedData.product && parsedData.type) {
      sList = parsedData;
    }
    this.rowsMappingList = [...this.rowsMappingList, ...sList];
    this.rowsMappingList = this.rowsMappingList.filter(
      (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
    );
    this.savedChildListSubSection = [...childList];
    this.subSectionMappingList = [...this.subSectionMappingList];
    addElementToLocalStorage(
      this.subSectionMappingList,
      localStorageKeysMap.APPLICATION_SUBSECTION_MAPPING,
      true,
    );
  }

  _fieldValuesChangedBySection(ev) {
    const { id } = ev.detail;
    const index = this.valueChangedSection.findIndex(data => data?.toString() === id?.toString());
    if (index === -1) {
      this.valueChangedSection.push(id);
    }
  }

  _fieldValuesChangedBySubSection(ev) {
    const { id } = ev.detail;
    const index = this.valueChangedSubSection.findIndex(
      data => data?.toString() === id?.toString(),
    );
    if (index === -1) {
      this.valueChangedSubSection.push(id);
    }
  }

  _fieldValuesChangedByRow(ev) {
    const { id } = ev.detail;
    const index = this.valueChangedRow.findIndex(data => data?.toString() === id?.toString());
    if (index === -1) {
      this.valueChangedRow.push(id);
    }
  }

  _fieldValuesChangedByNote(ev) {
    const { id } = ev.detail;
    const index = this.valueChangedNote.findIndex(data => data?.toString() === id?.toString());
    if (index === -1) {
      this.valueChangedNote.push(id);
    }
  }

  _fieldValuesChangedByRule(ev) {
    const { id } = ev.detail;
    const index = this.valueChangedRule.findIndex(data => data?.toString() === id?.toString());
    if (index === -1) {
      this.valueChangedRule.push(id);
    }
  }

  replaceUnSavedItemsForSection(isNeedTime) {
    if (this.valueChangedSection.length > 0) {
      this.valueChangedSection.forEach(id => {
        const index = this.savedSection.findIndex(
          section => section?.id?.toString() === id?.toString(),
        );
        if (index > -1) {
          const data = this.savedSection[index];
          // this.savedSection.splice(index, 1);
          const index1 = this.sectionsList.findIndex(
            section => section?.id?.toString() === id?.toString(),
          );
          if (index1 > -1) {
            this.sectionsList[index1] = this.deepObjectIteration(data);
          }
        }
      });

      if (!isNeedTime) {
        const sectionsList1 = this.sectionsList;
        this.sectionsList = [];
        setTimeout(() => {
          this.sectionsList = [...sectionsList1];
          this.subSectionMappingList = [...this.subSectionMappingList];
          this.valueChangedSection = [];
        });
      }
    }
  }

  replaceUnSavedItemsForSubSection(isNeedTime) {
    if (this.valueChangedSubSection.length > 0) {
      this.valueChangedSubSection.forEach(id => {
        const index = this.savedSubSection.findIndex(
          subSection => subSection?.id?.toString() === id?.toString(),
        );
        if (index > -1) {
          const data = this.savedSubSection[index];
          // this.savedSubSection.splice(index, 1);
          const index1 = this.subSectionsList.findIndex(
            subSection => subSection?.id?.toString() === id?.toString(),
          );
          if (index1 > -1) {
            this.subSectionsList[index1] = this.deepObjectIteration(data);
          }
        }
      });

      if (!isNeedTime) {
        const subSectionsList1 = this.subSectionsList;
        this.subSectionsList = [];
        setTimeout(() => {
          this.subSectionsList = [...subSectionsList1];
          this.rowsMappingList = [...this.rowsMappingList];
          this.valueChangedSubSection = [];
        });
      }
    }
  }

  replaceUnSavedItemsForRow(isNeedTime) {
    if (this.valueChangedRow.length > 0) {
      this.valueChangedRow.forEach(id => {
        const index = this.savedRow.findIndex(row => row?.id?.toString() === id?.toString());
        if (index > -1) {
          const data = this.savedRow[index];
          // this.savedRow.splice(index, 1);
          const index1 = this.rowData.findIndex(row => row?.id?.toString() === id?.toString());
          if (index1 > -1) {
            this.rowData[index1] = this.deepObjectIteration(data);
          }
        }
      });

      if (!isNeedTime) {
        const rowsList1 = this.rowData;
        this.rowData = [];
        setTimeout(() => {
          this.rowData = [...rowsList1];
          this.notesMappingList = [...this.notesMappingList];
          this.valueChangedRow = [];
        });
      }
    }
  }

  replaceUnSavedItemsForNote() {
    if (this.valueChangedNote.length > 0) {
      this.valueChangedNote.forEach(id => {
        const index = this.savedNote.findIndex(note => note?.id?.toString() === id?.toString());
        if (index > -1) {
          const data = this.savedNote[index];
          // this.savedNote.splice(index, 1);
          const index1 = this.notesData.findIndex(note => note?.id?.toString() === id?.toString());
          if (index1 > -1) {
            this.notesData[index1] = this.deepObjectIteration(data);
          }
        }
      });

      const notesList1 = this.notesData;
      this.notesData = [];
      setTimeout(() => {
        this.notesData = [...notesList1];
        this.valueChangedNote = [];
      });
    }
  }

  replaceUnSavedItemsForRule() {
    if (this.valueChangedRule.length > 0) {
      this.valueChangedRule.forEach(id => {
        const index = this.savedRule.findIndex(rule => rule?.id?.toString() === id?.toString());
        if (index > -1) {
          const data = this.savedRule[index];
          // this.savedRule.splice(index, 1);
          const index1 = this.ruleData.findIndex(rule => rule?.id?.toString() === id?.toString());
          if (index1 > -1) {
            this.ruleData[index1] = this.deepObjectIteration(data);
          }
        }
      });

      const rulesList1 = this.ruleData;
      this.ruleData = [];
      setTimeout(() => {
        this.ruleData = [...rulesList1];
        this.valueChangedRule = [];
      });
    }
  }

  _addSection(ev) {
    const { list, data1, savedChildList: childList } = ev.detail;
    this.sectionsList = [...list];
    const index = this.savedSection.findIndex(
      section => section?.id?.toString() === data1?.id?.toString(),
    );
    if (index === -1 && data1) {
      this.savedSection.push(this.deepObjectIteration(data1));
    } else if (index > -1 && data1) {
      this.savedSection[index] = this.deepObjectIteration(data1);
    }
    this.sectionsList = [...this.sectionsList];
    this.subSectionMappingList = this.subSectionsList
      .filter(item => !item.isNotSaved)
      ?.map(item => {
        const item2 = { ...item };
        item2.parentId = data1.id;
        return item2;
      });
    let sList = [];
    const data5 = localStorage.getItem(
      localStorageKeysMap[localStorageValuesMap.subSectionMappingList],
    );
    const parsedData = data5 && JSON.parse(data5);
    if (parsedData && Array.isArray(parsedData)) {
      sList = parsedData;
    } else if (parsedData && parsedData.product && parsedData.type) {
      sList = parsedData;
    }
    this.subSectionMappingList = [...this.subSectionMappingList, ...sList];
    this.subSectionMappingList = this.subSectionMappingList.filter(
      (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
    );
    this.savedChildList = childList;
  }

  // eslint-disable-next-line class-methods-use-this
  _deleteData(data) {
    return this.ajaxInstance.delete(`${baseURL}/${data}`);
  }

  async _removedSubSection(ev) {
    const { id } = ev.detail;
    const isElementCheck = this.checkSubSectionExistsIntoSection(id);
    const isRuleCheck = this.checkElementExistsIntoRules(id, 'SOTTOSEZIONE');
    if (!isElementCheck && !isRuleCheck) {
      this.replaceUnSavedItemsForSubSection(true);
      try {
        const index = this.subSectionsList.findIndex(d => d?.id?.toString() === id?.toString());
        if (
          this.subSectionsList[index] &&
          this.subSectionsList[index].linkedElement !== true &&
          !this.subSectionsList[index]?.isNotSaved &&
          this.subSectionsList.length > 0
        ) {
          await this._deleteData(id);
        }
        const sssList = this.subSectionsList;
        const ssIndex = this.subSectionsList.findIndex(
          item => item?.id?.toString() === id?.toString(),
        );
        this.subSectionsList = ev.detail.data.filter(
          data => data?.id?.toString() !== id?.toString(),
        );
        this.subSectionMappingList = this.subSectionsList.filter(item => !item.isNotSaved);
        let sectionLinkedIds = [];
        removeElementFromLocalStorage(id, localStorageKeysMap.APPLICATION_SUBSECTIONS);
        if (ssIndex > -1) {
          // If removed subsection It should update the section and subsections -api calls should need
          if (!sssList[ssIndex].rows) {
            sssList[ssIndex].rows = [];
          }
          sectionLinkedIds = sectionLinkedIds.concat(
            sssList[ssIndex].rows.filter(
              item => item?.parentId?.toString() === sssList[ssIndex]?.id?.toString(),
            ),
          );
          this.deleteRowsAndNotes(sectionLinkedIds);
          this.subSectionsList = this.subSectionsList.map(item => {
            const item2 = { ...item };
            if (!item2.rows) {
              item2.rows = [];
            }
            sectionLinkedIds.forEach(item1 => {
              if (!this.checkRowsExistsIntoSubSection(item1.id)) {
                item2.rows = item2.rows.filter(
                  item3 => item3?.id?.toString() !== item1?.id?.toString(),
                );
              }
            });
            return item2;
          });
          this.sectionsList = this.sectionsList.map(item => {
            const item2 = { ...item };
            if (!item2.subSections) {
              item2.subSections = [];
            }
            if (!this.checkSubSectionExistsIntoSection(id)) {
              item2.subSections = item2.subSections.filter(
                item3 => item3?.id?.toString() !== id?.toString(),
              );
            }
            return item2;
          });
          addElementToLocalStorage(
            this.subSectionsList,
            localStorageKeysMap.APPLICATION_SUBSECTIONS,
            true,
          );
          addElementToLocalStorage(
            this.sectionsList,
            localStorageKeysMap.APPLICATION_SECTIONS,
            true,
          );
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._deleteData(data)', e);
      }
    } else if (isElementCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.SottoSezioniToSezioni || [];
      this.openDialog();
    } else if (isRuleCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.SottoSezioniToRegola || [];
      this.openDialog();
    }
    this.subSectionMappingList = [...this.subSectionMappingList];
    addElementToLocalStorage(
      this.subSectionMappingList,
      localStorageKeysMap.APPLICATION_SUBSECTION_MAPPING,
      true,
    );
  }

  deleteNotes(noteColumn) {
    if (noteColumn.length > 0) {
      this.notesData = this.notesData.filter(note => {
        if (!this.checkNotesExistsIntoRows(note.id)) {
          const index = noteColumn.findIndex(
            note1 => note1?.id?.toString() === note?.id?.toString(),
          );
          if (index > -1) {
            removeElementFromLocalStorage(note.id, localStorageKeysMap.APPLICATION_NOTES);
            return false;
          }
        }
        return true;
      });

      this.notesMappingList = this.notesMappingList.filter(item => {
        if (!this.checkNotesExistsIntoRows(item.id)) {
          const ssIndex = noteColumn.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (ssIndex > -1) {
            removeElementFromLocalStorage(item.id, localStorageKeysMap.APPLICATION_NOTES_MAPPING);
            return false;
          }
        }
        return true;
      });
      this.existingElementNotes = this.existingElementNotes.filter(item => {
        if (!this.checkNotesExistsIntoRows(item)) {
          const index = noteColumn.findIndex(item1 => item1?.id?.toString() === item?.toString());
          if (index > -1) {
            removeElementFromLocalStorage(
              item,
              localStorageKeysMap.APPLICATION_EXISTING_NOTES_MAPPING,
              true,
            );
            return false;
          }
        }
        return true;
      });
    }
  }

  deleteRowsAndNotes(rows) {
    let noteColumn = [];
    if (rows.length > 0) {
      this.rowData = this.rowData.filter(row => {
        if (!this.checkRowsExistsIntoSubSection(row.id)) {
          const index = rows.findIndex(row1 => row1?.id?.toString() === row?.id?.toString());
          if (index > -1) {
            noteColumn = noteColumn.concat(row.columnNotes);
            removeElementFromLocalStorage(row.id, localStorageKeysMap.APPLICATION_ROWS);
            return false;
          }
        }
        return true;
      });

      this.rowsMappingList = this.rowsMappingList.filter(item => {
        if (!this.checkRowsExistsIntoSubSection(item.id)) {
          const ssIndex = rows.findIndex(item1 => item1?.id?.toString() === item?.id?.toString());
          if (ssIndex > -1) {
            removeElementFromLocalStorage(item.id, localStorageKeysMap.APPLICATION_ROWS_MAPPING);
            return false;
          }
        }
        return true;
      });
      this.existingElementRows = this.existingElementRows.filter(item => {
        if (!this.checkRowsExistsIntoSubSection(item)) {
          const index = rows.findIndex(item1 => item1?.id?.toString() === item?.toString());
          if (index > -1) {
            removeElementFromLocalStorage(
              item,
              localStorageKeysMap.APPLICATION_EXISTING_ROWS_MAPPING,
              true,
            );
            return false;
          }
        }
        return true;
      });
    }
    this.deleteNotes(noteColumn);
    this.rowData = this.rowData.map(item => {
      const item2 = { ...item };
      noteColumn.forEach(item1 => {
        if (!this.checkNotesExistsIntoRows(item1.id)) {
          item2.columnNotes = item2.columnNotes.filter(item3 => item3.id !== item1.id);
        }
      });
      return item2;
    });
    addElementToLocalStorage(this.rowData, localStorageKeysMap.APPLICATION_ROWS, true);
  }

  deleteSubSectionsList(subSectionsList) {
    if (subSectionsList && subSectionsList.length > 0) {
      let rows = [];
      this.subSectionsList = this.subSectionsList.filter(item => {
        if (!this.checkSubSectionExistsIntoSection(item.id)) {
          const ssIndex = subSectionsList.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (ssIndex > -1) {
            rows = rows.concat(item.rows);
            removeElementFromLocalStorage(item.id, localStorageKeysMap.APPLICATION_SUBSECTIONS);
            return false;
          }
        }
        return true;
      });

      this.subSectionMappingList = this.subSectionMappingList.filter(item => {
        if (!this.checkSubSectionExistsIntoSection(item.id)) {
          const ssIndex = subSectionsList.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          if (ssIndex > -1) {
            removeElementFromLocalStorage(
              item.id,
              localStorageKeysMap.APPLICATION_SUBSECTION_MAPPING,
            );
            return false;
          }
        }
        return true;
      });

      this.existingElementSubsection = this.existingElementSubsection.filter(item => {
        if (!this.checkSubSectionExistsIntoSection(item)) {
          const index = subSectionsList.findIndex(
            item1 => item1?.id?.toString() === item?.toString(),
          );
          if (index > -1) {
            removeElementFromLocalStorage(
              item,
              localStorageKeysMap.APPLICATION_EXISTING_SUBSECTION_MAPPING,
              true,
            );
            return false;
          }
        }
        return true;
      });
      this.deleteRowsAndNotes(rows);

      this.subSectionsList = this.subSectionsList.map(item => {
        const item2 = { ...item };
        rows.forEach(item1 => {
          if (!this.checkRowsExistsIntoSubSection(item1.id)) {
            item2.rows = item2.rows.filter(
              item3 => item3?.id?.toString() !== item1?.id?.toString(),
            );
          }
        });
        return item2;
      });
      addElementToLocalStorage(
        this.subSectionsList,
        localStorageKeysMap.APPLICATION_SUBSECTIONS,
        true,
      );
    }
  }

  checkSubSectionExistsIntoSection(id) {
    return this.sectionsList.some(section => {
      if (section && section.subSections) {
        const index = section.subSections.findIndex(
          subSection => subSection?.id?.toString() === id?.toString(),
        );
        if (index > -1) {
          return true;
        }
      }
      return false;
    });
  }

  checkRowsExistsIntoSubSection(id) {
    return this.subSectionsList.some(subSection => {
      if (subSection && subSection.rows) {
        const index = subSection.rows.findIndex(row => row?.id?.toString() === id?.toString());
        if (index > -1) {
          return true;
        }
      }
      return false;
    });
  }

  checkNotesExistsIntoRows(id) {
    return this.rowData.some(row => {
      if (row && row.columnNotes) {
        const index = row.columnNotes.findIndex(note => note?.id?.toString() === id?.toString());
        if (index > -1) {
          return true;
        }
      }
      return false;
    });
  }

  checkElementExistsIntoRules(id, name) {
    const typeId = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE')?.find(
      item => item?.name?.toString() === name?.toString(),
    )?.id;
    return this.ruleData.some(rule => {
      if (rule && rule.actions) {
        const index = rule.actions.findIndex(
          item =>
            item?.appliedToRule?.toString() === id?.toString() &&
            item?.appliedToElement?.toString() === typeId?.toString(),
        );
        if (index > -1) {
          return true;
        }
      }
      return false;
    });
  }

  async _removedSection(ev) {
    const { id } = ev.detail;
    if (!this.checkElementExistsIntoRules(id, 'SEZIONE')) {
      this.replaceUnSavedItemsForSection(true);
      const index = this.sectionsList.findIndex(d => d?.id?.toString() === id?.toString());
      try {
        if (
          this.sectionsList[index] &&
          this.sectionsList[index].linkedElement !== true &&
          !this.sectionsList[index]?.isNotSaved &&
          this.sectionsList.length > 0
        ) {
          await this._deleteData(id);
        }
        const ssList = this.sectionsList;
        const ssIndex = this.sectionsList.findIndex(
          item => item?.id?.toString() === id?.toString(),
        );
        this.sectionsList = ev.detail.data.filter(data => data?.id?.toString() !== id?.toString());
        let sectionLinkedIds = [];
        removeElementFromLocalStorage(id, localStorageKeysMap.APPLICATION_SECTIONS);
        if (ssIndex > -1) {
          if (!ssList[ssIndex].subSections) {
            ssList[ssIndex].subSections = [];
          }
          sectionLinkedIds = sectionLinkedIds.concat(
            ssList[ssIndex].subSections.filter(
              item => item?.parentId?.toString() === ssList[ssIndex]?.id,
            ),
          );
          this.deleteSubSectionsList(sectionLinkedIds);
          this.sectionsList = this.sectionsList.map(item => {
            const item2 = { ...item };
            if (!item2.subSections) {
              item2.subSections = [];
            }
            sectionLinkedIds.forEach(item1 => {
              if (!this.checkSubSectionExistsIntoSection(item1.id)) {
                item2.subSections = item2.subSections.filter(
                  item3 => item3?.id?.toString() !== item1?.id?.toString(),
                );
              }
            });
            return item2;
          });
          addElementToLocalStorage(
            this.sectionsList,
            localStorageKeysMap.APPLICATION_SECTIONS,
            true,
          );
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._deleteData(data)', e);
      }
    } else {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.SottoSezioniToRegola || [];
      this.openDialog();
    }
    this.sectionsList = [...this.sectionsList];
  }

  _getTabIndex(name) {
    const tabs = this.shadowRoot.querySelectorAll(this.getScopedTagName('ing-tab'));
    let index;
    tabs.forEach((t, i) => {
      if (t.getAttribute('name') === name) {
        index = i;
      }
    });
    return index;
  }

  _closeTabForExistingElement(tabName) {
    return event => {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }

      this.tabsData = this.tabsData.filter(td => td.name !== tabName);
      // eslint-disable-next-line
      setTimeout(() => this._setTabIndex(this.tabsData.length + 1)());
    };
  }

  _selectTab(tabName) {
    return event => {
      event.preventDefault();
      const index = this._getTabIndex(tabName);
      setTimeout(() => this._setTabIndex(index)());
    };
  }

  async makeDocumentsAjaxCall(transformFn) {
    const url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=DOCUMENTO`;
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      list = deriveData(res.data);
      // eslint-disable-next-line no-unused-vars
      list = list.map(d => transformFn(d));
      // this.data = list;
      this.data = list;
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    }
  }

  async makeElementsAjaxCall(transformFn, tabName) {
    // eslint-disable-next-line no-console
    // , pageNumber = 1, searchText= '', total
    // eslint-disable-next-line no-console
    // const url = `${baseURL}/${this.getAPIMapper[tabName]}/all?page=${pageNumber || 1}&searchtext=${searchText}`;
    // eslint-disable-next-line no-console
    // const urlTotal = `${baseURL}/${this.getAPIMapper[tabName]}/total`;
    let url;
    if (localEnvironment.production) {
      // FOR ACTUAL USE
      url = `${baseURL}s?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
      if (this.getAPIMapper[tabName] === 'REGOLA') {
        url = `${baseURL}s?itemTypeKey=RULE_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
      }
    } else {
      // FOR MOCK USE
      url = `${baseURL}/${this.getAPIMapper[tabName]}/all?itemTypeKey=DOCUMENT_TYPE&itemTypeValue=${this.getAPIMapper[tabName]}`;
    }

    // eslint-disable-next-line no-console
    // totalRes = {}
    let list;
    try {
      const res = await this.ajaxInstance.get(url);
      // eslint-disable-next-line no-console
      // if(!pageNumber || pageNumber === 1)
      // eslint-disable-next-line no-console
      //   totalRes = await this.ajaxInstance.get(urlTotal);
      list = deriveData(res.data);
      list = list.map(d => transformFn(d));
      return { list, total: list.length };
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return { list: [], total: 0 };
    }
  }

  async getDocumentList(tabName, pageNumber, searchText, totalCount) {
    let list = [];
    let headerData;
    let propertyId;
    let total;

    if (tabName === 'Regole') {
      headerData = rulesHeader;
      propertyId = 'ruleId';
      // data.forEach(document => {
      //   if (document.rules) {
      //     list = list.concat(document.rules);
      //   }
      // });
      const data = await this.makeElementsAjaxCall(
        transformRulesToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
      total = data.total;
    }
    if (tabName === 'Sezioni') {
      headerData = sectionsHeader;
      propertyId = 'sectionId';
      // data.forEach(document => {
      //   if (document?.sections?.length > 0) {
      //     list = list.concat(document.sections);
      //   }
      // });
      const data = await this.makeElementsAjaxCall(
        transformSectionsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
      total = data.total;
    } else if (tabName === 'Sotto Sezioni') {
      headerData = subSectionsHeader;
      propertyId = 'subSectionId';
      // data.forEach(document => {
      //   if (document.sections) {
      //     document.sections.forEach(section => {
      //       if (section?.subSections?.length > 0) {
      //         list = list.concat(section.subSections);
      //       }
      //     });
      //   }
      // });
      const data = await this.makeElementsAjaxCall(
        transformSubSectionsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
      total = data.total;
    } else if (tabName === 'Righe') {
      headerData = rowsHeader;
      propertyId = 'rowId';
      // data.forEach(document => {
      //   if (document.sections) {
      //     document.sections.forEach(section => {
      //       if (section.subSections) {
      //         section.subSections.forEach(subSection => {
      //           if (subSection?.rows?.length > 0) {
      //             list = list.concat([...subSection.rows]);
      //           }
      //         });
      //       }
      //     });
      //   }
      // });

      const data = await this.makeElementsAjaxCall(
        transformRowsToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
      total = data.total;
    } else if (tabName === 'Nota') {
      headerData = notesHeader;
      propertyId = 'noteId';
      // data.forEach(document => {
      //   if (document.sections) {
      //     document.sections.forEach(section => {
      //       if (section.subSections) {
      //         section.subSections.forEach(subSection => {
      //           if (subSection.rows) {
      //             subSection.rows.forEach(row => {
      //               if (row?.notes?.length > 0) {
      //                 list = list.concat(row.notes);
      //               }
      //             });
      //           }
      //         });
      //       }
      //     });
      //   }
      // });

      const data = await this.makeElementsAjaxCall(
        transformNoteToFrontEnd,
        tabName,
        pageNumber,
        searchText,
        totalCount,
      );
      list = data.list;
      total = data.total;
    }
    return { list, headerData, propertyId, total };
  }

  async _getTabPaginatedSearchedData(event) {
    const { tabName, pageNumber, searchText, total } = event.detail;
    const tabs = [...this.tabsData];
    const tabIndex = tabs.findIndex(t => t.name === tabName);
    if (tabIndex > -1) {
      const { list, total: totalCount } = await this.getDocumentList(
        tabName,
        pageNumber,
        searchText,
        total,
      );
      tabs[tabIndex].list = list;
      tabs[tabIndex].total = totalCount;
    }
    this.tabsData = [...tabs];
  }

  async _generateTab(tabName) {
    const index = this.tabsData.findIndex(td => td.name === tabName);
    const focusOnTab = () => {
      setTimeout(() => {
        this._setTabIndex(this._getTabIndex(tabName))();
        window.scrollTo(0, 0);
      }, 200);
    };
    if (index === -1) {
      const { list, headerData, propertyId, total } = await this.getDocumentList(tabName);
      // eslint-disable-next-line no-console
      console.log(total);
      this.tabsData = [
        ...this.tabsData,
        {
          name: tabName,
          // TO BE changed back to list: list
          list: [...list],
          headerData,
          propertyId,
          selectedRow: undefined,
          // TO BE changed back to total: total
          total: 30,
        },
      ];
      this.lastStep = tabName;
      focusOnTab();
    } else {
      focusOnTab();
      this.lastStep = tabName;
    }
  }

  getTabTemplate(tabName, tabTitle, template, showCloseButton) {
    return html` <ing-tab name="${tabName}" @click="${this._selectTab(tabName)}" slot="tab"
        >${tabTitle}
        ${showCloseButton
          ? html`<button
              href=""
              class="close-tab"
              @click="${this._closeTabForExistingElement(tabName)}"
            >
              X
            </button>`
          : ''}</ing-tab
      >
      <ing-tab-panel slot="panel"> ${template} </ing-tab-panel>`;
  }

  loadDocumentDetailsTab() {
    return this.getTabTemplate(
      'details',
      `Documento ${this._selectedValue?.docId}`,
      html`<document-details-page
        .selectedDocument=${this._selectedValue}
        @close-tab-event="${this._closeTab}"
      ></document-details-page>`,
    );
  }

  _addDocument(e) {
    const { detail } = e;
    this.documentData = detail;
    this.showSuccessStep = true;
  }

  _cancelDocument() {
    this.showSuccessStep = false;
  }

  _clearDocumentCreationWizard() {
    this.sectionsList = [];
    this.subSectionsList = [];
    this.rowData = [];
    this.notesData = [];
    this.ruleData = [];
    this.subSectionMappingList = [];
    this.rowsMappingList = [];
    this.notesMappingList = [];
    this.selectedSubSectionList = [];
    this.selectedSectionList = [];
    this.existingElementSubsection = [];
    this.existingElementRows = [];
    this.existingElementNotes = [];
    this.savedSection = [];
    this.savedSubSection = [];
    this.valueChangedSubSection = [];
    this.valueChangedSection = [];
    this.valueChangedRow = [];
    this.savedRow = [];
    this.valueChangedNote = [];
    this.savedNote = [];
    this.valueChangedRule = [];
    this.savedRule = [];
    this.appliedToElements = [];
  }

  _removeDocument() {
    this._clearDocumentCreationWizard();
    this.tabsData = [];
    this._stepIndex = 0;
    this._lastStepIndex = 0;
    this.lookupData = [];
    this._setTabIndex(0)();
    removeAllElementsFromLocalStorage();
  }

  _setTabIndex(index) {
    return async () => {
      this._selectedTabIndex = index;
      const ev = new CustomEvent('set-tab-index-homepage', {
        detail: index,
      });
      this.dispatchEvent(ev);
      if (index === 0) {
        removeAllElementsFromLocalStorage();
        this._clearDocumentCreationWizard();
        await this.getDocumentListByDocumentId();
      }
      if (index === 1) {
        this.replaceUnSavedElements();
        if (!this.savedChildList?.length) {
          this.savedChildList = [];
        }
        if (!this.savedChildListSubSection?.length) {
          this.savedChildListSubSection = [];
        }
        if (!this.savedChildListRule.length) {
          this.savedChildListRule = [];
        }
        if (!this.savedChildListRow.length) {
          this.savedChildListRow = [];
        }

        this.savedChildList = JSON.parse(JSON.stringify(this.savedChildList));
        this.savedChildListSubSection = JSON.parse(JSON.stringify(this.savedChildListSubSection));
        this.savedChildListRule = JSON.parse(JSON.stringify(this.savedChildListRule));
        this.savedChildListRow = JSON.parse(JSON.stringify(this.savedChildListRow));
      }
      this.loadDefaultData(true);
      // this._populateDataFromLocalStorage();
    };
  }

  _checkFilter() {
    const documentFilter = this.shadowRoot.getElementById('document_filter');
    documentFilter.modelValue = '';
  }

  _resetFilter() {
    this._filter = undefined;
    this.searchText = '';
    this._selectedValue = undefined;
    this.currentPage = 1;
    this._checkText();
    this._checkFilter();
    this._applyFilter();
  }

  _pageChanged(event) {
    const { current } = event.target;
    // eslint-disable-next-line
    this.currentPage = current ? current : 1;
    this.sliceItems(this._selectedValue);
  }

  getTotalPage() {
    this.totalPage = Math.ceil(this._displayData.length / this.pagePerItem);
  }

  sliceItems(value) {
    const indexOfLastItem = this.pagePerItem * this.currentPage;
    const indexOfFirstItem = indexOfLastItem - this.pagePerItem;
    const displayPaginatedData = this._displayData.slice(indexOfFirstItem, indexOfLastItem);
    const shadow = this.shadowRoot;
    const childComponent = shadow.querySelector(this.constructor.getScopedTagName('ing-table'));
    childComponent.displayData = displayPaginatedData;
    // eslint-disable-next-line
    this._selectedValue = value ? value : undefined;
    childComponent._selectedValue = this._selectedValue;
  }

  get showPagination() {
    return this._displayData.length > this.pagePerItem;
  }

  async _noteChanged(event) {
    const { data, id, data2 } = event.detail;
    const isElementCheck = id && this.checkNotesExistsIntoRows(id);
    const isRuleCheck = id && this.checkElementExistsIntoRules(id, 'NOTA');
    if (id && !isElementCheck && !isRuleCheck) {
      try {
        const index = this.notesData.findIndex(e => e?.id?.toString() === id?.toString());
        if (!(this.notesData[index] && this.notesData[index].linkedElement === true)) {
          await this._deleteData(id);
        }
        this.notesData = data.filter(data1 => data1?.id?.toString() !== id?.toString());
        this.notesMappingList = this.notesData.filter(item => !item.isNotSaved);
        removeElementFromLocalStorage(id, localStorageKeysMap.APPLICATION_NOTES);
        if (id) {
          // If removed notes It should update the rows columnNotes -api calls should need
          this.rowData = this.rowData.map(item => {
            const item2 = { ...item };
            if (item2 && item2.columnNotes) {
              item2.columnNotes = item2.columnNotes.filter(
                note => note?.id?.toString() !== id?.toString(),
              );
            }
            return item2;
          });
          addElementToLocalStorage(this.rowData, localStorageKeysMap.APPLICATION_ROWS, true);
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._deleteData(data)', e);
      }
    } else if (!id && data2) {
      this.notesData = data.filter(data1 => data1?.id?.toString() !== id?.toString());
      this.notesMappingList = this.notesData.filter(item => !item.isNotSaved);
      const index = this.savedNote.findIndex(
        note => note?.id?.toString() === data2?.id?.toString(),
      );
      if (index === -1 && data2) {
        this.savedNote.push(this.deepObjectIteration(data2));
      } else if (index > -1 && data2) {
        this.savedNote[index] = this.deepObjectIteration(data2);
      }
      addElementToLocalStorage(this.notesData, localStorageKeysMap.APPLICATION_NOTES);
    } else if (id && isElementCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.NoteToRighe || [];
      this.openDialog();
    } else if (id && isRuleCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.NoteToRegola || [];
      this.openDialog();
    }

    this.notesMappingList = [...this.notesMappingList];
    addElementToLocalStorage(
      this.notesMappingList,
      localStorageKeysMap.APPLICATION_NOTES_MAPPING,
      true,
    );
  }

  filterNote(event) {
    const { notesData } = event.detail;
    if (notesData) {
      this.notesData = [...notesData];
      addElementToLocalStorage(this.notesData, localStorageKeysMap.APPLICATION_NOTES);
    }
  }

  filterRow(event) {
    const { rowData } = event.detail;
    if (rowData) {
      this.rowData = [...rowData];
      addElementToLocalStorage(this.rowData, localStorageKeysMap.APPLICATION_ROWS);
    }
  }

  filterRule(event) {
    const { rowData } = event.detail;
    if (rowData) {
      this.ruleData = [...rowData];
    }
  }

  async _rowChanged(event) {
    const { data, id, data2, savedChildList: childList } = event.detail;
    const isElementCheck = id && this.checkRowsExistsIntoSubSection(id);
    const isRuleCheck = id && this.checkElementExistsIntoRules(id, 'RIGA');
    if (id && !isElementCheck && !isRuleCheck) {
      this.replaceUnSavedItemsForRow(true);
      // If removed rows It should update the subsections rows -api calls should need
      try {
        const index = this.rowData.findIndex(e => e?.id?.toString() === id?.toString());
        if (!(this.rowData[index] && this.rowData[index].linkedElement === true)) {
          await this._deleteData(id);
        }
        const rList = this.rowData;
        const ssIndex = this.rowData.findIndex(item => item?.id?.toString() === id?.toString());
        this.rowData = data.filter(data1 => data1?.id?.toString() !== id?.toString());
        this.rowsMappingList = this.rowData.filter(item => !item.isNotSaved);
        removeElementFromLocalStorage(id, localStorageKeysMap.APPLICATION_ROWS);
        let sectionLinkedIds = [];
        if (ssIndex > -1) {
          if (!rList[ssIndex].columnNotes) {
            rList[ssIndex].columnNotes = [];
          }
          sectionLinkedIds = sectionLinkedIds.concat(
            rList[ssIndex].columnNotes.filter(
              item => item?.parentId?.toString() === rList[ssIndex]?.id?.toString(),
            ),
          );
          this.deleteNotes(sectionLinkedIds);
          this.rowData = this.rowData.map(item => {
            const item2 = { ...item };
            sectionLinkedIds.forEach(item1 => {
              if (!item2.columnNotes) {
                item2.columnNotes = [];
              }
              if (!this.checkNotesExistsIntoRows(item1.id)) {
                item2.columnNotes = item2.columnNotes.filter(
                  item3 => item3?.id?.toString() !== item1?.id?.toString(),
                );
              }
            });
            return item2;
          });
          this.subSectionsList = this.subSectionsList.map(item => {
            const item2 = { ...item };
            if (!item2.rows) {
              item2.rows = [];
            }
            if (!this.checkRowsExistsIntoSubSection(id)) {
              item2.rows = item2.rows.filter(item3 => item3?.id?.toString() !== id?.toString());
            }
            return item2;
          });
          addElementToLocalStorage(this.rowData, localStorageKeysMap.APPLICATION_ROWS, true);
          addElementToLocalStorage(
            this.subSectionsList,
            localStorageKeysMap.APPLICATION_SUBSECTIONS,
            true,
          );
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.log('failed this._deleteData(data)', e);
      }
    } else if (!id && data2) {
      this.rowData = data.filter(data1 => data1?.id?.toString() !== id?.toString());
      this.rowsMappingList = this.rowData.filter(item => !item.isNotSaved);
      const index = this.savedRow.findIndex(row => row?.id?.toString() === data2?.id?.toString());
      if (index === -1 && data2) {
        this.savedRow.push(this.deepObjectIteration(data2));
      } else if (index > -1 && data2) {
        this.savedRow[index] = this.deepObjectIteration(data2);
      }
      const notesMappingList = JSON.parse(
        JSON.stringify(this.notesData.filter(item => !item.isNotSaved) || []),
      );
      this.notesMappingList = notesMappingList.map(item => {
        const item2 = { ...item };
        item2.parentId = data2.id;
        delete item2.versionDetailLevel2ID;
        delete item2.versionDetailLevel1ID;
        return item2;
      });
      let sList = [];
      const data5 = localStorage.getItem(
        localStorageKeysMap[localStorageValuesMap.notesMappingList],
      );
      const parsedData = data5 && JSON.parse(data5);
      if (parsedData && Array.isArray(parsedData)) {
        sList = parsedData;
      } else if (parsedData && parsedData.product && parsedData.type) {
        sList = parsedData;
      }
      this.notesMappingList = [...this.notesMappingList, ...sList];
      this.notesMappingList = this.notesMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
    } else if (id && isElementCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.RigheToSottoSezioni || [];
      this.openDialog();
    } else if (id && isRuleCheck) {
      this.confirmationMessageDetail = {};
      this.confirmationMessageDetail.messages =
        messages?.existingElementAssociation?.RigheToRegola || [];
      this.openDialog();
    }
    this.rowsMappingList = [...this.rowsMappingList];
    addElementToLocalStorage(
      this.rowsMappingList,
      localStorageKeysMap.APPLICATION_ROWS_MAPPING,
      true,
    );
    this.savedChildListRow = childList;
  }

  _rowColumnChanged(event) {
    const { id, data, data2 } = event.detail;
    this.rowData = [...data];
    this.savedChildListRow = [...this.rowData];
    if (id && data2) {
      const index = this.savedRow.findIndex(row => row?.id?.toString() === data2?.id?.toString());
      if (index > -1 && data2) {
        if (Array.isArray(data2?.columns) && this.savedRow[index]?.columns) {
          this.savedRow[index].columns = data2?.columns;
        }
        if (Array.isArray(data2?.columnNotes) && this.savedRow[index]?.columnNotes) {
          this.savedRow[index].columnNotes = data2?.columnNotes;
        }
        this.savedRow[index] = this.deepObjectIteration(data2);
      }
    }
  }

  _ruleChanged(event) {
    const { data, data2, savedChildList: childList } = event.detail;
    this.ruleData = [...data];
    const index = this.savedRule.findIndex(rule => rule?.id?.toString() === data2?.id?.toString());
    if (index === -1 && data2) {
      this.savedRule.push(this.deepObjectIteration(data2));
    } else if (index > -1 && data2) {
      this.savedRule[index] = this.deepObjectIteration(data2);
    }
    this.savedChildListRule = childList;
    this.ruleData = [...this.ruleData];
  }

  _ruleColumnChanged(event) {
    const { id, data, index1 } = event.detail;
    const ruleData1 = JSON.parse(JSON.stringify(data));
    const data2 = ruleData1[index1];
    const actions = ruleData1[index1]?.actions;
    ruleData1[index1].actions = [];
    this.ruleData = [...ruleData1];
    setTimeout(() => {
      ruleData1[index1].actions = actions;
      this.ruleData = [...ruleData1];
    });
    if (id && data2) {
      const index = this.savedRule.findIndex(row => row?.id?.toString() === data2?.id?.toString());
      if (index > -1 && data2) {
        if (Array.isArray(data2?.conditions) && this.savedRule[index]?.conditions) {
          this.savedRule[index].conditions = data2?.conditions;
        }
        if (Array.isArray(data2?.actions) && this.savedRule[index]?.actions) {
          this.savedRule[index].actions = data2?.actions;
        }
        this.savedRule[index] = this.deepObjectIteration(data2);
      }
    }
  }

  _changedStepIndex(event) {
    const { data } = event.detail;
    this._stepIndex = data;
    this.loadExistingElementData();
    this.replaceUnSavedElements();
    if (!this.savedChildList?.length) {
      this.savedChildList = [];
    }
    if (!this.savedChildListSubSection?.length) {
      this.savedChildListSubSection = [];
    }
    if (!this.savedChildListRule?.length) {
      this.savedChildListRule = [];
    }
    if (!this.savedChildListRow?.length) {
      this.savedChildListRow = [];
    }

    this.savedChildList = JSON.parse(JSON.stringify(this.savedChildList));
    this.savedChildListSubSection = JSON.parse(JSON.stringify(this.savedChildListSubSection));
    this.savedChildListRule = JSON.parse(JSON.stringify(this.savedChildListRule));
    this.savedChildListRow = JSON.parse(JSON.stringify(this.savedChildListRow));

    this._populateDataFromLocalStorage();
    this.loadDefaultData(true);
  }

  replaceUnSavedElements() {
    if (this._lastStepIndex === 3) {
      this.replaceUnSavedItemsForSection();
    } else if (this._lastStepIndex === 2) {
      this.replaceUnSavedItemsForSubSection();
    } else if (this._lastStepIndex === 1) {
      this.replaceUnSavedItemsForRow();
    } else if (this._lastStepIndex === 0) {
      this.replaceUnSavedItemsForNote();
    } else if (this._lastStepIndex === 4) {
      this.replaceUnSavedItemsForRule();
    }
    this._lastStepIndex = this._stepIndex;
  }

  async loadExistingElementData() {
    if (this._stepIndex === 0 && this.existingElementNotes.length > 0) {
      try {
        this.disableBackButtons = true;
        const dataList = await this._getExistingData(this.existingElementNotes);
        const existingNotes = transformNotesListToFrontEnd(dataList);
        existingNotes.forEach(item => {
          const nIndex = this.notesData.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          const note1 = { ...item };
          if (!note1.validity) note1.validity = new Date().toLocaleDateString();
          // note1.validity = note1?.validity.split(/\D/).reverse().join('-');
          note1.linkedElement = true;
          if (nIndex > -1) {
            this.notesData[nIndex] = note1;
          } else {
            this.notesData.push(note1);
          }
        });
        this.notesData = [...this.notesData];
        this.notesMappingList = this.notesData.filter(item => !item.isNotSaved);
        this.savedNote = [...this.notesData];
        addElementToLocalStorage(this.notesData, localStorageKeysMap.APPLICATION_NOTES);
        removeElementFromLocalStorageByKey(localStorageKeysMap.APPLICATION_EXISTING_NOTES_MAPPING);
        this.existingElementNotes = [];
        this.disableBackButtons = false;
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log('Error', err);
        this.disableBackButtons = false;
      }
    } else if (this._stepIndex === 1 && this.existingElementRows.length > 0) {
      try {
        this.disableBackButtons = true;
        const dataList = await this._getExistingData(this.existingElementRows);
        const existingRows = transformRowsListToFrontEnd(dataList);
        const isColumnNotesExists = existingRows.some(rDetail => rDetail?.columnNotes?.length > 0);
        let notesData = {};
        if (isColumnNotesExists) {
          notesData = await this.makeElementsAjaxCall(transformNoteToFrontEnd, 'Nota');
        }
        existingRows.forEach(item => {
          const rIndex = this.rowData.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          const item2 = { ...item };
          item2.columnNotes = item2.columnNotes.map(note => {
            const note1 = { ...note };
            if (notesData?.list?.length) {
              mapPropertyToObjectFromList(notesData.list, note1);
            }
            note1.parentId = item2.id;
            delete note1.versionDetailLevel2ID;
            delete note1.versionDetailLevel1ID;
            this.notesMappingList.push(note1);
            this.existingElementNotes.push(note1.id);
            return note1;
          });
          this.notesMappingList = this.notesMappingList.filter(
            (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
          );
          this.existingElementNotes = this.existingElementNotes.filter(
            (v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i,
          );
          if (!item2.validity) item2.validity = new Date().toLocaleDateString();
          // item2.validity = item2?.validity.split(/\D/).reverse().join('-');
          item2.linkedElement = true;
          if (rIndex > -1) {
            this.rowData[rIndex] = item2;
          } else {
            this.rowData.push(item2);
          }
        });
        this.existingElementNotes = [...this.existingElementNotes];
        this.rowData = [...this.rowData];
        this.savedRow = [...this.rowData];
        addElementToLocalStorage(this.rowData, localStorageKeysMap.APPLICATION_ROWS);
        this.rowsMappingList = this.rowData.filter(item => !item.isNotSaved);
        removeElementFromLocalStorageByKey(localStorageKeysMap.APPLICATION_EXISTING_ROWS_MAPPING);
        addElementToLocalStorage(
          this.notesMappingList,
          localStorageKeysMap.APPLICATION_NOTES_MAPPING,
        );
        addElementToLocalStorage(
          this.existingElementNotes,
          localStorageKeysMap.APPLICATION_EXISTING_NOTES_MAPPING,
        );
        this.existingElementRows = [];
        this.disableBackButtons = false;
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log('Error', err);
        this.disableBackButtons = false;
      }
    } else if (this._stepIndex === 2 && this.existingElementSubsection.length > 0) {
      try {
        this.disableBackButtons = true;
        const dataList = await this._getExistingDataByStyle(this.existingElementSubsection);

        const existingSubSections = transformSubSectionsListToFrontEnd(dataList);
        existingSubSections.forEach(item => {
          const ssIndex = this.subSectionsList.findIndex(
            item1 => item1?.id?.toString() === item?.id?.toString(),
          );
          const subSection1 = { ...item };
          subSection1.rows = subSection1.rows.map(row => {
            const row1 = { ...row };
            row1.parentId = subSection1.id;
            this.existingElementRows.push(row1.id);
            return row1;
          });
          this.rowsMappingList = [
            ...this.rowsMappingList,
            ...subSection1.rows.filter(item3 => !item3.isNotSaved),
          ];
          this.rowsMappingList = this.rowsMappingList.filter(
            (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
          );
          this.existingElementRows = this.existingElementRows.filter(
            (v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i,
          );
          if (!subSection1.validity) subSection1.validity = new Date().toLocaleDateString();
          // subSection1.validity = subSection1?.validity?.split(/\D/).reverse().join('-');
          subSection1.linkedElement = true;
          if (ssIndex > -1) {
            this.subSectionsList[ssIndex] = subSection1;
          } else {
            this.subSectionsList.push(subSection1);
          }
        });
        this.existingElementRows = [...this.existingElementRows];
        this.subSectionsList = [...this.subSectionsList];
        this.savedSubSection = [...this.subSectionsList];
        addElementToLocalStorage(this.subSectionsList, localStorageKeysMap.APPLICATION_SUBSECTIONS);
        this.subSectionMappingList = this.subSectionsList.filter(item => !item.isNotSaved);
        removeElementFromLocalStorageByKey(
          localStorageKeysMap.APPLICATION_EXISTING_SUBSECTION_MAPPING,
        );
        addElementToLocalStorage(
          this.rowsMappingList,
          localStorageKeysMap.APPLICATION_ROWS_MAPPING,
        );
        addElementToLocalStorage(
          this.existingElementRows,
          localStorageKeysMap.APPLICATION_EXISTING_ROWS_MAPPING,
        );
        this.existingElementSubsection = [];
        this.disableBackButtons = false;
      } catch (err) {
        // eslint-disable-next-line no-console
        console.log('Error', err);
        this.disableBackButtons = false;
      }
    } else if (this._stepIndex === 4) {
      const lookupList = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE');
      const siApplicaList = ['NOTA', 'RIGA', 'SEZIONE', 'SOTTOSEZIONE'];
      const isExistsStatus = siApplicaList.some(item => {
        const index = lookupList.findIndex(item1 => item1?.name?.toString() === item?.toString());
        if (index > -1) {
          return false;
        }
        return true;
      });

      if (isExistsStatus) {
        const res = await this.getLookUpDataList();
        this.lookupData = deriveData(res?.data);
        const list = transformLookUpDataToFrontEnd(this.lookupData, 'DOCUMENT_TYPE') || [];
        this.appliesToElements = [
          {
            id: '0',
            name: 'Select Element',
          },
          ...list,
        ];
      }
    }
  }

  getLinkedRowsData(rows) {
    rows.forEach(item => {
      const item2 = { ...item };
      const rIndex = this.rowData.findIndex(row => row?.id?.toString() === item2?.id?.toString());
      item2.validity = item2?.from.split(/\D/).reverse().join('-');
      item2.style = item2.type ? item2.type : '1';
      item2.linkedElement = true;

      if (!item2.notes) {
        item2.notes = [];
      }

      item2.notes.forEach(note => {
        const note1 = { ...note };
        const nIndex = this.notesData.findIndex(
          item1 => note1?.id?.toString() === item1?.id?.toString(),
        );
        note1.validity = note1?.from.split(/\D/).reverse().join('-');
        note1.linkedElement = true;
        if (nIndex > -1) {
          this.notesData[nIndex] = { ...note1 };
        } else {
          this.notesData.push(note1);
        }
      });
      if (rIndex > -1) {
        this.rowData[rIndex] = { ...item2 };
      } else {
        this.rowData.push({ ...item2 });
      }
    });
  }

  addLinkedElement(type, data) {
    const data1 = { ...data };
    if (type === 'Sezioni') {
      if (!data1.subSections) {
        data1.subSections = [];
      }

      this.existingElementSubsection = [
        ...this.existingElementSubsection,
        ...data1.subSections.map(item => item.id),
      ];
      this.subSectionMappingList = [
        ...this.subSectionMappingList,
        ...data1.subSections.map(item => {
          const item2 = { ...item };
          item2.parentId = data1.id;
          return item2;
        }),
      ];
      this.subSectionMappingList = this.subSectionMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      this.existingElementSubsection = this.existingElementSubsection.filter(
        (v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i,
      );
      addElementToLocalStorage(
        this.subSectionMappingList,
        localStorageKeysMap.APPLICATION_SUBSECTION_MAPPING,
      );
      addElementToLocalStorage(
        this.existingElementSubsection,
        localStorageKeysMap.APPLICATION_EXISTING_SUBSECTION_MAPPING,
      );
    } else if (type === 'Sotto Sezioni') {
      if (!data1.rows) {
        data1.rows = [];
      }
      this.existingElementRows = [...this.existingElementRows, ...data1.rows.map(item => item.id)];
      this.rowsMappingList = [
        ...this.rowsMappingList,
        ...data1.rows.map(item => {
          const item2 = { ...item };
          item2.parentId = data1.id;
          return item2;
        }),
      ];
      this.rowsMappingList = this.rowsMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      this.existingElementRows = this.existingElementRows.filter(
        (v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i,
      );
      addElementToLocalStorage(this.rowsMappingList, localStorageKeysMap.APPLICATION_ROWS_MAPPING);
      addElementToLocalStorage(
        this.existingElementRows,
        localStorageKeysMap.APPLICATION_EXISTING_ROWS_MAPPING,
      );
    } else if (type === 'Righe') {
      if (!data1.columnNotes) {
        data1.columnNotes = [];
      }

      this.existingElementNotes = [
        ...this.existingElementNotes,
        ...data1.columnNotes.map(item => item.id),
      ];
      const notesList1 = JSON.parse(JSON.stringify(data1.columnNotes));
      this.notesMappingList = [
        ...this.notesMappingList,
        ...notesList1.map(item => {
          const item2 = { ...item };
          item2.parentId = data1.id;
          delete item2.versionDetailLevel2ID;
          delete item2.versionDetailLevel1ID;
          return item2;
        }),
      ];
      this.notesMappingList = this.notesMappingList.filter(
        (v, i, a) => a.findIndex(v2 => v2?.id?.toString() === v?.id?.toString()) === i,
      );
      this.existingElementNotes = this.existingElementNotes.filter(
        (v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i,
      );
      addElementToLocalStorage(
        this.notesMappingList,
        localStorageKeysMap.APPLICATION_NOTES_MAPPING,
      );
      addElementToLocalStorage(
        this.existingElementNotes,
        localStorageKeysMap.APPLICATION_EXISTING_NOTES_MAPPING,
      );
    }
  }

  async _addRowElements(event) {
    const { data, type } = event.detail;
    this._setTabIndex(1)();
    this.tabsData = this.tabsData.filter(td => td.name !== type);
    try {
      if (type === 'Sezioni' && data) {
        const index = this.sectionsList.findIndex(
          item => item?.id?.toString() === data?.id?.toString(),
        );
        if (index === -1) {
          // let sectionDetail = { ...data };
          // if (!sectionDetail.isVersionChanged) {
          const res = await this._getVersionItemDetail(data.id);
          const sectionDetail = transformSectionsToFrontEnd(res?.data);
          // }
          if (!sectionDetail.validity) sectionDetail.validity = new Date().toLocaleDateString();
          // sectionDetail.validity = sectionDetail?.validity.split(/\D/).reverse().join('-');
          // sectionDetail.sectionStyle = sectionDetail.sectionStyle ? sectionDetail.type : '1';
          sectionDetail.linkedElement = true;
          if (!sectionDetail.subSections) {
            sectionDetail.subSections = [];
          }
          sectionDetail.subSections = sectionDetail.subSections.map(subSection => {
            const a = { ...subSection };
            a.linkedElement = true;
            a.parentId = sectionDetail.id;
            return a;
          });
          this.sectionsList.push(sectionDetail);
          this.sectionsList = [...this.sectionsList];
          this.addLinkedElement(type, sectionDetail);
          addElementToLocalStorage(sectionDetail, localStorageKeysMap.APPLICATION_SECTIONS);
        }
      } else if (type === 'Sotto Sezioni' && data) {
        const index = this.subSectionsList.findIndex(
          item => item?.id?.toString() === data?.id?.toString(),
        );
        if (index === -1) {
          // eslint-disable-next-line
          // let subsectionDetail = { ...data };
          // If connecting remote api, use below line
          const res = await this._getVersionItemDetail(data.id, 'Righe');
          const subsectionDetail = transformSubSectionsToFrontEnd(res?.data);
          if (!subsectionDetail.validity)
            subsectionDetail.validity = new Date().toLocaleDateString();
          // subsectionDetail.validity = subsectionDetail?.validity.split(/\D/).reverse().join('-');
          // subsectionDetail.sectionStyle = subsectionDetail.type ? subsectionDetail.type : '1';
          subsectionDetail.linkedElement = true;
          if (!subsectionDetail.rows) {
            subsectionDetail.rows = [];
          }
          subsectionDetail.rows = subsectionDetail.rows.map(row => {
            const a = { ...row };
            a.linkedElement = true;
            a.parentId = subsectionDetail.id;
            return a;
          });
          this.subSectionsList.push(subsectionDetail);
          this.subSectionMappingList = this.subSectionsList.filter(item => !item.isNotSaved);
          this.addLinkedElement(type, subsectionDetail);
          addElementToLocalStorage(subsectionDetail, localStorageKeysMap.APPLICATION_SUBSECTIONS);
        }
      } else if (type === 'Righe' && data) {
        const index = this.rowData.findIndex(item => item?.id?.toString() === data?.id?.toString());
        if (index === -1) {
          // eslint-disable-next-line
          // let rowDetail = { ...data };
          // If connecting remote api, use below line
          const res = await this._getVersionItemDetail(data.id);
          const rowDetail = transformRowsToFrontEnd(res?.data);
          if (!rowDetail.validity) rowDetail.validity = new Date().toLocaleDateString();
          // rowDetail.validity = rowDetail?.validity.split(/\D/).reverse().join('-');
          // rowDetail.style = rowDetail.type;
          rowDetail.linkedElement = true;
          if (!rowDetail.columnNotes) {
            rowDetail.columnNotes = [];
          }
          rowDetail.columnNotes = rowDetail.columnNotes.map(note => {
            const a = { ...note };
            a.linkedElement = true;
            a.parentId = rowDetail.id;
            return a;
          });
          if (rowDetail?.columnNotes?.length) {
            const notesData = await this.makeElementsAjaxCall(transformNoteToFrontEnd, 'Nota');
            rowDetail.columnNotes.forEach(note => {
              mapPropertyToObjectFromList(notesData.list, note);
            });
          }
          if (rowDetail?.columns?.length > 0) {
            // eslint-disable-next-line
            rowDetail.columns = sortArray(rowDetail.columns, 'name');
          }
          this.rowData.push(rowDetail);
          this.rowsMappingList = this.rowData.filter(item => !item.isNotSaved);
          this.addLinkedElement(type, rowDetail);
          addElementToLocalStorage(rowDetail, localStorageKeysMap.APPLICATION_ROWS);
        }
      } else if (type === 'Nota' && data) {
        const index = this.notesData.findIndex(
          item => item?.id?.toString() === data?.id?.toString(),
        );
        if (index === -1) {
          // eslint-disable-next-line
          // let noteDetail = { ...data };
          // If connecting remote api, use below line
          const res = await this._getVersionItemDetail(data.id);
          const noteDetail = transformNoteToFrontEnd(res?.data);
          if (!noteDetail.validity) noteDetail.validity = new Date().toLocaleDateString();
          // noteDetail.validity = noteDetail?.validity.split(/\D/).reverse().join('-');
          noteDetail.linkedElement = true;
          this.notesData.push(noteDetail);
          this.notesMappingList = this.notesData.filter(item => !item.isNotSaved);
          this.notesData = [...this.notesData];
          addElementToLocalStorage(noteDetail, localStorageKeysMap.APPLICATION_NOTES);
        }
      } else if (type === 'Regole' && data) {
        const index = this.ruleData.findIndex(
          item => item?.id?.toString() === data?.id?.toString(),
        );
        if (index === -1) {
          // eslint-disable-next-line
          // let rule = { ...data };
          // If connecting remote api, use below line
          const res = await this._getVersionItemDetail(data.id);
          const rule = transformRulesToFrontEnd(res?.data);
          if (!rule.validity) rule.validity = new Date().toLocaleDateString();
          rule.linkedElement = true;
          this.ruleData.push(rule);
          this.ruleData = [...this.ruleData];
          addElementToLocalStorage(rule, localStorageKeysMap.APPLICATION_RULES);
        }
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  _selectedTableRow(event) {
    const { data, type } = event.detail;
    this.tabsData = this.tabsData.map(td => {
      const td1 = td;
      if (type === td.name) {
        td1.selectedRow = data;
      }
      return td1;
    });
  }

  _cancelTask(event) {
    const { type } = event.detail;
    this._setTabIndex(1)();
    this.tabsData = this.tabsData.filter(td => td.name !== type);
  }

  async _documentView(ev) {
    const { detail } = ev;
    const res = await this._getVersionItemDetail(detail);
    const data = transformDocumentsToFrontEnd(res?.data);
    this._selectedValue = data;
    this._openDocumentDetails();
    removeAllElementsFromLocalStorage();
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingData(data) {
    let data1 = data;
    data1 = data1.filter((v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i);
    let chunkData = await chunks(data1, fetchChildItems, 50);
    if (!chunkData) {
      chunkData = [];
    }
    chunkData = [
      ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
    ];
    chunkData = chunkData.filter(
      (v, i, a) =>
        a.findIndex(v2 => v2?.itemsVersionsID?.toString() === v?.itemsVersionsID?.toString()) === i,
    );
    return chunkData;
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingDataByStyle(data) {
    let data1 = data;
    data1 = data1.filter((v, i, a) => a.findIndex(v2 => v2?.toString() === v?.toString()) === i);
    let chunkData = await chunks(data1, fetchChildItemsByStyle, 50);
    if (!chunkData) {
      chunkData = [];
    }
    chunkData = [
      ...chunkData.filter(item2 => item2.status === 'fulfilled').map(item2 => item2.value),
    ];
    chunkData = chunkData.filter(
      (v, i, a) =>
        a.findIndex(v2 => v2?.itemsVersionsID?.toString() === v?.itemsVersionsID?.toString()) === i,
    );
    return chunkData;
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingSubsectionsData(data) {
    const dataBackend = transformSubSectionsIdsToBackend(data);
    const dataList = await this.ajaxInstance.post(`${baseURL}/subsections`, dataBackend);
    return dataList;
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingRowsData(data) {
    const dataBackend = transformRowsIdsToBackend(data);
    const dataList = await this.ajaxInstance.post(`${baseURL}/rows`, dataBackend);
    return dataList;
  }

  // eslint-disable-next-line class-methods-use-this
  async _getExistingNotesData(data) {
    const dataBackend = transformNotesIdsToBackend(data);
    const dataList = await this.ajaxInstance.post(`${baseURL}/notes`, dataBackend);
    return dataList;
  }

  // eslint-disable-next-line class-methods-use-this
  async getVersionsList(id) {
    const res = await this.ajaxInstance.get(`${baseURL}/${id}/versions`);
    return res.data ? deriveData(res.data) : [];
  }

  // eslint-disable-next-line
  async _getVersionItemDetail(id, type) {
    try {
      let url = `${baseURL2}/version/${id}`;
      if (this.getAPIMapper[type] === 'RIGA') {
        url = `${baseURL2}/version/${id}/select?itemTypeKeyParent=DOCUMENT_TYPE&itemTypeValueChild=STILE`;
      }
      return await this.ajaxInstance.get(url);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.log('Error', err);
    }
  }

  async getDocumentVersion(ev) {
    try {
      const rowData1 = ev.detail.rowData;
      const versionList = await this.getVersionsList(rowData1.docId);

      const rowDetail = this._displayData?.find(
        data => data?.id?.toString() === rowData1?.id?.toString(),
      );
      if (rowDetail) {
        rowDetail.versionList = [...versionList];
        // versionList.forEach(item => {
        //   if (rowDetail?.id?.toString() === item?.itemsVersionsID?.toString()) {
        //     rowDetail.versionList.unshift(item);
        //   } else {
        //     rowDetail.versionList.push(item);
        //   }
        // });

        this.sliceItems(this._selectedValue);
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  async changeDocumentVersionDetail(event) {
    try {
      const { id } = event.detail;
      const res = await this._getVersionItemDetail(id);
      const row = transformDocumentsToFrontEnd(res?.data);
      const index = this._displayData.findIndex(
        item => item?.docId?.toString() === row?.docId?.toString(),
      );
      if (index > -1) {
        row.versionList = this._displayData[index].versionList;
        row.isVersionChanged = true;
        this._displayData[index] = row;
        this.sliceItems(this._selectedValue);
      }
    } catch (err) {
      // eslint-disable-next-line
      console.log('Error', err);
    }
  }

  openDialog() {
    const dialog = this.shadowRoot.querySelector('#dialog2');
    dialog.opened = true;
  }

  _closeDialog(ev) {
    this.confirmationMessageDetail = {};
    closeDialog(ev);
  }

  _navigateToDocumentReview(tabName) {
    return () => {
      this._setTabIndex(0)();
      const ev = new CustomEvent('navigate-to', {
        detail: {
          route: tabName,
        },
      });
      this.dispatchEvent(ev);
    };
  }

  // eslint-disable-next-line class-methods-use-this
  async getLookUpDataList() {
    const url = `${baseURL3}`;
    try {
      return await this.ajaxInstance.get(url);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
      return {};
    }
  }

  // eslint-disable-next-line
  getSectionName(tabName) {
    if (tabName.toLowerCase() === 'righe') {
      return 'Riga';
      // eslint-disable-next-line
    } else if (tabName.toLowerCase() === 'sotto sezioni') {
      return 'Sotto Sezione';
      // eslint-disable-next-line
    } else if (tabName.toLowerCase() === 'sezioni') {
      return 'Sezione';
      // eslint-disable-next-line
    } else {
      return tabName;
    }
  }

  _showStatusInDialog(event) {
    const { data, status } = event.detail;
    const type = status || data.status === 200 || data.status === 201 ? 'success' : 'error';
    this.confirmationMessageDetail = {};
    this.confirmationMessageDetail.messages = messages?.save[type];
    // eslint-disable-next-line
    console.log('data data data', data);
    const dialog = this.shadowRoot.querySelector('#dialog3');
    dialog.opened = true;
  }

  render() {
    return html`
      <ing-dialog id="dialog2">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Cancella Errore</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              ?isNormalConfirmation=${true}
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
      <ing-dialog id="dialog3">
        <ing-dialog-frame slot="content" has-close-button>
          <div slot="header">Salva</div>
          <div slot="content">
            <confirmation-dialog
              .confirmationMessageDetail="${this.confirmationMessageDetail}"
              ?isNormalConfirmation=${true}
              customClasses="message-bold"
              @close-dialog-event="${this._closeDialog}"
            ></confirmation-dialog>
          </div>
        </ing-dialog-frame>
      </ing-dialog>
      <div class="grey-empty-area"></div>

      <div class="main_container">
        <div class="content_body_area">
          <ing-tabs id="navigation_tabs" .selectedIndex=${this._selectedTabIndex}>
            <ing-tab name="tab1" slot="tab" @click="${this._setTabIndex(0)}"
              >Elenco e ricerca</ing-tab
            >
            <ing-tab slot="tab" @click="${this._setTabIndex(1)}">Crea nuovo documento</ing-tab>
            ${this._selectedValue?.id &&
            this._selectedTabIndex === 0 &&
            this.data?.length &&
            this.isShowReviewTab
              ? html`<ing-tab
                  slot="tab"
                  @click="${this._navigateToDocumentReview('reviews_documents')}"
                  >Review</ing-tab
                >`
              : ''}
            <ing-tab-panel slot="panel">
              <div class="tab_content">
                <div class="search_document_content">
                  <div class="search_document_label">
                    <label class="search_document_text"
                      >Cerca documenti esistenti per modificarli o rivederli</label
                    >
                  </div>
                  <ing-form>
                    <form>
                      <ing-chip-choice-group
                        id="document_filter"
                        name="document_filter"
                        label="Filtra per"
                      >
                        ${this.filters.map(
                          filter =>
                            html`
                              <ing-chip-choice
                                @click="${() => this._setFilter(filter)}"
                                label=${filter.label}
                                .choiceValue=${filter.name}
                                class="chip_choice_filter"
                              ></ing-chip-choice>
                            `,
                        )}
                      </ing-chip-choice-group>
                      <ing-input
                        .modelValue="${'Cerca documento'}"
                        id="searchText"
                        name="searchText"
                        class="param_filter_search"
                        @click=${this._checkText}
                      ></ing-input>
                      <ing-button
                        id="searchButton"
                        class="search-button"
                        @click="${this._applyFilter}"
                        >Cerca</ing-button
                      >
                      <ing-button
                        outline
                        indigo
                        id="resetFilter"
                        class="reset-button"
                        @click="${this._resetFilter}"
                        ?disabled="${!this._filter}"
                        >Azzera filtri</ing-button
                      >
                    </form>
                  </ing-form>
                  <div class="homelist__table">
                    <ing-table
                      @selected-table-row="${this._viewDocumentDetails}"
                      @changed-version-detail="${this.changeDocumentVersionDetail}"
                      @version-detail-list="${this.getDocumentVersion}"
                    ></ing-table>
                  </div>
                  <br />
                  <div>
                    ${this.showPagination
                      ? html`<ing-pagination-links
                          page-url="${this.urlHashed}#"
                          id="pagination-event"
                          count=${this.totalPage}
                          current="${this.currentPage}"
                          @current-changed=${this._pageChanged}
                        ></ing-pagination-links>`
                      : ''}
                  </div>
                  <div class="container">
                    ${this._displayData && this._displayData.length > 0
                      ? html`<div class="center">
                          <ing-button
                            indigo
                            font14
                            class="view_button"
                            data-tag-id="viewRowBtn"
                            @click="${this._openDocumentDetails}"
                            ?disabled="${this._selectedValue === undefined}"
                            >Vedi dettaglio</ing-button
                          >
                          <ing-button
                            indigo
                            font14
                            class="review_button"
                            data-tag-id="reviewRowBtn"
                            @click="${this.__handleAppendClick}"
                            ?disabled="${this._selectedValue === undefined}"
                            >Review</ing-button
                          >
                        </div>`
                      : ''}
                  </div>
                </div>
              </div>
            </ing-tab-panel>
            <ing-tab-panel slot="panel">
              ${this._selectedTabIndex === 1
                ? html` <stepper-custom
                    @changed-step-index="${this._changedStepIndex}"
                    .stepIndex="${this._stepIndex}"
                    ?disableBackButtons="${this.disableBackButtons}"
                  >
                    <div slot="step-1">
                      <ing-button
                        indigo
                        class="create-new-button add-note"
                        @click="${() => this._generateTab('Nota')}"
                      >
                        Aggiungi</ing-button
                      >
                      <new-document-creation
                        .notesData="${this.notesData}"
                        @notes-changed="${this._noteChanged}"
                        @field-values-changed="${this._fieldValuesChangedByNote}"
                        @remove-event="${this.filterNote}"
                        @show-status-dialog="${this._showStatusInDialog}"
                      ></new-document-creation>
                    </div>
                    <div slot="step-2">
                      <ing-button
                        indigo
                        class="create-new-button add-row"
                        @click="${() => this._generateTab('Righe')}"
                      >
                        Aggiungi</ing-button
                      >
                      <row-creation
                        .rowData="${this.rowData}"
                        .notes="${this.notesMappingList}"
                        .lookupData="${this.lookupData}"
                        .ruleData="${this.ruleData}"
                        .savedChildList="${this.savedChildListRow}"
                        @rows-changed="${this._rowChanged}"
                        @field-values-changed="${this._fieldValuesChangedByRow}"
                        @row_column_changed="${this._rowColumnChanged}"
                        @remove-event="${this.filterRow}"
                        @show-status-dialog="${this._showStatusInDialog}"
                      ></row-creation>
                    </div>
                    <div slot="step-3">
                      <ing-button
                        indigo
                        class="create-new-button add-sub-section"
                        @click="${() => this._generateTab('Sotto Sezioni')}"
                      >
                        Aggiungi</ing-button
                      >
                      <create-sub-section
                        currentStep="subsection"
                        .rows="${this.rowsMappingList}"
                        .subSectionsData="${this.subSectionsList}"
                        .lookupData="${this.lookupData}"
                        .savedChildList="${this.savedChildListSubSection}"
                        @event-section-added="${this._addSubSection}"
                        @event-section-removed="${this._removedSubSection}"
                        @field-values-changed="${this._fieldValuesChangedBySubSection}"
                        @show-status-dialog="${this._showStatusInDialog}"
                      ></create-sub-section>
                    </div>
                    <div slot="step-4">
                      <ing-button
                        indigo
                        class="create-new-button add-section"
                        @click="${() => this._generateTab('Sezioni')}"
                      >
                        Aggiungi</ing-button
                      >
                      <create-sub-section
                        currentStep="section"
                        .subSectionsData="${this.sectionsList}"
                        .subSectionsList="${this.subSectionMappingList}"
                        .lookupData="${this.lookupData}"
                        .savedChildList="${this.savedChildList}"
                        @event-section-added="${this._addSection}"
                        @event-section-removed="${this._removedSection}"
                        @field-values-changed="${this._fieldValuesChangedBySection}"
                        @show-status-dialog="${this._showStatusInDialog}"
                      ></create-sub-section>
                    </div>
                    <div slot="step-5">
                      <rule-creation
                        .rowData="${this.ruleData}"
                        .sectionsList="${this.sectionsList}"
                        .subSectionsList="${this.subSectionMappingList}"
                        .rows="${this.rowsMappingList}"
                        .notes="${this.notesMappingList}"
                        .appliesToElements="${this.appliesToElements}"
                        .lookupData="${this.lookupData}"
                        .savedChildList="${this.savedChildListRule}"
                        @rows-changed="${this._ruleChanged}"
                        @field-values-changed="${this._fieldValuesChangedByRule}"
                        @row_column_changed="${this._ruleColumnChanged}"
                        @remove-event="${this.filterRule}"
                        @show-status-dialog="${this._showStatusInDialog}"
                      ></rule-creation>
                    </div>
                    <div slot="step-6">
                      ${!this.showSuccessStep
                        ? html`<create-document
                            .documentData="${this.documentData}"
                            .sectionsList="${this.sectionsList.filter(item => !item.isNotSaved)}"
                            .rulesData="${this.ruleData.filter(item => !item.isNotSaved)}"
                            .lookupData="${this.lookupData}"
                            @added-document="${this._addDocument}"
                            @cancel-document="${this._removeDocument}"
                          ></create-document>`
                        : html`<document-created-successfully
                            .documentData="${this.documentData}"
                            @cancel-document="${this._cancelDocument}"
                            @document-view="${this._documentView}"
                          >
                          </document-created-successfully>`}
                    </div>
                  </stepper-custom>`
                : ''}
            </ing-tab-panel>
            ${this._selectedValue?.id &&
            this._selectedTabIndex === 0 &&
            this.data?.length &&
            this.isShowReviewTab
              ? html`<ing-tab-panel slot="panel"> </ing-tab-panel>`
              : ''}
            ${this.tabsData?.map(data =>
              this.getTabTemplate(
                data.name,
                `Aggiungi ${this.getSectionName(data.name)}`,
                html`<element-from-scratch
                  sectionName=${data.name}
                  .headerData=${data.headerData}
                  .tableContentData=${data.list}
                  total=${data.total}
                  .selectedRow=${data.selectedRow}
                  propertyId=${data.propertyId}
                  type="document-creation"
                  @add-row-elements="${this._addRowElements}"
                  @selected-table-row="${this._selectedTableRow}"
                  @cancel-action="${this._cancelTask}"
                  @pagination-search-request="${this._getTabPaginatedSearchedData}"
                ></element-from-scratch>`,
                true,
              ),
            )}
          </ing-tabs>
        </div>
      </div>
    `;
  }
}
customElements.define('document-home-page', DocumentListHomePage);
