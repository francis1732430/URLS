import {
  css,
  orange,
  black15,
  green,
  black6,
  indigo,
  font14Mixin,
  font16BoldMixin,
  font14BoldMixin,
  black80,
  font12BoldMixin,
  white,
} from 'ing-web';

export default css`
  .main_container {
    background: ${black6};
  }

  .content_body_area {
    margin: 0 auto;
    width: 1232px;
  }

  .dcouemnt-review-tr td {
    min-width: 200px;
  }
  .document-review-status {
    color: ${orange};
  }
  [reviewtextarea],
  [reviewertextarea],
  [name='reviewer'] {
    width: 80%;
  }
  [reviewertextarea],
  .review-switch-label {
    margin: 35px 0;
    color: ${black80};
    ${font16BoldMixin()}
  }
  [review-switch] {
    width: 20%;
    min-width: 0;
    display: inline-flex;
  }
  .positive-text {
    color: ${green};
    font-weight: bold;
    margin-left: 15px;
    ${font16BoldMixin()}
  }
  .review-seperator {
    width: 80%;
    background-color: ${black15};
    height: 2px;
    margin: 35px 0;
  }
  .review-tab-content {
    width: 90%;
  }
  .dcouemnt-review-table {
    margin-top: 20px;
  }
  [ing-generic-table],
  .document-review-history-btns {
    margin-top: 42px;
    display: block;
  }
  [ing-generic-table] td {
    color: ${orange};
  }
  .document-review-history-btns {
    text-align: center;
  }
  .document-review-history-btns [indigo] {
    background-color: ${indigo};
    margin: 0 35px;
  }
  .document-review-history-btns [transparent] {
    background-color: transparent;
    margin: 0 35px;
    color: ${indigo};
    border: 1px solid ${indigo};
  }
  [thumbsdown-indigo] {
    fill: ${indigo};
  }
  [inputLabel] label {
    color: ${black80};
    ${font14Mixin()}
    margin-bottom: 8px !important;
    display: block;
  }
  .file-upload-title {
    color: ${black80};
    ${font14Mixin()}
  }
  [review-switch] label {
    ${font16BoldMixin()}
  }
  [ing-generic-table] {
    margin-top: 75px;
    margin-bottom: 72px;
  }
  .ing_standard_bottom_line {
    border-bottom: 1px solid ${orange};
  }
  .btn {
    ${font14BoldMixin()}
    width: 181px;
    height: 33px;
  }
  .save-button [indigo] {
    margin-left: calc(100% - 400px);
    width: 180px;
    height: 25px;
    margin-top: 20px;
    ${font12BoldMixin()}
  }
  [review-child-tabs] {
    background-color: ${white};
    width: 1200px;
  }
`;
