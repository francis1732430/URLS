export { IngFeatTransparencyTool } from './src/IngFeatTransparencyTool.js';
