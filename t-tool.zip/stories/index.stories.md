# IngFeatTransparencyTool

A component for...

## Features

- a
- b
- ...

## How to use

### Installation

```bash
yarn add ing-feat-ita-document-template-administration
```

```js
import { html, LitElement, ScopedElementsMixin } from 'ing-web';
```

```js script
import { html, withWebComponentsKnobs, withKnobs } from '@open-wc/demoing-storybook';

import '../src/IngFeatTransparencyTool.js';
import '../src/DocumentListHomePage.js';
import '../src/DocumentDetailsPage.js';
import '../src/DocumentModification.js';
import '../src/DocumentListReviewPage.js';
import '../src/components/tables/DocumentRowsDetailsTable.js';
import '../src/components/fileUpload/fileUpload.js';
import * as data from '../__element-definitions/data.js';

export default {
  title: 'IngFeatTransparencyTool',
  component: 'ing-feat-ita-document-template-administration',
  decorators: [withKnobs, withWebComponentsKnobs],
  options: { selectedPanel: "storybookjs/knobs/panel" },
};
```


## Variations

### Custom Title

```js preview-story
export const Default = () => html` <ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration> `;

export const DocumentListHomePage = () => html`
  <document-home-page title="Hello World" .data=${data.documents}></document-home-page>
`;
```

```js preview-story
export const DocumentDetailsPage = () => html`
  <document-details-page .versionList=${data.versionList} .documentData=${data.documentData} .section=${data.section}></document-details-page>
`;
```

```js preview-story
export const DocumentModification = () => html`
  <document-modification .selectedValue=${data.documentData}></document-modification>
`;
```
```js preview-story
export const DocumentReview = () => html`
  <document-list-review-page .reviewData=${data.reviewData} .requestReview=${data.requestReview} .reviews=${data.reviews}></document-list-review-page>
`;
```
```js preview-story
export const DocumentDetailsTable = () => html`
  <document-rows-details-table .headerData=${data.headerData} .tableData=${data.tableData} propertyId=${data.propertyId}></document-rows-details-table>
`;
```

```js preview-story
export const FileUpload = () => html`
  <file-upload></file-upload>
`;
```