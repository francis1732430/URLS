import { expect, fixture, html } from '@open-wc/testing';
import '../__element-definitions/ing-feat-ita-document-template-administration.js';

describe('IngFeatTransparencyTool', () => {
  it('has a default title "Hi! Here is a counter:" and counter property with value 5', async () => {
    const el = await fixture(
      html`<ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration>`,
    );

    expect(el.title).to.equal('Hi! Here is a counter:');
    expect(el.counter).to.equal(5);
  });

  it('shows initially the text "Hi! Here is a counter: 5" and an "increment" button', async () => {
    const el = await fixture(
      html`<ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration>`,
    );

    expect(el).shadowDom.to.equal(
      `
        <p>Hi! Here is a counter: 5</p>
        <ing-button>Increment</ing-button>
      `,
      {
        ignoreAttributes: [
          'font14',
          'tabindex',
          'indigo',
          'role',
          'type',
          'aria-disabled',
          'data-tag-name',
        ],
        ignoreChildren: ['ing-button'],
      },
    );
  });

  it('increases the counter on button click', async () => {
    const el = await fixture(
      html`<ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration>`,
    );
    el.shadowRoot.querySelector(el.constructor.getScopedTagName('ing-button')).click();

    expect(el.counter).to.equal(6);
  });

  it('can override the title via attribute', async () => {
    const el = await fixture(html`
      <ing-feat-ita-document-template-administration
        title="attribute title"
      ></ing-feat-ita-document-template-administration>
    `);

    expect(el.title).to.equal('attribute title');
  });

  it('is accessible', async () => {
    const el = await fixture(
      html`<ing-feat-ita-document-template-administration></ing-feat-ita-document-template-administration>`,
    );
    await expect(el).to.be.accessible();
  });
});
