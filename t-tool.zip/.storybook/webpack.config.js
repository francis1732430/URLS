const path = require('path');

module.exports = {
  performance: {
    hints: false,
    maxAssetSize: 10000,
  },
  entry: path.resolve(__dirname, 'index.html'),
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, '../demo-storybook'),
  },
  optimization: {
    splitChunks: {
      chunks: 'all',
    },
  },
};
